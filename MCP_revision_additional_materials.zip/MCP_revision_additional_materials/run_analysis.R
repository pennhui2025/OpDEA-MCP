# RStudio: setwd("the extracted MCP_revision folder")
# source("run_analysis.R"); run_analysis("task3")
# Command line: Rscript run_analysis.R task3
# All generated files go to reproduced/; reference/ is never overwritten.
run_analysis <- function(task, root=getwd(), make_plots=FALSE) {
  # Keep a deliberately short Windows extraction/junction path; normalizePath()
  # resolves junctions back to a long physical path and can break base-R file IO.
  root <- gsub("\\\\","/",root)
  stopifnot(file.exists(file.path(root,"run_analysis.R")))
  old <- getwd(); on.exit(setwd(old)); setwd(root)
  normalizePath <- function(path,winslash="/",mustWork=NA) {
    if(.Platform$OS.type!="windows") return(base::normalizePath(path,winslash,mustWork))
    p <- gsub("\\\\","/",path.expand(path))
    p <- ifelse(grepl("^[A-Za-z]:/|^//",p),p,paste0(getwd(),"/",p))
    if(isTRUE(mustWork) && any(!file.exists(paste0("\\\\?\\",gsub("/","\\\\",p)))))
      stop("Missing package input: ",paste(p,collapse="; "))
    if(winslash=="\\")gsub("/","\\\\",p) else p
  }
  out <- file.path("reproduced",task)
  dir.create(out,recursive=TRUE,showWarnings=FALSE)
  ref <- "reference/Response"
  load_code <- function(x) sys.source(file.path("code/analysis",x),envir=parent.frame())
  if(task=="task1") {
    load_code("r1c6/MCP_r1c6_baseline_reanalysis.R")
    ans <- run_r1c6_baselines(out=out,make_plots=make_plots)
  } else if(task=="task2") {
    load_code("r2c1/MCP_r2c1_ranking_threshold_manual.R")
    r2c1_selftest(); ans <- run_r2c1(out=out)
  } else if(task=="task3") {
    load_code("r1c5/r1c5_task3_dp_fdr_reanalysis.R")
    ans <- run_r1c5(out=out,make_plots=make_plots)
  } else if(task=="fixed_views") {
    load_code("r1c6/recompute_fixedview_evidence.R")
    ans <- recompute_fixedview_evidence(output_dir=out)
    if(make_plots)plot_fixedview_evidence(ans,out)
  } else if(task=="mcp_mut") {
    load_code("r1c5/MCP_r1c5_MCPmut_manual.R")
    ans <- run_mcp_mut(out=out)
  } else if(task=="opdea") {
    load_code("r1c3/updated_20261002/MCP_r1c3_original_OpDEA_manual.R")
    ans <- run_original_opdea(out=out)
  } else if(task=="fc_sensitivity") {
    load_code("r4c2/r4c2_fold_change_sensitivity.R")
    ans <- run_r4c2(out=out)
  } else if(task=="fc_fdr_grid") {
    load_code("r4mc1/r4mc1_threshold_overlap_manual.R")
    ans <- run_r4mc1(out=out)
  } else if(task=="native_rots") {
    load_code("r4mc2/r4mc2_native_ROTS_manual.R")
    ans <- run_r4mc2(out=out)
  } else if(task=="sam_reference") {
    load_code("r4mc3/r4mc3_SAM_reference_manual.R")
    ans <- run_r4mc3(out=out)
  } else if(task=="sam_initialization") {
    load_code("r4mc3/r4mc3_SAM_allviews_initialization_manual.R")
    ans <- run_sam_initialization_allviews(out=out,
      metrics_script="code/analysis/r4mc3/r4mc3_SAM_reference_manual.R")
  } else if(task=="unique_dep") {
    load_code("r4mc5/r4mc5_unique_DEP_manual.R")
    ans <- run_r4mc5(out=out)
  } else if(task=="correlations") {
    load_code("r4minor8/r4minor8_correlations_manual.R")
    ans <- run_correlations(file.path(ref,"r4minor8"),write_files=FALSE)
    write.csv(ans,file.path(out,"correlations_by_dataset_pair_R.csv"),row.names=FALSE)
  } else if(task=="two_three_views") {
    load_code("r4minor14/r4minor14_two_three_view_manual.R")
    ans <- check_two_three_views(file.path(ref,"r4minor14"),write_files=FALSE)
    write.csv(ans$summary,file.path(out,"two_three_view_dep_overlap_summary.csv"),row.names=FALSE)
    write.csv(ans$calls,file.path(out,"two_three_view_dep_presence.csv"),row.names=FALSE)
  } else if(task=="survival") {
    # This historical script executes at source time. Its output path is explicitly
    # relocated in the packaged copy; no original source table is changed.
    load_code("r2c5/R2C5_DEA_survival_manual.R")
    ans <- invisible(NULL)
  } else stop("Unknown task: ",task,". See docs/EXPERIMENT_MAP.md")
  writeLines(capture.output(sessionInfo()),file.path(out,"R_sessionInfo.txt"))
  message("Finished ",task,": ",normalizePath(out,winslash="/"))
  invisible(ans)
}

if(sys.nframe()==0L) {
  args <- commandArgs(trailingOnly=TRUE)
  if(!length(args)) stop("Specify a task, e.g. Rscript run_analysis.R task1")
  script <- sub("^--file=","",grep("^--file=",commandArgs(),value=TRUE)[1])
  root <- Sys.getenv("MCP_REPRO_ROOT",unset="")
  if(!nzchar(root)) root <- if(dirname(script)==".")getwd() else dirname(script)
  run_analysis(args[1],root=root,make_plots="--plots" %in% args)
}
