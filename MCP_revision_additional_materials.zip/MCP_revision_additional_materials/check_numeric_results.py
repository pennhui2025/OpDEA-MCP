"""Compare independently rerun tables to frozen references, never to themselves."""
from pathlib import Path
import csv,json
import pandas as pd
import numpy as np
ROOT=Path(__file__).resolve().parent
specs=[
('task1','per_stratum.csv','r1c6/analysis/per_stratum.csv',['dataset','platform','dea','method']),
('task1','platform_primary_median_14strata.csv','r1c6/analysis/platform_primary_median_14strata.csv',['platform','method']),
('task2','per_run.csv','r2c1/data/per_run.csv',['dataset','platform','dea','method']),
('task3','task3_condition_metrics.csv','r1c5/data_work/task3_condition_metrics.csv',['dataset','platform','dea','group']),
('task3','task3_plus_original_summary.csv','r1c5/data_work/task3_plus_original_summary.csv',['platform','group']),
('fixed_views','fixed4_raw_config_metrics_common_union.csv','r1c6/fixedview_work/fixed4_raw_config_metrics_common_union.csv',['comparison_id','method']),
('fixed_views','fixed3_vs_fixed4_raw_config_metrics_common_union.csv','r1c6/fixedview_work/fixed3_vs_fixed4_raw_config_metrics_common_union.csv',['comparison_id','method']),
('mcp_mut','MCPmut_setting_medians.csv','r1c5/mcp_mut_data/MCPmut_setting_medians.csv',['platform','views','method']),
('opdea','original_opdea_strata.csv','r1c6/original_opdea_analysis/original_opdea_strata.csv',['dataset','platform','method']),
('fc_sensitivity','per_run.csv','r4c2/data/per_run.csv',['dataset','platform','dea','method','fc_ratio']),
('fc_fdr_grid','per_run.csv','r4mc1/data/per_run.csv',['dataset','platform','dea','method','fc_ratio','statistical_FDR_cutoff']),
('native_rots','per_run.csv','r4mc2/data/per_run.csv',['dataset','platform','method','fc_ratio']),
('sam_reference','per_run.csv','r4mc3/data/per_run.csv',['dataset','platform','method','fc_ratio']),
('sam_initialization','initialization_per_run.csv','r4mc3/data/initialization_per_run.csv',['dataset','platform','views','method','fc_ratio']),
('unique_dep','quality_by_stratum.csv','r4mc5/data/quality_by_stratum.csv',['dataset','platform','initialization','group','metric']),
('correlations','correlations_by_dataset_pair_R.csv','r4minor8/data/correlations_by_dataset_pair.csv',['dataset','platform','pair']),
('two_three_views','two_three_view_dep_overlap_summary.csv','r4minor14/data/two_three_view_dep_overlap_summary.csv',['cohort']),
('survival','survival_by_candidate_set.csv','r2c5/analysis/survival_by_candidate_set.csv',['candidate_set','Protein','SYMBOL']),
]
answers=[]
for task,out,ref,keys in specs:
    row={'task':task,'output':'reproduced/'+task+'/'+out,'reference':'reference/Response/'+ref,'status':'FAIL'}
    try:
        a=pd.read_csv(ROOT/row['output']);b=pd.read_csv(ROOT/row['reference'])
        if task=='task2':
            b=b.rename(columns={'tn':'TN','fp':'FP','fn':'FN','tp':'TP','mcc':'MCC','f1':'F1','auroc':'AUROC','pauc001':'pAUC_0.01','pauc005':'pAUC_0.05','pauc01':'pAUC_0.1'})
        keys=[k for k in keys if k in a and k in b]
        if a.duplicated(keys).any() or b.duplicated(keys).any():raise ValueError('Comparison key not unique: '+str(keys))
        a=a.set_index(keys).sort_index();b=b.set_index(keys).sort_index()
        if not a.index.equals(b.index):raise ValueError('Missing/different row keys')
        nums=[c for c in a.columns.intersection(b.columns) if pd.api.types.is_numeric_dtype(a[c]) and pd.api.types.is_numeric_dtype(b[c])]
        if not nums:raise ValueError('No numeric columns compared')
        x=a[nums].to_numpy(float);y=b[nums].to_numpy(float)
        same=np.isclose(x,y,rtol=0,atol=1e-8,equal_nan=True)
        finite=np.isfinite(x)&np.isfinite(y)
        row.update(n_rows=len(a),n_numeric_columns=len(nums),numeric_columns=nums,n_numeric_cells=int(x.size),max_absolute_difference=float(np.max(np.abs(x[finite]-y[finite]))) if finite.any() else 0,status='PASS' if same.all() else 'FAIL',mismatched_cells=int((~same).sum()),keys=';'.join(keys))
    except Exception as e:row['error']=str(e)
    answers.append(row);print(json.dumps(row),flush=True)
(ROOT/'validation').mkdir(exist_ok=True)
(ROOT/'validation/numeric_comparison.json').write_text(json.dumps(answers,indent=2),encoding='utf-8')
if any(r['status']!='PASS' for r in answers):raise SystemExit('Some tables did not match; see validation/numeric_comparison.json')
