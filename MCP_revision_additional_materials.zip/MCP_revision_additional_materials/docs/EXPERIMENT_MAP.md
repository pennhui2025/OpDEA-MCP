# Analysis and result map

All paths are relative to the package root. `run_analysis.R` accepts the names in
the first column. These are analysis commands, not instructions to retrain the
model. The source manifests specify the exact records used for each comparison.

| Analysis / training stage | Purpose | Frozen results | Inputs beyond this lightweight package |
|---|---|---|---|
| `task1` | MCP, single-view MCP, neural/ridge fusion, statistical aggregation | `reference/Response/r1c6/analysis/` | Task 1/2 predictions, native DEA outputs and ridge predictions |
| `task2` | Ranking before/after adjustment and calling rules | `reference/Response/r2c1/data/` | Full-MCP Task 1/2 protein predictions |
| View-combination shards | All pairs and triples | `results/additional/` | Downloaded DIA views and metadata |
| `task3` | Alternative reference, single-view/hurdle-only, union/intersection and noisy labels | `reference/Response/r1c5/data_work/` | Task 3 and original-control predictions |
| `mcp_mut` | Full cross-view label concordance | `reference/Response/r1c5/mcp_mut_data/` | Historical MCP_mut/native-universe metric files |
| `fixed_views` | Fixed-supervision single/four/three-view input controls | `reference/Response/r1c6/fixedview_work/` | Fixed4 and fixed3 predictions and merged ledgers |
| Remaining-task shards | Task 4 view complementarity and Task 5 component ablations, alongside Task 3 | `results/additional/` | Task 1/2 and combination merges, DIA views |
| `opdea` | Original OpDEA rank-1 and matched-four-view ensembles | `reference/Response/r1c6/original_opdea_analysis/` | Original OpDEA ensemble files and original workflow-ranking workbook |
| `fc_sensitivity` | Final FC filters: none, 1.2-fold, 1.5-fold | `reference/Response/r4c2/data/` | 28 full-MCP revision predictions |
| `fc_fdr_grid` | FC/FDR grid and DEP overlap | `reference/Response/r4mc1/data/` | 71 original full-view benchmark records and original common-union audit |
| `native_rots` | Standard native ROTS FDR, without an additional BH step | `reference/Response/r4mc2/data/` | Original native ROTS outputs |
| `sam_reference` | Standalone single-view SAM before pseudo-label assignment | `reference/Response/r4mc3/data/per_run.csv` | Historical SAM single-view DEA outputs and MCP comparators |
| `sam_initialization` | SAM replaces the initialization DEA within MCP | `reference/Response/r4mc3/data/initialization_*.csv` | Historical SAM/limma/ROTS runs on matched available combinations |
| `unique_dep` | Abundance, variance, missingness, FC and statistical evidence | `reference/Response/r4mc5/data/` | Saved raw/normed matrices and MCP/limma/ROTS/SAM outputs |
| `correlations` | Paired Pearson/Spearman correlations and coverage | `reference/Response/r4minor8/data/` | View matrices identified by the correlation manifest |
| `two_three_views` | Clinical two/three-view DEP overlap | `reference/Response/r4minor14/data/` | Saved TPD/CRC two- and three-view outputs |
| `survival` | Frozen candidates, standard DEA rankings, Cox/log-rank and BH | `reference/Response/r2c5/analysis/` | CPTAC abundance and clinical data, frozen candidate sets |
| Multi-seed shards | Full-MCP algorithmic seed stability | `reference/diagnostics/multiseed/` | Views for training; none for saved-metric reaggregation |
| LOODO | Empirical held-out-dataset view selection | `reference/diagnostics/loodo/` | Combination results for rescoring; none for saved-metric reaggregation |
| Archived TPD code | Diagnosis and exploratory feature-fusion controls | `reference/Response/r1c9/` | Clinical views, labels, panel lists and the recorded clinical environment |
| Supporting figure scripts | Corrected ASW and Fig. 4b/4f/5d | `supporting/` source code; supplementary workbooks for reported values | Original clustering/survival inputs and path configuration |

Current table numbering/captions are preserved in `results/workbooks/`.
The original OpDEA ranking workbook called `Supplementary Data 7.xlsx` in old
paths is not the current CRC supplementary workbook with the same number.
Filenames alone therefore do not establish that the correct source was supplied.

For analyses outside the freshly generated DIA revision tree,
`external_reanalysis_files.csv` inventories the excluded historical inputs.
It is a file-location catalogue, not evidence that every listed file is hosted
in the Zenodo view-data record. Download or obtain the indicated original results
separately and verify their provenance before running those analyses.

The original Task 4/5, multi-seed and LOODO metrics remain available for
traceability. Do not silently substitute them for the later median/standardized
pAUC evidence. The historical MCP_mut summaries also retain their native protein
universes; they are not newly common-union-rescored predictions.

