"""Check the downloaded DIA files listed in required_training_files.csv."""
from pathlib import Path
import argparse
import csv
import hashlib

root = Path(__file__).resolve().parent

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--hash', action='store_true', help='also compare original file hashes')
    args = parser.parse_args()
    with (root / 'required_training_files.csv').open(encoding='utf-8-sig') as f:
        rows = list(csv.DictReader(f))
    missing, different = [], []
    for row in rows:
        path = root / row['path']
        if not path.is_file():
            missing.append(row['path'])
        elif args.hash:
            digest = hashlib.sha256()
            with path.open('rb') as f:
                for block in iter(lambda: f.read(1024 * 1024), b''):
                    digest.update(block)
            if digest.hexdigest() != row['sha256']:
                different.append(row['path'])
    print('Expected:', len(rows), 'Present:', len(rows) - len(missing))
    for name in missing:
        print('MISSING:', name)
    for name in different:
        print('HASH DIFFERS:', name)
    if missing or different:
        raise SystemExit('Check the download and file placement. See TUTORIAL.md, section 3.')
    print('Input check passed. No training was started.')

if __name__ == '__main__':
    main()

