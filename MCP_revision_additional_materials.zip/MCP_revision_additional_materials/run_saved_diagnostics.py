"""Recompute historical multi-seed/LOODO summaries from saved run-level metrics.

These legacy diagnostics retain their original metric and mean-aggregation rules.
This is NOT neural-model training or protein-level rescoring. For the final
median/DP_fdr/pAUC evidence, use run_analysis.R instead.
"""
from pathlib import Path
import argparse, subprocess, sys, json
ROOT=Path(__file__).resolve().parent
TRAIN=ROOT/'code/training'

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('task',choices=['multiseed','loodo'])
    a=p.parse_args()
    out=ROOT/'reproduced'/a.task
    out.mkdir(parents=True,exist_ok=True)
    if a.task=='multiseed':
        subprocess.run([sys.executable,str(TRAIN/'MCP_r1_multiseed_stability_analysis.py'),
                        '--shards-root',str(ROOT/'inputs/diagnostics/multiseed'),
                        '--output-dir',str(out)],check=True,cwd=ROOT)
    else:
        import pandas as pd
        sys.path.insert(0,str(TRAIN))
        from MCP_r1_leave_one_dataset_out_view_selection import validate_design,run_loodo,paired_summary
        long=pd.read_csv(ROOT/'inputs/diagnostics/loodo_stratum_metrics.csv')
        audit=validate_design(long)
        dataset=long.groupby(['metric','dataset','view_set'],as_index=False).agg(value=('value','mean'),n_platform_dea_strata=('value','count'))
        heldout=run_loodo(dataset)
        frequency=heldout.groupby(['metric','selected_view_set','selected_view_count'],as_index=False).agg(n_selected_folds=('held_out_dataset','count'))
        for name,table in [('all_stratum_metrics_used',long),('dataset_level_view_metrics',dataset),('input_design_audit',audit),('loodo_selection_per_dataset',heldout),('loodo_paired_comparisons',paired_summary(heldout)),('loodo_selected_view_frequency',frequency)]:
            table.to_csv(out/(name+'.csv'),index=False)
        (out/'analysis_summary.json').write_text(json.dumps({'scope':'Recomputed from saved stratum-level metrics, not prediction files','n_datasets':7,'n_view_sets':15,'selector':'empirical LOODO, not the feature-based Fig.3 recommender'},indent=2),encoding='utf-8')
        print('Completed saved-metric LOODO analysis:',out)
if __name__=='__main__':main()
