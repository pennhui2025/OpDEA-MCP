# Environment

## Result analysis

Most numerical analyses use base R. Plotting needs `ggplot2`; survival analysis
needs `survival`; some figure scripts also use `survminer`, `patchwork`, `cowplot`,
`ggpubr`, `readxl` or `openxlsx`. Inspect the imports in the selected figure script
before running it. No package is installed automatically.

Python saved-metric diagnostics and numerical comparisons use NumPy, pandas and
SciPy. R syntax checks for this release use R 4.5.2 on Windows. Exact check results
are recorded under `validation/`; this is not the original training environment.

## Neural experiments

`requirements-training-unpinned.txt` preserves the supplied Python package list.
It is not a lock file. Use Python 3.10 or later for the wrappers' annotations,
with a compatible PyTorch/CUDA build for your GPU. Dependency resolution for a
new installation must be tested; this release does not invent historical version
pins. The original Linux training environment was not fully archived.

R helpers require MSnbase, GMSimpute, SeqKnn, rrcovNA, NormalyzerDE, limma, ROTS,
dplyr and seqinr. The SAM routes additionally require `samr`. Some packages are
loaded by the historical helpers even when the configured normalization or
imputation option is blank. Use `check_training_environment.R` as an initial
check, not a substitute for a complete trial run.

Before training, record the environment, for example:

```bash
python check_environment.py
python -m pip freeze > resolved_python_packages.txt
Rscript -e 'sessionInfo()' > resolved_R_session.txt
```

Run these commands from this `environment` directory. Record CUDA/cuDNN, device,
BLAS/thread settings and operating system as well. Keep the original seeds and
manifest parameters unchanged when checking reproducibility.

## Clinical diagnosis

The archived TPD evidence was produced with the paper-environment Python 3.11.5
Windows Anaconda setup. It is separate from the DIA neural-training environment
and the earlier environment labelled `directlfq`. Version records are retained
with the R1C9 results. Do not interpret that distribution inventory as a portable
cross-platform pip lock.

Software versions, stochastic optimization, thread scheduling and GPU kernels
can change fitted models. Report rerun differences rather than overwriting the
submitted reference results or claiming bitwise equivalence.

