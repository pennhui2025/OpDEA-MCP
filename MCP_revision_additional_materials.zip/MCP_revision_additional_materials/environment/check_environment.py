"""Report, do not install, the selected Python environment."""
import sys,platform,json,os,importlib.metadata as md
from pathlib import Path
names=['numpy','pandas','scipy','scikit-learn','statsmodels','matplotlib','seaborn','optuna','torch','openpyxl','threadpoolctl']
data={'python':sys.version,'executable':sys.executable,'platform':platform.platform(),'packages':{},'thread_environment':{k:os.environ.get(k) for k in ['PYTHONHASHSEED','OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS']}}
for name in names:
    try:data['packages'][name]=md.version(name)
    except md.PackageNotFoundError:data['packages'][name]='NOT_INSTALLED'
try:
    import torch
    data['cuda']={'available':torch.cuda.is_available(),'torch_cuda':torch.version.cuda,'cudnn':torch.backends.cudnn.version(),'device_names':[torch.cuda.get_device_name(i) for i in range(torch.cuda.device_count())]}
except Exception as e:data['torch_import_error']=str(e)
print(json.dumps(data,indent=2))
out=Path(__file__).resolve().parent.parent/'reproduced/environment';out.mkdir(parents=True,exist_ok=True)
(out/'python_environment.json').write_text(json.dumps(data,indent=2),encoding='utf-8')
if any(v=='NOT_INSTALLED' for v in data['packages'].values()):raise SystemExit('Some training packages are missing. No packages were installed.')
