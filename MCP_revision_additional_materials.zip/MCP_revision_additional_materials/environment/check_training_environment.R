# Check only. Some historical R packages are loaded even with blank normalization.
packages <- c("MSnbase","GMSimpute","SeqKnn","rrcovNA","NormalyzerDE",
              "limma","ROTS","dplyr","seqinr")
x <- data.frame(package=packages,
  available=vapply(packages,requireNamespace,logical(1),quietly=TRUE))
print(x,row.names=FALSE)
print(sessionInfo())
if(!all(x$available))stop("Missing R training dependencies; see environment/README.md. No automatic installation.")
