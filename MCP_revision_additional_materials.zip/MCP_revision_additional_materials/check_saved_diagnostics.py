"""Compare rerun legacy diagnostics to frozen run-level reference summaries."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent
specs=[
 ('multiseed','dataset_seed_performance.csv',['variant','metric','dataset','seed']),
 ('multiseed','seed_stability_by_dataset.csv',['variant','metric','dataset']),
 ('multiseed','seed_stability_summary.csv',['variant','metric']),
 ('loodo','dataset_level_view_metrics.csv',['metric','dataset','view_set']),
 ('loodo','loodo_selection_per_dataset.csv',['metric','held_out_dataset']),
 ('loodo','loodo_paired_comparisons.csv',['metric','method_a','method_b']),
 ('loodo','loodo_selected_view_frequency.csv',['metric','selected_view_set','selected_view_count']),
 ('loodo','input_design_audit.csv',['metric','dataset','view_set']),
]
report=[]
for task,name,keys in specs:
    row={'task':task,'file':name,'status':'FAIL'}
    try:
        a=pd.read_csv(ROOT/'reproduced'/task/name)
        b=pd.read_csv(ROOT/'reference/diagnostics'/task/name)
        if a.duplicated(keys).any() or b.duplicated(keys).any():raise ValueError('Non-unique comparison keys')
        a=a.set_index(keys).sort_index();b=b.set_index(keys).sort_index()
        if not a.index.equals(b.index):raise ValueError('Different row keys')
        if set(a.columns)!=set(b.columns):raise ValueError('Different columns')
        nums=[c for c in a.columns if pd.api.types.is_numeric_dtype(a[c]) and pd.api.types.is_numeric_dtype(b[c])]
        other=[c for c in a if c not in nums]
        x=a[nums].to_numpy(float);y=b[nums].to_numpy(float)
        same=np.isclose(x,y,rtol=0,atol=1e-8,equal_nan=True).all()
        same_text=a[other].fillna('<NA>').astype(str).equals(b[other].fillna('<NA>').astype(str))
        finite=np.isfinite(x)&np.isfinite(y)
        row.update(status='PASS' if same and same_text else 'FAIL',n_rows=len(a),n_numeric_cells=x.size,n_text_columns=len(other),numeric_columns=nums,max_absolute_difference=float(np.max(np.abs(x[finite]-y[finite]))) if finite.any() else 0)
    except Exception as e:row['error']=str(e)
    report.append(row);print(json.dumps(row),flush=True)
(ROOT/'validation').mkdir(exist_ok=True)
(ROOT/'validation/saved_diagnostics_comparison.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
if any(r['status']!='PASS' for r in report):raise SystemExit('Diagnostic comparison failed')
