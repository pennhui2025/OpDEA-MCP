# Release checks (16 October 2026)

This lightweight release was assembled from the previously prepared revision
package. The reference numbers were not updated or selected again during
packaging.

Checks performed on this release:

- 98 Python files passed syntax parsing.
- 47 R files passed syntax parsing; the R2C1 metric self-test also completed.
- All 106 retained Python/R training source files were byte-identical to the
  previous package. Model code, seeds, tuning budgets and metric formulas were
  not changed for this release.
- Nine supplementary Excel files passed ZIP/XML-container integrity checks.
  This is a file-structure check, not a new visual audit of every worksheet.
- Saved multiseed and LOODO reaggregation completed. All eight comparison tables
  passed against frozen references at absolute tolerance `1e-8`; the maximum
  observed difference was `3.33e-16`.
- The download checklist contains 84 required files: 28 bundled design/candidate
  tables and 56 external intensity matrices. No DIA intensity matrix is bundled.

Machine-readable checks are in `static_checks.json`, `R_syntax_checks.csv`,
`saved_diagnostics_comparison.json` and `R_sessionInfo.txt`.

Changes were limited to packaging, English documentation, path defaults in the
analysis copies, creation of validation output folders and the explicit ridge
input-file argument. The R Task 1 analysis now accepts the ridge file produced by
the supplied training script; its metric calculations are unchanged. Six small
true-fold-change annotation files missing from the old package were added in the
two locations used by the original R-helper lookup.

Full GPU training and all protein-level reanalyses were not repeated during
this packaging pass. The previous package's complete numerical validation is
not being presented as a new end-to-end validation of this lightweight release.
External Zenodo archive names/content could not be independently enumerated in
the packaging environment. Confirm downloads against the supplied checklist.

The retained clinical script has a legacy Windows-path escape warning under a
newer Python parser; its source was preserved. Configure its clinical paths and
recorded environment before use. Local R startup also reported unavailable
locale settings; syntax and metric self-tests nevertheless completed.

The release is ready for code/result distribution with these dependencies
documented, not a claim that every historical analysis runs without external
inputs or matches every GPU/software environment bit for bit.

