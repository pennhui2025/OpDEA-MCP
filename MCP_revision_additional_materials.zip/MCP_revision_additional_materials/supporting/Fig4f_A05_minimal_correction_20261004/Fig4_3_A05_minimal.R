##
####
# 1. case study 1 TPD DEP comparison, UMAP for visualization of DEP based seperation of normal and disease
#    classification
# 2. Case study 2 PD

library(pheatmap)
library(VennDiagram)
library(ggplot2)
library(clusterProfiler)
library(org.Hs.eg.db)
library(SuperExactTest)
library(reshape2)


root_fold<-'D:/Roffline/MVIDIA/case_Res/all08/'
raw_fold<-'D:/Roffline/MVIDIA/case_Res/all08'

#select case1 TPD
#select case2 CRC
# other cases can be described in Supplementary results

dt_name = 'TPD_dis'#'TPD_dis'#'CRC'#'LC'#'PD'#'TPD_ret'#
if (dt_name == 'TPD_dis'){
  
  raw_fold = 'D:/Roffline/MVIDIA/case_Res/TPD_views/dis/'
  sub_fold = 'TPD_dis_filter_all08'
  # sub_fold = 'TPD_dis_proteomics_v1_1'
  best_fold = 'DIA_dlfq_maxlfq_top3'
  all_fold = 'DIA_dlfq_maxlfq_top3_top1'
  # sub_fold = 'TPD_res_ori_001_2_mcc'
  logthre = log2(2)
  qthre = 0.01
  dlfq_logT = 'F'
  post = '.csv'
  g2 = 'M'
}else if(dt_name == 'TPD_ret'){
  
  raw_fold = 'D:/Roffline/MVIDIA/case_Res/TPD_views/ret/'
  sub_fold = 'TPD_ret_filter_all08'
  best_fold = 'DIA_dlfq_maxlfq_top3'
  all_fold = 'DIA_dlfq_maxlfq_top3_top1'
  logthre = log2(2)
  qthre = 0.01
  dlfq_logT = 'F'
  post = '.csv'
  g2 = 'M'
  # args.batch_size = 8
}else if(dt_name == 'PD'){
  
  raw_fold = 'D:/Roffline/MVIDIA/case_Res/PD_views/Columbia/views/'
  sub_fold = 'PD_filter_all08'
  best_fold = 'DIA_dlfq_top3'
  all_fold = 'DIA_dlfq_maxlfq_top3_top1'
  # sub_fold = 'PD_Columbia_res_MCC_005_15'
  # best_fold = 'DIA_dlfq_maxlfq'
  # all_fold = 'DIA_dlfq_maxlfq_top3_top1'
  logthre = log2(1.5)
  qthre = 0.05
  dlfq_logT = 'T'
  post = '.tsv'
  g2 = 'PD'
  args.batch_size = 16
  
}else if(dt_name == 'LC'){
  
  raw_fold = 'D:/Roffline/MVIDIA/case_Res/PXD047839/dt2/renamed/'
  sub_fold = 'LC2filter_all08'
  best_fold = 'DIA_dlfq_maxlfq_top3'
  all_fold = 'DIA_dlfq_maxlfq_top3_top1'
  logthre = 0.6
  qthre = 0.05
  dlfq_logT = 'T'
  post = '.tsv'
  g2 = 'cancer'
  args.batch_size = 16
  
}else if(dt_name == 'CRC'){
  
  raw_fold = 'D:/Roffline/MVIDIA/case_Res/CRC/'
  sub_fold = 'CRC_filter_all08'
  best_fold = 'DIA_dlfq_maxlfq_top3'
  all_fold = 'DIA_dlfq_maxlfq_top3_top1'
  logthre = log2(1.5)
  qthre = 0.05
  dlfq_logT = 'T'
  post = '.tsv'
  g2 = 'N'
}

res_all<-read.table(paste0(root_fold, sub_fold, '/', all_fold, '/DEA_res.csv'), header = T, sep = ',')
res_all1<-read.table(paste0(root_fold, sub_fold, '/', best_fold,'/DEA_res.csv'), header = T, sep = ',')
#latents<-read.table(paste0(root_fold, sub_fold, '/', best_fold,'/fused_latent.csv'), header = T, sep = ',')


list_to_matrix <- function(gene_sets) {
  # 获取所有唯一基因/蛋白ID
  all_genes <- unique(unlist(gene_sets))
  
  # 创建二进制矩阵
  binary_mat <- matrix(0,
                       nrow = length(all_genes),
                       ncol = length(gene_sets),
                       dimnames = list(all_genes, names(gene_sets)))
  
  # 填充矩阵
  for(i in seq_along(gene_sets)) {
    binary_mat[rownames(binary_mat) %in% gene_sets[[i]], i] <- 1
  }
  
  return(binary_mat)
}



dlfq_deg <- subset(res_all, dlfq_qval <= qthre & abs(dlfq_logFC) >= logthre)
maxlfq_deg <- subset(res_all, maxlfq_qval <= qthre & abs(maxlfq_logFC) >= logthre)
top3_deg <- subset(res_all, top3_qval <= qthre & abs(top3_logFC) >= logthre)
top1_deg <- subset(res_all, top1_qval <= qthre & abs(top1_logFC) >= logthre)
# hurdle_deg <- subset(res_all1, hurdle_qval < qthre & abs(hurdle_logFC) > logthre)
DL_direct_deg <- subset(res_all1, MVcontrast_score.2 >= max(res_all1$MVcontrast_threshold.2) & abs(MVcontrast_logFC.2) >= logthre)
# DL_vote_deg<- subset(res_all, MVcontrast_score.1 > max(res_all$MVcontrast_threshold.1) & abs(MVcontrast_logFC.1) > logthre)
# DL_direct_FDR_deg <- subset(res_all, MVcontrast_score.2 > max(res_all$MVcontrast_threshold.2) & abs(MVcontrast_logFC.2) > logthre)

input=list(dlfq=dlfq_deg$Protein, top3=top3_deg$Protein, maxlfq=maxlfq_deg$Protein, top1 = top1_deg$Protein,
           MCP=DL_direct_deg$Protein)


library(UpSetR)

UpSetR::upset(fromList(input),
              sets = c('dlfq', 'maxlfq',
                       'top3', 'top1',
                       'MCP'#,
              ),
              order.by="freq", matrix.color="black", point.size=3,
              sets.bar.color=c("#b2df8a", "#33a02c", "#1f78b4", "lightblue", "#f078b4"
                               #"#CD6155",
                               #'#FF1493'#,
                               #'#40E0D0'
              ),mb.ratio=c(0.6, 0.4), text.scale = 1.5,
              number.angles =0,
              keep.order = T,nintersects=20)

input_top3=list(dlfq=dlfq_deg$Protein, maxlfq=maxlfq_deg$Protein, 
                MCP=DL_direct_deg$Protein)
library(VennDiagram)
library(ggVennDiagram)
library("readxl")
library(ggplot2)
library(reshape2)
library(ggpubr)
library(cowplot)
set.seed(123)
nature_palette <- c("#b2df8a", "#33a02c", "#f078b4")

ggVennDiagram(
  input_top3,
  label_alpha = 0,            # 隐藏标签背景
  label = "count",             # 显示交集数量
  set_label_pos = 0.001,
  set_color = nature_palette   # 直接设置外圈颜色
) +
  scale_fill_gradient(low = "#FFFFFF", high = "#E64B35") +  # 设置填充渐变
  theme_void(base_size = 14) +                              # 使用空白主题
  theme(
    legend.position = "none",                                # 隐藏图例
    plot.title = element_text(size = 16, face = "bold", hjust = 0.6)#,
    #plot.margin = margin(t = 20, r = 20, b = 20, l = 20, unit = "mm")
  ) #+

dlfq<-read.table(paste0('D:/Roffline/MVIDIA/case_Res/all08/DP_fdr_3/', dt_name, 'dlfq.csv'), sep = ',', header = T)
dlfq_view<-dlfq[,2:(length(dlfq[1,])-1)]
dlfq_lab<-dlfq[,length(dlfq[1,])]
dlfq_lab_chr<-c(rep('benign', length(dlfq_lab)))
dlfq_lab_chr[which(dlfq_lab==1)]='malignant'
dlfq_full<-read.table(paste0('D:/Roffline/MVIDIA/case_Res/all08/DP_fdr_3/', dt_name, 'dlfq_full.csv'), sep = ',', header = T)
dlfq_view_full<-dlfq_full[,2:(length(dlfq_full[1,])-1)]
dlfq_pro<-colnames(dlfq_view_full)
dlfq_pro<-gsub('\\.', '|', dlfq_pro)

maxlfq<-read.table(paste0('D:/Roffline/MVIDIA/case_Res/all08/DP_fdr_3/', dt_name, 'maxlfq.csv'), sep = ',', header = T)
maxlfq_view<-maxlfq[,2:(length(maxlfq[1,])-1)]
maxlfq_lab<-maxlfq[,length(maxlfq[1,])]
maxlfq_lab_chr<-c(rep('benign', length(maxlfq_lab)))
maxlfq_lab_chr[which(maxlfq_lab==1)]='malignant'
maxlfq_full<-read.table(paste0('D:/Roffline/MVIDIA/case_Res/all08/DP_fdr_3/', dt_name, 'maxlfq_full.csv'), sep = ',', header = T)
maxlfq_view_full<-maxlfq_full[,2:(length(maxlfq_full[1,])-1)]
maxlfq_pro<-colnames(maxlfq_view_full)
maxlfq_pro<-gsub('\\.', '|', maxlfq_pro)

top3<-read.table(paste0('D:/Roffline/MVIDIA/case_Res/all08/DP_fdr_3/', dt_name, 'top3.csv'), sep = ',', header = T)
top3_view<-top3[,2:(length(top3[1,])-1)]
top3_lab<-top3[,length(top3[1,])]
top3_lab_chr<-c(rep('benign', length(top3_lab)))
top3_lab_chr[which(top3_lab==1)]='malignant'
top3_full<-read.table(paste0('D:/Roffline/MVIDIA/case_Res/all08/DP_fdr_3/', dt_name, 'top3_full.csv'), sep = ',', header = T)
top3_view_full<-top3_full[,2:(length(top3_full[1,])-1)]
top3_pro<-colnames(top3_view_full)
top3_pro<-gsub('\\.', '|', top3_pro)

top1<-read.table(paste0('D:/Roffline/MVIDIA/case_Res/all08/DP_fdr_3/', dt_name, 'top1.csv'), sep = ',', header = T)
top1_view<-top1[,2:(length(top1[1,])-1)]
top1_lab<-top1[,length(top1[1,])]
top1_lab_chr<-c(rep('benign', length(top1_lab)))
top1_lab_chr[which(top1_lab==1)]='malignant'
top1_full<-read.table(paste0('D:/Roffline/MVIDIA/case_Res/all08/DP_fdr_3/', dt_name, 'top1_full.csv'), sep = ',', header = T)
top1_view_full<-top1_full[,2:(length(top1_full[1,])-1)]
top1_pro<-colnames(top1_view_full)
top1_pro<-gsub('\\.', '|', top1_pro)

MVDEA<-read.table(paste0('D:/Roffline/MVIDIA/case_Res/all08/DP_fdr_3/', dt_name, best_fold, 'mvdea.csv'), sep = ',', header = T)
MVDEA_view<-MVDEA[,2:(length(MVDEA[1,])-1)]
MVDEA_lab<-MVDEA[,length(MVDEA[1,])]
MVDEA_lab_chr<-c(rep('benign', length(MVDEA_lab)))
MVDEA_lab_chr[which(MVDEA_lab==1)]='malignant'

hurdle<-read.table(paste0('D:/Roffline/MVIDIA/case_Res/all08/DP_fdr_3/', dt_name, best_fold, 'hurdle.csv'), sep = ',', header = T)
hurdle_view<-hurdle[,2:(length(hurdle[1,])-1)]
hurdle_lab<-hurdle[,length(hurdle[1,])]
hurdle_lab_chr<-c(rep('benign', length(hurdle_lab)))
hurdle_lab_chr[which(hurdle_lab==1)]='malignant'

library(umap)
library(ggpubr)
library("gridExtra")

clus_perform<-read.table(paste0('D:/Roffline/MVIDIA/case_Res/all08/DP_fdr_3/', dt_name, '_clustering_performance_fill0_', best_fold, '.csv'), sep = ',', header = T)[,1:4]

umap_dlfq<-umap(as.matrix(dlfq_view), min_dist = 0.05, random_state=2025)

umap_maxlfq<-umap(as.matrix(maxlfq_view), min_dist = 0.05, random_state=2025)


umap_top3<-umap(as.matrix(top3_view), min_dist = 0.05, random_state=2025)


umap_top1<-umap(as.matrix(top1_view), min_dist = 0.05, random_state=2025)

umap_mvdea<-umap(as.matrix(MVDEA_view), min_dist = 0.05, random_state=2025)

umap_hurdle<-umap(as.matrix(hurdle_view), min_dist = 0.05, random_state=2025)



extract_legend <- function(my_ggp) {
  step1 <- ggplot_gtable(ggplot_build(my_ggp))
  step2 <- which(sapply(step1$grobs, function(x) x$name) == "guide-box")
  step3 <- step1$grobs[[step2]]
  return(step3)
}

# plot_umap2 <- function(umap_result_optimized, cluster_label, method_name, clus_perform, show_legend = FALSE){
#   
#   library(ggplot2)
#   library(dplyr)
#   
#   umap_df <- data.frame(
#     UMAP1 = umap_result_optimized$layout[, 1],
#     UMAP2 = umap_result_optimized$layout[, 2],
#     cluster = as.factor(cluster_label)
#   )
#   
#   # 凸包
#   hull_df <- umap_df %>%
#     group_by(cluster) %>%
#     filter(n() >= 3) %>%
#     do({
#       idx <- chull(.$UMAP1, .$UMAP2)
#       .[c(idx, idx[1]), ]
#     }) %>%
#     ungroup()
#   
#   # 中心点
#   center_df <- umap_df %>% 
#     group_by(cluster) %>% 
#     summarise(UMAP1 = mean(UMAP1), UMAP2 = mean(UMAP2))
#   
#   # 注释位置（永远不会跟散点重叠）
#   ann_x <- min(umap_df$UMAP1) + 0.02 * diff(range(umap_df$UMAP1))
#   ann_y <- max(umap_df$UMAP2) - 0.02 * diff(range(umap_df$UMAP2))
#   
#   # 提取本方法的性能指标
#   annot_df <- subset(clus_perform, X == method_name)
#   
#   pup <- ggplot() +
#     geom_point(data = umap_df, aes(UMAP1, UMAP2, color = cluster),
#                size = 3, alpha = 0.8) +
#     # geom_polygon(data = hull_df,
#     #              aes(UMAP1, UMAP2, group = cluster, color = cluster),
#     #              fill = NA, linewidth = 1) +
#     # geom_point(data = center_df,
#     #            aes(UMAP1, UMAP2, color = cluster),
#     #            shape = 3, size = 3, stroke = 1.2) +
#     
#     labs(x = "UMAP1", y = "UMAP2") +
#     
#     theme_minimal(base_size = 12) +
#     theme(
#       axis.text = element_blank(),
#       axis.ticks = element_blank(),
#       legend.position = 'right',
#       panel.grid = element_line(color = "grey90", size = 0.2)
#     ) +
#     
#     scale_color_manual(values = c("#15d08a","#f2ca01"))+#"#E64B35FF", "#4DBBD5FF")) +
#     
#     annotate("label",
#              x = ann_x, y = ann_y,
#              label = sprintf("ARI = %.2f\nASW = %.2f\nNMI = %.2f",
#                              annot_df$ARI, annot_df$ASW, annot_df$NMI),
#              hjust = 0, vjust = 1,
#              size = 4,
#              fill = alpha("white", 0.25),
#              label.size = 0,
#              label.r = unit(0.15, "lines")
#     )
#   
#   return(list(p = pup, dt = umap_df))
# }

plot_umap2 <- function(umap_result_optimized, cluster_label, method_name, clus_perform, show_legend = TRUE){
  
  library(ggplot2)
  library(dplyr)
  
  umap_df <- data.frame(
    UMAP1 = umap_result_optimized$layout[, 1],
    UMAP2 = umap_result_optimized$layout[, 2],
    cluster = as.factor(cluster_label)
  )
  
  # 凸包（保持注释状态，如需启用可取消注释）
  hull_df <- umap_df %>%
    group_by(cluster) %>%
    filter(n() >= 3) %>%
    do({
      idx <- chull(.$UMAP1, .$UMAP2)
      .[c(idx, idx[1]), ]
    }) %>%
    ungroup()
  
  # 中心点（保持注释状态，如需启用可取消注释）
  center_df <- umap_df %>% 
    group_by(cluster) %>% 
    summarise(UMAP1 = mean(UMAP1), UMAP2 = mean(UMAP2))
  
  # 注释位置：右下角（调整偏移量确保不超出画布）
  range_x <- diff(range(umap_df$UMAP1))
  range_y <- diff(range(umap_df$UMAP2))
  ann_x <- max(umap_df$UMAP1) - 0.03 * range_x  # 右侧偏移
  ann_y <- min(umap_df$UMAP2) + 0.03 * range_y  # 下侧偏移
  
  # 提取本方法的性能指标
  annot_df <- subset(clus_perform, X == method_name)
  
  # Nature风格绘图
  pup <- ggplot() +
    # 散点层
    geom_point(data = umap_df, aes(UMAP1, UMAP2, color = cluster),
               size = 2, alpha = 0.7, stroke = 0.1) +
    # 凸包层（如需启用取消注释）
    # geom_polygon(data = hull_df, aes(UMAP1, UMAP2, group = cluster, color = cluster),
    #              fill = NA, linewidth = 0.8, alpha = 0.8) +
    # 中心点层（如需启用取消注释）
    # geom_point(data = center_df, aes(UMAP1, UMAP2, color = cluster),
    #            shape = 3, size = 3, stroke = 1) +
    
    # 坐标轴标签
    labs(x = "UMAP1", y = "UMAP2") +
    
    # Nature期刊风格主题
    theme_bw(base_size = 12) +
    theme(
      # 背景设置
      panel.background = element_rect(fill = "white", colour = NA),
      plot.background = element_rect(fill = "white", colour = NA),
      panel.border = element_rect(colour = "black", fill = NA, linewidth = 0.7),
      
      # 坐标轴设置
      axis.title = element_text(face = "bold", size = 14, colour = "black"),
      axis.text = element_blank(),
      axis.ticks = element_blank(),
      axis.ticks.length = unit(0, "mm"),
      
      # 图例设置（根据参数控制显示）
      legend.position = ifelse(show_legend, "right", "none"),
      legend.title = element_text(face = "bold", size = 17),
      legend.text = element_text(size = 15),
      legend.key = element_rect(fill = "white", colour = NA),
      
      # 网格线（Nature风格通常隐藏网格）
      panel.grid = element_blank(),
      
      # 边距调整
      plot.margin = margin(t = 5, r = 5, b = 5, l = 5, unit = "mm")
    ) +
    
    # Nature风格配色（可根据聚类数扩展）
    scale_color_manual(values = c("#15983D", "#FFA000", "#91D1C2FF","#E64B35FF", "#4878CF")) +
    
    # 右下角性能注释
    annotate("label",
             x = ann_x, y = ann_y,
             label = sprintf("ARI = %.2f\nASW = %.2f\nNMI = %.2f",
                             annot_df$ARI, annot_df$ASW, annot_df$NMI),
             hjust = 0.9, vjust = 0,  # 右对齐+下对齐
             size = 3,
             fill = alpha("white", 0.5),  # 增强背景透明度
             color = "black",
             label.size = 0.3,  # 细边框
             label.r = unit(0.2, "lines")
    )
  
  return(list(p = pup, dt = umap_df))
}




p_dlfq <- plot_umap2(umap_dlfq, as.character(dlfq_lab_chr), "dlfq", clus_perform)
p_maxlfq <- plot_umap2(umap_maxlfq, as.character(maxlfq_lab_chr), "maxlfq", clus_perform)
p_top3   <- plot_umap2(umap_top3,  as.character(top3_lab_chr),  "top3",  clus_perform)
p_top1   <- plot_umap2(umap_top1,  as.character(top1_lab_chr),  "top1",  clus_perform)
p_mvdea  <- plot_umap2(umap_mvdea, as.character(MVDEA_lab_chr), "MVDEA", clus_perform)
p_hurdle <- plot_umap2(umap_hurdle,as.character(hurdle_lab_chr),"hurdle",clus_perform)

shared_legend <- extract_legend(p_dlfq$p)
# pall<-grid.arrange(
#   p_dlfq$p+ggtitle('dlfq')+theme(legend.position = 'none',plot.title = element_text(hjust = 0.5), axis.title.x = element_blank()),
#   p_maxlfq$p+ggtitle('maxlfq')+theme(legend.position = 'none', axis.title.y = element_blank(), axis.title.x = element_blank(),plot.title = element_text(hjust = 0.5)),
#   p_top3$p+ggtitle('top3')+theme(legend.position = 'none', axis.title.x = element_blank(),plot.title = element_text(hjust = 0.5)),
#   p_top1$p+ggtitle('top1')+theme(legend.position = 'none', axis.title.y = element_blank(), plot.title = element_text(hjust = 0.5)),
#   p_mvdea$p+ggtitle('MCP')+theme(legend.position = 'none', plot.title = element_text(hjust = 0.5)),
#   #p_hurdle$p+ggtitle('Hurdle')+theme(legend.position = 'none', axis.title.y = element_blank(), plot.title = element_text(hjust = 0.5)),
#   shared_legend,
#   ncol=2,widths=c(1, 1))

pall<-grid.arrange(
  p_dlfq$p+ggtitle('dlfq')+theme(legend.position = 'none',plot.title = element_text(hjust = 0.5), axis.title.x = element_blank()),
  p_maxlfq$p+ggtitle('maxlfq')+theme(legend.position = 'none', axis.title.y = element_blank(), axis.title.x = element_blank(),plot.title = element_text(hjust = 0.5)),
  p_top3$p+ggtitle('top3')+theme(legend.position = 'none', axis.title.y = element_blank(), axis.title.x = element_blank(),plot.title = element_text(hjust = 0.5)),
  p_top1$p+ggtitle('top1')+theme(legend.position = 'none', plot.title = element_text(hjust = 0.5)),
  p_mvdea$p+ggtitle('MCP')+theme(legend.position = 'none', axis.title.y = element_blank(), plot.title = element_text(hjust = 0.5)),
  #p_hurdle$p+ggtitle('Hurdle')+theme(legend.position = 'none', axis.title.y = element_blank(), plot.title = element_text(hjust = 0.5)),
  shared_legend,
  ncol=3,widths=c(1, 1, 1)) #, ncol=3, heights=c(1,1.2), widths=c(1, 1, 1)

per_melt<-melt(clus_perform)

colnames(per_melt)<-c('Method', 'Metrics', 'Value')
per_melt<-per_melt[which(per_melt$Method!='hurdle'),]
per_melt<-per_melt[which(per_melt$Metrics!='ASW'),]
per_melt$Method<-factor(per_melt$Method, levels = c("dlfq", "maxlfq", "top3", "top1",  "MVDEA"))#"hurdle",
per_melt$Value<-round(as.numeric(per_melt$Value), 3)


hp_per <- ggdotchart(
  per_melt, 
  x = "Metrics", 
  y = "Value", 
  group = "Method", 
  color = "Method",
  #'gold','#40E0D0',"#CD6155","#b2df8a","#1f78b4",'#FF1493'
  palette = c("#b2df8a", "#33a02c", "#1f78b4", "lightblue", "#f078b4"),# "orange",
  add = "segments",
  add.params = list(color = "black", size = 1),
  dot.size = 3,
  position = position_dodge(width = 0.8)
) +
  geom_text(
    aes(label = round(Value, 2), group = Method), 
    position = position_dodge(width = 0.8),   
    vjust = -0.8,
    size = 4,
    inherit.aes = TRUE
  ) +
  theme(
    axis.text.x = element_text(size = 14, angle = 0, hjust = 0.5),
    axis.title.x = element_blank(),
    legend.position = 'right'
  )
hp_per

### DEP based patient diagnosis
diag_perform<-read.table('D:/Roffline/MVIDIA/case_Res/all08/DEPs_XGB_perform.csv', sep = ',', header = T)
diag_perform<-diag_perform[which(diag_perform$X!='hurdle'),]
colnames(diag_perform)[3:8]<-c('AUC', 'Accuracy','Precision', 'Recall', 'F1', 'MCC')
library(ggplot2)

# ========== 1. 基础R数据处理（调整轴对应关系） ==========
methods <- diag_perform$X
metrics <- setdiff(names(diag_perform), c("X", "FeatureSet"))
perf_matrix <- as.matrix(diag_perform[, metrics])  # 行：Method，列：Metric
rownames(perf_matrix) <- methods

# 构建热图数据（x=Method，y=Metric）
heat_data <- expand.grid(Method = methods, Metric = metrics)  # 先Method（x），后Metric（y）
heat_data$Value <- as.vector(perf_matrix)  # 直接取矩阵值（行优先匹配）

# ========== 2. 调整轴后的热图可视化 ==========
p <- ggplot(heat_data, aes(x = Method, y = Metric, fill = Value)) +
  # 热图色块（白色边框区分）
  geom_tile(color = "white", linewidth = 0.5) +
  # 数值标签（居中）
  geom_text(aes(label = sprintf("%.2f", Value)), 
            size = 3.5, color = "black", family = "Arial") +
  # 颜色梯度（蓝→红，低→高）
  scale_fill_gradient2(
    low = "#3C5488",      
    high = "#E64B35",     
    midpoint = mean(heat_data$Value),  
    limits = c(0.5, 0.95), 
    name = "Performance"  
  ) +
  # Nature风格主题
  theme_minimal() +
  theme(
    plot.background = element_rect(fill = "white", color = NA),
    plot.margin = margin(10, 10, 10, 10),
    # 标题与标签
    plot.title = element_text(size = 12, face = "bold", hjust = 0.5, family = "Arial"),
    axis.title = element_text(size = 11, face = "bold", family = "Arial"),
    axis.text = element_text(size = 10, family = "Arial"),
    axis.text.x = element_text(angle = 0, hjust = 0.5),  # x轴标签旋转（Method名）
    # 图例
    legend.title = element_text(size = 9, face = "bold", family = "Arial"),
    legend.text = element_text(size = 8, family = "Arial"),
    legend.key.height = unit(1.5, "cm"),
    # 网格线移除
    panel.grid = element_blank(),
    # 坐标轴简化
    axis.line = element_blank(),
    axis.ticks = element_blank()
  ) +
  # 标签设置
  labs(
    title = "Applying DEPs for Patient Diagnosis",
    x = "Method for detecting DEPs",
    y = "Evaluation Metric",
    fill = "Performance Value"
  )

print(p)
##################################################################

library(pheatmap)
library(VennDiagram)
library(ggplot2)
library(clusterProfiler)
library(org.Hs.eg.db)
library(SuperExactTest)
library(reshape2)


root_fold<-'D:/Roffline/MVIDIA/case_Res/all08/'
raw_fold<-'D:/Roffline/MVIDIA/case_Res/all08'

#select case1 TPD
#select case2 CRC
# other cases can be described in Supplementary results

dt_name = 'CRC'#'TPD_dis'#'CRC'#'LC'#'PD'#'TPD_ret'#
if(dt_name == 'CRC'){
  
  raw_fold = 'D:/Roffline/MVIDIA/case_Res/CRC/'
  sub_fold = 'CRC_filter_all08'
  # sub_fold = 'CRC_filter_proteomics_v1'
  best_fold = 'DIA_dlfq_maxlfq_top3'
  all_fold = 'DIA_dlfq_maxlfq_top3_top1'
  logthre = log2(1.5)
  qthre = 0.05
  dlfq_logT = 'T'
  post = '.tsv'
  g2 = 'N'
}

res_all<-read.table(paste0(root_fold, sub_fold, '/', all_fold, '/DEA_res.csv'), header = T, sep = ',')
res_all1<-read.table(paste0(root_fold, sub_fold, '/', best_fold,'/DEA_res.csv'), header = T, sep = ',')
#latents<-read.table(paste0(root_fold, sub_fold, '/', best_fold,'/fused_latent.csv'), header = T, sep = ',')


list_to_matrix <- function(gene_sets) {
  # 获取所有唯一基因/蛋白ID
  all_genes <- unique(unlist(gene_sets))
  
  # 创建二进制矩阵
  binary_mat <- matrix(0,
                       nrow = length(all_genes),
                       ncol = length(gene_sets),
                       dimnames = list(all_genes, names(gene_sets)))
  
  # 填充矩阵
  for(i in seq_along(gene_sets)) {
    binary_mat[rownames(binary_mat) %in% gene_sets[[i]], i] <- 1
  }
  
  return(binary_mat)
}


dlfq_deg <- subset(res_all, dlfq_qval <= qthre & abs(dlfq_logFC) >= logthre)
maxlfq_deg <- subset(res_all, maxlfq_qval <= qthre & abs(maxlfq_logFC) >= logthre)
top3_deg <- subset(res_all, top3_qval <= qthre & abs(top3_logFC) >= logthre)
top1_deg <- subset(res_all, top1_qval <= qthre & abs(top1_logFC) >= logthre)
# hurdle_deg <- subset(res_all1, hurdle_qval < qthre & abs(hurdle_logFC) > logthre)
DL_direct_deg <- subset(res_all1, MVcontrast_score.2 >= max(res_all1$MVcontrast_threshold.2) & abs(MVcontrast_logFC.2) >= logthre)
# DL_vote_deg<- subset(res_all, MVcontrast_score.1 > max(res_all$MVcontrast_threshold.1) & abs(MVcontrast_logFC.1) > logthre)
# DL_direct_FDR_deg <- subset(res_all, MVcontrast_score.2 > max(res_all$MVcontrast_threshold.2) & abs(MVcontrast_logFC.2) > logthre)

input=list(dlfq=dlfq_deg$Protein, top3=top3_deg$Protein, maxlfq=maxlfq_deg$Protein, top1 = top1_deg$Protein,
           MCP=DL_direct_deg$Protein)#, DL_vote=DL_vote_deg$Protein,


library(UpSetR)

UpSetR::upset(fromList(input),
              sets = c('dlfq', 'maxlfq',
                       'top3', 'top1',
                       #'hurdle2',
                       #'hurdle',
                       #'MVIDIA2',
                       'MCP'#,
                       #'Concat2',
                       #'DL_vote',
                       #'MLE2',
                       #'DL_fdr'
              ),
              order.by="freq", matrix.color="black", point.size=3,
              sets.bar.color=c("#b2df8a", "#33a02c", "#1f78b4", "lightblue", "#f078b4"
                               #"#CD6155",
                               #'#FF1493'#,
                               #'#40E0D0'
              ),mb.ratio=c(0.6, 0.4), text.scale = 1.5,
              number.angles =0,
              keep.order = T,nintersects=20)

input_top3=list(dlfq=dlfq_deg$Protein, maxlfq=maxlfq_deg$Protein, 
                MCP=DL_direct_deg$Protein)
library(VennDiagram)
library(ggVennDiagram)
library("readxl")
library(ggplot2)
library(reshape2)
library(ggpubr)
library(cowplot)
set.seed(123)
nature_palette <- c("#b2df8a", "#33a02c", "#f078b4")

ggVennDiagram(
  input_top3,
  label_alpha = 0,            # 隐藏标签背景
  label = "count",             # 显示交集数量
  set_label_pos = 0.001,
  set_color = nature_palette   # 直接设置外圈颜色
) +
  scale_fill_gradient(low = "#FFFFFF", high = "#E64B35") +  # 设置填充渐变
  theme_void(base_size = 14) +                              # 使用空白主题
  theme(
    legend.position = "none",                                # 隐藏图例
    plot.title = element_text(size = 16, face = "bold", hjust = 0.6)#,
    #plot.margin = margin(t = 20, r = 20, b = 20, l = 20, unit = "mm")
  ) #+


dlfq<-read.table(paste0('D:/Roffline/MVIDIA/case_Res/all08/DP_fdr_3/', dt_name, 'dlfq.csv'), sep = ',', header = T)
dlfq_view<-dlfq[,2:(length(dlfq[1,])-1)]
dlfq_lab<-dlfq[,length(dlfq[1,])]
dlfq_lab_chr<-c(rep('Cancer', length(dlfq_lab)))
dlfq_lab_chr[which(dlfq_lab==1)]='Normal'
dlfq_full<-read.table(paste0('D:/Roffline/MVIDIA/case_Res/all08/DP_fdr_3/', dt_name, 'dlfq_full.csv'), sep = ',', header = T)
dlfq_view_full<-dlfq_full[,2:(length(dlfq_full[1,])-1)]
dlfq_pro<-colnames(dlfq_view_full)
dlfq_pro<-gsub('\\.', '|', dlfq_pro)

maxlfq<-read.table(paste0('D:/Roffline/MVIDIA/case_Res/all08/DP_fdr_3/', dt_name, 'maxlfq.csv'), sep = ',', header = T)
maxlfq_view<-maxlfq[,2:(length(maxlfq[1,])-1)]
maxlfq_lab<-maxlfq[,length(maxlfq[1,])]
maxlfq_lab_chr<-c(rep('Cancer', length(maxlfq_lab)))
maxlfq_lab_chr[which(maxlfq_lab==1)]='Normal'
maxlfq_full<-read.table(paste0('D:/Roffline/MVIDIA/case_Res/all08/DP_fdr_3/', dt_name, 'maxlfq_full.csv'), sep = ',', header = T)
maxlfq_view_full<-maxlfq_full[,2:(length(maxlfq_full[1,])-1)]
maxlfq_pro<-colnames(maxlfq_view_full)
maxlfq_pro<-gsub('\\.', '|', maxlfq_pro)

top3<-read.table(paste0('D:/Roffline/MVIDIA/case_Res/all08/DP_fdr_3/', dt_name, 'top3.csv'), sep = ',', header = T)
top3_view<-top3[,2:(length(top3[1,])-1)]
top3_lab<-top3[,length(top3[1,])]
top3_lab_chr<-c(rep('Cancer', length(top3_lab)))
top3_lab_chr[which(top3_lab==1)]='Normal'
top3_full<-read.table(paste0('D:/Roffline/MVIDIA/case_Res/all08/DP_fdr_3/', dt_name, 'top3_full.csv'), sep = ',', header = T)
top3_view_full<-top3_full[,2:(length(top3_full[1,])-1)]
top3_pro<-colnames(top3_view_full)
top3_pro<-gsub('\\.', '|', top3_pro)

top1<-read.table(paste0('D:/Roffline/MVIDIA/case_Res/all08/DP_fdr_3/', dt_name, 'top1.csv'), sep = ',', header = T)
top1_view<-top1[,2:(length(top1[1,])-1)]
top1_lab<-top1[,length(top1[1,])]
top1_lab_chr<-c(rep('Cancer', length(top1_lab)))
top1_lab_chr[which(top1_lab==1)]='Normal'
top1_full<-read.table(paste0('D:/Roffline/MVIDIA/case_Res/all08/DP_fdr_3/', dt_name, 'top1_full.csv'), sep = ',', header = T)
top1_view_full<-top1_full[,2:(length(top1_full[1,])-1)]
top1_pro<-colnames(top1_view_full)
top1_pro<-gsub('\\.', '|', top1_pro)

MVDEA<-read.table(paste0('D:/Roffline/MVIDIA/case_Res/all08/DP_fdr_3/', dt_name, best_fold, 'mvdea.csv'), sep = ',', header = T)
MVDEA_view<-MVDEA[,2:(length(MVDEA[1,])-1)]
MVDEA_lab<-MVDEA[,length(MVDEA[1,])]
MVDEA_lab_chr<-c(rep('Cancer', length(MVDEA_lab)))
MVDEA_lab_chr[which(MVDEA_lab==1)]='Normal'

hurdle<-read.table(paste0('D:/Roffline/MVIDIA/case_Res/all08/DP_fdr_3/', dt_name, best_fold, 'hurdle.csv'), sep = ',', header = T)
hurdle_view<-hurdle[,2:(length(hurdle[1,])-1)]
hurdle_lab<-hurdle[,length(hurdle[1,])]
hurdle_lab_chr<-c(rep('Cancer', length(hurdle_lab)))
hurdle_lab_chr[which(hurdle_lab==1)]='Normal'

clus_perform<-read.table(paste0('D:/Roffline/MVIDIA/case_Res/all08/DP_fdr_3/', dt_name, '_clustering_performance_fill0_', best_fold, '.csv'), sep = ',', header = T)[,1:4]

library(umap)
library(ggpubr)
library("gridExtra")

extract_legend <- function(my_ggp) {
  step1 <- ggplot_gtable(ggplot_build(my_ggp))
  step2 <- which(sapply(step1$grobs, function(x) x$name) == "guide-box")
  step3 <- step1$grobs[[step2]]
  return(step3)
}

plot_umap2 <- function(umap_result_optimized, cluster_label, method_name, clus_perform, show_legend = FALSE){
  
  library(ggplot2)
  library(dplyr)
  
  umap_df <- data.frame(
    UMAP1 = umap_result_optimized$layout[, 1],
    UMAP2 = umap_result_optimized$layout[, 2],
    cluster = as.factor(cluster_label)
  )
  
  # 凸包
  hull_df <- umap_df %>%
    group_by(cluster) %>%
    filter(n() >= 3) %>%
    do({
      idx <- chull(.$UMAP1, .$UMAP2)
      .[c(idx, idx[1]), ]
    }) %>%
    ungroup()
  
  # 中心点
  center_df <- umap_df %>% 
    group_by(cluster) %>% 
    summarise(UMAP1 = mean(UMAP1), UMAP2 = mean(UMAP2))
  
  # 注释位置（永远不会跟散点重叠）
  ann_x <- min(umap_df$UMAP1) + 0.02 * diff(range(umap_df$UMAP1))
  ann_y <- max(umap_df$UMAP2) - 0.02 * diff(range(umap_df$UMAP2))
  
  # 提取本方法的性能指标
  annot_df <- subset(clus_perform, X == method_name)
  
  pup <- ggplot() +
    geom_point(data = umap_df, aes(UMAP1, UMAP2, color = cluster),
               size = 3, alpha = 0.8) +
    # geom_polygon(data = hull_df,
    #              aes(UMAP1, UMAP2, group = cluster, color = cluster),
    #              fill = NA, linewidth = 1) +
    # geom_point(data = center_df,
    #            aes(UMAP1, UMAP2, color = cluster),
    #            shape = 3, size = 3, stroke = 1.2) +
    
    labs(x = "UMAP1", y = "UMAP2") +
    
    theme_minimal(base_size = 12) +
    theme(
      axis.text = element_blank(),
      axis.ticks = element_blank(),
      legend.position = 'right',
      panel.grid = element_line(color = "grey90", size = 0.2)
    ) +
    
    scale_color_manual(values = c("#15d08a","#f2ca01"))+#"#E64B35FF", "#4DBBD5FF")) +
    
    annotate("label",
             x = ann_x, y = ann_y,
             label = sprintf("ARI = %.2f\nASW = %.2f\nNMI = %.2f",
                             annot_df$ARI, annot_df$ASW, annot_df$NMI),
             hjust = 0, vjust = 1,
             size = 4,
             fill = alpha("white", 0.25),
             label.size = 0,
             label.r = unit(0.15, "lines")
    )
  
  return(list(p = pup, dt = umap_df))
}

umap_dlfq<-umap(as.matrix(dlfq_view), min_dist = 0.05, random_state=2025)

umap_maxlfq<-umap(as.matrix(maxlfq_view), min_dist = 0.05, random_state=2025)


umap_top3<-umap(as.matrix(top3_view), min_dist = 0.05, random_state=2025)


umap_top1<-umap(as.matrix(top1_view), min_dist = 0.05, random_state=2025)

umap_mvdea<-umap(as.matrix(MVDEA_view), min_dist = 0.05, random_state=2025)

umap_hurdle<-umap(as.matrix(hurdle_view), min_dist = 0.05, random_state=2025)


p_dlfq <- plot_umap2(umap_dlfq, as.character(dlfq_lab_chr), "dlfq", clus_perform)
p_maxlfq <- plot_umap2(umap_maxlfq, as.character(maxlfq_lab_chr), "maxlfq", clus_perform)
p_top3   <- plot_umap2(umap_top3,  as.character(top3_lab_chr),  "top3",  clus_perform)
p_top1   <- plot_umap2(umap_top1,  as.character(top1_lab_chr),  "top1",  clus_perform)
p_mvdea  <- plot_umap2(umap_mvdea, as.character(MVDEA_lab_chr), "MVDEA", clus_perform)
p_hurdle <- plot_umap2(umap_hurdle,as.character(hurdle_lab_chr),"hurdle",clus_perform)

shared_legend <- extract_legend(p_dlfq$p)
pall<-grid.arrange(
  p_dlfq$p+ggtitle('dlfq')+theme(legend.position = 'none',plot.title = element_text(hjust = 0.5), axis.title.x = element_blank()),
  p_maxlfq$p+ggtitle('maxlfq')+theme(legend.position = 'none', axis.title.y = element_blank(), axis.title.x = element_blank(),plot.title = element_text(hjust = 0.5)),
  p_top3$p+ggtitle('top3')+theme(legend.position = 'none', axis.title.x = element_blank(),plot.title = element_text(hjust = 0.5)),
  p_top1$p+ggtitle('top1')+theme(legend.position = 'none', axis.title.y = element_blank(), plot.title = element_text(hjust = 0.5)),
  p_mvdea$p+ggtitle('MCP')+theme(legend.position = 'none', plot.title = element_text(hjust = 0.5)),
  #p_hurdle$p+ggtitle('Hurdle')+theme(legend.position = 'none', axis.title.y = element_blank(), plot.title = element_text(hjust = 0.5)),
  shared_legend,
  ncol=2,widths=c(1, 1))
######################################
############ pathway enrichment analysis

run_kegg <- function(genes_symbol, ori_ty = 'SYMBOL', species = "hsa") {
  
  OrgDb <- if (species == "hsa") org.Hs.eg.db else org.Mm.eg.db
  
  gene_df <- bitr(genes_symbol,
                  fromType = ori_ty,
                  toType = "ENTREZID",
                  OrgDb = OrgDb)
  
  ekegg <- enrichKEGG(
    gene         = gene_df$ENTREZID,
    organism     = species,
    pvalueCutoff = 0.01
  )
  
  ekegg <- setReadable(ekegg, OrgDb = OrgDb, keyType = "ENTREZID")
  
  return(ekegg)
}

kegg_dlfq_crc<-run_kegg(dlfq_deg$Protein, ori_ty = "UNIPROT")
kegg_dlfq_crc_all<-kegg_dlfq_crc@result

kegg_maxlfq_crc<-run_kegg(maxlfq_deg$Protein, ori_ty = "UNIPROT")
kegg_maxlfq_crc_all<-kegg_maxlfq_crc@result

kegg_top3_crc<-run_kegg(top3_deg$Protein, ori_ty = "UNIPROT")
kegg_top3_crc_all<-kegg_top3_crc@result

kegg_top1_crc<-run_kegg(top1_deg$Protein, ori_ty = "UNIPROT")
kegg_top1_crc_all<-kegg_top1_crc@result

kegg_DL_crc<-run_kegg(DL_direct_deg$Protein, ori_ty = "UNIPROT")
kegg_DL_crc_all<-kegg_DL_crc@result

kegg_res_list <- list(
  MCP = kegg_DL_crc_all, 
  dlfq = kegg_dlfq_crc_all, 
  maxlfq = kegg_maxlfq_crc_all, 
  top3 = kegg_top3_crc_all, 
  top1 = kegg_top1_crc_all
)
head(kegg_res_list$MCP)


library(ggplot2)
library(dplyr)
library(forcats)
library(ggtext)
library(scales)

res_list<-list(MCP = kegg_DL_crc_all, 
               dlfq = kegg_dlfq_crc_all, 
               maxlfq = kegg_maxlfq_crc_all, 
               top3 = kegg_top3_crc_all, 
               top1 = kegg_top1_crc_all)

df <- purrr::map_df(names(res_list), function(nm) {
  res_list[[nm]] %>% mutate(Group = nm)
})

if (!"ID" %in% colnames(df)) {
  stop("df 中没有名为 'ID' 的列，请检查你的数据列名")
}

# 改用p.adjust <= 0.05筛选（若实际列名为p.ajust可改为p.ajust）
df_filt <- df %>% filter(p.adjust <= 0.05)

if (nrow(df_filt) == 0) {
  stop("没有 p.adjust <= 0.05 的 pathway")
}
df_filt$Pathway = df_filt$ID  # Pathway 重命名保留

### -----------------------------------------------
### 数据准备（保留GeneRatio和logP计算）
### -----------------------------------------------
df_plot <- df_filt %>%
  mutate(
    GeneRatio_num = purrr::map_dbl(GeneRatio, function(x){
      x <- gsub(" ", "", x)
      if(grepl("/", x)){
        v <- strsplit(x, "/")[[1]]
        return(as.numeric(v[1]) / as.numeric(v[2]))
      } else return(as.numeric(x))
    }),
    logP = -log10(p.adjust)  # 对应调整为p.adjust的-log10值
  )

# 全局排序：按显著性最大 -log10(p.adjust)
df_plot <- df_plot %>%
  group_by(Description) %>%
  mutate(max_logP = max(logP)) %>%
  ungroup() %>%
  mutate(
    Description = fct_reorder(Description, max_logP, .desc = TRUE)
  )

### -----------------------------------------------
### 颜色设置（出版级配色）
### -----------------------------------------------
cold_color <- "#4A6FA5"   # 柔和蓝
hot_color  <- "#B02E34"   # 柔和深红

### -----------------------------------------------
### 绘图主体
### -----------------------------------------------
p <- ggplot(df_plot, aes(
  x = Group,
  y = Description,
  color = logP,
  size  = GeneRatio_num
)) +
  geom_point(alpha = 0.85) +
  scale_color_gradient(
    low  = cold_color,
    high = hot_color,
    name = expression(-log[10](p[adjust]))  # 图例名称对应调整
  ) +
  scale_size(
    range = c(2.5, 10),
    name = "Gene Ratio"
  ) +
  guides(
    size = guide_legend(override.aes = list(alpha = 1)),
    color = guide_colorbar(barwidth = 1.2, barheight = 8)
  ) +
  labs(
    x = "",
    y = "",
    title = "Pathway Enrichment Comparison Across Quantification Methods"
  ) +
  
  ### ------------------------------
### 出版级主题设定
### ------------------------------
theme_bw(base_size = 14) +
  theme(
    plot.title      = element_text(face = "bold", hjust = 0.5, size = 13),  # 标题居中更美观
    panel.grid.minor = element_blank(),
    panel.grid.major = element_line(color = "grey92"),
    axis.text.x      = element_text(angle = 40, hjust = 1, vjust = 1, size = 12),
    axis.text.y      = element_text(size = 10, lineheight = 1.2),  # 移除markdown格式
    panel.border     = element_rect(color = "black", size = 0.8),
    legend.title     = element_text(size = 12, face = "bold"),
    legend.text      = element_text(size = 11),
    legend.key.width = unit(0.8, "cm"),
    plot.margin      = margin(10, 15, 10, 10)
  )

p



############################################################
##  KEGG + Reactome + Hallmark Enrichment
##############################

# ## 安装依赖（如缺失）
# pkg <- c("clusterProfiler", "ReactomePA", "msigdbr", "org.Hs.eg.db",
#          "ggplot2", "dplyr")
# for (p in pkg){
#   if(!requireNamespace(p, quietly = TRUE))
#     install.packages(p, dependencies = TRUE)
# }
# if(!requireNamespace("BiocManager", quietly = TRUE))
#   install.packages("BiocManager")
# 
# if(!require(clusterProfiler)) BiocManager::install("clusterProfiler")
# if(!require(ReactomePA))     BiocManager::install("ReactomePA")
# if(!require(org.Hs.eg.db))   BiocManager::install("org.Hs.eg.db")

library(clusterProfiler)
library(ReactomePA)
library(msigdbr)
library(org.Hs.eg.db)
library(ggplot2)
library(dplyr)
library(GSEABase)
library(tidyr)
library(dplyr)
############################################################
## 1. 用户提供差异基因列表 (Gene Symbols)
############################################################
## 示例: 用户在使用时替换此行

plot_enrichment <- function(enrich_obj, title) {
  # 提取富集结果数据框（用as.data.frame，而非直接$）
  df <- as.data.frame(enrich_obj)
  if (nrow(df) == 0) return(NULL)
  
  # 绘图（以ggplot为例）
  library(ggplot2)
  df$Description <- factor(df$Description, levels = rev(df$Description))
  ggplot(df[1:15, ], aes(x = Description, y = -log10(p.adjust))) +
    geom_bar(stat = "identity", fill = "#4DBBD5") +
    coord_flip() +
    labs(title = title, x = "KEGG Pathway", y = "-log10(Adjusted P-value)") +
    theme_minimal() +
    theme(plot.title = element_text(hjust = 0.5))
}

enrich_all<-function(deg, thre_ty, thre, view){

  uniports <- unique(deg$Protein)

  gene_df <- bitr(uniports,
                fromType = "UNIPROT",
                toType = "ENTREZID",
                OrgDb = org.Hs.eg.db)

  entrez <- gene_df$ENTREZID
  message("成功转换 Entrez IDs: ", length(entrez))

############################################################
## 3. KEGG 富集分析
############################################################
  ekegg <- enrichKEGG(
    gene         = entrez,
    organism     = "hsa",
    pvalueCutoff = 1,
    qvalueCutoff = 1
  )
  ekegg_thre <- ekegg[ekegg@result[,which(colnames(ekegg@result) == thre_ty)] <= 0.05, ]

############################################################
## 4. Reactome 富集
############################################################
  ereact <- enrichPathway(
    gene         = entrez,
    organism     = "human",
    pvalueCutoff = 1
  )
  ereact_thre <- ereact[ereact@result[,which(colnames(ereact@result) == thre_ty)] <= 0.05, ]

############################################################
## 5. Hallmark (MSigDB)
############################################################
# 确保加载必要包
 # 可选，用于更清晰的管道操作

  # 读取GMT文件（你的路径）
  gmt <- getGmt("C:/Users/Lenovo/Downloads/h.all.v2025.1.Hs.entrez.gmt")
  
  # 方法1：基础R + tidyr（无需dplyr）
  # 1. 提取基因集名称和对应的基因列表
  gs_names <- sapply(gmt, setName)          # 基因集名称向量
  gene_lists <- sapply(gmt, geneIds)        # 基因列表的嵌套列表（每个元素是一个基因集的基因）
  
  # 2. 构建数据框（关键：将基因列表作为“列表列”，而非直接展开）
  m_df <- data.frame(
    gs_name = gs_names,
    gene_entrez = I(gene_lists)  # 用I()标记为列表列，避免自动展开
  )
  
  # 3. 展开列表列（unnest）
  m_df <- tidyr::unnest(m_df, cols = gene_entrez)
  
  hall_list <- split(m_df$gene_entrez, m_df$gs_name)
  term2gene <- m_df[, c("gs_name", "gene_entrez")]
  colnames(term2gene) <- c("TERM", "GENE") # 必须命名为TERM和GENE
  entrez <- as.character(entrez)
  
  ehall <- enricher(
    gene = entrez,               # 输入基因（Entrez ID）
    TERM2GENE = term2gene,       # 两列数据框（TERM+GENE）
    pvalueCutoff = 1,            # 保留所有结果
    qvalueCutoff = 1,            # 可选：放宽q值过滤
    minGSSize = 10               # 可选：过滤基因数过少的基因集
  )
  ehall_thre <- ehall[ehall@result[,which(colnames(ehall@result) == thre_ty)] <= 0.05, ]


  p_kegg<-plot_enrichment(ekegg_thre, "KEGG Enrichment")
  p_react<-plot_enrichment(ereact_thre, "KEGG Enrichment")
  p_hall<-plot_enrichment(ehall_thre, "KEGG Enrichment")
  save_fold<-''
  enrichs = list(KEGG=ekegg@result, react=ereact@result, hall=ehall@result)
  write.table(ekegg@result, paste0(raw_fold, view, '_kegg.csv'), sep = ',', col.names = T, row.names = T)
  write.table(ereact@result, paste0(raw_fold, view, '_reactome.csv'), sep = ',', col.names = T, row.names = T)
  write.table(ehall@result, paste0(raw_fold, view, '_hall.csv'), sep = ',', col.names = T, row.names = T)
  return(list(enrichs = enrichs, plots=c(p_kegg, p_react, p_hall)))
}

res_dlfq = enrich_all(dlfq_deg, 'pvalue', 0.01, 'dlfq')
res_maxlfq = enrich_all(maxlfq_deg, 'pvalue', 0.01, 'maxlfq')
res_top3 = enrich_all(top3_deg, 'pvalue', 0.01, 'top3')
res_top1 = enrich_all(top1_deg, 'pvalue', 0.01, 'top1')
res_mcp = enrich_all(DL_direct_deg, 'pvalue', 0.01, 'MCP')

uni_pro_MCP<-setdiff(DL_direct_deg$Protein, c(dlfq_deg$Protein, maxlfq_deg$Protein, top3_deg$Protein, top1_deg$Protein))
uni_pro_MCP_record<-DL_direct_deg[match(uni_pro_MCP, DL_direct_deg$Protein), ]
res_uni_MCP = enrich_all(uni_pro_MCP_record, 'pvalue', 0.01, 'MCP_uni')


# 加载所需包
library(survival)
library(survminer)  
library(clusterProfiler)
library(org.Hs.eg.db)
library(ggplot2)
library(dplyr)
library(tidyr)
library(ggtext)     # 文本美化

# ====================== 1. 数据读取与预处理（同前，略） ======================
root_fold <- 'inputs/n/Figures/data/case_study/CRC_views/'
# A05：只改变生存分析数据路径和新输出目录；不覆盖原始结果。
fig4f_out <- 'inputs/p/outputs/Fig4f_A05_minimal_correction_20261004/results/'
dir.create(fig4f_out, recursive = TRUE, showWarnings = FALSE)

proteomics <- read.table(paste0(root_fold, 'proteomics_dataframe.tsv'), sep = '\t', header = T)
clinic <- read.table(paste0(root_fold, 'clinical_dataframe.tsv'), sep = '\t', header = T)

proteomics_clean<-proteomics[3:nrow(proteomics), , drop = FALSE]
colnames(proteomics_clean)[1]<-'Sample_ID'

for (i in 2:ncol(proteomics_clean)) {
  proteomics_clean[, i] <- as.numeric(proteomics_clean[, i])
}

clinical_surv <- clinic[, c("Patient_ID", 
                            "Overall.survival..days", 
                            "Survival.status..1..dead..0..alive.")]
colnames(clinical_surv) <- c("Sample_ID", "OS_time", "OS_status")
clinical_surv$OS_time <- as.numeric(as.character(clinical_surv$OS_time))
clinical_surv$OS_status <- as.numeric(as.character(clinical_surv$OS_status))

clinical_surv <- clinical_surv[!is.na(clinical_surv$Sample_ID) & 
                                 !is.na(clinical_surv$OS_time) & 
                                 !is.na(clinical_surv$OS_status) & 
                                 clinical_surv$OS_time > 0, ]
clinical_surv$OS_status <- as.numeric(clinical_surv$OS_status)

combined_data <- merge(proteomics_clean, clinical_surv, by = "Sample_ID")

# A05：保留原临床事件状态，不再把最长随访患者的死亡改成删失！
stopifnot(all(combined_data$OS_status %in% c(0, 1)), !anyDuplicated(combined_data$Sample_ID))
print(combined_data[combined_data$OS_time == max(combined_data$OS_time),
                    c("Sample_ID", "OS_time", "OS_status")])

cat("最终分析样本数：", nrow(combined_data), "\n")
cat("蛋白/基因数：", ncol(combined_data) - 3, "\n")


# ====================== 2. 匹配目标UniProt与数据中的SYMBOL（同前，略） ======================
target_uniprot <- uni_pro_MCP  # 需确保该变量已定义
stopifnot(length(unique(target_uniprot)) == 19L)  # 固定本次筛选的 19 个候选

gene_df <- bitr(target_uniprot,
                fromType = "UNIPROT",
                toType = "SYMBOL",
                OrgDb = org.Hs.eg.db)
write.table(gene_df, paste0(fig4f_out, 'MCP_unique_protein_CRC.csv'), sep = ',', col.names = T)
valid_symbols <- intersect(gene_df$SYMBOL, colnames(combined_data))
valid_uniprot_info <- gene_df[gene_df$SYMBOL %in% valid_symbols, ]  


# ====================== 3. 批量生存分析（同前，略） ======================
surv_results <- list()
for (i in seq_along(valid_uniprot_info$SYMBOL)) {
  col_name <- valid_uniprot_info$SYMBOL[i]  
  uniprot_id <- valid_uniprot_info$UNIPROT[i]  
  
  expr_vec <- combined_data[, col_name]
  data_temp <- combined_data[!is.na(expr_vec), c("Sample_ID", "OS_time", "OS_status", col_name)]
  
  if (nrow(data_temp) < 10) {
    warning(paste(uniprot_id, "(SYMBOL:", col_name, ")样本不足，跳过"))
    next
  }
  
  median_val <- median(data_temp[, col_name], na.rm = TRUE)
  data_temp$group <- factor(ifelse(data_temp[, col_name] > median_val, "High", "Low"), 
                            levels = c("Low", "High"))
  if (length(unique(data_temp$group)) < 2) next
  
  fit <- survfit(Surv(OS_time, OS_status) ~ group, data = data_temp,
                 conf.int = 0.95, conf.type = "log")
  
  lr_test <- survdiff(Surv(OS_time, OS_status) ~ group, data = data_temp)
  p_val <- ifelse(is.na(lr_test$chisq), 1, pchisq(lr_test$chisq, df = 1, lower.tail = FALSE))
  
  surv_results[[uniprot_id]] <- list(
    fit = fit,  
    p_val = p_val,
    n_low = sum(data_temp$group == "Low"),
    n_high = sum(data_temp$group == "High"),
    symbol = col_name,
    data_temp = data_temp,
    max_time = max(data_temp$OS_time, na.rm = TRUE)
  )
  
  cat(uniprot_id, "(SYMBOL:", col_name, ")→ p值：", signif(p_val, 3), 
      "（低表达n=", surv_results[[uniprot_id]]$n_low, 
      "，高表达n=", surv_results[[uniprot_id]]$n_high, "）\n", sep = "")
}


# ====================== 4. 绘制ggplot生存曲线（修复标题显示） ======================
plot_list <- list()
# if (interactive()) dev.new(width = 10, height = 8)
# 与现有修回分析一致：19 个计划候选构成校正 family，不只校正 VSIG4。
q_values <- p.adjust(sapply(surv_results, function(x) x$p_val), method = "BH",
                     n = 19L)

for (uniprot_id in names(surv_results)) {
  res <- surv_results[[uniprot_id]]
  plot_max_time <- ifelse(res$max_time == 0, 1, res$max_time)
  
  # 1. 构建ggsurvplot时不设置标题（避免冲突）
  ggsurv_temp <- ggsurvplot(
    res$fit,
    data = res$data_temp,
    xlab = "Time (Days)",
    ylab = "Survival Probability",
    palette = c("#2E9FDF", "#E7B800"),
    linetype = "solid",
    size = 1.2,
    conf.int = TRUE,
    conf.int.style = "step",  # 虚线显示点态 95% CI，与修订图注一致
    censor = TRUE,
    risk.table = TRUE,
    risk.table.height = 0.25,
    pval = sprintf("Log-rank p = %.4f; BH q = %.3f", res$p_val, q_values[uniprot_id]),
    pval.size = 5,
    pval.coord = c(plot_max_time * 0.03, 0.55),
    legend = "bottom",
    legend.title = "",
    legend.labs = c(paste0("Low (n=", res$n_low, ")"), paste0("High (n=", res$n_high, ")")),
    xlim = c(0, plot_max_time * 1.05),
    ylim = c(0, 1),  # 必须展示第 531 天的终末下降，不能仍裁去 0.6 以下
    break.time.by = ifelse(plot_max_time > 1000, 200, 100),
    ggtheme = theme_bw()
  )
  
  # 2. 手动添加标题（用ggtitle，确保优先级）
  plot_title <- paste("CPTAC-COAD:", uniprot_id, " (", res$symbol, ")", sep = "")
  
  p <- ggsurv_temp$plot +
    # 手动添加标题（关键：直接用ggtitle，避免被覆盖）
    ggtitle(plot_title) +
    # 主题设置：明确标题属性，确保显示
    theme(
      # 标题核心设置：居中、加粗、足够大小、留边距
      plot.title = element_text(
        size = 14, 
        face = "bold", 
        hjust = 0.5,  # 居中
        vjust = 1,    # 避免贴顶部
        margin = margin(b = 10)  # 标题下方留边距，避免与图重叠
      ),
      axis.title = element_text(size = 12),
      axis.text = element_text(size = 10),
      panel.grid = element_line(color = "gray90", linetype = "dashed"),
      legend.position = c(0.05, 0.05),
      legend.justification = c(0, 0),
      legend.background = element_rect(fill = "white"),
      legend.key = element_rect(fill = NA)
    )
  
  # 标出实际随访终点，避免将最后一个常规刻度 500 误认为截断点。
  p <- p + annotate("text", x = plot_max_time, y = 0.04,
                    label = paste0(plot_max_time, " days"), hjust = 1.1, size = 3)

  # suppressWarnings(print(p))
  ggsurv_temp$plot <- p
  plot_list[[uniprot_id]] <- ggsurv_temp  # 保留完整对象，否则风险人数表会丢失
  
  cat("已生成", uniprot_id, "的生存曲线（标题已添加）\n")
}

print(plot_list$Q9Y279)
# A05：导出完整曲线+风险人数表；不要只保存 plot_list$Q9Y279$plot。
pdf(paste0(fig4f_out, "Fig4f_VSIG4_corrected.pdf"), width = 7, height = 6)
print(plot_list$Q9Y279)
dev.off()
png(paste0(fig4f_out, "Fig4f_VSIG4_corrected.png"), width = 2100, height = 1800, res = 300)
print(plot_list$Q9Y279)
dev.off()
write.csv(surv_results$Q9Y279$data_temp,
          paste0(fig4f_out, "VSIG4_patients_original_status.csv"), row.names = FALSE)
# # ====================== 5. 测试显示O60888（含标题） ======================
# if ("O60888" %in% names(plot_list)) {
#   cat("\n正在显示O60888的生存曲线（含标题）：\n")
#   dev.new(width = 10, height = 8)
#   print(plot_list$O60888)
# } else {
#   warning("O60888不在plot_list中，请检查该ID是否存在！")
# }


# ====================== 6. 结果汇总 ======================
p_table <- data.frame(
  UniProt_ID = names(surv_results),
  Symbol = sapply(surv_results, function(x) x$symbol),
  Log_rank_p = sapply(surv_results, function(x) x$p_val),
  N_Low = sapply(surv_results, function(x) x$n_low),
  N_High = sapply(surv_results, function(x) x$n_high),
  FDR_p = as.numeric(q_values)
)
write.csv(p_table, paste0(fig4f_out, "CPTAC_survival_results.csv"), row.names = FALSE)
cat("\n=== 生存分析结果汇总 ===\n")
print(p_table)

# 加载必要的包
library(survival)
library(survminer)
library(tidyverse)
library(ezcox)
library(forestplot)
# 1. 数据准备（示例数据格式）
# 假设数据框包含：
# - 样本ID
# - 生存时间（time）
# - 生存状态（status，0=删失，1=事件）
# - 多个蛋白质表达量（prot1, prot2, ... protN）

# 生成模拟数据示例
set.seed(123)
n <- 200
sample_data <- cbind(combined_data$OS_time, combined_data$OS_status,combined_data[,match(valid_symbols, colnames(combined_data))])
colnames(sample_data)[1:2]<-c('time', 'status')
# 2. 单变量Cox回归分析
# # 自动遍历所有蛋白质变量（从第3列开始）
# univ_models <- lapply(names(sample_data)[3:ncol(sample_data)], function(x) {
#   formula <- as.formula(paste("Surv(time, status) ~", x))
#   cox_model <- coxph(formula, data = sample_data)
#   return(cox_model)
# })
# 
vars_to_analyze <- names(sample_data)[3:ncol(sample_data)]

# 使用ezcox执行单因素Cox回归（替代原lapply循环）
univ_models <- ezcox(
  data = sample_data,
  #surv = Surv(time, status),  # 生存对象（与原公式一致）
  covariates = vars_to_analyze,  # 批量传入待分析变量
  return_models = TRUE  # 关键：指定返回模型对象（默认仅返回结果表）
)


# univ_results <- lapply(univ_models,
#                        function(x){
#                          x <- summary(x)
#                          p.value<-signif(x$wald["pvalue"], digits=3)
#                          wald.test<-signif(x$wald["test"], digits=3)
#                          beta<-signif(x$coef[1], digits=3);#coeficient beta
#                          HR <-signif(x$coef[2], digits=3);#exp(beta)
#                          HR.confint.lower <- signif(x$conf.int[,"lower .95"], 3)
#                          HR.confint.upper <- signif(x$conf.int[,"upper .95"], 3)
#                          HR <- paste0(HR, " (",
#                                       HR.confint.lower, "-", HR.confint.upper, ")")
#                          res<-c(beta, HR, wald.test, p.value)
#                          names(res)<-c("beta", "HR (95% CI for HR)", "wald.test",
#                                        "p.value")
#                          return(res)
#                        })
# res <- t(as.data.frame(univ_results, check.names = FALSE))

set.seed(1234)
res_2_test <-univ_models$res

#构建tabletext
# sample <- as.data.frame(res_2_test)
# tabletext1<-as.character(sample[,1])
# tabletext2<-round(as.numeric(sample[,'HR']),5)
# tabletext3<-paste(round(as.numeric(sample[,'HR']),3),round(as.numeric(sample[,'lower_95']),2),sep="(")
# tabletext4<-paste(tabletext3,round(as.numeric(sample[,'upper_95']),2),sep="-")
# tabletext5<-paste0(tabletext4,sep=")")
# tabletext<-cbind(tabletext1,tabletext2,tabletext5)
# 
# forestplot(labeltext=tabletext, #文本信息  
#            mean = round(sample[,'HR'],3),##HR值
#            lower = round(sample[,"lower_95"],2),##95%置信区间
#            upper = round(sample[,"upper_95"],2),#95%置信区间
#            boxsize = 0.8,##大小
#            graph.pos=4,#图在表中的列位置
#            graphwidth = unit(0.4,"npc"),#图在表中的宽度比例
#            fn.ci_norm="fpDrawDiamondCI",#box类型选择钻石,可以更改fpDrawNormalCI；fpDrawCircleCI等
#            col=fpColors(box="steelblue", lines="black", zero = "black"),#颜色设置
#            lwd.ci=2,ci.vertices.height = 0.1,ci.vertices=TRUE,#置信区间用线宽、高、型
#            zero=1,#zero线横坐标
#            lwd.zero=2,#zero线宽
#            grid=T,
#            lwd.xaxis=2,#X轴线宽
#            title="Hazard Ratio",
#            xlab="",#X轴标题
#            clip=c(-Inf,3),#边界
#            colgap = unit(0.5,"cm")   
# )

# ggplot(res_2_test, aes(HR, Variable))+  ##定义X轴和Y轴，以类型分类
#   geom_point(size=2.5)+  #点的大小
#   geom_errorbarh(aes(xmax =upper_95, xmin = lower_95), height = 0.4)+ ##95%置信区间，误差线
#   geom_vline(aes(xintercept = 1))+ #以1为分界线
#   xlab('HR(95%CI)') + ylab(' ')+  #定义横纵坐标
#   theme_bw(base_size = 12)


#排序 ，标识type信息
# ggplot(res_2_test, aes(HR, reorder(Variable,HR),col=sig,shape=sig))+  
#   geom_point(size=2.5)+  
#   geom_errorbarh(aes(xmax =upper_95, xmin = lower_95), height = 0.4)+ 
#   geom_vline(aes(xintercept = 1))+ 
#   xlab('HR(95%CI)') + ylab(' ')+  
#   theme_bw(base_size = 12)+ 
#   scale_color_manual(values = c("gray", "red")) #设置颜色

ref_df <- data.frame(
  UNIPROT = c("P0DJI8", "P0DJI9", "P30086", "P32754", "P62328", "Q8NBJ4", "Q9UEW3", "Q9Y279"),
  SYMBOL = c("SAA1", "SAA2", "PEBP1", "HPD", "TMSB4X", "GOLM1", "MARCO", "VSIG4"),
  association = c("PMID:36345658", "PMID:24744574", "PMID:17179102", "PMID:36813208", "PMID:17072345", "PMID:40414849", "PMID:36958650", "PMID:40405491")
)

colnames(res_2_test)[1]<-'SYMBOL'
res_2_test$significant <- c(rep(NA,length(res_2_test$SYMBOL)))
res_2_test$significant[which(res_2_test$p.value<0.05)] = 'p<0.05'

all_gene_df <- bitr(target_uniprot,
                    fromType = "UNIPROT",
                    toType = "SYMBOL",
                    OrgDb = org.Hs.eg.db)
head(ref_df)
head(all_gene_df)

library(dplyr)  # 用于数据合并和处理

merge_ref_all <- full_join(
  ref_df, 
  all_gene_df, 
  by = "SYMBOL",  # 按SYMBOL合并
  suffix = c("_ref", "_all")  # 重复列加后缀区分（如UNIPROT_ref、UNIPROT_all）
) %>%
  # 合并重复的UNIPROT列（优先保留ref_df的，无则用all_gene_df的）
  mutate(UNIPROT = coalesce(UNIPROT_ref, UNIPROT_all)) %>%
  select(-UNIPROT_ref, -UNIPROT_all)  # 删除临时重复列

# 2. 再与res_2_test合并（按SYMBOL）
merged_all <- full_join(
  merge_ref_all, 
  res_2_test, 
  by = "SYMBOL",  # 按SYMBOL合并
  suffix = c("", "_test")  # 剩余重复列加后缀（如已有列名重复时）
)
# 3. 填充缺失值：数值型填0，逻辑型填FALSE，字符型保持空（或填""）
final_df <- merged_all %>%
  mutate(
    # 数值型列（如beta、HR、n_contrast）的NA填充为0
    across(where(is.numeric), ~replace(., is.na(.), NA)),
    # 逻辑型列（如is_control）的NA填充为FALSE
    across(where(is.logical), ~replace(., is.na(.), FALSE)),
    # 字符型列（如UNIPROT、association）的NA填充为空字符串（按需调整）
    across(where(is.character), ~replace(., is.na(.), NA))
  )


# ggplot(final_df, aes(HR, reorder(SYMBOL,HR),col=sig,shape=sig))+  
#   geom_point(size=2.5)+  
#   geom_errorbarh(aes(xmax =upper_95, xmin = lower_95), height = 0.4)+ 
#   geom_vline(aes(xintercept = 1))+ 
#   xlab('HR(95%CI)') + ylab(' ')+  
#   theme_bw(base_size = 12)+ 
#   scale_color_manual(values = c("gray", "red")) #设置颜色
# 
# ggplot(final_df, aes(HR, reorder(SYMBOL, HR), col = sig, shape = sig)) +  
#   # 原始图层：点、误差线、参考线
#   geom_point(size = 2.5) +  
#   geom_errorbarh(aes(xmax = upper_95, xmin = lower_95), height = 0.4) + 
#   geom_vline(aes(xintercept = 1), linetype = "dashed", color = "gray50") + 
#   # 添加association注释（仅非NA值，橙色，置于误差线右侧）
#   geom_text(
#     data = subset(final_df, !is.na(association)),  # 筛选非NA的association
#     aes(x = upper_95,  # 定位在误差线上限处（可加偏移量避免重叠）
#         y = reorder(SYMBOL, HR),  # 与y轴排序匹配，确保对齐
#         label = association),  # 显示association内容
#     color = "orange",  # 橙色标注
#     hjust = -0.1,  # 文本在x位置右侧（避免与误差线重叠）
#     size = 3.5,  # 文本大小
#     inherit.aes = FALSE  # 不继承主图的颜色/形状映射
#   ) +
#   # 轴标签与主题设置
#   xlab('HR(95%CI)') + 
#   ylab('') +  
#   theme_bw(base_size = 12) + 
#   scale_color_manual(values = c("gray", "red")) +
#   # 可选：扩大x轴范围，避免文本超出图边界
#   xlim(min(final_df$lower_95, na.rm = TRUE), 
#        max(final_df$upper_95, na.rm = TRUE) * 1.2)  # 右侧留1.2倍空间


ggplot(final_df, aes(HR, reorder(SYMBOL, HR), col = significant, shape = significant)) +  
  # 原始图层：点、误差线、参考线
  geom_point(size = 2.5) +  
  geom_errorbarh(aes(xmax = upper_95, xmin = lower_95), height = 0.4) + 
  geom_vline(aes(xintercept = 1), linetype = "dashed", color = "gray50") + 
  # 添加association注释：分情况定位
  geom_text(
    data = subset(final_df, !is.na(association)),  
    aes(
      x = ifelse(!is.na(upper_95), upper_95, 1),  
      y = reorder(SYMBOL, HR),
      label = association
    ),
    color = "orange",  
    hjust = ifelse(subset(final_df, !is.na(association))$upper_95 %>% is.na(), 
                   -0.1, -0.1),
    size = 3.5,
    inherit.aes = FALSE
  ) +
  # 轴标签与主题设置
  xlab('HR(95%CI)') + 
  ylab('') +  
  theme_bw(base_size = 12) + 
  scale_color_manual(values = c("gray", "red")) +
  # 扩大x轴范围，避免文本超出边界
  xlim(min(final_df$lower_95, na.rm = TRUE), 
       max(c(final_df$upper_95, 1.2*ifelse(is.na(final_df$upper_95),1,final_df$upper_95)), na.rm = TRUE)) +
  # 调整图例位置和大小（核心修改）
  theme(
    legend.position = "bottomright",  # 图例置于右下角
    legend.background = element_rect(fill = NA),  # 取消图例背景色，节省空间
    legend.margin = margin(t = 0, r = 0, b = 0, l = 0, unit = "pt"),  # 取消图例边距
    legend.key.size = unit(8, "pt"),  # 缩小图例符号大小
    legend.spacing.x = unit(4, "pt"),  # 减小图例内部水平间距
    legend.box.spacing = unit(0, "pt")  # 减小图例与图边界的间距
  )

# windowsFonts(Arial = windowsFont("Arial"))  # Windows
# ggplot(final_df, aes(HR, reorder(SYMBOL, HR), col = sig, shape = sig)) +  
#   # 核心图层：点（更小更精致）、误差线（细线条）
#   geom_point(size = 2, stroke = 0.8) +  # 减小点大小，增加轮廓精细度
#   geom_errorbarh(
#     aes(xmax = upper_95, xmin = lower_95), 
#     height = 0.3, linewidth = 0.5  # 细误差线，减小高度
#   ) + 
#   # 参考线（细虚线，浅灰色）
#   geom_vline(xintercept = 1, linetype = "dashed", color = "grey40", linewidth = 0.4) + 
#   # Association注释（橙色，更细字体）
#   geom_text(
#     data = subset(final_df, !is.na(association)),  
#     aes(
#       x = ifelse(!is.na(upper_95), upper_95, 1),  
#       y = reorder(SYMBOL, HR),
#       label = association
#     ),
#     color = "#FF7F0E",  # Nature常用橙色（饱和度适中）
#     hjust = -0.1, 
#     size = 2.8,  # 减小字体
#     family = "Arial",  # Nature字体
#     inherit.aes = FALSE
#   ) +
#   # 坐标轴标签（简洁，Arial字体）
#   xlab("HR (95% CI)") + 
#   ylab("") +  
#   # Nature风格主题（无背景、无网格、细线条）
#   theme_classic(base_size = 10, base_family = "Arial") +  # 小号字体，Arial
#   theme(
#     # 移除顶部/右侧边框
#     axis.line.y = element_line(color = "black", linewidth = 0.4),
#     axis.line.x = element_line(color = "black", linewidth = 0.4),
#     axis.ticks = element_line(color = "black", linewidth = 0.4),
#     # 图例（右下角，紧凑，无背景）
#     legend.position = c(0.95, 0.05),  # 精确坐标定位（右下）
#     legend.justification = c(1, 0),
#     legend.background = element_blank(),
#     legend.margin = margin(0, 0, 0, 0),
#     legend.key.size = unit(6, "pt"),
#     legend.text = element_text(size = 8),
#     legend.title = element_blank(),  # 隐藏图例标题
#     # 坐标轴文字（小号，紧凑）
#     axis.text = element_text(size = 9, color = "black"),
#     axis.title.x = element_text(size = 10, color = "black", margin = margin(t = 5)),
#     # 移除多余空白
#     plot.margin = margin(5, 15, 5, 5, unit = "pt")
#   ) +
#   # Nature风格配色（低饱和度）
#   scale_color_manual(values = c("grey50", "#D32F2F")) +  # 灰色/深红色
#   scale_shape_manual(values = c(19, 17)) +  # 圆形（不显著）/三角形（显著）
#   # 扩大x轴右侧空间（避免文本溢出）
#   xlim(
#     min(final_df$lower_95, na.rm = TRUE), 
#     max(c(final_df$upper_95, 1.2*ifelse(is.na(final_df$upper_95),1,final_df$upper_95)), na.rm = TRUE)
#   )

final_df <- final_df %>%
  mutate(
    significant = case_when(
      significant == "p<0.05" ~ "p<0.05",  # 保留显著组
      is.na(significant) ~ "ns",  # NA转为"Not significant"
      TRUE ~ "ns"  # 其他情况归为不显著
    ) %>% 
      factor(levels = c("ns", "p<0.05"))  # 明确水平顺序
  )

# 2. 绘图：确保颜色与水平严格对应
ggplot(final_df, aes(HR, reorder(SYMBOL, HR), col = significant, shape = significant)) +  
  geom_point(size = 2.5) +  
  geom_errorbarh(aes(xmax = upper_95, xmin = lower_95), height = 0.4) + 
  geom_vline(xintercept = 1, linetype = "dashed", color = "gray50") + 
  # association注释
  geom_text(
    data = subset(final_df, !is.na(association)),  
    aes(x = ifelse(!is.na(upper_95), upper_95, 1), y = reorder(SYMBOL, HR), label = association),
    color = "orange", hjust = -0.1, size = 3.5, inherit.aes = FALSE
  ) +
  xlab('HR(95%CI)') + ylab('') +  
  theme_bw(base_size = 12) + 
  # 3. 颜色映射：明确对应"Not significant"和"p<0.05"
  scale_color_manual(
    values = c("ns" = "gray50", "p<0.05" = "red"),  # 严格对应水平
    name = "Significance"  # 图例标题
  ) +
  # 形状映射（可选，与颜色匹配）
  scale_shape_manual(
    values = c("ns" = 19, "p<0.05" = 17),  # 圆形 vs 三角形
    name = "Significance"
  ) +
  # 图例位置与样式
  theme(
    legend.position = c(0.95, 0.05),
    legend.justification = c(1, 0),
    legend.background = element_rect(fill = NA),
    legend.key.size = unit(10, "pt")
  ) +
  xlim(0, max(final_df$upper_95, na.rm = TRUE) * 1.2)  # 调整x轴范围
