#!/usr/bin/env Rscript
# Corrected ASW figure rendering and independent R verification.
# Intended to run directly from RStudio via source(); it never rewrites source data,
# UMAP coordinates, or the Python recalculation results.

# ---- User parameters -------------------------------------------------------
project_dir <- "inputs/p/outputs/ASW_correction_20261004"
result_dir <- file.path(project_dir, "results_final")
results_csv <- file.path(result_dir, "ASW_current_results.csv")
plots_dir <- file.path(project_dir, "plots")
save_individual_panels <- TRUE
asw_tolerance <- 1e-8
extra_R_lib <- "inputs/p/MCP_r1_R_reanalysis/R_libs"
# Use the existing local R library; never install or change system packages.
if (dir.exists(extra_R_lib)) .libPaths(c(extra_R_lib, .libPaths()))

# ---- Dependencies ----------------------------------------------------------
needed <- c("ggplot2", "gtable", "cluster")
missing <- needed[!vapply(needed, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing)) stop("Missing R package(s): ", paste(missing, collapse = ", "),
                          ". Install them outside this script and rerun.")
suppressPackageStartupMessages({
  library(ggplot2)
  library(cluster)
})

if (!file.exists(results_csv)) stop("Expected Python output not found: ", results_csv)
dir.create(plots_dir, recursive = TRUE, showWarnings = FALSE)

results <- read.csv(results_csv, stringsAsFactors = FALSE, check.names = FALSE)
required <- c("source_id", "dataset", "combination", "method", "ARI", "ASW", "NMI",
              "PS", "matrix_path", "assignment_file", "n_samples", "n_features")
absent <- setdiff(required, names(results))
if (length(absent)) stop("Results schema is missing: ", paste(absent, collapse = ", "))

read_matrix <- function(path) {
  if (!file.exists(path)) stop("Matrix missing: ", path)
  # Python matrices are CSVs with row IDs first and binary truth labels last.
  d <- read.csv(path, row.names = 1, check.names = FALSE)
  if (ncol(d) < 2) stop("No feature columns in: ", path)
  X <- as.matrix(d[, seq_len(ncol(d) - 1), drop = FALSE])
  storage.mode(X) <- "double"
  truth <- as.numeric(d[[ncol(d)]])
  if (any(!is.finite(X)) || any(!is.finite(truth))) stop("Non-finite input: ", path)
  list(X = X, truth = truth, row_id = rownames(d))
}

read_umap <- function(path) {
  if (!file.exists(path)) stop("Saved UMAP coordinate file missing: ", path)
  d <- read.csv(path, row.names = 1, check.names = FALSE)
  if (!all(c("UMAP1", "UMAP2", "cluster") %in% names(d)))
    stop("Unexpected UMAP columns in: ", path)
  # The archived CSV contains UTF-8 bytes, while the R session can start in C locale.
  # Decode explicitly rather than allowing a locale-dependent legend label.
  d$cluster <- iconv(as.character(d$cluster), from = "UTF-8", to = "UTF-8")
  d
}

label_text <- function(dataset, truth) {
  if (dataset == "TPD_dis") return(ifelse(truth == 1, "malignant", "benign"))
  # intToUtf8 avoids dependence on the process locale/source-file decoding.
  if (dataset == "U2OS_filtered_rb") return(ifelse(truth == 1,
    paste0("IFN-", intToUtf8(0x03B3)), "Control"))
  if (dataset == "TPD_ret") return(ifelse(truth == 1, "malignant", "benign"))
  if (dataset == "CRC") return(ifelse(truth == 1, "Normal", "Cancer"))
  as.character(truth)
}

coord_path <- function(dataset, method) {
  ncs <- "inputs/n/Figures/res"
  if (dataset == "TPD_dis") {
    return(file.path(ncs, "Fig4", paste0(if (method == "MVDEA") "MVDEA" else method,
                                           "_umap_clustering.csv")))
  }
  if (dataset == "U2OS_filtered_rb") {
    name <- c(MVDEA = "MCP", dlfq = "dlfq", maxlfq = "maxlfq", top3 = "top3", top1 = "top1")[[method]]
    return(file.path(ncs, "Fig5", paste0("umap_", name, ".csv")))
  }
  NA_character_
}

verify_one <- function(row, need_coords = FALSE) {
  m <- read_matrix(row$matrix_path)
  a <- read.csv(row$assignment_file, stringsAsFactors = FALSE, check.names = FALSE)
  need_assign <- c("row_position", "saved_row_id", "truth", "cluster", "silhouette")
  if (!all(need_assign %in% names(a))) stop("Unexpected assignment file: ", row$assignment_file)
  if (nrow(m$X) != row$n_samples || ncol(m$X) != row$n_features)
    stop("Result dimensions disagree with matrix for ", row$dataset, "/", row$method)
  if (nrow(a) != nrow(m$X) || !identical(as.character(a$saved_row_id), as.character(m$row_id)))
    stop("Assignment ordering does not match matrix rows for ", row$dataset, "/", row$method)
  if (!isTRUE(all.equal(as.numeric(a$truth), m$truth, tolerance = 0)))
    stop("Assignment truth labels do not match final matrix labels for ", row$dataset, "/", row$method)

  # Independent check: R cluster::silhouette on Euclidean distances of actual features.
  sil <- cluster::silhouette(as.integer(a$cluster), stats::dist(m$X, method = "euclidean"))
  asw_r <- mean(sil[, "sil_width"])
  delta <- asw_r - as.numeric(row$ASW)
  if (abs(delta) > asw_tolerance)
    stop(sprintf("R ASW mismatch for %s/%s: %.17g", row$dataset, row$method, delta))

  coord_ok <- NA
  coord_n <- NA_integer_
  cp <- coord_path(row$dataset, row$method)
  if (need_coords && !is.na(cp)) {
    u <- read_umap(cp)
    coord_n <- nrow(u)
    coord_ok <- nrow(u) == nrow(m$X) &&
      identical(as.character(u$cluster), as.character(label_text(row$dataset, m$truth)))
    if (!coord_ok) stop("Saved UMAP coordinate label ordering differs from final matrix: ", cp)
  }
  data.frame(source_id = row$source_id, dataset = row$dataset, combination = row$combination,
             method = row$method, matrix_path = row$matrix_path, assignment_file = row$assignment_file,
             n_samples = nrow(m$X), n_features = ncol(m$X), asw_python = row$ASW,
             asw_r_cluster_silhouette = asw_r, difference = delta,
             coordinate_path = ifelse(is.na(cp), "", cp), coordinate_n = coord_n,
             coordinate_label_order_match = coord_ok, stringsAsFactors = FALSE)
}

main_specs <- list(
  Fig4 = list(source_id = "paper_20260320", dataset = "TPD_dis",
              combination = "DIA_dlfq_maxlfq_top3", style = "fig4"),
  Fig5 = list(source_id = "paper_20260320", dataset = "U2OS_filtered_rb",
              combination = "DIA_dlfq_maxlfq", style = "fig5")
)
plot_methods <- c("dlfq", "maxlfq", "top3", "top1", "MVDEA")

main_rows <- lapply(main_specs, function(s) {
  d <- subset(results, source_id == s$source_id & dataset == s$dataset &
                        combination == s$combination & method %in% plot_methods)
  d <- d[match(plot_methods, d$method), , drop = FALSE]
  if (nrow(d) != length(plot_methods) || anyNA(d$method))
    stop("Missing a five-panel main-figure method for ", s$dataset)
  d
})
verification <- do.call(rbind, lapply(main_rows, function(d)
  do.call(rbind, lapply(seq_len(nrow(d)), function(i) verify_one(d[i, ], TRUE)))))
write.csv(verification, file.path(plots_dir, "main_panel_R_ASW_verification.csv"), row.names = FALSE)

metric_label <- function(row) sprintf("ARI = %.2f\nASW = %.2f\nNMI = %.2f",
                                      as.numeric(row$ARI), as.numeric(row$ASW), as.numeric(row$NMI))

make_panel <- function(row, style) {
  u <- read_umap(coord_path(row$dataset, row$method))
  x_range <- diff(range(u$UMAP1)); y_range <- diff(range(u$UMAP2))
  if (style == "fig4") {
    ann_x <- max(u$UMAP1) - .03 * x_range
    ann_y <- min(u$UMAP2) + .03 * y_range
    return(ggplot(u, aes(UMAP1, UMAP2, color = cluster)) +
      geom_point(size = 2, alpha = .7, stroke = .1) + labs(x = "UMAP1", y = "UMAP2") +
      theme_bw(base_size = 12) +
      theme(panel.background = element_rect(fill = "white", colour = NA),
            plot.background = element_rect(fill = "white", colour = NA),
            panel.border = element_rect(colour = "black", fill = NA, linewidth = .7),
            axis.title = element_text(face = "bold", size = 14), axis.text = element_blank(),
            axis.ticks = element_blank(), axis.ticks.length = grid::unit(0, "mm"),
            legend.title = element_text(face = "bold", size = 17), legend.text = element_text(size = 15),
            legend.key = element_rect(fill = "white", colour = NA), panel.grid = element_blank(),
            plot.margin = margin(5, 5, 5, 5, unit = "mm")) +
      scale_color_manual(name = "Condition", values = c("#15983D", "#FFA000", "#91D1C2FF", "#E64B35FF", "#4878CF")) +
      annotate("label", x = ann_x, y = ann_y, label = metric_label(row), hjust = .9, vjust = 0,
               size = 3, fill = scales::alpha("white", .5), color = "black", linewidth = .3,
               label.r = grid::unit(.2, "lines")))
  }
  ann_x <- min(u$UMAP1) + .02 * x_range
  ann_y <- max(u$UMAP2) - .02 * y_range
  # Keep an ASCII grouping key internally; display gamma only through plotmath.
  u$cluster_id <- ifelse(u$cluster == "Control", "Control", "IFN_gamma")
  hull <- do.call(rbind, lapply(split(u, u$cluster_id), function(z) {
    if (nrow(z) < 3) return(z[0, ])
    z[c(chull(z$UMAP1, z$UMAP2), chull(z$UMAP1, z$UMAP2)[1]), ]
  }))
  centers <- aggregate(cbind(UMAP1, UMAP2) ~ cluster_id, u, mean)
  ggplot(u, aes(UMAP1, UMAP2, color = cluster_id)) + geom_point(size = 3, alpha = .8) +
    geom_polygon(data = hull, aes(group = cluster_id), fill = NA, linewidth = 1) +
    geom_point(data = centers, shape = 3, size = 4, stroke = 1.2) + labs(x = "UMAP1", y = "UMAP2") +
    theme_minimal(base_size = 12) +
    theme(axis.text = element_blank(), axis.ticks = element_blank(), legend.position = "right",
          panel.grid = element_line(color = "grey90", linewidth = .2)) +
    scale_color_manual(name = "Condition", values = c(Control = "#15d08a", IFN_gamma = "#f2ca01"),
      breaks = c("Control", "IFN_gamma"),
      labels = c("Control", expression("IFN-" * gamma))) +
    annotate("label", x = ann_x, y = ann_y, label = metric_label(row), hjust = 0, vjust = 1,
             size = 4, fill = scales::alpha("white", .25), linewidth = 0,
             label.r = grid::unit(.15, "lines"))
}

save_main_figure <- function(name, d, style) {
  panels <- lapply(seq_len(nrow(d)), function(i) make_panel(d[i, ], style) + ggtitle(
    if (d$method[i] == "MVDEA") "MCP" else d$method[i]))
  # Extract the legend grob while preserving the original panel arrangement.
  gt <- ggplotGrob(panels[[1]] + theme(legend.position = "right"))
  guide <- gt$grobs[[which(vapply(gt$grobs, function(g) g$name, "") == "guide-box")]]
  panels <- lapply(panels, `+`, theme(legend.position = "none", plot.title = element_text(hjust = .5)))
  if (style == "fig4") {
    panels[[1]] <- panels[[1]] + theme(axis.title.x = element_blank())
    panels[[2]] <- panels[[2]] + theme(axis.title.x = element_blank(), axis.title.y = element_blank())
    panels[[3]] <- panels[[3]] + theme(axis.title.x = element_blank(), axis.title.y = element_blank())
    panels[[5]] <- panels[[5]] + theme(axis.title.y = element_blank())
    g <- gtable::gtable(widths = grid::unit(rep(1, 3), "null"),
                         heights = grid::unit(rep(1, 2), "null"))
    grobs <- c(lapply(panels, ggplotGrob), list(guide))
    g <- gtable::gtable_add_grob(g, grobs = grobs,
                                  t = c(1, 1, 1, 2, 2, 2), l = c(1, 2, 3, 1, 2, 3))
  } else {
    panels[[1]] <- panels[[1]] + theme(axis.title.x = element_blank())
    panels[[2]] <- panels[[2]] + theme(axis.title.x = element_blank(), axis.title.y = element_blank())
    panels[[4]] <- panels[[4]] + theme(axis.title.y = element_blank())
    g <- gtable::gtable(widths = grid::unit(rep(1, 2), "null"),
                         heights = grid::unit(rep(1, 3), "null"))
    grobs <- c(lapply(panels, ggplotGrob), list(guide))
    g <- gtable::gtable_add_grob(g, grobs = grobs,
                                  t = c(1, 1, 2, 2, 3, 3), l = c(1, 2, 1, 2, 1, 2))
  }
  g
  pdf <- file.path(plots_dir, paste0(name, "_corrected_ASW_UMAP.pdf"))
  png <- file.path(plots_dir, paste0(name, "_corrected_ASW_UMAP.png"))
  svg <- file.path(plots_dir, paste0(name, "_corrected_ASW_UMAP.svg"))
  ggsave(pdf, g, width = if (style == "fig4") 12 else 8, height = if (style == "fig4") 7 else 12,
         device = grDevices::cairo_pdf)
  ggsave(png, g, width = if (style == "fig4") 12 else 8, height = if (style == "fig4") 7 else 12,
         dpi = 300)
  ggsave(svg, g, width = if (style == "fig4") 12 else 8, height = if (style == "fig4") 7 else 12,
         dpi = 300)
  if (save_individual_panels) for (i in seq_along(panels)) {
    p <- panels[[i]] + theme(legend.position = "right")
    ggsave(file.path(plots_dir, sprintf("%s_%s_corrected_ASW.png", name, d$method[i])), p,
           width = 4, height = 4, dpi = 300)
  }
  invisible(g)
}

for (i in seq_along(main_specs)) {
  s <- main_specs[[i]]
  save_main_figure(names(main_specs)[i], main_rows[[i]], s$style)
  write.csv(main_rows[[i]], file.path(plots_dir, paste0(names(main_specs)[i], "_corrected_metrics.csv")),
            row.names = FALSE)
}

# Current datasets only: no archive pooling.  One ASW heatmap per dataset/source.
heat_specs <- list(
  TPD_dis = list(source_id = "paper_20260320", dataset = "TPD_dis"),
  TPD_ret = list(source_id = "paper_20260320", dataset = "TPD_ret"),
  CRC = list(source_id = "figures_legacy", dataset = "CRC"),
  U2OS = list(source_id = "paper_20260320", dataset = "U2OS_filtered_rb")
)
for (nm in names(heat_specs)) {
  s <- heat_specs[[nm]]
  h <- subset(results, source_id == s$source_id & dataset == s$dataset)
  if (!nrow(h)) { warning("No current heatmap rows for ", nm); next }
  h$method <- factor(h$method, levels = c("dlfq", "maxlfq", "top3", "top1", "MVDEA", "hurdle"))
  h$combination <- factor(h$combination, levels = unique(h$combination))
  p <- ggplot(h, aes(combination, method, fill = ASW)) + geom_tile(color = "white", linewidth = .3) +
    geom_text(aes(label = sprintf("%.3f", ASW)), size = 3) +
    scale_fill_gradient2(low = "#3C5488", mid = "white", high = "#E64B35", midpoint = 0,
                         name = "Corrected ASW") + labs(x = "View combination", y = "Method",
                         title = paste0(nm, ": corrected ASW by combination")) +
    scale_y_discrete(labels = c(MVDEA = "MCP")) +
    theme_bw(base_size = 11) + theme(axis.text.x = element_text(angle = 35, hjust = 1),
                                     panel.grid = element_blank())

  ggsave(file.path(plots_dir, paste0("ASW_heatmap_", nm, ".pdf")), p, width = 10, height = 4.5)
  ggsave(file.path(plots_dir, paste0("ASW_heatmap_", nm, ".png")), p, width = 10, height = 4.5, dpi = 300)
  ggsave(file.path(plots_dir, paste0("ASW_heatmap_", nm, ".svg")), p, width = 10, height = 4.5, dpi = 300)
  write.csv(h, file.path(plots_dir, paste0("ASW_heatmap_", nm, "_data.csv")), row.names = FALSE)
}

writeLines(capture.output(sessionInfo()), file.path(plots_dir, "R_sessionInfo.txt"))
message("Completed corrected ASW replotting in: ", normalizePath(plots_dir, winslash = "/"))
