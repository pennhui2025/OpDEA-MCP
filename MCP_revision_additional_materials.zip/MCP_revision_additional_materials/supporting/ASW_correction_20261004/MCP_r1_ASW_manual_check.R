# 独立 R 复核：使用已保存的聚类分配，重新计算所有归档的 ASW。
# 可直接在 RStudio source，不需要运行 DEA，也不重新拟合 KMeans。
# Python 和 R 的 KMeans 初始化实现不完全一样；这里固定同一批 cluster IDs。
project_dir <- "inputs/p/outputs/ASW_correction_20261004"
result_dir <- file.path(project_dir, "results_final")
if (!requireNamespace("cluster", quietly = TRUE)) stop("Missing R package: cluster")
d <- read.csv(file.path(result_dir, "ASW_all_archived_results.csv"), check.names = FALSE)
u <- d[!duplicated(d$matrix_numeric_sha256), ]
u$ASW_R <- NA_real_
u$max_individual_error <- NA_real_

for (i in seq_len(nrow(u))) {
  # 第一列是保存的行号，最后一列是真实标签，都不放进特征 X。
  m <- read.csv(u$matrix_path[i], row.names = 1, check.names = FALSE)
  X <- as.matrix(m[, -ncol(m), drop = FALSE])
  truth <- as.numeric(m[[ncol(m)]])
  a <- read.csv(u$assignment_file[i])
  stopifnot(nrow(X) == nrow(a), all(is.finite(X)),
            identical(rownames(m), as.character(a$saved_row_id)),
            identical(truth, as.numeric(a$truth)))
  # silhouette 的第一个参数是聚类分配；第二个参数是特征矩阵距离。
  s <- cluster::silhouette(as.integer(a$cluster), dist(X, method = "euclidean"))
  u$ASW_R[i] <- mean(s[, "sil_width"])
  u$max_individual_error[i] <- max(abs(s[, "sil_width"] - a$silhouette))
  stopifnot(abs(u$ASW_R[i] - u$ASW[i]) < 1e-8, u$max_individual_error[i] < 1e-8)
  if (i %% 25 == 0) message("Verified ", i, "/", nrow(u), " distinct inputs")
}
d$ASW_R <- u$ASW_R[match(d$matrix_numeric_sha256, u$matrix_numeric_sha256)]
d$R_minus_Python <- d$ASW_R - d$ASW
write.csv(u, file.path(result_dir, "ASW_R_validation_unique_inputs.csv"), row.names = FALSE)
write.csv(d, file.path(result_dir, "ASW_R_validation_all_records.csv"), row.names = FALSE)
message("PASS: ", nrow(u), " distinct inputs; ", nrow(d), " archived records; max ASW difference = ",
        format(max(abs(d$R_minus_Python)), scientific = TRUE))
