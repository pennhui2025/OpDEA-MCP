"""Correct archived sample-clustering ASW without rerunning DEA/MCP.

直接在 PyCharm 运行；只读原始目录，结果写入本脚本旁的 results。
ASW 的 X 必须是实际用于 KMeans 的定量特征矩阵，不是疾病/处理标签。
Historical versions are kept separate; do NOT pool their results.
"""
from pathlib import Path
import argparse
import hashlib
import json
import platform
import re
import sys

import numpy as np
import pandas as pd
import scipy
from scipy.spatial.distance import cdist
import sklearn
from sklearn.cluster import KMeans
from sklearn.metrics import (adjusted_rand_score, normalized_mutual_info_score,
                             silhouette_samples, silhouette_score, confusion_matrix)
from threadpoolctl import threadpool_limits

HERE = Path(__file__).resolve().parent
NCS = Path(r'inputs/n')
PRIOR = HERE.parent / 'TPD_clustering_corrected_ASW_20260921/verified_run'
METHODS = ['dlfq', 'maxlfq', 'top3', 'top1', 'MVDEA', 'hurdle']
METRICS = ['ARI', 'ASW', 'NMI', 'PS']
PARAMETERS = dict(init='k-means++', n_init=10, random_state=2024,
                  max_iter=300, tol=1e-4, algorithm='lloyd')


def cluster_perform(data, label):
    """可替换原脚本的同名函数，返回顺序保持 [ARI, ASW, NMI, PS], y。

    显式固定 n_init，避免 sklearn 新旧版本默认次数不同。
    若需要完全保留旧聚类，请使用旧运行实际保存的 y，不能仅凭汇总指标恢复。
    """
    X = np.asarray(data, dtype=float)
    truth = np.asarray(label).ravel()
    if X.ndim != 2 or X.shape[0] != len(truth) or not np.isfinite(X).all():
        raise ValueError('Expected finite samples-by-features matrix aligned to labels')
    y = KMeans(n_clusters=len(np.unique(truth)), **PARAMETERS).fit_predict(X)
    asw = silhouette_score(X, y, metric='euclidean')
    cm = confusion_matrix(truth, y)
    return [adjusted_rand_score(truth, y), asw,
            normalized_mutual_info_score(truth, y), cm.max(axis=0).sum()/len(y)], y


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def manual_silhouettes(X, groups):
    """独立复核 silhouette 公式；不是再次调用 sklearn。

    a=同簇其他样本平均距离；b=其它簇平均距离的最小值；s=(b-a)/max(a,b)。
    单元素簇 silhouette=0，与标准定义一致。
    """
    D = cdist(X, X, metric='euclidean')
    labels = np.unique(groups)
    s = np.zeros(len(X))
    for i in range(len(X)):
        own = np.flatnonzero(groups == groups[i])
        own = own[own != i]
        if len(own) == 0:
            continue
        a = D[i, own].mean()
        b = min(D[i, groups == g].mean() for g in labels if g != groups[i])
        s[i] = (b-a)/max(a, b) if max(a, b) else 0.0
    return s


def read_features(path):
    # 原 Python to_csv 写出：第1列为行号、末列为真实类别；中间才是特征。
    d = pd.read_csv(path, index_col=0)
    if d.shape[1] < 2:
        raise ValueError(f'No usable feature column: {path}')
    X = d.iloc[:, :-1].to_numpy(dtype=float)
    truth = d.iloc[:, -1].to_numpy(dtype=float)
    if not np.isfinite(X).all() or not np.isfinite(truth).all():
        raise ValueError(f'Non-finite values: do not silently change preprocessing: {path}')
    if not np.isin(truth, [0, 1]).all():
        raise ValueError(f'Unexpected last-column labels: {path}')
    return X, truth, d.index.astype(str).to_numpy()


def resolve_matrix(folder, dataset, comb, method):
    flag = '_p' if dataset.endswith('_p') else ('2b_cb_mp' if dataset == 'U2OS_2b_cb_mp' else '')
    stem = dataset + flag
    if method in ('MVDEA', 'hurdle'):
        stem += comb + ('mvdea' if method == 'MVDEA' else 'hurdle')
    else:
        stem += method
    return folder / (stem + '.csv')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--ncs-root', type=Path, default=NCS)
    parser.add_argument('--prior-tpd-root', type=Path, default=PRIOR)
    parser.add_argument('--output-dir', type=Path, default=HERE/'results_final')
    args = parser.parse_args()
    out = args.output_dir.resolve()
    if out.exists():
        raise FileExistsError(f'Choose a new output directory; originals/results not overwritten: {out}')
    out.mkdir(parents=True)
    (out/'assignments').mkdir()
    sources = {
        'paper_20260320': args.ncs_root/'Figures/data/clustering_20260320',
        'figures_legacy': args.ncs_root/'Figures/data/clustering',
        'codes_legacy': args.ncs_root/'Supplementary_codes/res/clustering',
        'codes_20260320': args.ncs_root/'Supplementary_codes/res/clustering_20260320',
        'codes_check1': args.ncs_root/'Supplementary_codes/res/clustering_20260320_check1',
    }
    cache, records, inputs, coverage = {}, [], {}, []

    def calculate(matrix, meta, historical=None):
        inputs[str(matrix)] = sha(matrix)
        X, truth, row_id = read_features(matrix)
        # 相同数值矩阵只算一次；不同归档仍保留独立记录，绝不平均归档版本。
        h = hashlib.sha256()
        h.update(str(X.shape).encode()); h.update(X.tobytes()); h.update(truth.tobytes())
        # Include row IDs as well: equal numbers with different IDs must not reuse assignments.
        h.update(json.dumps(row_id.tolist(), ensure_ascii=True).encode('utf-8'))
        key = h.hexdigest()
        if key not in cache:
            scores, groups = cluster_perform(X, truth)
            individual = silhouette_samples(X, groups, metric='euclidean')
            manual = manual_silhouettes(X, groups)
            error = float(np.max(np.abs(individual-manual)))
            if error > 1e-8:
                raise AssertionError(f'Independent ASW validation failed: {error}')
            # 仅诊断用：复算旧错误公式，不能用于论文中解释 ASW。
            invalid = silhouette_score(truth.reshape(-1, 1), groups)
            cached = dict(zip(METRICS, map(float, scores)))
            cached.update(n_samples=X.shape[0], n_features=X.shape[1],
                          invalid_label_space_ASW=float(invalid), manual_check_max_error=error,
                          matrix_numeric_sha256=key,
                          assignment_file=str(out/'assignments'/f'{key[:20]}.csv'))
            pd.DataFrame(dict(row_position=np.arange(len(X)), saved_row_id=row_id,
                              truth=truth, cluster=groups, silhouette=individual)).to_csv(
                                  cached['assignment_file'], index=False)
            cache[key] = cached
        row = {**meta, **cache[key], 'matrix_path': str(matrix), 'matrix_file_sha256': inputs[str(matrix)]}
        if historical is not None:
            for metric in METRICS:
                row['old_'+metric] = float(historical[metric])
                row['delta_'+metric] = row[metric]-row['old_'+metric]
            row['external_metrics_match_4dp'] = all(
                abs(round(row[m], 4)-row['old_'+m]) < 0.000051 for m in ['ARI','NMI','PS'])
        records.append(row)
        return row

    with threadpool_limits(limits=1):
        for source_id, folder in sources.items():
            if not folder.exists():
                coverage.append(dict(source_id=source_id, status='missing_folder', path=str(folder)))
                continue
            for report in sorted(folder.glob('*_clustering_performance_fill0_*.csv')):
                match = re.fullmatch(r'(.+)_clustering_performance_fill0_(DIA_(?:(?:dlfq|maxlfq|top3|top1)_?)+?)(?:_p|2b_cb_mp)?', report.stem)
                if match is None:
                    raise ValueError(f'Unknown report naming: {report}')
                dataset, comb = match.groups()
                comb = comb.rstrip('_')
                old = pd.read_csv(report, index_col=0)
                inputs[str(report)] = sha(report)
                corrected_rows = []
                for method in METHODS:
                    matrix = resolve_matrix(folder, dataset, comb, method)
                    meta = dict(source_id=source_id, dataset=dataset, combination=comb,
                                method=method, source_report=str(report))
                    if not matrix.exists():
                        coverage.append({**meta, 'status':'missing_matrix', 'path':str(matrix)})
                        continue
                    row = calculate(matrix, meta, old.loc[method])
                    corrected_rows.append({m:row[m] for m in METRICS} | {'method':method})
                    coverage.append({**meta, 'status':'recalculated', 'path':str(matrix)})
                if len(corrected_rows) == len(METHODS):
                    dest = out/'corrected_tables'/source_id/report.name
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    # 与原文件列名/方法名一致；R 的指标读取路径改指这里。
                    # 特征矩阵/UMAP 的原始读取路径不要改成此目录。
                    table = pd.DataFrame(corrected_rows).set_index('method')[METRICS]
                    table.index.name = None
                    table.to_csv(dest, float_format='%.10f')
                print(f'{source_id}: {report.name}: {len(corrected_rows)}/6', flush=True)
            # This historical report used discovery-panel transfer, not ret-selected DEPs.
            transfer = folder/'train_DEP_test_clustering_perform.csv'
            if transfer.exists():
                inputs[str(transfer)] = sha(transfer)
                coverage.append(dict(source_id=source_id, status='transfer_report_separate_protocol',
                                     path=str(transfer)))

        # 另有 288 人固定发现队列 panel 的验证，使用此前已核实并保存的实际输入。
        transfer_root = args.prior_tpd_root/'ret_discovery_panel'
        if transfer_root.exists():
            report = sources['paper_20260320']/'train_DEP_test_clustering_perform.csv'
            old = pd.read_csv(report, index_col=0)
            for method in METHODS:
                matrix = transfer_root/f'TPD_ret_discovery_panel_{method}.csv'
                calculate(matrix, dict(source_id='verified_transfer', dataset='TPD_ret_discovery_panel',
                                       combination='DIA_dlfq_maxlfq_top3', method=method,
                                       source_report=str(report)), old.loc[method])
        else:
            coverage.append(dict(source_id='verified_transfer', status='missing_transfer_inputs',
                                 path=str(transfer_root)))

    result = pd.DataFrame(records)
    result.to_csv(out/'ASW_all_archived_results.csv', index=False)
    primary = result[(result.source_id == 'paper_20260320') |
                     ((result.source_id == 'figures_legacy') & (result.dataset == 'CRC')) |
                     (result.source_id == 'verified_transfer')].copy()
    primary.to_csv(out/'ASW_current_results.csv', index=False)
    # Follow the ORIGINAL plotted combinations; Fig5 uses TWO views, not three.
    main = primary[((primary.dataset != 'U2OS_filtered_rb') &
                    (primary.combination == 'DIA_dlfq_maxlfq_top3')) |
                   ((primary.dataset == 'U2OS_filtered_rb') &
                    (primary.combination == 'DIA_dlfq_maxlfq'))].copy()
    main.to_csv(out/'ASW_main_comparison.csv', index=False)
    pd.DataFrame(coverage).to_csv(out/'coverage_audit.csv', index=False)
    pd.DataFrame([dict(path=p, sha256=v) for p,v in inputs.items()]).to_csv(out/'input_manifest.csv', index=False)
    assert all(sha(p) == v for p,v in inputs.items()), 'An original input changed during this run'
    metadata = dict(status='completed', n_archived_rows=len(result), n_current_rows=len(primary),
                    n_unique_matrices=len(cache), parameters=PARAMETERS, python=sys.version,
                    sklearn=sklearn.__version__, numpy=np.__version__, pandas=pd.__version__,
                    scipy=scipy.__version__, platform=platform.platform(), script_sha256=sha(__file__),
                    originals_unchanged=True, max_validation_error=float(result.manual_check_max_error.max()),
                    warning='Historical partitions were not saved. Explicit n_init=10 is a reproducible rerun, '
                            'not a guarantee of identical historical ARI/NMI. No seed/model search was performed. '
                            'Historical archive variants are not independent experiments.')
    (out/'run_metadata.json').write_text(json.dumps(metadata, indent=2), encoding='utf-8')
    print(json.dumps(metadata, indent=2))


if __name__ == '__main__':
    main()
