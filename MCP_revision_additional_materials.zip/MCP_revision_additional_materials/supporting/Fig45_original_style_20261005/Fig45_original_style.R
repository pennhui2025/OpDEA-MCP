# 直接在 RStudio 中 Source；只重新绘图，不重新训练、聚类或计算 UMAP。
# 样式来源：Fig4_3.R 的 322-446 行、1230-1295 行；Fig5/Fig5.R 的 984-1093 行。
# 保留已纠正的 ASW、原始临床事件及多重检验结果，不恢复旧错误数值。

library(ggplot2)
library(gridExtra)
library(grid)
library(survival)
library(survminer)

## 1. 路径：换电脑时修改这里 ------------------------------------------------
base_dir <- "D:/proteomics/mauns4_3"
work_dir <- file.path(base_dir, "Submission/revision_v1/outputs")
asw_dir <- file.path(work_dir, "ASW_correction_20261004/plots")
surv_dir <- file.path(work_dir, "Fig4f_A05_minimal_correction_20261004/results")
coord_dir <- file.path(base_dir, "Submission/NCS/Figures/res")
out_dir <- file.path(work_dir, "Fig45_original_style_20261005/figures")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

## 2. 按像素尺寸直接绘图，不先画大图再缩小 ----------------------------------
# 原 SVG 的 525pt x 300pt = 700px x 400px（96 px/in，72 pt/in）。
# 使用原图同类 Cairo SVG 设备，字体转矢量路径，避免换电脑时字体替换。
save_panel <- function(name, draw, width_px, height_px) {
  filename <- file.path(out_dir, name)
  grDevices::svg(paste0(filename, ".svg"), width = width_px / 96,
                 height = height_px / 96, pointsize = 12, bg = "white", family = "sans")
  draw()
  dev.off()
  # 只将根节点物理单位明确写成 px；保留设备生成的 viewBox 和图形内容。
  s <- readLines(paste0(filename, ".svg"), warn = FALSE)
  i <- grep("^<svg ", s)
  s[i] <- sub('width="[^"]+"', sprintf('width="%dpx"', width_px), s[i])
  s[i] <- sub('height="[^"]+"', sprintf('height="%dpx"', height_px), s[i])
  writeLines(s, paste0(filename, ".svg"), useBytes = TRUE)
  # PDF 尺寸相同；PNG 仅用于检查，3 倍像素但保持相同字体比例。
  grDevices::cairo_pdf(paste0(filename, ".pdf"), width = width_px / 96,
                       height = height_px / 96, pointsize = 12, family = "sans")
  draw()
  dev.off()
  png(paste0(filename, ".png"), width = width_px * 3, height = height_px * 3,
      res = 288, type = "cairo", bg = "white")
  draw()
  dev.off()
}

extract_legend <- function(p) {
  g <- ggplotGrob(p)
  g$grobs[[which(vapply(g$grobs, function(x) x$name, "") == "guide-box")]]
}

methods <- c("dlfq", "maxlfq", "top3", "top1", "MVDEA")
read_metrics <- function(file) {
  d <- read.csv(file, check.names = FALSE)
  d <- d[match(methods, d$method), ]
  stopifnot(!anyNA(d$method), all(is.finite(d$ASW)))
  d
}
read_umap <- function(file) {
  d <- read.csv(file, row.names = 1, check.names = FALSE, fileEncoding = "UTF-8")
  d$cluster <- factor(d$cluster) # 原脚本按 factor 的顺序分配颜色。
  d
}
metric_label <- function(d) sprintf("ARI = %.2f\nASW = %.2f\nNMI = %.2f", d$ARI, d$ASW, d$NMI)

## 3. Fig.4b：原始 3 列 x 2 行；700 x 400 -----------------------------------
m4 <- read_metrics(file.path(asw_dir, "Fig4_corrected_metrics.csv"))
p4 <- list()
for (i in seq_along(methods)) {
  d <- read_umap(file.path(coord_dir, "Fig4", paste0(methods[i], "_umap_clustering.csv")))
  stopifnot(nrow(d) == m4$n_samples[i])
  ann_x <- max(d$UMAP1) - 0.03 * diff(range(d$UMAP1))
  ann_y <- min(d$UMAP2) + 0.03 * diff(range(d$UMAP2))
  p4[[i]] <- ggplot(d, aes(UMAP1, UMAP2, color = cluster)) +
    geom_point(size = 2, alpha = 0.7, stroke = 0.1) +
    labs(x = "UMAP1", y = "UMAP2") + theme_bw(base_size = 12) +
    theme(panel.background = element_rect(fill = "white", colour = NA),
          plot.background = element_rect(fill = "white", colour = NA),
          panel.border = element_rect(colour = "black", fill = NA, linewidth = 0.7),
          axis.title = element_text(face = "bold", size = 14, colour = "black"),
          axis.text = element_blank(), axis.ticks = element_blank(),
          axis.ticks.length = unit(0, "mm"), legend.position = "right",
          legend.title = element_text(face = "bold", size = 17),
          legend.text = element_text(size = 15),
          legend.key = element_rect(fill = "white", colour = NA),
          panel.grid = element_blank(), plot.margin = margin(5, 5, 5, 5, "mm")) +
    scale_color_manual(values = c("#15983D", "#FFA000", "#91D1C2FF", "#E64B35FF", "#4878CF")) +
    annotate("label", x = ann_x, y = ann_y, label = metric_label(m4[i, ]),
             hjust = 0.9, vjust = 0, size = 3, fill = scales::alpha("white", 0.5),
             color = "black", linewidth = 0.3, label.r = unit(0.2, "lines"))
}
legend4 <- extract_legend(p4[[1]])
for (i in seq_along(p4)) p4[[i]] <- p4[[i]] +
  ggtitle(ifelse(methods[i] == "MVDEA", "MCP", methods[i])) +
  theme(legend.position = "none", plot.title = element_text(hjust = 0.5))
p4[[1]] <- p4[[1]] + theme(axis.title.x = element_blank())
p4[[2]] <- p4[[2]] + theme(axis.title.x = element_blank(), axis.title.y = element_blank())
p4[[3]] <- p4[[3]] + theme(axis.title.x = element_blank(), axis.title.y = element_blank())
p4[[5]] <- p4[[5]] + theme(axis.title.y = element_blank())
fig4b <- arrangeGrob(grobs = c(p4, list(legend4)), ncol = 3, widths = c(1, 1, 1))
save_panel("Fig4b_ASW_corrected_700_400", function() { grid.newpage(); grid.draw(fig4b) }, 700, 400)

## 4. Fig.5d：原始 2 列 x 3 行；470 x 700 -----------------------------------
m5 <- read_metrics(file.path(asw_dir, "Fig5_corrected_metrics.csv"))
p5 <- list()
for (i in seq_along(methods)) {
  method_file <- ifelse(methods[i] == "MVDEA", "MCP", methods[i])
  d <- read_umap(file.path(coord_dir, "Fig5", paste0("umap_", method_file, ".csv")))
  stopifnot(nrow(d) == m5$n_samples[i])
  hull <- do.call(rbind, lapply(split(d, d$cluster), function(z) {
    j <- chull(z$UMAP1, z$UMAP2)
    z[c(j, j[1]), ]
  }))
  center <- aggregate(cbind(UMAP1, UMAP2) ~ cluster, d, mean)
  ann_x <- min(d$UMAP1) + 0.02 * diff(range(d$UMAP1))
  ann_y <- max(d$UMAP2) - 0.02 * diff(range(d$UMAP2))
  p5[[i]] <- ggplot(d, aes(UMAP1, UMAP2, color = cluster)) +
    geom_point(size = 3, alpha = 0.8) +
    geom_polygon(data = hull, aes(group = cluster), fill = NA, linewidth = 1) +
    geom_point(data = center, shape = 3, size = 4, stroke = 1.2) +
    labs(x = "UMAP1", y = "UMAP2") + theme_minimal(base_size = 12) +
    theme(axis.text = element_blank(), axis.ticks = element_blank(), legend.position = "right",
          panel.grid = element_line(color = "grey90", linewidth = 0.2)) +
    scale_color_manual(values = c("#15d08a", "#f2ca01")) +
    annotate("label", x = ann_x, y = ann_y, label = metric_label(m5[i, ]),
             hjust = 0, vjust = 1, size = 4, fill = scales::alpha("white", 0.25),
             linewidth = 0, label.r = unit(0.15, "lines"))
}
legend5 <- extract_legend(p5[[1]])
for (i in seq_along(p5)) p5[[i]] <- p5[[i]] +
  ggtitle(ifelse(methods[i] == "MVDEA", "MCP", methods[i])) +
  theme(legend.position = "none", plot.title = element_text(hjust = 0.5))
p5[[1]] <- p5[[1]] + theme(axis.title.x = element_blank())
p5[[2]] <- p5[[2]] + theme(axis.title.x = element_blank(), axis.title.y = element_blank())
p5[[3]] <- p5[[3]] + theme(axis.title.x = element_blank())
p5[[4]] <- p5[[4]] + theme(axis.title.y = element_blank())
fig5d <- arrangeGrob(grobs = c(p5, list(legend5)), ncol = 2, widths = c(1, 1))
save_panel("Fig5d_ASW_corrected_470_700", function() { grid.newpage(); grid.draw(fig5d) }, 470, 700)

## 5. Fig.4f：原始蓝/金、字体、网格；500 x 400 --------------------------------
# 读取上次核实的患者级数据；保留第 531 天死亡，不能恢复旧的强制删失。
d <- read.csv(file.path(surv_dir, "VSIG4_patients_original_status.csv"))
d$group <- factor(ifelse(d$VSIG4 > median(d$VSIG4), "High", "Low"), levels = c("Low", "High"))
stopifnot(nrow(d) == 97, sum(d$OS_status) == 7, max(d$OS_time) == 531,
          all(d$OS_status[d$OS_time == 531] == 1))
fit <- survfit(Surv(OS_time, OS_status) ~ group, data = d, conf.int = 0.95, conf.type = "log")
lr <- survdiff(Surv(OS_time, OS_status) ~ group, data = d)
p <- pchisq(lr$chisq, df = 1, lower.tail = FALSE)
all_tests <- read.csv(file.path(surv_dir, "CPTAC_survival_results.csv"))
q <- p.adjust(all_tests$Log_rank_p, method = "BH", n = 19L)[all_tests$UniProt_ID == "Q9Y279"]
stopifnot(abs(p - 0.0141170186425436) < 1e-10, abs(q - 0.268223354208329) < 1e-10)

fig4f <- ggsurvplot(fit, data = d, xlab = "Time (Days)", ylab = "Survival Probability",
  palette = c("#2E9FDF", "#E7B800"), linetype = "solid", size = 1.2,
  conf.int = TRUE, conf.int.style = "step", censor = TRUE,
  pval = sprintf("Log-rank p = %.4f\nBH q = %.3f", p, q), pval.size = 5,
  pval.coord = c(531 * 0.06, 0.48), legend = "none",
  legend.labs = c("Low (n=49)", "High (n=48)"),
  xlim = c(0, 531 * 1.05), ylim = c(0, 1), break.time.by = 100, ggtheme = theme_bw(),
  risk.table = TRUE, risk.table.height = 0.26, risk.table.fontsize = 3,
  risk.table.y.text.col = TRUE, tables.theme = theme_bw())
fig4f$plot <- fig4f$plot + ggtitle("CPTAC-COAD:Q9Y279 (VSIG4)") +
  theme(plot.title = element_text(size = 14, face = "bold", hjust = 0.5, vjust = 1,
                                  margin = margin(b = 10)),
        axis.title = element_text(size = 12), axis.text = element_text(size = 10),
        panel.grid = element_line(color = "gray90", linetype = "dashed")) +
  annotate("text", x = 531, y = 0.04, label = "531 days", hjust = 1.1, size = 3)
fig4f$table <- fig4f$table +
  theme(plot.title = element_text(size = 12), axis.text.y = ggtext::element_markdown(size = 9),
        axis.title.x = element_blank(), axis.text.x = element_text(size = 8),
        panel.grid = element_blank(), panel.border = element_blank(), axis.ticks = element_blank())
# 保存完整对象（含风险人数表），不是只保存 fig4f$plot。
save_panel("Fig4f_survival_corrected_500_400", function() print(fig4f), 500, 400)

## 6. 保存图中使用的数值，方便逐项核对 --------------------------------------
write.csv(m4[, c("method", "ARI", "ASW", "NMI", "n_samples", "n_features")],
          file.path(out_dir, "Fig4b_metrics.csv"), row.names = FALSE)
write.csv(m5[, c("method", "ARI", "ASW", "NMI", "n_samples", "n_features")],
          file.path(out_dir, "Fig5d_metrics.csv"), row.names = FALSE)
write.csv(data.frame(N = nrow(d), deaths = sum(d$OS_status), max_followup = max(d$OS_time),
                     log_rank_p = p, BH_q_19 = q), file.path(out_dir, "Fig4f_metrics.csv"), row.names = FALSE)
write.csv(data.frame(panel = c("Fig4b", "Fig4f", "Fig5d"),
                     width_px = c(700, 500, 470), height_px = c(400, 400, 700)),
          file.path(out_dir, "SVG_dimensions.csv"), row.names = FALSE)
writeLines(capture.output(sessionInfo()), file.path(out_dir, "R_sessionInfo.txt"))
message("完成：", out_dir)
