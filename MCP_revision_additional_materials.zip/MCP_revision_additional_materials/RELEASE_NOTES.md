# Lightweight release

- Replaced the earlier tutorial with English instructions and direct commands
  for the existing seven-shard scripts.
- Removed bundled intensity matrices, protein-level prediction archives and
  historical intermediate data from the upload set. Preserved organized result
  CSVs, supplementary workbooks, source manifests and small necessary metadata.
- Added the supplied Zenodo and web-application links and an exact input-path
  checklist. Included candidate-universe lists so that only 56 DIA intensity
  matrices are needed for the documented training route.
- Retained the original training source style and file names. No architecture,
  pseudo-label rule, training seed or metric formula was rewritten.
- Updated analysis path defaults to the output tree produced by a fresh run.
  Historical source filenames remain explicit; manifests must be checked if
  temporary directory names differ in a rerun.
- Kept saved-result checking separate from model training. Additional historical
  SAM, OpDEA, DDA and clinical inputs are described rather than silently omitted
  from the stated requirements.

The previous release and manuscript documents are unchanged. No files were
uploaded to GitHub, Zenodo or the journal submission system by this preparation.
Before publishing, confirm the data links, third-party code/data attribution and
the repository's existing license. No new license grant is implied by packaging.

