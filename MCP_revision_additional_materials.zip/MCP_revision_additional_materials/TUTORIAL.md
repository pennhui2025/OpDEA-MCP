# Reproducing the additional experiments

## 1. Folder layout and software

Extract `MCP_revision` into a short path without spaces, for example
`/work/MCP_revision` on Linux or `D:/MCP_revision` on Windows. Long historical
prediction filenames may exceed the Windows path limit. Linux is recommended
for the full training workflow; the saved-result analyses can also be used in
RStudio on Windows.

```
MCP_revision/
  code/training/                 Python experiments, R DEA helpers and run plans
    codes/                      R helper scripts and true-fold-change metadata
    data/
      DIA_DIANN.txt
      DIA_spt.txt
      dataset_info/             True-fold-change metadata
      DIA/DIANN/                Downloaded DIA-NN views
      DIA/Spectronaut/           Downloaded Spectronaut views
    revision_results/           Created by training; not included
  code/analysis/                R result analyses; original function-based style
  reference/Response/           Frozen record-level and summary CSV tables
  results/workbooks/            Supplementary Data workbooks
  results/additional/           Earlier Task 4/5, seed and selection summaries
  inputs/diagnostics/           Small saved run-level metric tables
  supporting/                  Clinical and corrected-figure source scripts
  environment/                 Dependency checks
  reproduced/                  Created by reanalysis; not included
```

Use the dependency lists in `environment/README.md`. From the package root:

```bash
python environment/check_environment.py
Rscript environment/check_training_environment.R
```

These checks report missing packages; they do not install software or start
training. Ensure `Rscript` is on `PATH` and belongs to the intended R library.
The historical Python training dependency list is unpinned, not a tested
environment lock. Record your resolved environment before a full run.

## 2. Check saved results without downloading matrices

The Excel workbooks and CSV summaries can be inspected directly. To reproduce
the saved-metric seed and leave-one-dataset-out (LOODO) summaries:

```bash
python run_saved_diagnostics.py multiseed
python run_saved_diagnostics.py loodo
python check_saved_diagnostics.py
```

These commands use small bundled run-level tables, not the raw abundance data.
They do not refit MCP. Eight result tables are compared with frozen references
using an absolute numerical tolerance of `1e-8`.

The seed experiment's main profile includes only full MCP, so the
`full_mcp_vs_variants_paired_tests.csv` file has headers but no comparisons. That
is expected. The LOODO selector is the empirical training-dataset selector, not
the feature-based Fig. 3 recommendation model. These historical summaries retain
their original aggregation rules; they must not be relabelled as the later
median-performance tables.

## 3. Download and place the DIA view data

Download the view data from https://zenodo.org/records/19469151. The project web
interface is http://www.ai4pro.tech:3838/. Do not download the old multi-gigabyte
reproducibility input bundle merely to run the DIA training experiments.

The seven datasets are:

```
HYEtims735_DIA
MYtims709_DIA
HEof_n600_DIA
HEof_w600_DIA
HYtims134_DIA
HEqe777_DIA
HEqe408_DIA
```

Each dataset/platform needs four view matrices, a design table and an
`all_proteins` table: 84 files in total. Fourteen design tables and fourteen
small candidate-protein tables are already included; download the 56 intensity
matrices. The `all_proteins` tables are required inputs, not optional results.
For example, the DIA-NN files for the first dataset must be:

```
code/training/data/DIA/DIANN/HYEtims735_DIA_DIANN_dlfq.tsv
code/training/data/DIA/DIANN/HYEtims735_DIA_DIANN_maxlfq.tsv
code/training/data/DIA/DIANN/HYEtims735_DIA_DIANN_top3.tsv
code/training/data/DIA/DIANN/HYEtims735_DIA_DIANN_top1.tsv
code/training/data/DIA/DIANN/HYEtims735_DIA_DIANN_all_proteins.tsv
code/training/data/DIA/DIANN/HYEtims735_DIA_DIANN_design.tsv
```

For Spectronaut, use `data/DIA/Spectronaut/` and replace the filename tag
`_DIANN_` with `_spt_`. The full list and original local file hashes are in
`required_training_files.csv`.

Copy the extracted files into these directories without altering values,
protein identifiers, sample order or column names. Do not concatenate matrices
or regenerate the protein universe simply to satisfy a filename check. If the
download does not contain the listed files, identify the corresponding export
before training; the package cannot infer a missing protein universe.

```bash
python check_inputs.py
python check_inputs.py --hash
```

The first command checks presence; `--hash` additionally compares against the
local files used to prepare the release. A hash mismatch can also arise from
line-ending or formatting changes; inspect the file before deciding it is a
different dataset. The Zenodo archive inventory was not independently retrievable
during package preparation, so the checklist, rather than an assumed ZIP name,
defines the expected inputs.

Keep the bundled dataset metadata and UPS FASTA in place. The six true-fold-change
files are present under both `data/dataset_info/` and
`codes/data/dataset_info/`, because the original entry points use two R-helper
roots. These are small ground-truth annotations, not extra expression matrices.

## 4. Run the DIA experiments

Change directory once:

```bash
cd code/training
```

All commands in this section are run from this directory, with the Python
environment selected for MCP. In PyCharm, select the same interpreter and run
the corresponding entry-point file. There is no need to edit model code.

### 4.1 Task 1/2: models, fusion controls and original four-view runs

Run these seven scripts, once each:

```bash
python MCP_r1_pycharm_limma_ROTS_shard_1_gpu0.py
python MCP_r1_pycharm_limma_ROTS_shard_2_gpu0.py
python MCP_r1_pycharm_limma_ROTS_shard_3_gpu0.py
python MCP_r1_pycharm_limma_ROTS_shard_4_gpu0.py
python MCP_r1_pycharm_limma_ROTS_shard_5_gpu1.py
python MCP_r1_pycharm_limma_ROTS_shard_6_gpu1.py
python MCP_r1_pycharm_limma_ROTS_shard_7_gpu1.py
```

For parallel execution, launch each line in a separate terminal or PyCharm run
configuration. The supplied assignment is four processes on GPU 0 and three on
GPU 1. Reduce concurrency if RAM, GPU memory or CPU/R workers are limiting.
For a one-GPU system, change only the GPU argument in the shard entry points to
0. Do not start the same shard twice against the same output directory.

The combined plan has 336 runs, including limma and ROTS. After all seven finish:

```bash
python MCP_r1_pycharm_merge_limma_ROTS_and_analyze.py
```

The merged ledger is written under
`revision_results/task1_2_core_merged_limma_ROTS/`. The obsolete limma-only shard
entry points are not included in this release.

### 4.2 Two- and three-view combinations

Run the seven `MCP_r1_pycharm_view_combinations_shard_*_gpu*.py` entry points,
using the same shard/GPU assignment. They add 280 runs: six pairs and four
triples across seven datasets, two platforms and two DEA methods.

```bash
python MCP_r1_pycharm_merge_view_combinations_and_analyze.py
```

### 4.3 Task 3–5: initialization, complementarity and component ablations

Complete both merges above first. Then run the seven
`MCP_r1_pycharm_remaining_tasks_shard_*_gpu*.py` scripts. Finally:

```bash
python MCP_r1_pycharm_merge_remaining_tasks.py
```

Task 3 changes pseudo-label initialization; Task 4 characterizes view
quality/complementarity; Task 5 tests component variants. Their saved Python
summary tables are not interchangeable with the later R tables using final MCP
scores, common protein universes and platform-level medians.

### 4.4 Fixed-supervision input ablation

Run the seven `MCP_r1_pycharm_fixed4label_ablation_shard_*_gpu*.py` scripts, then:

```bash
python MCP_r1_pycharm_merge_fixed4label_ablation.py
```

This comprises 140 runs: five input configurations across seven datasets, two
platforms and two DEA methods. The pseudo-labels, supervised-protein mask and
fold-change reference are fixed. After this stage, run the seven
`MCP_r1_pycharm_fixed3view_confirmatory_shard_*_gpu*.py` scripts and merge:

```bash
python MCP_r1_pycharm_merge_fixed3view_confirmatory.py
```

Do not edit the core or fixed-supervision scripts between fixed4 and fixed3:
the latter checks code and artifact fingerprints against the former.

This adds 28 three-view runs. It is a fixed combination, not a search across all
triples selected using their test results.

### 4.5 Multiple seeds and other controls

Run the seven `MCP_r1_pycharm_multiseed_shard_*_gpu*.py` scripts, then:

```bash
python MCP_r1_multiseed_stability_analysis.py --shards-root revision_results/multiseed_stability_shards --output-dir revision_results/final_required/multiseed_stability
```

The main profile comprises 140 full-MCP runs. To fit the linear fusion controls
after Task 1/2 and run the empirical LOODO selector after the view combinations:

```bash
python MCP_r1_linear_fusion_baselines.py --results-root revision_results --output-dir revision_results/final_required/linear_fusion_baselines
python MCP_r1_leave_one_dataset_out_view_selection.py --results-root revision_results --output-dir revision_results/final_required/loodo_view_selection
```

The ridge output is `linear_fusion_predictions.csv.gz`. The R Task 1 analysis
reads its ridge columns; MCP itself is read from the saved MCP final-score block,
not from a surrogate full-MCP column in the ridge output.

The earlier quality-characterization route is also available:

```bash
python MCP_r1_mcp_unique_dep_characterization.py --results-root revision_results --output-dir revision_results/final_required/mcp_unique_dep
```

The later Data14 analysis also compares SAM and all twelve DEA pipelines; use
the R analysis and the additional sources in the experiment map for that table.

### 4.6 Completion and restarting

Read the shard ledgers and merge validation messages. A folder existing does not
establish successful completion. The runners check existing artifacts and skip
completed runs according to their own resume rules. Do not reuse an old result
root after changing the code, data or experimental parameters; use a fresh
package copy for a changed experiment.

## 5. Recalculate the manuscript evidence tables

Return to the package root. R files retain individual analysis functions so that
the calculations can be inspected and run manually. For example, in RStudio:

```r
setwd("D:/MCP_revision")  # change to your extracted package root
source("run_analysis.R")
run_analysis("task1", make_plots = TRUE)
run_analysis("task2")
run_analysis("task3", make_plots = TRUE)
run_analysis("fixed_views", make_plots = TRUE)
```

Or from a terminal:

```bash
Rscript run_analysis.R task1 --plots
Rscript run_analysis.R task2
Rscript run_analysis.R task3 --plots
Rscript run_analysis.R fixed_views --plots
```

These commands require protein-level files created by the appropriate training
stages. They do not analyze the frozen Excel tables instead. The bundled source
manifests point to `code/training/revision_results/`. They retain historical run
identities and filenames: check these against the newly generated ledgers and
update the path columns if a different run ordering changes temporary folder
names. Never match a file by basename alone across datasets or methods.

For Task 1, the optional `linear_file` argument of `run_r1c6_baselines()` can point
to a previously saved ridge-prediction table with the required columns. Other
function arguments expose the input manifest/output directory where applicable.
Generated tables are written to `reproduced/<analysis>/`.

`check_numeric_results.py` compares the complete set of final R tables to the
frozen references. Run it only after all relevant analyses and external inputs
are available; absent analyses are reported as failures, not silently skipped.
Exact reference agreement is expected when rescoring the original saved
predictions, not guaranteed after retraining under a different environment.

## 6. Analyses that need additional historical or clinical inputs

The DIA training commands do not generate the original DDA benchmark, MCP_mut,
SAM-initialized historical runs, original OpDEA ensembles or patient datasets.
Their analysis scripts and organized results are included, but their large
inputs are deliberately excluded. See `docs/EXPERIMENT_MAP.md` and
`external_reanalysis_files.csv` for the expected filenames and locations.

In particular, replacing limma/ROTS with SAM in the historical MCP experiments
is distinct from standalone SAM performance. Original OpDEA analysis requires
the original ensemble outputs and workflow-ranking table, not only view matrices.
Clinical survival analysis requires CPTAC abundance/clinical information and
the frozen candidate lists; diagnosis requires the original clinical views and
panel lists. Download access and reuse conditions must be checked at the source.

The three folders under `supporting/` contain the ASW and figure-correction
scripts. Their original path configuration is retained for traceability. Edit
the input/output path section before running them; do not expect the original
machine's drive letters or network paths to exist. Likewise configure the
archived TPD script's clinical paths and use its recorded environment.

## 7. Interpretation of outputs

- MCP in the final evidence tables is the final saved MCP score block (called
  `DP_fdr` internally), not the direct classifier output. The name does not by
  itself establish formal FDR control.
- Common-universe comparisons use the same protein list within a comparison;
  missing method predictions receive score zero and a non-DEP call. Historical
  native-universe analyses are labelled separately in the experiment map.
- pAUCs are McClish-standardized ROC areas up to FPR 0.01, 0.05 and 0.1. No DEP
  cutoff or fold-change filter is imposed on the ranking calculation. Calling
  metrics use the rule specified in each analysis.
- Final platform tables usually summarize fourteen dataset-by-DEA records using
  medians. MCC, precision and recall are calculated per record before taking the
  median, not recomputed from median confusion counts. Noise repeats are first
  averaged within a condition where specified by Task 3.
- Seven datasets repeated across DEAs, platforms and seeds are not independent
  biological replicates. Legacy seed/LOODO summaries retain their saved rules.

