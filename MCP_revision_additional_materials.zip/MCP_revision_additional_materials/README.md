# MCP revision experiments

Code and organized results for the additional MCP revision experiments. The
original model implementations, experiment names, seven-shard entry points,
seeds and metric definitions are retained. Large view matrices, protein-level
prediction files and historical intermediate folders are not included.

## Start here

1. Read [TUTORIAL.md](TUTORIAL.md) for data placement and training commands.
2. See [docs/EXPERIMENT_MAP.md](docs/EXPERIMENT_MAP.md) for the analysis/result map.
3. Open `results/workbooks/` for the supplementary tables, or
   `reference/Response/` for their record-level CSV sources.

Data access: [Zenodo record 19469151](https://zenodo.org/records/19469151).
The [MCP web application](http://www.ai4pro.tech:3838/) is a separate interface;
it is not required for the local commands below. Use the exact file list in
`required_training_files.csv` to check downloaded views. The archive's internal
folder names should not be assumed to match this package.

There are three different uses of this release:

| Use | Additional inputs | Instructions |
|---|---|---|
| Inspect the submitted results | None | `results/`, `reference/Response/` |
| Reaggregate saved seed/LOODO metrics | None; Python dependencies needed | Tutorial, section 2 |
| Train models and recalculate protein-level metrics | Downloaded view data; some historical/clinical analyses need additional inputs | Tutorial, sections 3–6 |

The reference tables are frozen results, not outputs of a new training run made
during packaging. New outputs go to `code/training/revision_results/` or
`reproduced/`. Do not overwrite `reference/` when comparing a rerun.

This release does not claim bitwise reproducibility across software versions,
GPU hardware or numerical libraries. See `environment/README.md` and
`validation/README.md` for the environment and checks actually performed.

