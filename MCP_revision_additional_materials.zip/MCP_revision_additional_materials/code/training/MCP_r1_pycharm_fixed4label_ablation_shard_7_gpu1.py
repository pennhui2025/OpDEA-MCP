"""Run fixed4label ablation shard 7 (data index 6) on physical GPU 1."""
from MCP_r1_pycharm_run_fixed4label_ablation_shard import run_shard

if __name__ == "__main__":
    run_shard(7, 1)
