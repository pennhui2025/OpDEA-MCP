"""Shared utilities for the reviewer-requested supplementary analyses.

This module intentionally contains no experiment-specific entry point.  Each
analysis remains in one English-named ``.py`` script, while common parsing,
metric, bootstrap, and multiple-testing code lives here so that all analyses
use identical definitions.

本文件只提供共享函数，不代表一项独立实验。所有补做分析仍各自位于单独脚本中。
"""

from __future__ import annotations

import json
import math
import random
from pathlib import Path
from typing import Iterable, Mapping, Sequence

import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    balanced_accuracy_score,
    brier_score_loss,
    confusion_matrix,
    f1_score,
    matthews_corrcoef,
    precision_score,
    recall_score,
    roc_auc_score,
)


COLUMN_ALIASES: Mapping[str, Sequence[str]] = {
    "protein": ("protein", "Protein", "protein_id", "ProteinID", "id"),
    "sample": ("sample", "sample_id", "Sample", "sample_name", "patient_id"),
    "true_label": ("true_label", "True_lab", "true_lab", "ground_truth", "truth", "label", "y_true"),
    "score": ("score", "Probability", "probability", "posterior", "pred_score", "y_score"),
    "qvalue": ("qvalue", "q_value", "qval", "adj_pvalue", "padj", "FDR"),
    "pvalue": ("pvalue", "p_value", "pval", "PValue"),
    "log2fc": ("log2fc", "log2FC", "logFC", "ori_logFC", "rec_logFC", "log_fc", "effect"),
    "split": ("split", "set", "partition"),
}


def seed_everything(seed: int) -> np.random.Generator:
    """Seed Python/NumPy and return a NumPy generator. / 固定随机种子。"""

    random.seed(seed)
    np.random.seed(seed)
    return np.random.default_rng(seed)


def ensure_output_dir(path: str | Path) -> Path:
    out = Path(path).expanduser().resolve()
    out.mkdir(parents=True, exist_ok=True)
    return out


def read_table(path: str | Path) -> pd.DataFrame:
    """Read CSV/TSV/Excel using the filename suffix."""

    path = Path(path).expanduser()
    suffix = path.suffix.lower()
    if suffix in {".xlsx", ".xls"}:
        return pd.read_excel(path)
    if suffix in {".tsv", ".txt"}:
        return pd.read_csv(path, sep="\t")
    return pd.read_csv(path)


def resolve_path(base_file: str | Path, value: str | Path) -> Path:
    path = Path(value).expanduser()
    if path.is_absolute():
        return path
    return (Path(base_file).expanduser().resolve().parent / path).resolve()


def require_columns(frame: pd.DataFrame, columns: Iterable[str], context: str = "table") -> None:
    missing = [column for column in columns if column not in frame.columns]
    if missing:
        raise ValueError(f"{context} is missing required columns: {missing}")


def find_column(frame: pd.DataFrame, canonical: str, required: bool = True) -> str | None:
    candidates = COLUMN_ALIASES.get(canonical, (canonical,))
    for candidate in candidates:
        if candidate in frame.columns:
            return candidate
    if required:
        raise ValueError(
            f"Could not find '{canonical}'. Accepted aliases: {list(candidates)}; "
            f"available columns: {list(frame.columns)}"
        )
    return None


def prediction_column_map(record) -> dict[str, str]:
    """Extract optional explicit prediction-column names from a manifest row."""

    mapping: dict[str, str] = {}
    for canonical in ["protein", "sample", "true_label", "score", "qvalue", "log2fc", "split"]:
        value = record.get(f"{canonical}_column", "")
        if isinstance(value, str) and value.strip():
            mapping[canonical] = value.strip()
    return mapping


def standardize_prediction_table(
    frame: pd.DataFrame, column_map: Mapping[str, str] | None = None
) -> pd.DataFrame:
    """Map core-code exports to a stable long-form prediction schema.

    Required: protein, true_label, and score or qvalue.  The core model uses a
    high score for DEP; if only q-values are present, ``score = 1 - qvalue``.
    """

    column_map = column_map or {}
    explicit_method_fields = any(
        key in column_map for key in ["score", "qvalue", "log2fc"]
    )

    def mapped_column(canonical: str, required: bool = True) -> str | None:
        requested = column_map.get(canonical)
        if isinstance(requested, str) and requested.strip():
            requested = requested.strip()
            if requested not in frame.columns:
                raise ValueError(
                    f"Explicit {canonical}_column '{requested}' is absent; available: {list(frame.columns)}"
                )
            return requested
        # A core combined result can contain several methods side by side. Once
        # one method-specific field is explicit, never auto-select an optional
        # score/q-value/effect column from a different result block.
        if explicit_method_fields and canonical in {"score", "qvalue", "log2fc"}:
            return None
        return find_column(frame, canonical, required=required)

    protein_col = mapped_column("protein")
    true_col = mapped_column("true_label")
    score_col = mapped_column("score", required=False)
    q_col = mapped_column("qvalue", required=False)
    if score_col is None and q_col is None:
        raise ValueError("Prediction table needs either a score/probability column or a q-value column")

    result = pd.DataFrame(
        {
            "protein": frame[protein_col],
            "true_label": pd.to_numeric(frame[true_col], errors="coerce"),
        }
    )
    if score_col is not None:
        result["score"] = pd.to_numeric(frame[score_col], errors="coerce")
    else:
        result["score"] = 1.0 - pd.to_numeric(frame[q_col], errors="coerce")
    if q_col is not None:
        result["qvalue"] = pd.to_numeric(frame[q_col], errors="coerce")
    else:
        result["qvalue"] = np.nan

    logfc_col = mapped_column("log2fc", required=False)
    result["log2fc"] = (
        pd.to_numeric(frame[logfc_col], errors="coerce") if logfc_col is not None else np.nan
    )
    split_col = mapped_column("split", required=False)
    if split_col is not None:
        result["split"] = frame[split_col].astype(str).str.lower()

    result = result.dropna(subset=["protein", "true_label", "score"])
    result = result[np.isfinite(result["true_label"]) & np.isfinite(result["score"])]
    result = result[result["true_label"].isin([0, 1])]
    result["true_label"] = result["true_label"].astype(int)
    result["protein"] = result["protein"].astype(str).str.strip()
    result = result[(result["protein"] != "") & (result["protein"].str.lower() != "nan")]
    if result["protein"].duplicated().any():
        examples = result.loc[result["protein"].duplicated(keep=False), "protein"].unique()[:5]
        raise ValueError(
            "Prediction table contains duplicate protein identifiers; aggregate them before evaluation. "
            f"Examples: {examples.tolist()}"
        )
    return result.reset_index(drop=True)


def binary_metrics(y_true: Sequence[int], y_pred: Sequence[int]) -> dict[str, float]:
    """Correct ground-truth-based metrics; labels are never inferred from q-values."""

    truth = np.asarray(y_true, dtype=int)
    pred = np.asarray(y_pred, dtype=int)
    tn, fp, fn, tp = confusion_matrix(truth, pred, labels=[0, 1]).ravel()
    specificity = tn / (tn + fp) if (tn + fp) else np.nan
    return {
        "accuracy": accuracy_score(truth, pred),
        "balanced_accuracy": balanced_accuracy_score(truth, pred),
        "precision": precision_score(truth, pred, zero_division=0),
        "recall": recall_score(truth, pred, zero_division=0),
        "specificity": specificity,
        "f1": f1_score(truth, pred, zero_division=0),
        "mcc": matthews_corrcoef(truth, pred) if len(np.unique(truth)) > 1 else np.nan,
        "tn": float(tn),
        "fp": float(fp),
        "fn": float(fn),
        "tp": float(tp),
    }


def ranking_metrics(y_true: Sequence[int], score: Sequence[float]) -> dict[str, float]:
    truth = np.asarray(y_true, dtype=int)
    values = np.asarray(score, dtype=float)
    if len(np.unique(truth)) < 2:
        return {"auroc": np.nan, "auprc": np.nan, "pauc_0.01": np.nan, "pauc_0.05": np.nan}
    return {
        "auroc": roc_auc_score(truth, values),
        "auprc": average_precision_score(truth, values),
        "pauc_0.01": roc_auc_score(truth, values, max_fpr=0.01),
        "pauc_0.05": roc_auc_score(truth, values, max_fpr=0.05),
    }


def expected_calibration_error(
    y_true: Sequence[int], score: Sequence[float], bins: int = 10
) -> float:
    truth = np.asarray(y_true, dtype=float)
    prob = np.clip(np.asarray(score, dtype=float), 0.0, 1.0)
    edges = np.linspace(0.0, 1.0, bins + 1)
    total = len(prob)
    if total == 0:
        return np.nan
    ece = 0.0
    for index in range(bins):
        if index == bins - 1:
            mask = (prob >= edges[index]) & (prob <= edges[index + 1])
        else:
            mask = (prob >= edges[index]) & (prob < edges[index + 1])
        if mask.any():
            ece += mask.mean() * abs(prob[mask].mean() - truth[mask].mean())
    return float(ece)


def calibration_metrics(y_true: Sequence[int], score: Sequence[float], bins: int = 10) -> dict[str, float]:
    truth = np.asarray(y_true, dtype=int)
    prob = np.asarray(score, dtype=float)
    if ((prob < 0) | (prob > 1)).any():
        return {"brier": np.nan, "ece": np.nan}
    return {
        "brier": brier_score_loss(truth, prob),
        "ece": expected_calibration_error(truth, prob, bins=bins),
    }


def calls_from_thresholds(
    table: pd.DataFrame,
    fdr_threshold: float,
    fold_change_ratio: float,
    score_threshold: float | None = None,
) -> np.ndarray:
    """Create binary calls with a common threshold policy.

    ``fold_change_ratio=1`` disables the effect-size filter.  Values above one
    are converted to the log2 scale used by the core code.
    """

    if score_threshold is None:
        if table["qvalue"].notna().any():
            called = table["qvalue"].to_numpy(float) <= fdr_threshold
        else:
            called = table["score"].to_numpy(float) >= 1.0 - fdr_threshold
    else:
        called = table["score"].to_numpy(float) >= score_threshold

    if fold_change_ratio > 1.0:
        if table["log2fc"].isna().all():
            raise ValueError("A fold-change filter was requested but the prediction table has no log2FC column")
        called &= np.abs(table["log2fc"].to_numpy(float)) >= math.log2(fold_change_ratio)
    return called.astype(int)


def bh_adjust(pvalues: Sequence[float]) -> np.ndarray:
    """Benjamini-Hochberg adjustment without relying on method-specific q-values."""

    p = np.asarray(pvalues, dtype=float)
    out = np.full(len(p), np.nan, dtype=float)
    valid = np.isfinite(p)
    pv = p[valid]
    if len(pv) == 0:
        return out
    order = np.argsort(pv)
    ranked = pv[order]
    adjusted = ranked * len(ranked) / np.arange(1, len(ranked) + 1)
    adjusted = np.minimum.accumulate(adjusted[::-1])[::-1]
    restored = np.empty_like(adjusted)
    restored[order] = np.clip(adjusted, 0.0, 1.0)
    out[np.where(valid)[0]] = restored
    return out


def percentile_interval(values: Sequence[float], confidence: float = 0.95) -> tuple[float, float]:
    arr = np.asarray(values, dtype=float)
    arr = arr[np.isfinite(arr)]
    if len(arr) == 0:
        return np.nan, np.nan
    alpha = (1.0 - confidence) / 2.0
    return float(np.quantile(arr, alpha)), float(np.quantile(arr, 1.0 - alpha))


def bootstrap_mean_ci(
    values: Sequence[float], rng: np.random.Generator, iterations: int = 2000
) -> tuple[float, float, float]:
    arr = np.asarray(values, dtype=float)
    arr = arr[np.isfinite(arr)]
    if len(arr) == 0:
        return np.nan, np.nan, np.nan
    boot = np.array([rng.choice(arr, size=len(arr), replace=True).mean() for _ in range(iterations)])
    low, high = percentile_interval(boot)
    return float(arr.mean()), low, high


def parse_number_list(text: str, cast=float) -> list:
    return [cast(item.strip()) for item in text.split(",") if item.strip()]


def parse_text_list(text: str) -> list[str]:
    return [item.strip() for item in text.split(",") if item.strip()]


def write_json(data: object, path: str | Path) -> None:
    Path(path).write_text(json.dumps(data, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
