"""Build the missing 2/3-view DIA full-MCP manifests for limma and ROTS.

The view sets exactly follow the manuscript code:

``combinations(['dlfq', 'maxlfq', 'top3', 'top1'], view_num)``

Existing 1-view and 4-view runs are intentionally not duplicated. / 仅生成缺失的
二视图和三视图组合，已有单视图和四视图结果继续复用。
"""

from __future__ import annotations

import argparse
import csv
from itertools import combinations
from pathlib import Path


VIEWS = ("dlfq", "maxlfq", "top3", "top1")
MASTER_NAME = "MCP_r1_DIA_view_combinations_limma_ROTS_incremental_manifest.csv"
SHARD_STEM = "MCP_r1_DIA_view_combinations_limma_ROTS_incremental_shard"


def split_plus(value: str) -> list[str]:
    return [part.strip() for part in str(value).split("+") if part.strip()]


def dea_label(value: str) -> str:
    values = {part.upper() if part.upper() == "ROTS" else part.lower() for part in split_plus(value)}
    return next(iter(values)) if len(values) == 1 else "+".join(sorted(values))


def build_rows(source_manifest: Path) -> tuple[list[str], list[dict[str, str]]]:
    with source_manifest.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        fieldnames = list(reader.fieldnames or [])
        source_rows = list(reader)
    if not source_rows or "run_id" not in fieldnames:
        raise ValueError(f"Invalid source manifest: {source_manifest}")

    # One existing four-view limma row provides the original group contrast and
    # runtime settings for each of the seven indices and two DIA platforms.
    templates: dict[tuple[int, str], dict[str, str]] = {}
    for row in source_rows:
        views = split_plus(row.get("views", ""))
        key = (int(row["data_index"]), row["platform"])
        if (
            row.get("variant") == "full_mcp"
            and len(views) == 4
            and dea_label(row.get("dea_methods", "")) == "limma"
        ):
            if key in templates:
                raise ValueError(f"Duplicate four-view limma template for {key}")
            templates[key] = row
    expected_keys = {(index, platform) for index in range(7) for platform in ("DIANN", "Spectronaut")}
    if set(templates) != expected_keys:
        raise ValueError(
            f"Source manifest lacks template rows; missing={sorted(expected_keys - set(templates))}"
        )

    view_sets = [values for size in (2, 3) for values in combinations(VIEWS, size)]
    if len(view_sets) != 10:
        raise AssertionError("Expected 10 missing DIA view combinations")

    output: list[dict[str, str]] = []
    for data_index in range(7):
        for platform in ("DIANN", "Spectronaut"):
            template = templates[(data_index, platform)]
            for values in view_sets:
                view_text = "+".join(values)
                view_slug = "_".join(values)
                log_text = "+".join("T" if view == "dlfq" else "F" for view in values)
                for dea_method in ("limma", "ROTS"):
                    row = dict(template)
                    suffix = "_ROTS" if dea_method == "ROTS" else ""
                    row.update(
                        {
                            "run_id": (
                                f"DIA_{platform}_i{data_index}_mcp_v{len(values)}_{view_slug}{suffix}"
                            ),
                            "views": view_text,
                            "variant": "full_mcp",
                            "statistical_fusion": "",
                            "dea_methods": "+".join([dea_method] * len(values)),
                            "log_transforms": log_text,
                            "force": "FALSE",
                        }
                    )
                    output.append({name: row.get(name, "") for name in fieldnames})
    return fieldnames, output


def validate_rows(rows: list[dict[str, str]]) -> None:
    if len(rows) != 280:
        raise ValueError(f"Expected 280 incremental rows; found {len(rows)}")
    run_ids = [row["run_id"] for row in rows]
    if len(run_ids) != len(set(run_ids)):
        raise ValueError("Incremental run_id values are not unique")
    for data_index in range(7):
        shard = [row for row in rows if int(row["data_index"]) == data_index]
        if len(shard) != 40:
            raise ValueError(f"data_index={data_index} must have 40 rows; found {len(shard)}")
        for platform in ("DIANN", "Spectronaut"):
            for dea_method in ("limma", "ROTS"):
                selected = [
                    row for row in shard
                    if row["platform"] == platform and dea_label(row["dea_methods"]) == dea_method
                ]
                if len(selected) != 10:
                    raise ValueError(
                        f"data_index={data_index}, {platform}, {dea_method} must have 10 rows"
                    )
                counts = {len(split_plus(row["views"])) for row in selected}
                if counts != {2, 3}:
                    raise ValueError(f"Unexpected view counts for {platform}/{dea_method}: {counts}")


def write_csv(path: Path, fieldnames: list[str], rows: list[dict[str, str]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, quoting=csv.QUOTE_MINIMAL)
        writer.writeheader()
        writer.writerows(rows)


def build(source_manifest: Path, output_dir: Path) -> list[Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    fieldnames, rows = build_rows(source_manifest)
    validate_rows(rows)
    paths = [output_dir / MASTER_NAME]
    write_csv(paths[0], fieldnames, rows)
    for shard_id in range(1, 8):
        shard_rows = [row for row in rows if int(row["data_index"]) == shard_id - 1]
        shard_path = output_dir / f"{SHARD_STEM}_{shard_id}.csv"
        write_csv(shard_path, fieldnames, shard_rows)
        paths.append(shard_path)
    return paths


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--source-manifest",
        type=Path,
        default=Path(__file__).resolve().parent / "MCP_r1_task1_2_DIA_limma_ROTS_manifest.csv",
    )
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    for path in build(args.source_manifest.resolve(), args.output_dir.resolve()):
        print(path)


if __name__ == "__main__":
    main()

