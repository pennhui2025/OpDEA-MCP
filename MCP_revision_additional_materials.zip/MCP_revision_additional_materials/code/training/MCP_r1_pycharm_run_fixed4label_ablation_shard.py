"""Run or resume one fixed-four-label ablation shard from PyCharm or CLI."""

from __future__ import annotations

import argparse
import csv
import importlib.util
import os
import sys
import traceback
from collections import defaultdict
from pathlib import Path
from time import perf_counter
from typing import Any

import pandas as pd

from MCP_r1_build_fixed4label_ablation_manifest import SHARD_STEM, build, build_rows


DEFAULT_SHARD_ID = 1
DEFAULT_GPU_ID = 0


def _core_helpers(project_dir: Path) -> Any:
    """Import path discovery helpers without importing the training core. / 复用路径辅助函数。"""
    helper_file = project_dir / "MCP_r1_pycharm_run_core_shard.py"
    spec = importlib.util.spec_from_file_location("_fixed4_core_helpers", helper_file)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load helpers from {helper_file}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _read_manifest(path: Path, expected_index: int) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    if len(rows) != 20 or {int(row["data_index"]) for row in rows} != {expected_index}:
        raise ValueError(f"{path} must contain exactly 20 runs for data_index={expected_index}")
    if len({row["run_id"] for row in rows}) != len(rows):
        raise ValueError(f"Duplicate run_id in {path}")
    expected = {
        row["run_id"]: row
        for row in build_rows()
        if int(row["data_index"]) == expected_index
    }
    observed = {row["run_id"]: row for row in rows}
    if set(observed) != set(expected):
        raise ValueError(
            f"{path} is not the current fixed4label manifest; rerun "
            "MCP_r1_build_fixed4label_ablation_manifest.py"
        )
    # Paths/GPU/force may be set at runtime; all scientific fields are immutable.
    ignored = {"data_root", "r_code", "rscript_path", "gpu_id", "force"}
    for run_id, expected_row in expected.items():
        for field, expected_value in expected_row.items():
            if field not in ignored and observed[run_id].get(field, "") != expected_value:
                raise ValueError(
                    f"Outdated/edited manifest value for {run_id}/{field}: "
                    f"{observed[run_id].get(field)!r} != {expected_value!r}"
                )
    return rows


def _write_ledger(path: Path, rows: list[dict[str, Any]]) -> None:
    fields = sorted({key for row in rows for key in row}) if rows else ["run_id", "status"]
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def _artifact_csv(artifact: dict[str, Any], key: str, run_dir: Path) -> Path | None:
    """Resolve a library artifact path, accepting relative and flat deployment paths."""
    value = artifact.get(key)
    if value:
        candidate = Path(str(value))
        if not candidate.is_absolute():
            candidate = run_dir / candidate
        if candidate.is_file():
            return candidate
    expected = {"prediction_file": "generated_prediction_manifest.csv", "metrics_file": "generated_performance_wide.csv"}.get(key)
    if expected:
        found = list(run_dir.rglob(expected))
        if len(found) == 1:
            return found[0]
    return None


def _collect_csv(paths: list[Path], destination: Path) -> None:
    frames: list[pd.DataFrame] = []
    for path in paths:
        try:
            frames.append(pd.read_csv(path))
        except pd.errors.EmptyDataError:
            continue
    if frames:
        pd.concat(frames, ignore_index=True, sort=False).to_csv(destination, index=False)
    else:
        pd.DataFrame().to_csv(destination, index=False)


def run_shard(shard_id: int, gpu_id: int, result_root: Path | None = None) -> None:
    if shard_id not in range(1, 8):
        raise ValueError(f"shard_id must be 1..7; got {shard_id}")
    if gpu_id < 0:
        raise ValueError("gpu_id must be non-negative")
    project_dir = Path(__file__).resolve().parent
    os.chdir(project_dir)
    manifest = project_dir / f"{SHARD_STEM}_{shard_id}.csv"
    if not manifest.exists():
        build(project_dir)
    rows = _read_manifest(manifest, shard_id - 1)
    helpers = _core_helpers(project_dir)
    codes_dir = helpers.validate_project(project_dir, manifest)
    rscript = helpers.locate_rscript()
    for required_r in ("normalization_MVAE_R1.R", "limma_DE_rep.R", "ROTS_DE_rep.R"):
        if not (codes_dir / required_r).is_file():
            raise FileNotFoundError(codes_dir / required_r)
    # The four-view core invokes this exact filename (not Hurdle.R).
    if not (codes_dir / "Hurdle_rep.R").is_file():
        raise FileNotFoundError(codes_dir / "Hurdle_rep.R")
    data_root = project_dir / "data"
    core_script = project_dir / "MCP_r1_mv_contrast_v6.0.3_4_linux_comb_exp_mcc2_new.py"

    # CUDA must be selected before importing torch or the fixed4label core.
    os.environ["CUDA_VISIBLE_DEVICES"] = str(gpu_id)
    os.environ.setdefault("MCP_VERBOSE_TRAIN", "0")
    if str(project_dir) not in sys.path:
        sys.path.insert(0, str(project_dir))
    from MCP_r1_fixed4label_ablation import load_core, prepare_fixed_bundle, run_fixed_ablation_model

    root = result_root or project_dir / "revision_results"
    shard_root = root.expanduser().resolve() / "final_required" / "fixed4label_single_view_ablation" / "shards" / f"shard_{shard_id}"
    shard_root.mkdir(parents=True, exist_ok=True)
    ledger_path = shard_root / "core_run_ledger.csv"
    ledger: list[dict[str, Any]] = []
    prediction_rows: list[dict[str, Any]] = []
    metrics_paths: list[Path] = []
    bundle_rows: list[dict[str, Any]] = []
    failures: list[str] = []
    core = load_core(core_script)
    rscript_path = str(rscript.parent) + os.sep

    # Group runs by a data/platform/DEA stratum; one immutable label bundle each.
    strata: dict[tuple[str, str, str], list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        strata[(row["data_index"], row["platform"], row["dea_method"])].append(row)
    for key, stratum_rows in sorted(strata.items()):
        template = dict(stratum_rows[0])
        template.update({"data_root": str(data_root.resolve()), "r_code": str(codes_dir), "rscript_path": rscript_path, "gpu_id": str(gpu_id)})
        bundle_dir = shard_root / "bundles" / f"i{key[0]}_{key[1]}_{key[2]}"
        try:
            bundle = prepare_fixed_bundle(template, project_dir, core, core_script, bundle_dir, codes_dir, rscript, force=False)
            bundle_rows.append({**bundle, "data_index": key[0], "platform": key[1], "dea_method": key[2]})
        except Exception as exc:
            detail = f"bundle prepare failed ({key}): {exc}"
            failures.append(detail)
            for row in stratum_rows:
                ledger.append({"run_id": row["run_id"], "status": "error", "stage": "prepare_bundle", "error": detail})
                _write_ledger(ledger_path, ledger)
            continue
        for row in stratum_rows:
            spec = dict(row)
            spec.update({"data_root": str(data_root.resolve()), "r_code": str(codes_dir), "rscript_path": rscript_path, "gpu_id": str(gpu_id)})
            run_dir = shard_root / "runs" / row["run_id"]
            start = perf_counter()
            try:
                artifact = run_fixed_ablation_model(spec, core, core_script, bundle_dir, run_dir, force=False)
                record = {**row, **artifact, "stage": "run", "runner_runtime_seconds": round(perf_counter() - start, 3)}
                ledger.append(record)
                prediction = _artifact_csv(artifact, "prediction_file", run_dir)
                metrics = _artifact_csv(artifact, "metrics_file", run_dir)
                if prediction:
                    prediction_rows.append(
                        {
                            "run_id": artifact["run_id"],
                            "dataset": artifact["dataset"],
                            "data_index": artifact["data_index"],
                            "platform": artifact["platform"],
                            "dea_method": artifact["dea_method"],
                            "variant": artifact["variant"],
                            "model_input_views": artifact["model_input_views"],
                            "label_mode": artifact["label_mode"],
                            "test_type": "DP_fdr",
                            "seed": int(row["seed"]),
                            "prediction_file": str(prediction.resolve()),
                            "prediction_file_relative": str(
                                prediction.resolve().relative_to(shard_root.parent.parent)
                            ),
                            "run_metadata_file": artifact["run_metadata_file"],
                            "protein_column": "Protein",
                            "truth_column": "True_lab",
                            "score_column": "DP_fdr_probability",
                            "called_column": "called_DP_fdr",
                            "log2fc_column": "shared_full_log2fc",
                            "label_fingerprint": artifact["label_fingerprint"],
                        }
                    )
                if metrics:
                    metrics_paths.append(metrics)
                if str(artifact.get("status", "ok")).lower() not in {
                    "ok", "completed", "success", "skipped", "skipped_existing", "resumed"
                }:
                    failures.append(f"run {row['run_id']} returned status={artifact.get('status')}")
            except Exception as exc:
                detail = "".join(traceback.format_exception_only(type(exc), exc)).strip()
                failures.append(f"run {row['run_id']} failed: {detail}")
                ledger.append({**row, "status": "error", "stage": "run", "error": detail, "runner_runtime_seconds": round(perf_counter() - start, 3)})
            finally:
                # Persist after every run so an interrupted PyCharm session remains auditable.
                _write_ledger(ledger_path, ledger)

    pd.DataFrame(prediction_rows).to_csv(
        shard_root / "generated_prediction_manifest.csv", index=False
    )
    _collect_csv(metrics_paths, shard_root / "generated_performance_wide.csv")
    _write_ledger(shard_root / "bundle_manifest.csv", bundle_rows)
    if len(ledger) != 20:
        failures.append(f"expected 20 ledger rows, found {len(ledger)}")
    if len(prediction_rows) != 20:
        failures.append(f"expected 20 prediction-manifest rows, found {len(prediction_rows)}")
    if failures:
        raise RuntimeError("Fixed4label shard completed with failures:\n  " + "\n  ".join(failures))
    print(f"SHARD {shard_id} COMPLETED: {len(ledger)} runs; output={shard_root}", flush=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--shard-id", type=int, default=DEFAULT_SHARD_ID)
    parser.add_argument("--gpu-id", type=int, default=DEFAULT_GPU_ID)
    parser.add_argument("--result-root", type=Path, default=None)
    args = parser.parse_args()
    run_shard(args.shard_id, args.gpu_id, args.result_root)


if __name__ == "__main__":
    main()
