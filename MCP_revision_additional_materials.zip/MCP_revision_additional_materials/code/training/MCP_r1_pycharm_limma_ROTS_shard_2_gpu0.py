"""Run combined limma+ROTS DIA shard 2 on physical GPU 0."""
from pathlib import Path
from MCP_r1_pycharm_run_core_shard import run_shard

def main() -> None:
    run_shard(2, 0, Path(__file__).resolve().parent / "revision_results",
              manifest_stem="MCP_r1_task1_2_DIA_limma_ROTS_shard")

if __name__ == "__main__":
    main()
