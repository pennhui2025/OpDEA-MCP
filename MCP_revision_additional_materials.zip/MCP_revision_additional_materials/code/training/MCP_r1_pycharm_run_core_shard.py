"""Run one DIA shard directly with a Python/PyCharm interpreter.

Normally this file is launched by ``MCP_r1_pycharm_parallel_launcher.py``.
For debugging one shard in PyCharm, edit DEFAULT_SHARD_ID/DEFAULT_GPU_ID below
and click Run. / 也可修改下面两个默认值后，在 PyCharm 中单独运行一个分片。
"""

from __future__ import annotations

import argparse
import csv
import importlib
import os
import shutil
import sys
from collections import Counter
from itertools import combinations
from pathlib import Path

import pandas as pd


# Direct-PyCharm single-shard defaults / 单分片调试默认值。
DEFAULT_SHARD_ID = 1
DEFAULT_GPU_ID = 0


def locate_rscript() -> Path:
    preferred = Path("/usr/lib/R/bin/Rscript")
    if preferred.is_file():
        return preferred.resolve()
    located = shutil.which("Rscript")
    if located:
        return Path(located).resolve()
    raise FileNotFoundError(
        "Rscript was not found. Configure the same R environment used by the original MCP project."
    )


def validate_dependencies() -> None:
    packages = ["numpy", "pandas", "scipy", "sklearn", "statsmodels", "optuna", "torch"]
    failures: list[str] = []
    for package in packages:
        try:
            importlib.import_module(package)
        except Exception as exc:
            failures.append(f"{package}: {exc}")
    if failures:
        raise RuntimeError(
            "Missing/invalid Python dependencies:\n  " + "\n  ".join(failures)
            + "\nInstall MCP_r1_requirements_supplementary.txt in the selected PyCharm interpreter."
        )


def locate_codes_dir(project_dir: Path) -> Path:
    """Locate the original R ``codes`` directory.

    Server layouts commonly place these Python entry points in
    ``Result_reproducing/DEA`` while keeping ``codes`` one or more levels
    above it.  ``MCP_R_CODE_DIR`` remains available for unusual layouts.
    """

    candidates: list[Path] = []
    configured = os.environ.get("MCP_R_CODE_DIR", "").strip()
    if configured:
        candidates.append(Path(configured).expanduser())
    # Support both common layouts:
    #   1) R scripts are directly beside this Python entry point (flat DEA dir);
    #   2) R scripts are collected in a sibling/ancestor ``codes`` directory.
    for parent in (project_dir, *project_dir.parents):
        candidates.extend((parent, parent / "codes"))

    checked: list[Path] = []
    for candidate in candidates:
        resolved = candidate.resolve()
        if resolved in checked:
            continue
        checked.append(resolved)
        # These marker files are used by the original MCP preprocessing/DEA
        # pipeline and prevent accidentally selecting an unrelated codes dir.
        if (
            resolved.is_dir()
            and (resolved / "normalization_MVAE_R1.R").is_file()
            and (resolved / "limma_DE_rep.R").is_file()
        ):
            return resolved

    raise FileNotFoundError(
        "Could not locate the original MCP R codes directory. Checked:\n  "
        + "\n  ".join(str(value) for value in checked)
        + "\nSet MCP_R_CODE_DIR to the directory containing "
        "normalization_MVAE_R1.R and limma_DE_rep.R if it is elsewhere."
    )


def validate_project(project_dir: Path, source_manifest: Path) -> Path:
    required_files = [
        source_manifest.name,
        "MCP_r1_mcp_experiment_runner.py",
        "MCP_r1_mv_contrast_v6.0.3_4_linux_comb_exp_mcc2_new.py",
        "MCP_r1_MV_regression_DP.py",
        "MCP_r1_Utils.py",
        "data/DIA_DIANN.txt",
        "data/DIA_spt.txt",
    ]
    required_dirs = ["data/DIA/DIANN", "data/DIA/Spectronaut"]
    missing = [value for value in required_files if not (project_dir / value).is_file()]
    missing += [value for value in required_dirs if not (project_dir / value).is_dir()]
    if missing:
        raise FileNotFoundError(
            "The PyCharm working copy/interpreter cannot see required project paths:\n  "
            + "\n  ".join(str(project_dir / value) for value in missing)
        )
    return locate_codes_dir(project_dir)


def prepare_runtime_manifest(
    source: Path,
    target: Path,
    rscript: Path,
    codes_dir: Path,
    gpu_id: int,
    expected_index: int,
    validation_profile: str = "task1_2",
) -> int:
    with source.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        fieldnames = reader.fieldnames or []
        rows = list(reader)
    if not rows:
        raise ValueError(f"{source} contains no runs")
    if {int(row["data_index"]) for row in rows} != {expected_index}:
        raise ValueError(f"{source} does not exclusively contain data_index={expected_index}")
    if len({row["run_id"] for row in rows}) != len(rows):
        raise ValueError(f"{source} contains duplicate run_id values")

    def row_dea(row: dict[str, str]) -> str:
        values = {
            value.strip().upper() if value.strip().upper() == "ROTS" else value.strip().lower()
            for value in row["dea_methods"].replace(",", "+").split("+")
            if value.strip()
        }
        if len(values) != 1 or next(iter(values)) not in {"limma", "ROTS"}:
            raise ValueError(
                f"Each run must use only limma or only ROTS across its views: {row['run_id']}"
            )
        return next(iter(values))

    dea_methods = sorted({row_dea(row) for row in rows})
    if validation_profile == "task1_2":
        expected: dict[tuple[str, str, str], int] = {}
        for dea_method in dea_methods:
            for platform in ("DIANN", "Spectronaut"):
                expected.update(
                    {
                        (dea_method, platform, "full_mcp"): 1,
                        (dea_method, platform, "single_view_mcp"): 4,
                        (dea_method, platform, "simple_early_fusion"): 1,
                        (dea_method, platform, "simple_late_fusion"): 1,
                        (dea_method, platform, "single_view_statistical"): 4,
                        (dea_method, platform, "rank_or_pvalue_fusion"): 1,
                    }
                )
        observed = Counter((row_dea(row), row["platform"], row["variant"]) for row in rows)
        if observed != expected:
            raise ValueError(f"Unexpected DEA/platform/variant counts: {dict(observed)}")
        expected_rows = 24 * len(dea_methods)
        if len(rows) != expected_rows:
            raise ValueError(
                f"{source} must contain {expected_rows} rows for {dea_methods}; found {len(rows)}"
            )
    elif validation_profile == "view_combination_incremental":
        # Exactly reproduce itertools.combinations for the missing 2- and
        # 3-view DIA subsets. Single-view and all-four-view runs are reused
        # from the existing task1_2 limma+ROTS experiment.
        if set(dea_methods) != {"limma", "ROTS"}:
            raise ValueError(
                "The view-combination incremental shard must contain both limma and ROTS"
            )
        all_views = ("dlfq", "maxlfq", "top3", "top1")
        expected_view_sets = {
            "+".join(values)
            for size in (2, 3)
            for values in combinations(all_views, size)
        }
        if len(expected_view_sets) != 10:
            raise AssertionError("Expected six 2-view and four 3-view DIA combinations")
        expected_view_counter = Counter({view_set: 1 for view_set in expected_view_sets})
        for dea_method in ("limma", "ROTS"):
            for platform in ("DIANN", "Spectronaut"):
                selected = [
                    row for row in rows
                    if row_dea(row) == dea_method and row["platform"] == platform
                ]
                observed_views = Counter(row["views"] for row in selected)
                if observed_views != expected_view_counter:
                    raise ValueError(
                        f"{source}: {dea_method}/{platform} must contain each 2/3-view "
                        f"combination exactly once; observed={dict(observed_views)}"
                    )
                if {row["variant"] for row in selected} != {"full_mcp"}:
                    raise ValueError(
                        f"{source}: incremental combinations must use variant=full_mcp"
                    )
        if len(rows) != 40:
            raise ValueError(f"{source} must contain 40 incremental runs; found {len(rows)}")
    else:
        raise ValueError(f"Unknown validation_profile={validation_profile!r}")
    if "ROTS" in dea_methods and not (codes_dir / "ROTS_DE_rep.R").is_file():
        raise FileNotFoundError(codes_dir / "ROTS_DE_rep.R")

    rscript_dir = str(rscript.parent) + os.sep
    for row in rows:
        row["rscript_path"] = rscript_dir
        row["r_code"] = str(codes_dir)
        row["gpu_id"] = str(gpu_id)
    with target.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    return len(rows)


def print_dataset_names(project_dir: Path, data_index: int) -> None:
    for platform, relative in (
        ("DIANN", "data/DIA_DIANN.txt"),
        ("Spectronaut", "data/DIA_spt.txt"),
    ):
        metadata_path = project_dir / relative
        metadata = pd.read_csv(metadata_path, sep="\t")
        if "dataset" not in metadata.columns or len(metadata) <= data_index:
            raise ValueError(f"Cannot resolve data_index={data_index} from {metadata_path}")
        print(
            f"dataset: platform={platform}, data_index={data_index}, "
            f"name={metadata.iloc[data_index]['dataset']}",
            flush=True,
        )


def run_shard(
    shard_id: int,
    gpu_id: int,
    result_root: Path,
    manifest_stem: str = "MCP_r1_task1_2_DIA_shard",
    output_group: str = "task1_2_shards",
    validation_profile: str = "task1_2",
) -> None:
    if shard_id not in range(1, 8):
        raise ValueError(f"shard_id must be 1-7; got {shard_id}")
    if gpu_id < 0:
        raise ValueError(f"gpu_id must be non-negative; got {gpu_id}")
    output_group_path = Path(output_group)
    if output_group_path.is_absolute() or ".." in output_group_path.parts:
        raise ValueError(f"output_group must be a safe relative path; got {output_group!r}")

    project_dir = Path(__file__).resolve().parent
    os.chdir(project_dir)
    source_manifest = project_dir / f"{manifest_stem}_{shard_id}.csv"
    runtime_manifest = project_dir / f"{manifest_stem}_{shard_id}.runtime.csv"
    codes_dir = validate_project(project_dir, source_manifest)

    # Set GPU visibility before torch/core imports.
    os.environ["CUDA_VISIBLE_DEVICES"] = str(gpu_id)
    os.environ.setdefault("MCP_VERBOSE_TRAIN", "0")
    os.environ.setdefault("MCP_LEGACY_AUGMENTATION", "0")
    os.environ.setdefault("MCP_USE_LEGACY_FDR", "0")
    os.environ.setdefault("MCP_FAST_RESUME", "1")
    validate_dependencies()

    import torch

    print(
        f"PyCharm shard {shard_id}: physical GPU={gpu_id}, "
        f"CUDA available={torch.cuda.is_available()}, visible GPUs={torch.cuda.device_count()}",
        flush=True,
    )
    if torch.cuda.is_available():
        print(f"visible GPU 0: {torch.cuda.get_device_name(0)}", flush=True)
    else:
        print("WARNING: CUDA is unavailable; this shard will run on CPU.", flush=True)

    data_index = shard_id - 1
    rscript = locate_rscript()
    run_count = prepare_runtime_manifest(
        source_manifest, runtime_manifest, rscript, codes_dir, gpu_id, data_index,
        validation_profile=validation_profile,
    )
    print(f"R codes directory: {codes_dir}", flush=True)
    print_dataset_names(project_dir, data_index)

    shard_output = result_root.expanduser().resolve() / output_group_path / f"shard_{shard_id}"
    shard_output.mkdir(parents=True, exist_ok=True)
    core_script = project_dir / "MCP_r1_mv_contrast_v6.0.3_4_linux_comb_exp_mcc2_new.py"

    # Import only after CUDA_VISIBLE_DEVICES has been set.
    if str(project_dir) not in sys.path:
        sys.path.insert(0, str(project_dir))
    from MCP_r1_mcp_experiment_runner import execute_run_manifest

    print(f"Shard {shard_id}: validating the {run_count}-row run plan", flush=True)
    dry = execute_run_manifest(
        runtime_manifest, shard_output, core_script=core_script, dry_run=True, strict=True
    )
    plan = pd.read_csv(dry.plan_path)
    if len(plan) != run_count:
        raise RuntimeError(f"Dry-run plan has {len(plan)} rows instead of {run_count}")

    print(f"Shard {shard_id}: starting/resuming {run_count} core runs", flush=True)
    artifacts = execute_run_manifest(
        runtime_manifest, shard_output, core_script=core_script, dry_run=False, strict=True
    )
    ledger = pd.read_csv(artifacts.ledger_path)
    if len(ledger) != run_count:
        raise RuntimeError(f"Ledger has {len(ledger)} rows instead of {run_count}")
    errors = ledger[ledger["status"].astype(str).eq("error")]
    if not errors.empty:
        raise RuntimeError(f"Shard {shard_id} contains {len(errors)} failed runs")
    predictions = pd.read_csv(artifacts.prediction_manifest_path)
    if predictions.empty:
        raise RuntimeError(f"Shard {shard_id} generated no prediction rows")
    print(
        f"SHARD {shard_id} COMPLETED: ledger={run_count}, prediction rows={len(predictions)}, "
        f"output={shard_output}",
        flush=True,
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--shard-id", type=int, default=DEFAULT_SHARD_ID)
    parser.add_argument("--gpu-id", type=int, default=DEFAULT_GPU_ID)
    parser.add_argument(
        "--result-root",
        type=Path,
        default=Path(__file__).resolve().parent / "revision_results",
    )
    parser.add_argument("--manifest-stem", default="MCP_r1_task1_2_DIA_shard")
    parser.add_argument("--output-group", default="task1_2_shards")
    parser.add_argument(
        "--validation-profile",
        choices=["task1_2", "view_combination_incremental"],
        default="task1_2",
    )
    return parser


def main() -> None:
    args = build_parser().parse_args()
    run_shard(
        args.shard_id,
        args.gpu_id,
        args.result_root,
        manifest_stem=args.manifest_stem,
        output_group=args.output_group,
        validation_profile=args.validation_profile,
    )


if __name__ == "__main__":
    main()
