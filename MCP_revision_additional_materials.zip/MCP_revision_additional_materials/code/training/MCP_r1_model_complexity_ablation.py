"""Analyze whether MCP's added architectural/view complexity is justified.

补做任务 5：多视图与模型结构因子化消融、运行成本和简约模型选择。

The script has three roles:
1. emit a reviewer-oriented experiment design (DIA exhaustive by default;
   optional small DDA confirmation set);
2. optionally expand a compact dataset manifest and run every design row by
   calling the original MCP core;
3. aggregate core ``*_metrics_all_s.csv`` outputs from completed variants.

Required result-manifest columns
--------------------------------
dataset, acquisition, platform, variant, view_set, result_file, test_type

Optional columns
----------------
seed, runtime_seconds, peak_memory_mb, parameter_count, complexity_rank

``test_type`` selects the matching row from the core metric file, whose usual
columns are Acc, Prec, Rec, F1, Mcc, pAUC, etc.
"""

from __future__ import annotations

import argparse
import itertools
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import wilcoxon

from MCP_r1_mcp_experiment_runner import add_core_runner_arguments, run_core_from_args

from MCP_r1_supplementary_analysis_utils import (
    bh_adjust,
    bootstrap_mean_ci,
    ensure_output_dir,
    read_table,
    resolve_path,
    seed_everything,
)


DEFAULT_COMPLEXITY_RANK = {
    "single_view_statistical": 1,
    "rank_or_pvalue_fusion": 2,
    "simple_early_fusion": 3,
    "simple_late_fusion": 3,
    "single_view_mcp": 4,
    "no_cross_attention": 5,
    "no_contrastive": 5,
    "no_balancing": 5,
    "full_mcp": 6,
}


def experiment_design(include_targeted_dda: bool = False) -> pd.DataFrame:
    rows: list[dict] = []
    dia_views = ["dlfq", "maxlfq", "top3", "top1"]
    dda_sets = [
        ("dlfq",),
        ("maxlfq",),
        ("dlfq", "maxlfq"),
        ("dlfq", "count"),
        ("dlfq", "maxlfq", "top0", "top3", "count"),
    ]
    broad_variants = [
        "rank_or_pvalue_fusion",
        "simple_early_fusion",
        "simple_late_fusion",
        "full_mcp",
    ]
    deep_ablation_variants = ["no_balancing", "no_contrastive", "no_cross_attention"]
    dia_ablation_sets = {
        "dlfq+maxlfq",
        "dlfq+maxlfq+top1",
        "dlfq+maxlfq+top3+top1",
    }
    for size in range(2, len(dia_views) + 1):
        for views in itertools.combinations(dia_views, size):
            view_set = "+".join(views)
            variants = broad_variants + (deep_ablation_variants if view_set in dia_ablation_sets else [])
            for variant in variants:
                rows.append(
                    {
                        "acquisition": "DIA",
                        "view_set": view_set,
                        "variant": variant,
                        "scope": "exhaustive_primary",
                        "complexity_rank": DEFAULT_COMPLEXITY_RANK[variant],
                    }
                )
    for view in dia_views:
        for variant in ["single_view_statistical", "single_view_mcp"]:
            rows.append(
                {
                    "acquisition": "DIA",
                    "view_set": view,
                    "variant": variant,
                    "scope": "single_view_control",
                    "complexity_rank": DEFAULT_COMPLEXITY_RANK[variant],
                }
            )
    # The reviewer response can be supported by the seven DIA datasets alone.
    # DDA is opt-in because its five-view combination space across 11 datasets is
    # disproportionately expensive; even when enabled, only representative sets
    # are emitted rather than every DDA combination.
    if include_targeted_dda:
        for views in dda_sets:
            view_set = "+".join(views)
            if len(views) == 1:
                variants = ["single_view_statistical", "single_view_mcp"]
            else:
                variants = list(broad_variants)
                if view_set in {"dlfq+count", "dlfq+maxlfq+top0+top3+count"}:
                    variants += deep_ablation_variants
            for variant in variants:
                rows.append(
                    {
                        "acquisition": "DDA",
                        "view_set": view_set,
                        "variant": variant,
                        "scope": "targeted_confirmation",
                        "complexity_rank": DEFAULT_COMPLEXITY_RANK[variant],
                    }
                )
    return pd.DataFrame(rows)


def expand_design_for_datasets(
    dataset_manifest_path: Path, design: pd.DataFrame, output_path: Path
) -> Path:
    """Cross a compact dataset list with the recommended view/variant design."""

    datasets = read_table(dataset_manifest_path)
    required = ["dataset", "acquisition", "platform", "data_index", "group1", "group2"]
    missing = [column for column in required if column not in datasets.columns]
    if missing:
        raise ValueError(f"Dataset manifest missing columns: {missing}")
    rows: list[dict] = []
    for _, dataset in datasets.iterrows():
        matching = design[
            design["acquisition"].astype(str).str.upper()
            == str(dataset["acquisition"]).upper()
        ]
        if matching.empty:
            raise ValueError(f"No ablation design exists for acquisition {dataset['acquisition']!r}")
        for _, configuration in matching.iterrows():
            row = dataset.to_dict()
            for path_field in ["data_root", "r_code"]:
                path_value = row.get(path_field, "")
                if isinstance(path_value, str) and path_value.strip():
                    candidate = Path(path_value).expanduser()
                    if not candidate.is_absolute():
                        candidate = (dataset_manifest_path.resolve().parent / candidate).resolve()
                    row[path_field] = str(candidate)
            row.update(
                {
                    "views": configuration["view_set"],
                    "variant": configuration["variant"],
                    "scope": configuration["scope"],
                    "complexity_rank": configuration["complexity_rank"],
                    "run_id": (
                        f"{dataset['dataset']}__{dataset['platform']}__{configuration['variant']}__"
                        f"{str(configuration['view_set']).replace('+', '-')}"
                    ),
                }
            )
            rows.append(row)
    pd.DataFrame(rows).to_csv(output_path, index=False)
    return output_path


def normalized_metric_columns(frame: pd.DataFrame) -> dict[str, str]:
    aliases = {
        "accuracy": ["accuracy", "Acc"],
        "precision": ["precision", "Prec"],
        "recall": ["recall", "Rec"],
        "f1": ["f1", "F1"],
        "mcc": ["mcc", "Mcc"],
        "pauc_0.01": ["pauc_0.01", "pauc001"],
        "pauc_0.05": ["pauc_0.05", "pauc005"],
        "pauc_0.10": ["pauc_0.10", "pauc01"],
    }
    mapping: dict[str, str] = {}
    for canonical, candidates in aliases.items():
        for candidate in candidates:
            if candidate in frame.columns:
                mapping[canonical] = candidate
                break
    return mapping


def load_results(manifest_path: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    manifest = read_table(manifest_path)
    required = ["dataset", "acquisition", "platform", "variant", "view_set", "result_file", "test_type"]
    missing = [column for column in required if column not in manifest.columns]
    if missing:
        raise ValueError(f"Result manifest missing columns: {missing}")
    rows: list[dict] = []
    audit: list[dict] = []
    for row_number, row in manifest.iterrows():
        path = resolve_path(manifest_path, row["result_file"])
        try:
            result = read_table(path)
            type_column = "test_type" if "test_type" in result.columns else "method"
            if type_column not in result.columns:
                raise ValueError(f"{path} has neither test_type nor method column")
            selected = result[result[type_column].astype(str) == str(row["test_type"])]
            if selected.empty:
                raise ValueError(f"No row with {type_column}={row['test_type']!r} in {path}")
            selected = selected.iloc[0]
            metric_columns = normalized_metric_columns(result)
            if not metric_columns:
                raise ValueError(f"No recognized metric columns in {path}")
            base = {
                "dataset": row["dataset"],
                "acquisition": row["acquisition"],
                "platform": row["platform"],
                "dea_method": row.get("dea_method", ""),
                "variant": row["variant"],
                "view_set": row["view_set"],
                "seed": row.get("seed", np.nan),
                "runtime_seconds": row.get("runtime_seconds", np.nan),
                "peak_memory_mb": row.get("peak_memory_mb", np.nan),
                "parameter_count": row.get("parameter_count", np.nan),
                "complexity_rank": row.get(
                    "complexity_rank", DEFAULT_COMPLEXITY_RANK.get(str(row["variant"]), 99)
                ),
            }
            for canonical, actual in metric_columns.items():
                rows.append({**base, "metric": canonical, "value": pd.to_numeric(selected[actual], errors="coerce")})
            audit.append({"manifest_row": row_number + 2, "status": "ok", "file": str(path), "message": ""})
        except Exception as exc:
            audit.append(
                {"manifest_row": row_number + 2, "status": "error", "file": str(path), "message": repr(exc)}
            )
    return pd.DataFrame(rows), pd.DataFrame(audit)


def aggregate(results: pd.DataFrame, rng: np.random.Generator, bootstrap: int) -> pd.DataFrame:
    rows: list[dict] = []
    group_columns = ["acquisition", "platform", "variant", "view_set", "metric"]
    if "dea_method" in results.columns and results["dea_method"].astype(str).str.len().gt(0).any():
        group_columns.insert(2, "dea_method")
    seed_average = (
        results.groupby(group_columns + ["dataset"], as_index=False)["value"].mean()
    )
    for keys, group in seed_average.groupby(group_columns, dropna=False):
        values = group["value"].dropna().to_numpy(float)
        mean, low, high = bootstrap_mean_ci(values, rng, bootstrap)
        rows.append(
            {
                **dict(zip(group_columns, keys)),
                "n_datasets": len(values),
                "mean": mean,
                "median": float(np.median(values)) if len(values) else np.nan,
                "mean_ci_low": low,
                "mean_ci_high": high,
                "standard_error": float(np.std(values, ddof=1) / np.sqrt(len(values))) if len(values) > 1 else np.nan,
            }
        )
    return pd.DataFrame(rows)


def paired_against_full(results: pd.DataFrame, rng: np.random.Generator, bootstrap: int) -> pd.DataFrame:
    stratum_columns = ["acquisition", "platform"]
    if "dea_method" in results.columns and results["dea_method"].astype(str).str.len().gt(0).any():
        stratum_columns.append("dea_method")
    seed_average = results.groupby(
        ["dataset", *stratum_columns, "variant", "view_set", "metric"], as_index=False
    )["value"].mean()
    rows: list[dict] = []
    pair_columns = [*stratum_columns, "view_set", "metric"]
    for keys, group in seed_average.groupby(pair_columns, dropna=False):
        if not isinstance(keys, tuple):
            keys = (keys,)
        metadata = dict(zip(pair_columns, keys))
        pivot = group.pivot(index="dataset", columns="variant", values="value")
        if "full_mcp" not in pivot.columns:
            continue
        for comparator in pivot.columns:
            if comparator == "full_mcp":
                continue
            paired = pivot[["full_mcp", comparator]].dropna()
            differences = paired["full_mcp"].to_numpy() - paired[comparator].to_numpy()
            if not len(differences):
                continue
            mean, low, high = bootstrap_mean_ci(differences, rng, bootstrap)
            try:
                pvalue = float(wilcoxon(differences).pvalue) if len(differences) >= 2 else np.nan
            except ValueError:
                pvalue = 1.0
            rows.append(
                {
                    **metadata,
                    "comparator": comparator,
                    "n_pairs": len(differences),
                    "mean_full_minus_comparator": mean,
                    "ci_low": low,
                    "ci_high": high,
                    "wilcoxon_pvalue": pvalue,
                }
            )
    result = pd.DataFrame(rows)
    if not result.empty:
        result["wilcoxon_fdr_bh"] = bh_adjust(result["wilcoxon_pvalue"])
    return result


def one_standard_error_selection(summary: pd.DataFrame, metric: str = "mcc") -> pd.DataFrame:
    rows: list[dict] = []
    selected_metric = summary[summary["metric"] == metric]
    group_columns = ["acquisition", "platform"]
    if "dea_method" in summary.columns and summary["dea_method"].astype(str).str.len().gt(0).any():
        group_columns.append("dea_method")
    group_columns.append("view_set")
    for keys, group in selected_metric.groupby(group_columns, dropna=False):
        if not isinstance(keys, tuple):
            keys = (keys,)
        metadata = dict(zip(group_columns, keys))
        group = group.copy()
        if group.empty:
            continue
        best = group.loc[group["mean"].idxmax()]
        cutoff = best["mean"] - (best["standard_error"] if np.isfinite(best["standard_error"]) else 0.0)
        eligible = group[group["mean"] >= cutoff].copy()
        eligible["complexity_rank"] = eligible["variant"].map(DEFAULT_COMPLEXITY_RANK).fillna(99)
        choice = eligible.sort_values(["complexity_rank", "mean"], ascending=[True, False]).iloc[0]
        rows.append(
            {
                **metadata,
                "best_variant": best["variant"],
                "best_mean": best["mean"],
                "one_se_cutoff": cutoff,
                "parsimonious_variant": choice["variant"],
                "parsimonious_mean": choice["mean"],
                "complexity_rank": choice["complexity_rank"],
            }
        )
    return pd.DataFrame(rows)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--result-manifest", type=Path, default=None)
    parser.add_argument(
        "--dataset-manifest",
        type=Path,
        help="Compact dataset list to expand across the recommended DIA ablation design",
    )
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--bootstrap", type=int, default=2000)
    parser.add_argument("--seed", type=int, default=2024)
    parser.add_argument("--design-only", action="store_true")
    parser.add_argument(
        "--include-targeted-dda",
        action="store_true",
        help="Also emit a small representative DDA confirmation set (disabled by default)",
    )
    add_core_runner_arguments(parser)
    return parser


def main() -> None:
    args = build_parser().parse_args()
    out = ensure_output_dir(args.output_dir)
    design = experiment_design(args.include_targeted_dda)
    design.to_csv(out / "recommended_experiment_design.csv", index=False)
    if args.design_only:
        scope = "DIA plus targeted DDA" if args.include_targeted_dda else "DIA-only"
        print(f"Wrote recommended {scope} ablation design: {out}")
        return
    if args.dataset_manifest is not None:
        if args.run_manifest is not None:
            raise ValueError("Use either --dataset-manifest or --run-manifest, not both")
        args.run_manifest = expand_design_for_datasets(
            args.dataset_manifest, design, out / "expanded_ablation_run_manifest.csv"
        )
    core_artifacts = run_core_from_args(args, out)
    if args.dry_run_core and core_artifacts is not None:
        print(f"Core dry-run plan written to {core_artifacts.plan_path}")
        return
    result_manifest = args.result_manifest or (
        core_artifacts.ablation_manifest_path if core_artifacts is not None else None
    )
    if result_manifest is None:
        raise ValueError("Provide --result-manifest, --run-manifest, or use --design-only")
    rng = seed_everything(args.seed)
    results, audit = load_results(result_manifest)
    audit.to_csv(out / "input_audit.csv", index=False)
    if results.empty:
        raise RuntimeError("No ablation result was loaded; inspect input_audit.csv")
    results.to_csv(out / "ablation_metrics_long.csv", index=False)
    summary = aggregate(results, rng, args.bootstrap)
    summary.to_csv(out / "ablation_summary.csv", index=False)
    paired_against_full(results, rng, args.bootstrap).to_csv(
        out / "paired_differences_vs_full_mcp.csv", index=False
    )
    one_standard_error_selection(summary).to_csv(out / "one_standard_error_selection.csv", index=False)
    print(f"Completed model-complexity ablation analysis. Results: {out}")


if __name__ == "__main__":
    main()
