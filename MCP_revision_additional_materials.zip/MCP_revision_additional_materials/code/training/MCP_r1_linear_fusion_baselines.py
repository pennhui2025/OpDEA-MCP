"""True linear early/late-fusion baselines using MCP's own pseudo-labels.

Unlike the existing ``simple_early_fusion`` neural ablation, these baselines
are ordinary L2-regularized logistic regressions:

* ridge_early_fusion: concatenate the four preprocessed view vectors;
* ridge_late_fusion: fit one ridge model per view and average probabilities.

The fitted labels are reconstructed from the saved MCP training-protein table
using the same native-FDR and fold-change rule.  Spike-in ``True_lab`` is never
used for fitting, cross-validation, threshold choice, or feature processing;
it is read only after predictions have been produced for final evaluation.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegressionCV
from sklearn.metrics import (
    average_precision_score,
    confusion_matrix,
    matthews_corrcoef,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import MinMaxScaler, StandardScaler

from MCP_r1_final_revision_utils import (
    bh_adjust,
    bootstrap_mean_ci,
    exact_signflip_p,
    rebase_recorded_path,
    resolve_results_root,
)


VIEWS = ("dlfq", "maxlfq", "top3", "top1")
INFERENTIAL_METRICS = {"auroc", "auprc", "pauc_0.01", "precision", "recall", "mcc"}


def parse_training_labels(path: Path, fdr: float, fc_ratio: float) -> pd.DataFrame:
    table = pd.read_csv(path)
    if "Protein" not in table.columns:
        raise ValueError(f"Unexpected MCP training table: {path}")

    # One historical writer used the header order
    # Protein,organism,scores,logFC,true_label while writing
    # Protein,score,logFC,organism,true_label.  Detect both layouts explicitly.
    numeric_fraction = {
        column: pd.to_numeric(table[column], errors="coerce").notna().mean()
        for column in table.columns
    }
    if numeric_fraction.get("scores", 0.0) > 0.95 and numeric_fraction.get("logFC", 0.0) > 0.95:
        score_column, logfc_column = "scores", "logFC"
    elif numeric_fraction.get("organism", 0.0) > 0.95 and numeric_fraction.get("scores", 0.0) > 0.95:
        score_column, logfc_column = "organism", "scores"
    else:
        raise ValueError(
            f"Cannot identify score/logFC columns in {path}; numeric fractions={numeric_fraction}"
        )

    score = pd.to_numeric(table[score_column], errors="coerce")
    logfc = pd.to_numeric(table[logfc_column], errors="coerce")
    valid = score.notna() & logfc.notna()
    pseudo = (
        (1.0 - score).le(fdr)
        & logfc.abs().ge(float(np.log2(fc_ratio)))
    ).astype(int)
    output = pd.DataFrame({
        "Protein": table["Protein"].astype(str),
        "pseudo_label": pseudo,
        "pseudo_score": score,
        "pseudo_log2fc": logfc,
    })[valid].drop_duplicates("Protein")
    return output


def load_core_features(run_dir: Path) -> tuple[pd.Series, list[np.ndarray], np.ndarray]:
    proteins: pd.Series | None = None
    features: list[np.ndarray] = []
    missing_masks: list[np.ndarray] = []
    for index, view in enumerate(VIEWS):
        real = list(run_dir.glob(f"real_normed_v{index}_union_*_{view}.tsv"))
        normed = list(run_dir.glob(f"*_normed_view{index}_union.csv"))
        if len(real) != 1 or len(normed) != 1:
            raise FileNotFoundError(f"Expected one real/normed matrix for {view} in {run_dir}")
        meta = pd.read_csv(real[0], sep="\t", usecols=["Protein"])["Protein"].astype(str)
        matrix = pd.read_csv(normed[0], header=None).apply(pd.to_numeric, errors="coerce").to_numpy(float)
        if len(meta) != matrix.shape[0]:
            raise ValueError(f"Row mismatch for {view} in {run_dir}")
        if proteins is None:
            proteins = meta.reset_index(drop=True)
        elif not proteins.equals(meta.reset_index(drop=True)):
            raise ValueError(f"Protein order differs between views in {run_dir}")
        missing_masks.append(~np.isfinite(matrix))
        scaled = MinMaxScaler(feature_range=(0.0, 1.0)).fit_transform(matrix)
        scaled[~np.isfinite(scaled)] = 0.0
        features.append(scaled)
    assert proteins is not None
    high_missing = np.concatenate(missing_masks, axis=1).mean(axis=1) >= 0.80
    return proteins, features, high_missing


def make_model(labels: np.ndarray, seed: int) -> LogisticRegressionCV:
    counts = np.bincount(labels.astype(int), minlength=2)
    n_splits = int(min(5, counts.min()))
    if n_splits < 2:
        raise ValueError(f"Linear baseline needs >=2 pseudo-labelled proteins per class; found {counts.tolist()}")
    cv = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    return LogisticRegressionCV(
        Cs=np.logspace(-4, 4, 17),
        cv=cv,
        penalty="l2",
        solver="liblinear",
        scoring="roc_auc",
        class_weight="balanced",
        max_iter=5000,
        n_jobs=1,
        random_state=seed,
        refit=True,
    )


def fit_probability(features: np.ndarray, labels: np.ndarray, train_mask: np.ndarray, seed: int) -> np.ndarray:
    scaler = StandardScaler()
    x_train = scaler.fit_transform(features[train_mask])
    x_all = scaler.transform(features)
    model = make_model(labels[train_mask], seed)
    model.fit(x_train, labels[train_mask])
    return model.predict_proba(x_all)[:, 1]


def evaluate(
    truth: np.ndarray,
    score: np.ndarray,
    called: np.ndarray,
) -> dict[str, float]:
    keep = np.isfinite(truth) & np.isfinite(score)
    y = truth[keep].astype(int)
    s = score[keep]
    c = called[keep].astype(int)
    tn, fp, fn, tp = confusion_matrix(y, c, labels=[0, 1]).ravel()
    return {
        "n_proteins": int(len(y)),
        "auroc": float(roc_auc_score(y, s)),
        "auprc": float(average_precision_score(y, s)),
        "pauc_0.01": float(roc_auc_score(y, s, max_fpr=0.01)),
        "precision": float(precision_score(y, c, zero_division=0)),
        "recall": float(recall_score(y, c, zero_division=0)),
        "mcc": float(matthews_corrcoef(y, c)),
        "tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp),
    }


def parse_truth_and_reference(path: Path, fdr: float, fc_ratio: float) -> pd.DataFrame:
    table = pd.read_csv(path)
    columns = ["Protein", "True_lab"]
    for view in VIEWS:
        columns.extend([f"score_DP{view}", f"logFC_DP{view}"])
    stat = table[columns].copy().drop_duplicates("Protein")
    stat["Protein"] = stat["Protein"].astype(str)
    direct = table[["Protein.1", "Probability", "ori_logFC", "qvalue"]].copy()
    direct = direct.rename(columns={"Protein.1": "Protein"}).drop_duplicates("Protein")
    direct["Protein"] = direct["Protein"].astype(str)
    output = stat.merge(direct, on="Protein", how="inner", validate="one_to_one")
    logfc_threshold = float(np.log2(fc_ratio))
    calls = []
    scores = []
    for view in VIEWS:
        score = pd.to_numeric(output[f"score_DP{view}"], errors="coerce")
        logfc = pd.to_numeric(output[f"logFC_DP{view}"], errors="coerce")
        calls.append((1.0 - score).le(fdr) & logfc.abs().ge(logfc_threshold))
        scores.append(score.to_numpy(float))
    output["statistical_union_call"] = np.column_stack(calls).any(axis=1)
    output["statistical_intersection_call"] = np.column_stack(calls).all(axis=1)
    output["statistical_union_score"] = np.nanmax(np.column_stack(scores), axis=1)
    output["statistical_intersection_score"] = np.nanmin(np.column_stack(scores), axis=1)
    return output


def run_one(record: dict[str, object], results_root: Path, output: Path, fdr: float, fc_ratio: float, seed: int) -> tuple[pd.DataFrame, list[dict[str, object]]]:
    prediction = rebase_recorded_path(record["prediction_file"], results_root)
    run_dir = prediction.parent.parent
    training_files = list(run_dir.glob("*4views_train_pros.csv"))
    if len(training_files) != 1:
        raise FileNotFoundError(f"Expected one four-view training table in {run_dir}")
    pseudo = parse_training_labels(training_files[0], fdr, fc_ratio)
    proteins, view_features, high_missing = load_core_features(run_dir)
    protein_frame = pd.DataFrame({"Protein": proteins, "row_index": np.arange(len(proteins))})
    labels = protein_frame.merge(pseudo, on="Protein", how="left")
    pseudo_label = pd.to_numeric(labels["pseudo_label"], errors="coerce").to_numpy(float)
    pseudo_label[high_missing] = 0.0  # Same explicit >=80% missing negative rule as MCP.
    train_mask = np.isfinite(pseudo_label)
    y_pseudo = np.where(train_mask, pseudo_label, 0).astype(int)
    if len(np.unique(y_pseudo[train_mask])) != 2:
        raise ValueError(f"Both pseudo-label classes are required in {run_dir}")

    early = fit_probability(np.concatenate(view_features, axis=1), y_pseudo, train_mask, seed)
    late_components = [fit_probability(view, y_pseudo, train_mask, seed) for view in view_features]
    late = np.mean(np.column_stack(late_components), axis=1)

    reference = parse_truth_and_reference(prediction, fdr, fc_ratio)
    predictions = protein_frame[["Protein"]].copy()
    predictions["pseudo_label"] = np.where(train_mask, y_pseudo, np.nan)
    predictions["ridge_early_probability"] = early
    predictions["ridge_late_probability"] = late
    predictions = predictions.merge(reference, on="Protein", how="inner", validate="one_to_one")
    truth = pd.to_numeric(predictions["True_lab"], errors="coerce").to_numpy(float)
    logfc = pd.to_numeric(predictions["ori_logFC"], errors="coerce").to_numpy(float)
    fc_ok = np.abs(logfc) >= float(np.log2(fc_ratio))

    methods = {
        "full_mcp_probability": (
            pd.to_numeric(predictions["Probability"], errors="coerce").to_numpy(float),
            pd.to_numeric(predictions["Probability"], errors="coerce").to_numpy(float) >= 0.5,
        ),
        "ridge_early_fusion": (
            predictions["ridge_early_probability"].to_numpy(float),
            predictions["ridge_early_probability"].to_numpy(float) >= 0.5,
        ),
        "ridge_late_fusion": (
            predictions["ridge_late_probability"].to_numpy(float),
            predictions["ridge_late_probability"].to_numpy(float) >= 0.5,
        ),
        "statistical_union": (
            predictions["statistical_union_score"].to_numpy(float),
            predictions["statistical_union_call"].to_numpy(bool),
        ),
        "statistical_intersection": (
            predictions["statistical_intersection_score"].to_numpy(float),
            predictions["statistical_intersection_call"].to_numpy(bool),
        ),
    }
    rows: list[dict[str, object]] = []
    dea = str(record["dea_methods"]).split("+")[0]
    for method, (score, base_call) in methods.items():
        called = base_call if method.startswith("statistical_") else (base_call & fc_ok)
        metrics = evaluate(truth, score, called)
        for metric, value in metrics.items():
            rows.append({
                "dataset": record["dataset"],
                "platform": record["platform"],
                "dea_method": dea,
                "method": method,
                "metric": metric,
                "value": value,
            })
    predictions.insert(0, "dea_method", dea)
    predictions.insert(0, "platform", record["platform"])
    predictions.insert(0, "dataset", record["dataset"])
    return predictions, rows


def paired_tests(dataset_metrics: pd.DataFrame) -> pd.DataFrame:
    dataset_metrics = dataset_metrics[dataset_metrics["metric"].isin(INFERENTIAL_METRICS)].copy()
    full = dataset_metrics[dataset_metrics["method"].eq("full_mcp_probability")][
        ["dataset", "metric", "value"]
    ].rename(columns={"value": "full_mcp"})
    rows: list[dict[str, object]] = []
    for method in sorted(set(dataset_metrics["method"]) - {"full_mcp_probability"}):
        other = dataset_metrics[dataset_metrics["method"].eq(method)][
            ["dataset", "metric", "value"]
        ].rename(columns={"value": "comparator"})
        paired = full.merge(other, on=["dataset", "metric"], how="inner", validate="one_to_one")
        for metric, block in paired.groupby("metric", sort=True):
            differences = (block["full_mcp"] - block["comparator"]).to_numpy(float)
            low, high = bootstrap_mean_ci(differences)
            rows.append({
                "metric": metric,
                "method_a": "full_mcp_probability",
                "method_b": method,
                "n_biological_datasets": len(differences),
                "mean_paired_difference": float(np.mean(differences)),
                "median_paired_difference": float(np.median(differences)),
                "bootstrap_95ci_low": low,
                "bootstrap_95ci_high": high,
                "exact_signflip_p": exact_signflip_p(differences),
            })
    output = pd.DataFrame(rows)
    if not output.empty:
        output["bh_q_across_method_metric_tests"] = bh_adjust(output["exact_signflip_p"])
    return output


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results-root", default=None)
    parser.add_argument("--output-dir", default="revision_results/final_required/linear_fusion_baselines")
    parser.add_argument("--fdr", type=float, default=0.05)
    parser.add_argument("--fc-ratio", type=float, default=1.5)
    parser.add_argument("--seed", type=int, default=2024)
    args = parser.parse_args()
    results_root = resolve_results_root(args.results_root)
    ledger_path = results_root / "task1_2_core_merged_limma_ROTS" / "core_run_ledger.csv"
    ledger = pd.read_csv(ledger_path)
    selected = ledger[
        ledger["variant"].astype(str).eq("full_mcp")
        & ledger["status"].astype(str).isin(["completed", "skipped_existing"])
    ]
    if len(selected) != 28:
        raise ValueError(f"Expected 28 full MCP runs; found {len(selected)}")

    output = Path(args.output_dir).expanduser().resolve()
    output.mkdir(parents=True, exist_ok=True)
    prediction_blocks, metric_rows = [], []
    for record in selected.to_dict("records"):
        predictions, rows = run_one(
            record, results_root, output, args.fdr, args.fc_ratio, args.seed
        )
        prediction_blocks.append(predictions)
        metric_rows.extend(rows)
    all_predictions = pd.concat(prediction_blocks, ignore_index=True)
    stratum_metrics = pd.DataFrame(metric_rows)
    dataset_metrics = (
        stratum_metrics.groupby(["dataset", "method", "metric"], as_index=False)
        .agg(value=("value", "mean"), n_platform_dea_strata=("value", "count"))
    )
    tests = paired_tests(dataset_metrics)

    all_predictions.to_csv(output / "linear_fusion_predictions.csv.gz", index=False, compression="gzip")
    stratum_metrics.to_csv(output / "linear_fusion_metrics_by_stratum.csv", index=False)
    dataset_metrics.to_csv(output / "linear_fusion_metrics_by_dataset.csv", index=False)
    tests.to_csv(output / "full_mcp_vs_linear_baselines_paired_tests.csv", index=False)
    summary = {
        "models": ["ridge_early_fusion", "ridge_late_fusion"],
        "training_labels": "MCP pseudo-labels reconstructed from saved score/log2FC; truth excluded",
        "hyperparameter_selection": "stratified CV on pseudo-labels only",
        "primary_binary_rule": f"probability >= 0.5 and abs(log2FC) >= log2({args.fc_ratio})",
        "inferential_unit": "seven biological datasets",
    }
    (output / "analysis_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"Completed true linear fusion baselines: {output}")


if __name__ == "__main__":
    main()
