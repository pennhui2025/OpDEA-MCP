"""Analyze MCP performance across all 1/2/3/4-view DIA combinations.

Combination replicates are first averaged within each biological dataset. Only
the resulting dataset-level values enter cross-dataset confidence intervals and
paired tests, preventing pseudoreplication. / 先在数据集内汇总组合，再跨数据集统计。
"""

from __future__ import annotations

import argparse
import json
from itertools import combinations
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import wilcoxon

from MCP_r1_fair_baseline_benchmark import evaluate_manifest
from MCP_r1_supplementary_analysis_utils import (
    bh_adjust,
    bootstrap_mean_ci,
    ensure_output_dir,
    parse_number_list,
    seed_everything,
)


VIEWS = ("dlfq", "maxlfq", "top3", "top1")
EXPECTED_BY_COUNT = {
    size: {"+".join(values) for values in combinations(VIEWS, size)}
    for size in range(1, 5)
}
METRICS = ["precision", "recall", "specificity", "f1", "mcc", "balanced_accuracy"]


def add_view_metadata(frame: pd.DataFrame) -> pd.DataFrame:
    output = frame.copy()
    output["view_count"] = output["view_set"].astype(str).map(
        lambda value: len([part for part in value.split("+") if part.strip()])
    )
    output["combination_id"] = output["view_set"].astype(str).str.replace(
        "+", "_", regex=False
    )
    return output


def select_mcp_rows(main_manifest: Path, incremental_manifest: Path) -> pd.DataFrame:
    main = add_view_metadata(pd.read_csv(main_manifest))
    incremental = add_view_metadata(pd.read_csv(incremental_manifest))

    def direct_probability(frame: pd.DataFrame) -> pd.Series:
        return frame["score_column"].fillna("").astype(str).eq("Probability")

    single = main[
        main["variant"].astype(str).eq("single_view_mcp")
        & main["method"].astype(str).str.startswith("single_view_mcp_")
        & direct_probability(main)
        & main["view_count"].eq(1)
    ].copy()
    full_four = main[
        main["variant"].astype(str).eq("full_mcp")
        & main["method"].astype(str).eq("full_mcp")
        & direct_probability(main)
        & main["view_count"].eq(4)
    ].copy()
    middle = incremental[
        incremental["variant"].astype(str).eq("full_mcp")
        & incremental["method"].astype(str).eq("full_mcp")
        & direct_probability(incremental)
        & incremental["view_count"].isin([2, 3])
    ].copy()
    single["source_experiment"] = "existing_single_view"
    full_four["source_experiment"] = "existing_four_view"
    middle["source_experiment"] = "incremental_two_three_view"
    selected = pd.concat([single, middle, full_four], ignore_index=True, sort=False)
    selected["source_method"] = selected["method"]
    selected["method"] = "MCP"
    selected["comparison_group"] = (
        selected["acquisition"].astype(str)
        + "|" + selected["platform"].astype(str)
        + "|" + selected["dataset"].astype(str)
        + "|" + selected["dea_method"].astype(str)
        + "|" + selected["view_set"].astype(str)
    )
    return selected


def validate_design(selected: pd.DataFrame) -> pd.DataFrame:
    required = {"dataset", "acquisition", "platform", "dea_method", "view_set", "view_count"}
    missing = sorted(required - set(selected.columns))
    if missing:
        raise ValueError(f"Selected prediction manifest lacks columns: {missing}")
    if len(selected) != 420:
        raise ValueError(f"Complete 1/2/3/4-view design must contain 420 prediction rows; found {len(selected)}")
    key_columns = ["dataset", "acquisition", "platform", "dea_method", "view_set"]
    if selected.duplicated(key_columns).any():
        duplicates = selected.loc[selected.duplicated(key_columns, keep=False), key_columns]
        raise ValueError(f"Duplicate MCP view-set rows: {duplicates.head().to_dict('records')}")

    audit: list[dict[str, object]] = []
    stratum_columns = ["dataset", "acquisition", "platform", "dea_method"]
    for keys, group in selected.groupby(stratum_columns, dropna=False):
        base = dict(zip(stratum_columns, keys))
        observed_all = set(group["view_set"].astype(str))
        expected_all = set().union(*EXPECTED_BY_COUNT.values())
        missing_sets = sorted(expected_all - observed_all)
        unexpected = sorted(observed_all - expected_all)
        counts = group.groupby("view_count").size().to_dict()
        status = "ok" if not missing_sets and not unexpected and counts == {1: 4, 2: 6, 3: 4, 4: 1} else "error"
        audit.append(
            {
                **base,
                "status": status,
                "total_combinations": len(group),
                "view1": int(counts.get(1, 0)),
                "view2": int(counts.get(2, 0)),
                "view3": int(counts.get(3, 0)),
                "view4": int(counts.get(4, 0)),
                "missing_view_sets": ";".join(missing_sets),
                "unexpected_view_sets": ";".join(unexpected),
            }
        )
    audit_frame = pd.DataFrame(audit)
    if len(audit_frame) != 28 or not audit_frame["status"].eq("ok").all():
        raise ValueError("Expected 28 complete dataset/platform/DEA strata")
    per_platform_dea = audit_frame.groupby(["platform", "dea_method"]).size().to_dict()
    expected_strata = {
        (platform, dea): 7
        for platform in ("DIANN", "Spectronaut")
        for dea in ("limma", "ROTS")
    }
    if per_platform_dea != expected_strata:
        raise ValueError(f"Expected seven datasets per platform/DEA: {per_platform_dea}")
    return audit_frame


def to_long_metrics(per_combination: pd.DataFrame) -> pd.DataFrame:
    id_columns = [column for column in per_combination.columns if column not in METRICS]
    return per_combination.melt(
        id_vars=id_columns,
        value_vars=[metric for metric in METRICS if metric in per_combination.columns],
        var_name="metric",
        value_name="value",
    )


def within_dataset_summary(long_metrics: pd.DataFrame) -> pd.DataFrame:
    group_columns = [
        "dataset", "acquisition", "platform", "dea_method", "view_count",
        "fdr_threshold", "fold_change_ratio", "metric",
    ]
    summary = (
        long_metrics.groupby(group_columns, dropna=False)["value"]
        .agg(n_combinations="count", mean="mean", median="median", std="std", minimum="min", maximum="max")
        .reset_index()
    )
    expected_counts = {1: 4, 2: 6, 3: 4, 4: 1}
    wrong = summary[
        summary.apply(
            lambda row: int(row["n_combinations"]) != expected_counts[int(row["view_count"])], axis=1
        )
    ]
    if not wrong.empty:
        raise ValueError(
            "Within-dataset combination counts are incomplete: "
            + str(wrong.head().to_dict("records"))
        )
    return summary


def across_dataset_summary(
    within: pd.DataFrame, rng: np.random.Generator, bootstrap: int
) -> pd.DataFrame:
    group_columns = [
        "acquisition", "platform", "dea_method", "view_count",
        "fdr_threshold", "fold_change_ratio", "metric",
    ]
    records: list[dict[str, object]] = []
    for keys, group in within.groupby(group_columns, dropna=False):
        values = pd.to_numeric(group["mean"], errors="coerce").dropna().to_numpy()
        mean, low, high = bootstrap_mean_ci(values, rng, bootstrap)
        records.append(
            {
                **dict(zip(group_columns, keys)),
                "n_datasets": len(values),
                "mean_of_dataset_means": mean,
                "median_of_dataset_means": float(np.median(values)) if len(values) else np.nan,
                "mean_ci_low": low,
                "mean_ci_high": high,
            }
        )
    result = pd.DataFrame(records)
    if not result.empty and not result["n_datasets"].eq(7).all():
        raise ValueError("Every across-dataset view-count summary must contain seven datasets")
    return result


def exact_view_set_summary(
    long_metrics: pd.DataFrame, rng: np.random.Generator, bootstrap: int
) -> pd.DataFrame:
    group_columns = [
        "acquisition", "platform", "dea_method", "view_count", "view_set",
        "fdr_threshold", "fold_change_ratio", "metric",
    ]
    records: list[dict[str, object]] = []
    for keys, group in long_metrics.groupby(group_columns, dropna=False):
        values = pd.to_numeric(group["value"], errors="coerce").dropna().to_numpy()
        mean, low, high = bootstrap_mean_ci(values, rng, bootstrap)
        records.append(
            {
                **dict(zip(group_columns, keys)),
                "n_datasets": len(values),
                "mean": mean,
                "median": float(np.median(values)) if len(values) else np.nan,
                "mean_ci_low": low,
                "mean_ci_high": high,
            }
        )
    result = pd.DataFrame(records)
    if not result.empty and not result["n_datasets"].eq(7).all():
        raise ValueError("Every exact view-set summary must contain seven datasets")
    return result


def paired_view_count_tests(
    within: pd.DataFrame,
    primary_fdr: float,
    primary_fc: float,
    rng: np.random.Generator,
    bootstrap: int,
) -> pd.DataFrame:
    primary = within[
        np.isclose(within["fdr_threshold"], primary_fdr)
        & np.isclose(within["fold_change_ratio"], primary_fc)
    ]
    records: list[dict[str, object]] = []
    for (acquisition, platform, dea_method, metric), group in primary.groupby(
        ["acquisition", "platform", "dea_method", "metric"], dropna=False
    ):
        pivot = group.pivot(index="dataset", columns="view_count", values="mean")
        for lower, higher in combinations((1, 2, 3, 4), 2):
            paired = pivot[[lower, higher]].dropna()
            differences = paired[higher].to_numpy() - paired[lower].to_numpy()
            mean, low, high = bootstrap_mean_ci(differences, rng, bootstrap)
            try:
                pvalue = float(wilcoxon(differences).pvalue) if len(differences) >= 2 else np.nan
            except ValueError:
                pvalue = 1.0
            records.append(
                {
                    "acquisition": acquisition,
                    "platform": platform,
                    "dea_method": dea_method,
                    "metric": metric,
                    "lower_view_count": lower,
                    "higher_view_count": higher,
                    "contrast": f"view{higher}-view{lower}",
                    "n_paired_datasets": len(differences),
                    "mean_paired_difference": mean,
                    "difference_ci_low": low,
                    "difference_ci_high": high,
                    "median_paired_difference": (
                        float(np.median(differences)) if len(differences) else np.nan
                    ),
                    "wilcoxon_pvalue": pvalue,
                }
            )
    result = pd.DataFrame(records)
    if not result.empty:
        if not result["n_paired_datasets"].eq(7).all():
            raise ValueError("Every view-count contrast must pair seven biological datasets")
        result["wilcoxon_fdr_bh"] = bh_adjust(result["wilcoxon_pvalue"])
    return result


def run_analysis(
    main_manifest: Path,
    incremental_manifest: Path,
    output_dir: Path,
    fdr_thresholds: list[float],
    fc_ratios: list[float],
    primary_fdr: float,
    primary_fc: float,
    bootstrap: int,
    seed: int,
) -> dict[str, object]:
    output_dir = ensure_output_dir(output_dir)
    selected = select_mcp_rows(main_manifest, incremental_manifest)
    design_audit = validate_design(selected)
    selected_path = output_dir / "selected_mcp_prediction_manifest.csv"
    selected.to_csv(selected_path, index=False)
    design_audit.to_csv(output_dir / "view_combination_design_audit.csv", index=False)

    per_combination, input_audit = evaluate_manifest(
        selected_path, fdr_thresholds, fc_ratios
    )
    input_audit.to_csv(output_dir / "input_audit.csv", index=False)
    errors = input_audit[input_audit["status"].astype(str).str.lower().eq("error")]
    if not errors.empty:
        raise RuntimeError(f"Prediction input audit contains {len(errors)} errors")
    per_combination.to_csv(output_dir / "per_combination_threshold_metrics.csv", index=False)
    long_metrics = to_long_metrics(per_combination)
    long_metrics.to_csv(output_dir / "per_combination_metrics_long.csv", index=False)

    within = within_dataset_summary(long_metrics)
    within.to_csv(output_dir / "within_dataset_view_count_summary.csv", index=False)
    rng = seed_everything(seed)
    across = across_dataset_summary(within, rng, bootstrap)
    across.to_csv(output_dir / "across_dataset_view_count_summary.csv", index=False)
    exact = exact_view_set_summary(long_metrics, rng, bootstrap)
    exact.to_csv(output_dir / "exact_view_set_summary.csv", index=False)
    paired = paired_view_count_tests(
        within, primary_fdr, primary_fc, rng, bootstrap
    )
    paired.to_csv(output_dir / "paired_view_count_comparisons.csv", index=False)

    summary: dict[str, object] = {
        "status": "complete",
        "selected_prediction_rows": len(selected),
        "complete_dataset_platform_dea_strata": len(design_audit),
        "view_counts": [1, 2, 3, 4],
        "expected_combinations_per_view_count": {"1": 4, "2": 6, "3": 4, "4": 1},
        "dea_methods": sorted(selected["dea_method"].astype(str).unique()),
        "platforms": sorted(selected["platform"].astype(str).unique()),
        "primary_fdr": primary_fdr,
        "primary_fc": primary_fc,
        "statistical_unit": "biological dataset after within-dataset combination averaging",
        "output_dir": str(output_dir),
    }
    with (output_dir / "analysis_summary.json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--main-manifest", required=True, type=Path)
    parser.add_argument("--incremental-manifest", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--fdr-thresholds", default="0.01,0.05,0.10")
    parser.add_argument("--fc-ratios", default="1.0,1.2,1.5")
    parser.add_argument("--primary-fdr", type=float, default=0.05)
    parser.add_argument("--primary-fc", type=float, default=1.5)
    parser.add_argument("--bootstrap", type=int, default=2000)
    parser.add_argument("--seed", type=int, default=2024)
    args = parser.parse_args()
    summary = run_analysis(
        args.main_manifest.resolve(),
        args.incremental_manifest.resolve(),
        args.output_dir.resolve(),
        parse_number_list(args.fdr_thresholds),
        parse_number_list(args.fc_ratios),
        args.primary_fdr,
        args.primary_fc,
        args.bootstrap,
        args.seed,
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

