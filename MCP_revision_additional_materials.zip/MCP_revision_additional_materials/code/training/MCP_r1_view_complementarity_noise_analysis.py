"""Distinguish genuine cross-view complementarity from measurement noise.

补做任务 4：从相关性、覆盖度、缺失机制、变异度和真值DEP角度检验视图互补性。

Required matrix manifest columns
--------------------------------
dataset, acquisition, platform, view, matrix_file, protein_column

Optional columns
----------------
design_file, sample_column, condition_column, group1, group2,
dea_file, dea_protein_column, dea_qvalue_column, dea_log2fc_column,
dea_true_label_column, dea_method

Matrices are protein-by-sample tables.  When a design file is supplied, sample
columns are matched using the same exact/substring convention as ``Utils.py``.
"""

from __future__ import annotations

import argparse
import itertools
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import pearsonr, spearmanr

from MCP_r1_mcp_experiment_runner import add_core_runner_arguments, run_core_from_args

from MCP_r1_supplementary_analysis_utils import ensure_output_dir, read_table, resolve_path


REQUIRED = ["dataset", "acquisition", "platform", "view", "matrix_file", "protein_column"]


def safe_corr(left: np.ndarray, right: np.ndarray, method: str) -> tuple[float, float]:
    mask = np.isfinite(left) & np.isfinite(right)
    if mask.sum() < 3 or np.nanstd(left[mask]) == 0 or np.nanstd(right[mask]) == 0:
        return np.nan, np.nan
    result = pearsonr(left[mask], right[mask]) if method == "pearson" else spearmanr(left[mask], right[mask])
    return float(result.statistic), float(result.pvalue)


def match_sample_columns(
    matrix: pd.DataFrame,
    protein_column: str,
    design_path: Path | None,
    sample_column: str,
    condition_column: str = "condition",
    group1: str | None = None,
    group2: str | None = None,
) -> pd.DataFrame:
    numeric = matrix.drop(columns=[protein_column]).apply(pd.to_numeric, errors="coerce")
    numeric.index = matrix[protein_column].astype(str)
    numeric = numeric.groupby(level=0).mean()
    # Remove annotation columns (for example Organism) that became all-NA after
    # numeric conversion; they must not be counted as biological samples.
    numeric = numeric.dropna(axis=1, how="all")
    if design_path is None:
        return numeric

    design = read_table(design_path)
    if sample_column not in design.columns:
        raise ValueError(f"Design {design_path} has no sample column '{sample_column}'")
    selected_groups = {
        str(value) for value in (group1, group2)
        if value is not None and str(value).strip()
    }
    if selected_groups:
        if condition_column not in design.columns:
            raise ValueError(
                f"Design {design_path} has no condition column '{condition_column}'"
            )
        design = design[
            design[condition_column].astype(str).isin(selected_groups)
        ].copy()
        observed = set(design[condition_column].astype(str))
        if observed != selected_groups:
            raise ValueError(
                f"Design {design_path} does not contain both requested groups "
                f"{sorted(selected_groups)}; found {sorted(observed)}"
            )
    matched: dict[str, pd.Series] = {}
    for sample in design[sample_column].astype(str).drop_duplicates():
        exact = [column for column in numeric.columns if str(column) == sample]
        candidates = exact or [column for column in numeric.columns if sample in str(column)]
        if candidates:
            # Technical columns matching one biological sample are averaged.
            matched[sample] = numeric[candidates].mean(axis=1, skipna=True)
    if not matched:
        raise ValueError(f"No sample columns in {design_path} matched matrix columns")
    return pd.DataFrame(matched, index=numeric.index)


def transform_values(
    data: pd.DataFrame, log2p1: bool, missing_sentinel: float | None
) -> pd.DataFrame:
    result = data.replace([np.inf, -np.inf], np.nan).astype(float)
    # The core code uses -1 in some intermediate arrays, but a real log-scale
    # measurement can also equal -1. Therefore sentinel handling is explicit.
    # 核心代码部分中间数组使用-1；只有用户明确指定时才按缺失值处理。
    if missing_sentinel is not None:
        result[np.isclose(result, missing_sentinel)] = np.nan
    if log2p1:
        observed = result.to_numpy(float)
        if np.isfinite(observed).any() and np.nanmin(observed) <= -1:
            raise ValueError("--log2p1 requires all observed matrix values to be greater than -1")
        result = np.log2(result + 1.0)
    return result


def view_qc(metadata: dict, data: pd.DataFrame) -> dict:
    values = data.to_numpy(float)
    missing_rate = float(np.isnan(values).mean())
    means = np.nanmean(values, axis=1)
    stds = np.nanstd(values, axis=1, ddof=1)
    valid_cv = np.isfinite(means) & np.isfinite(stds) & (np.abs(means) > 1e-12)
    cv = np.abs(stds[valid_cv] / means[valid_cv])
    observed = values[np.isfinite(values)]
    return {
        **metadata,
        "n_proteins": data.shape[0],
        "n_samples": data.shape[1],
        "missing_rate": missing_rate,
        "median_protein_cv": float(np.nanmedian(cv)) if len(cv) else np.nan,
        "value_q05": float(np.quantile(observed, 0.05)) if len(observed) else np.nan,
        "value_median": float(np.median(observed)) if len(observed) else np.nan,
        "value_q95": float(np.quantile(observed, 0.95)) if len(observed) else np.nan,
        "dynamic_range_q95_q05": float(np.quantile(observed, 0.95) - np.quantile(observed, 0.05))
        if len(observed)
        else np.nan,
    }


def pairwise_complementarity(metadata: dict, left_name: str, left: pd.DataFrame, right_name: str, right: pd.DataFrame):
    common_proteins = left.index.intersection(right.index)
    union_proteins = left.index.union(right.index)
    samples = left.columns.intersection(right.columns)
    # Correlations use proteins represented in both tables. Coverage and missing
    # complementarity use the union, so view-specific proteins are not discarded.
    left_common = left.reindex(index=common_proteins, columns=samples).to_numpy(float)
    right_common = right.reindex(index=common_proteins, columns=samples).to_numpy(float)
    left_union = left.reindex(index=union_proteins, columns=samples).to_numpy(float)
    right_union = right.reindex(index=union_proteins, columns=samples).to_numpy(float)
    both = np.isfinite(left_union) & np.isfinite(right_union)
    left_only = np.isfinite(left_union) & ~np.isfinite(right_union)
    right_only = ~np.isfinite(left_union) & np.isfinite(right_union)
    neither = ~np.isfinite(left_union) & ~np.isfinite(right_union)
    pearson_flat, pearson_flat_p = safe_corr(left_common.ravel(), right_common.ravel(), "pearson")
    spearman_flat, spearman_flat_p = safe_corr(left_common.ravel(), right_common.ravel(), "spearman")
    left_mean = np.nanmean(left_common, axis=1) if len(samples) else np.full(len(common_proteins), np.nan)
    right_mean = np.nanmean(right_common, axis=1) if len(samples) else np.full(len(common_proteins), np.nan)
    pearson_mean, pearson_mean_p = safe_corr(left_mean, right_mean, "pearson")
    spearman_mean, spearman_mean_p = safe_corr(left_mean, right_mean, "spearman")
    left_detected = np.isfinite(left_union).any(axis=1) if len(samples) else np.zeros(len(union_proteins), bool)
    right_detected = np.isfinite(right_union).any(axis=1) if len(samples) else np.zeros(len(union_proteins), bool)
    total = left_union.size
    return {
        **metadata,
        "view_a": left_name,
        "view_b": right_name,
        "n_common_proteins": len(common_proteins),
        "n_union_proteins": len(union_proteins),
        "n_detected_proteins_a": int(left_detected.sum()),
        "n_detected_proteins_b": int(right_detected.sum()),
        "n_detected_only_a": int((left_detected & ~right_detected).sum()),
        "n_detected_only_b": int((~left_detected & right_detected).sum()),
        "n_common_samples": len(samples),
        "n_paired_observations": int(both.sum()),
        "fraction_both_observed": both.sum() / total if total else np.nan,
        "fraction_a_only": left_only.sum() / total if total else np.nan,
        "fraction_b_only": right_only.sum() / total if total else np.nan,
        "fraction_neither": neither.sum() / total if total else np.nan,
        "missing_complementarity": (left_only.sum() + right_only.sum()) / total if total else np.nan,
        "pearson_flat": pearson_flat,
        "pearson_flat_pvalue": pearson_flat_p,
        "spearman_flat": spearman_flat,
        "spearman_flat_pvalue": spearman_flat_p,
        "pearson_protein_mean": pearson_mean,
        "pearson_protein_mean_pvalue": pearson_mean_p,
        "spearman_protein_mean": spearman_mean,
        "spearman_protein_mean_pvalue": spearman_mean_p,
    }


def load_dea_calls(row: pd.Series, manifest_path: Path, q_threshold: float, fc_ratio: float) -> pd.DataFrame | None:
    dea_file = row.get("dea_file", "")
    if not isinstance(dea_file, str) or not dea_file:
        return None
    path = resolve_path(manifest_path, dea_file)
    frame = read_table(path)
    protein_col = row.get("dea_protein_column", "Protein")
    q_col = row.get("dea_qvalue_column", "qvalue")
    fc_col = row.get("dea_log2fc_column", "log2fc")
    for column in [protein_col, q_col, fc_col]:
        if column not in frame.columns:
            raise ValueError(f"DEA table {path} has no '{column}' column")
    output = pd.DataFrame(
        {
            "protein": frame[protein_col].astype(str),
            "qvalue": pd.to_numeric(frame[q_col], errors="coerce"),
            "log2fc": pd.to_numeric(frame[fc_col], errors="coerce"),
        }
    )
    output["called"] = (
        (output["qvalue"] <= q_threshold) & (np.abs(output["log2fc"]) >= np.log2(fc_ratio))
    ).astype(int)
    truth_col = row.get("dea_true_label_column", "")
    if isinstance(truth_col, str) and truth_col and truth_col in frame.columns:
        output["true_label"] = pd.to_numeric(frame[truth_col], errors="coerce")
    return output.drop_duplicates("protein")


def unique_dep_rows(metadata: dict, view_calls: dict[str, pd.DataFrame]) -> pd.DataFrame:
    rows: list[dict] = []
    for left_name, right_name in itertools.combinations(sorted(view_calls), 2):
        left = view_calls[left_name].set_index("protein")
        right = view_calls[right_name].set_index("protein")
        proteins = left.index.union(right.index)
        left_called = left["called"].reindex(proteins, fill_value=0).astype(bool)
        right_called = right["called"].reindex(proteins, fill_value=0).astype(bool)
        for owner, unique_mask, source in [
            (left_name, left_called & ~right_called, left),
            (right_name, right_called & ~left_called, right),
        ]:
            unique_proteins = proteins[unique_mask]
            row = {
                **metadata,
                "view_a": left_name,
                "view_b": right_name,
                "unique_to": owner,
                "n_unique_deps": len(unique_proteins),
            }
            if "true_label" in source.columns and len(unique_proteins):
                truth = pd.to_numeric(source["true_label"].reindex(unique_proteins), errors="coerce")
                truth = truth[truth.isin([0, 1])]
                row["unique_dep_true_positive_fraction"] = float(truth.mean()) if len(truth) else np.nan
                row["n_unique_with_truth"] = int(len(truth))
            rows.append(row)
    return pd.DataFrame(rows)


def incremental_gain_analysis(pairwise: pd.DataFrame, performance_path: Path) -> pd.DataFrame:
    perf = read_table(performance_path)
    required = ["dataset", "platform", "view_set", "metric", "value"]
    missing = [column for column in required if column not in perf.columns]
    if missing:
        raise ValueError(f"Performance table missing columns: {missing}")
    records: list[dict] = []
    for _, row in pairwise.iterrows():
        subset = perf[(perf["dataset"] == row["dataset"]) & (perf["platform"] == row["platform"])]
        # limma and ROTS are separate experimental strata.  Without this
        # filter the two DEA methods would be averaged together and the
        # resulting gain could not support a method-stratified reviewer reply.
        if (
            "dea_method" in row.index
            and "dea_method" in perf.columns
            and pd.notna(row["dea_method"])
        ):
            subset = subset[
                subset["dea_method"].astype(str) == str(row["dea_method"])
            ]
        for metric in subset["metric"].unique():
            metric_data = subset[subset["metric"] == metric]
            pair_metric_data = metric_data
            single_metric_data = metric_data
            if "variant" in metric_data.columns:
                full = metric_data[metric_data["variant"].astype(str) == "full_mcp"]
                single = metric_data[
                    metric_data["variant"].astype(str) == "single_view_mcp"
                ]
                if not full.empty:
                    pair_metric_data = full
                if not single.empty:
                    single_metric_data = single
            pair_names = {
                f"{row['view_a']}+{row['view_b']}",
                f"{row['view_b']}+{row['view_a']}",
            }
            pair_value = pair_metric_data.loc[
                pair_metric_data["view_set"].isin(pair_names), "value"
            ]
            a_value = single_metric_data.loc[
                single_metric_data["view_set"] == row["view_a"], "value"
            ]
            b_value = single_metric_data.loc[
                single_metric_data["view_set"] == row["view_b"], "value"
            ]
            if len(pair_value) and len(a_value) and len(b_value):
                records.append(
                    {
                        **row.to_dict(),
                        "metric": metric,
                        "pair_performance": float(pair_value.mean()),
                        "best_single_performance": float(max(a_value.mean(), b_value.mean())),
                        "incremental_gain": float(pair_value.mean() - max(a_value.mean(), b_value.mean())),
                    }
                )
    return pd.DataFrame(records)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--performance-file", type=Path, default=None)
    parser.add_argument("--q-threshold", type=float, default=0.05)
    parser.add_argument("--fc-ratio", type=float, default=1.5)
    parser.add_argument("--log2p1", action="store_true")
    parser.add_argument(
        "--missing-sentinel",
        type=float,
        default=None,
        help="Optional exact numeric sentinel to convert to NA (for core intermediate arrays, often -1)",
    )
    add_core_runner_arguments(parser)
    return parser


def main() -> None:
    args = build_parser().parse_args()
    out = ensure_output_dir(args.output_dir)
    core_artifacts = run_core_from_args(args, out)
    if args.dry_run_core and core_artifacts is not None:
        print(f"Core dry-run plan written to {core_artifacts.plan_path}")
        return
    performance_file = args.performance_file or (
        core_artifacts.performance_path if core_artifacts is not None else None
    )
    manifest = read_table(args.manifest)
    missing = [column for column in REQUIRED if column not in manifest.columns]
    if missing:
        raise ValueError(f"Matrix manifest missing columns: {missing}")

    qc_rows: list[dict] = []
    pair_rows: list[dict] = []
    unique_rows: list[pd.DataFrame] = []
    audit_rows: list[dict] = []
    group_columns = ["dataset", "acquisition", "platform"]
    if "dea_method" in manifest.columns:
        # The same quantitative matrices can legitimately be analyzed against
        # both limma and native-ROTS calls.  dea_method makes those repeated
        # view rows two independent strata instead of duplicate view errors.
        group_columns.append("dea_method")
    for optional_group in ("group1", "group2"):
        if optional_group in manifest.columns:
            group_columns.append(optional_group)
    for keys, group in manifest.groupby(group_columns, sort=False, dropna=False):
        if not isinstance(keys, tuple):
            keys = (keys,)
        metadata = dict(zip(group_columns, keys))
        matrices: dict[str, pd.DataFrame] = {}
        calls: dict[str, pd.DataFrame] = {}
        for _, row in group.iterrows():
            try:
                matrix_path = resolve_path(args.manifest, row["matrix_file"])
                matrix = read_table(matrix_path)
                design_value = row.get("design_file", "")
                design_path = (
                    resolve_path(args.manifest, design_value)
                    if isinstance(design_value, str) and design_value
                    else None
                )
                sample_column = row.get("sample_column", "sample_name")
                data = match_sample_columns(
                    matrix,
                    row["protein_column"],
                    design_path,
                    sample_column,
                    str(row.get("condition_column", "condition")),
                    row.get("group1", ""),
                    row.get("group2", ""),
                )
                data = transform_values(data, args.log2p1, args.missing_sentinel)
                view = str(row["view"])
                if view in matrices:
                    raise ValueError(f"Duplicate view '{view}' within {metadata}")
                matrices[view] = data
                qc_rows.append(view_qc({**metadata, "view": view}, data))
                dea = load_dea_calls(row, args.manifest, args.q_threshold, args.fc_ratio)
                if dea is not None:
                    calls[view] = dea
                audit_rows.append({**metadata, "view": view, "status": "ok", "message": ""})
            except Exception as exc:
                audit_rows.append(
                    {**metadata, "view": row.get("view", ""), "status": "error", "message": repr(exc)}
                )
        for left_name, right_name in itertools.combinations(sorted(matrices), 2):
            pair_rows.append(
                pairwise_complementarity(
                    metadata, left_name, matrices[left_name], right_name, matrices[right_name]
                )
            )
        if len(calls) >= 2:
            unique_rows.append(unique_dep_rows(metadata, calls))

    qc = pd.DataFrame(qc_rows)
    pairs = pd.DataFrame(pair_rows)
    qc.to_csv(out / "view_quality_summary.csv", index=False)
    pairs.to_csv(out / "pairwise_complementarity.csv", index=False)
    unique = pd.concat(unique_rows, ignore_index=True) if unique_rows else pd.DataFrame()
    unique.to_csv(out / "pairwise_unique_dep_truth.csv", index=False)
    pd.DataFrame(audit_rows).to_csv(out / "input_audit.csv", index=False)
    if performance_file is not None and not pairs.empty:
        incremental_gain_analysis(pairs, performance_file).to_csv(
            out / "complementarity_vs_incremental_gain.csv", index=False
        )
    if pairs.empty:
        raise RuntimeError("No view pair was analyzed; inspect input_audit.csv")
    print(f"Completed complementarity-versus-noise analysis. Results: {out}")


if __name__ == "__main__":
    main()
