"""Characterize proteins called uniquely by MCP versus single-view DEA.

Primary definition
------------------
MCP: calibrated q-like value <= 0.05 and |FC| >= log2(1.5).
Statistical union: any of dLFQ/MaxLFQ/Top3/Top1 has native limma BH-FDR or
native ROTS FDR <= 0.05 and |FC| >= log2(1.5).

A Probability >= 0.5 + FC sensitivity rule is reported separately.  Missing
fractions are calculated from the saved pre-imputation raw matrices.  Abundance
and variance are converted to within-view percentiles before averaging, so
incomparable numerical scales are never pooled across quantification views.

For inference, platform and DEA strata are averaged inside each biological
dataset.  Exact sign-flip tests and dataset bootstrap CIs therefore use n=7,
not proteins, platforms, DEA methods, or views as independent replicates.
"""

from __future__ import annotations

import argparse
import json
import warnings
from pathlib import Path

import numpy as np
import pandas as pd

from MCP_r1_final_revision_utils import (
    bh_adjust,
    bootstrap_mean_ci,
    exact_signflip_p,
    rebase_recorded_path,
    resolve_results_root,
)


VIEWS = ("dlfq", "maxlfq", "top3", "top1")
QUALITY_METRICS = (
    "mean_intensity_percentile",
    "mean_within_group_variance_percentile",
    "mean_missing_fraction",
    "max_missing_fraction",
    "mean_abs_view_log2fc",
    "mcp_abs_log2fc",
)


def median_or_nan(values: np.ndarray, axis: int = 1) -> np.ndarray:
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=RuntimeWarning)
        with np.errstate(all="ignore"):
            return np.nanmedian(values, axis=axis)


def variance_or_nan(values: np.ndarray) -> np.ndarray:
    valid_n = np.isfinite(values).sum(axis=1)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=RuntimeWarning)
        with np.errstate(all="ignore"):
            result = np.nanvar(values, axis=1, ddof=1)
    result[valid_n < 2] = np.nan
    return result


def row_mad(values: np.ndarray) -> np.ndarray:
    med = median_or_nan(values)
    return median_or_nan(np.abs(values - med[:, None]))


def fraction_missing(values: np.ndarray, zero_is_missing: bool) -> np.ndarray:
    missing = ~np.isfinite(values)
    if zero_is_missing:
        missing |= values == 0
    return missing.mean(axis=1)


def load_quality_for_view(
    run_dir: Path,
    view_index: int,
    view_name: str,
    group1: str,
    group2: str,
    zero_is_missing: bool,
) -> pd.DataFrame:
    real_files = list(run_dir.glob(f"real_normed_v{view_index}_union_*_{view_name}.tsv"))
    raw_files = list(run_dir.glob(f"*_raw_view{view_index}_union.csv"))
    normed_files = list(run_dir.glob(f"*_normed_view{view_index}_union.csv"))
    design_files = list((run_dir / "dt").glob("*design.tsv"))
    if not (len(real_files) == len(raw_files) == len(normed_files) == len(design_files) == 1):
        raise FileNotFoundError(
            f"Expected one real/raw/normed/design file for {view_name} under {run_dir}; "
            f"found {len(real_files)}/{len(raw_files)}/{len(normed_files)}/{len(design_files)}"
        )

    metadata = pd.read_csv(real_files[0], sep="\t", usecols=["Protein"])
    raw = pd.read_csv(raw_files[0], header=None).apply(pd.to_numeric, errors="coerce").to_numpy(float)
    normed = pd.read_csv(normed_files[0], header=None).apply(pd.to_numeric, errors="coerce").to_numpy(float)
    design = pd.read_csv(design_files[0], sep="\t")
    if len(metadata) != raw.shape[0] or len(metadata) != normed.shape[0]:
        raise ValueError(f"Protein row mismatch in {run_dir} for {view_name}")
    if raw.shape[1] != len(design) or normed.shape[1] != len(design):
        raise ValueError(f"Sample/design mismatch in {run_dir} for {view_name}")

    conditions = design["condition"].astype(str).to_numpy()
    idx1, idx2 = conditions == str(group1), conditions == str(group2)
    if not idx1.any() or not idx2.any():
        raise ValueError(
            f"Design {design_files[0]} lacks requested conditions {group1!r}/{group2!r}"
        )

    missing_all = fraction_missing(raw, zero_is_missing)
    missing_g1 = fraction_missing(raw[:, idx1], zero_is_missing)
    missing_g2 = fraction_missing(raw[:, idx2], zero_is_missing)
    abundance = median_or_nan(normed)
    abundance_g1 = median_or_nan(normed[:, idx1])
    abundance_g2 = median_or_nan(normed[:, idx2])
    variance_g1 = variance_or_nan(normed[:, idx1])
    variance_g2 = variance_or_nan(normed[:, idx2])
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=RuntimeWarning)
        pooled_variance = np.nanmean(np.column_stack([variance_g1, variance_g2]), axis=1)
    mad_g1 = row_mad(normed[:, idx1])
    mad_g2 = row_mad(normed[:, idx2])
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=RuntimeWarning)
        pooled_mad = np.nanmean(np.column_stack([mad_g1, mad_g2]), axis=1)

    output = pd.DataFrame({
        "Protein": metadata["Protein"].astype(str),
        f"{view_name}_median_abundance": abundance,
        f"{view_name}_{group1}_median_abundance": abundance_g1,
        f"{view_name}_{group2}_median_abundance": abundance_g2,
        f"{view_name}_within_group_variance": pooled_variance,
        f"{view_name}_within_group_mad": pooled_mad,
        f"{view_name}_missing_fraction": missing_all,
        f"{view_name}_{group1}_missing_fraction": missing_g1,
        f"{view_name}_{group2}_missing_fraction": missing_g2,
    })
    output[f"{view_name}_intensity_percentile"] = output[
        f"{view_name}_median_abundance"
    ].rank(method="average", pct=True)
    output[f"{view_name}_variance_percentile"] = output[
        f"{view_name}_within_group_variance"
    ].rank(method="average", pct=True)
    return output


def parse_full_result(path: Path, fdr: float, fc_ratio: float) -> pd.DataFrame:
    table = pd.read_csv(path)
    required = {"Protein", "True_lab", "Protein.1", "Probability", "ori_logFC", "qvalue"}
    for view in VIEWS:
        required.update({f"score_DP{view}", f"logFC_DP{view}"})
    missing = required - set(table.columns)
    if missing:
        raise ValueError(f"Missing expected MCP/statistical columns in {path}: {sorted(missing)}")

    truth = table[["Protein", "True_lab"]].copy()
    truth["Protein"] = truth["Protein"].astype(str)
    truth = truth.drop_duplicates("Protein")
    direct = table[["Protein.1", "Probability", "ori_logFC", "qvalue"]].copy()
    direct = direct.rename(columns={"Protein.1": "Protein"})
    direct["Protein"] = direct["Protein"].astype(str)
    direct = direct.drop_duplicates("Protein")
    output = truth.merge(direct, on="Protein", how="inner", validate="one_to_one")

    statistical = table[["Protein"] + [
        name for view in VIEWS for name in (f"score_DP{view}", f"logFC_DP{view}")
    ]].copy()
    statistical["Protein"] = statistical["Protein"].astype(str)
    statistical = statistical.drop_duplicates("Protein")
    output = output.merge(statistical, on="Protein", how="left", validate="one_to_one")

    logfc_cutoff = float(np.log2(fc_ratio))
    support = np.zeros(len(output), dtype=int)
    for view in VIEWS:
        score = pd.to_numeric(output[f"score_DP{view}"], errors="coerce")
        logfc = pd.to_numeric(output[f"logFC_DP{view}"], errors="coerce")
        native_fdr = 1.0 - score
        output[f"{view}_native_fdr"] = native_fdr
        output[f"{view}_log2fc"] = logfc
        call = native_fdr.le(fdr) & logfc.abs().ge(logfc_cutoff)
        output[f"{view}_statistical_call"] = call
        support += call.fillna(False).to_numpy(int)
    output["statistical_view_support"] = support
    output["statistical_union_call"] = support >= 1
    output["statistical_intersection_call"] = support == len(VIEWS)
    return output


def attach_quality(
    proteins: pd.DataFrame,
    run_dir: Path,
    group1: str,
    group2: str,
    zero_is_missing: bool,
) -> pd.DataFrame:
    output = proteins.copy()
    for index, view in enumerate(VIEWS):
        quality = load_quality_for_view(
            run_dir, index, view, group1, group2, zero_is_missing
        )
        output = output.merge(quality, on="Protein", how="left", validate="one_to_one")

    output["mean_intensity_percentile"] = output[
        [f"{view}_intensity_percentile" for view in VIEWS]
    ].mean(axis=1)
    output["mean_within_group_variance_percentile"] = output[
        [f"{view}_variance_percentile" for view in VIEWS]
    ].mean(axis=1)
    output["mean_missing_fraction"] = output[
        [f"{view}_missing_fraction" for view in VIEWS]
    ].mean(axis=1)
    output["max_missing_fraction"] = output[
        [f"{view}_missing_fraction" for view in VIEWS]
    ].max(axis=1)
    output["mean_abs_view_log2fc"] = output[
        [f"{view}_log2fc" for view in VIEWS]
    ].abs().mean(axis=1)
    output["mcp_abs_log2fc"] = pd.to_numeric(output["ori_logFC"], errors="coerce").abs()
    return output


def label_categories(table: pd.DataFrame, fdr: float, fc_ratio: float) -> pd.DataFrame:
    logfc_cutoff = float(np.log2(fc_ratio))
    q_call = (
        pd.to_numeric(table["qvalue"], errors="coerce").le(fdr)
        & pd.to_numeric(table["ori_logFC"], errors="coerce").abs().ge(logfc_cutoff)
    )
    probability_call = (
        pd.to_numeric(table["Probability"], errors="coerce").ge(0.5)
        & pd.to_numeric(table["ori_logFC"], errors="coerce").abs().ge(logfc_cutoff)
    )
    outputs: list[pd.DataFrame] = []
    for rule, mcp_call in (
        ("q_like_le_0.05_and_fc", q_call),
        ("probability_ge_0.5_and_fc", probability_call),
    ):
        block = table.copy()
        stat_call = block["statistical_union_call"].fillna(False).astype(bool)
        mcp_call = mcp_call.fillna(False).astype(bool)
        block["call_rule"] = rule
        block["mcp_call"] = mcp_call
        block["detection_category"] = np.select(
            [
                mcp_call & ~stat_call,
                mcp_call & stat_call,
                ~mcp_call & stat_call,
            ],
            ["MCP_unique", "MCP_and_statistical", "statistical_only"],
            default="neither",
        )
        outputs.append(block)
    return pd.concat(outputs, ignore_index=True)


def summarize_groups(proteins: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    keys = ["dataset", "platform", "dea_method", "call_rule", "detection_category"]
    aggregations: dict[str, tuple[str, str]] = {
        "n_proteins": ("Protein", "size"),
        "truth_positive_fraction": ("True_lab", "mean"),
        "median_statistical_view_support": ("statistical_view_support", "median"),
    }
    for metric in QUALITY_METRICS:
        aggregations["median_" + metric] = (metric, "median")
    stratum = proteins.groupby(keys, as_index=False).agg(**aggregations)

    # First summarize within platform/DEA; then average those analysis strata
    # inside each biological dataset.  Protein counts remain descriptive.
    numeric = [column for column in stratum.columns if column not in keys]
    dataset = (
        stratum.groupby(["dataset", "call_rule", "detection_category"], as_index=False)[numeric]
        .mean()
    )
    return stratum, dataset


def paired_quality_tests(dataset_summary: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    rows: list[dict[str, object]] = []
    paired_rows: list[dict[str, object]] = []
    for rule, block in dataset_summary.groupby("call_rule", sort=True):
        for metric in QUALITY_METRICS:
            value = "median_" + metric
            pivot = block.pivot(index="dataset", columns="detection_category", values=value)
            if not {"MCP_unique", "MCP_and_statistical"}.issubset(pivot.columns):
                continue
            paired = pivot[["MCP_unique", "MCP_and_statistical"]].dropna().copy()
            paired["difference_unique_minus_overlap"] = (
                paired["MCP_unique"] - paired["MCP_and_statistical"]
            )
            for dataset, record in paired.iterrows():
                paired_rows.append({
                    "call_rule": rule,
                    "metric": metric,
                    "dataset": dataset,
                    "mcp_unique": record["MCP_unique"],
                    "mcp_and_statistical": record["MCP_and_statistical"],
                    "difference_unique_minus_overlap": record["difference_unique_minus_overlap"],
                })
            differences = paired["difference_unique_minus_overlap"].to_numpy(float)
            low, high = bootstrap_mean_ci(differences)
            rows.append({
                "call_rule": rule,
                "metric": metric,
                "contrast": "MCP_unique_minus_MCP_and_statistical",
                "n_biological_datasets": len(differences),
                "mean_paired_difference": float(np.mean(differences)) if len(differences) else np.nan,
                "median_paired_difference": float(np.median(differences)) if len(differences) else np.nan,
                "bootstrap_95ci_low": low,
                "bootstrap_95ci_high": high,
                "exact_signflip_p": exact_signflip_p(differences),
            })
    tests = pd.DataFrame(rows)
    if not tests.empty:
        tests["bh_q_across_quality_tests"] = bh_adjust(tests["exact_signflip_p"])
    return tests, pd.DataFrame(paired_rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results-root", default=None)
    parser.add_argument("--output-dir", default="revision_results/final_required/mcp_unique_dep")
    parser.add_argument("--fdr", type=float, default=0.05)
    parser.add_argument("--fc-ratio", type=float, default=1.5)
    parser.add_argument(
        "--zero-is-missing", action="store_true",
        help="Also treat exact zero in raw input matrices as missing (default: NaN/blank only).",
    )
    args = parser.parse_args()

    results_root = resolve_results_root(args.results_root)
    ledger_path = results_root / "task1_2_core_merged_limma_ROTS" / "core_run_ledger.csv"
    if not ledger_path.exists():
        raise FileNotFoundError(ledger_path)
    ledger = pd.read_csv(ledger_path)
    selected = ledger[
        ledger["variant"].astype(str).eq("full_mcp")
        & ledger["status"].astype(str).isin(["completed", "skipped_existing"])
    ].copy()
    if len(selected) != 28:
        raise ValueError(f"Expected 7 datasets x 2 platforms x 2 DEA = 28 full MCP runs; found {len(selected)}")

    all_proteins: list[pd.DataFrame] = []
    audit_rows: list[dict[str, object]] = []
    for record in selected.to_dict("records"):
        prediction = rebase_recorded_path(record["prediction_file"], results_root)
        run_dir = prediction.parent.parent
        protein = parse_full_result(prediction, args.fdr, args.fc_ratio)
        protein = attach_quality(
            protein, run_dir, str(record["group1"]), str(record["group2"]), args.zero_is_missing
        )
        dea_method = str(record["dea_methods"]).split("+")[0]
        protein.insert(0, "dea_method", dea_method)
        protein.insert(0, "platform", record["platform"])
        protein.insert(0, "dataset", record["dataset"])
        protein = label_categories(protein, args.fdr, args.fc_ratio)
        all_proteins.append(protein)
        audit_rows.append({
            "dataset": record["dataset"],
            "platform": record["platform"],
            "dea_method": dea_method,
            "group1": record["group1"],
            "group2": record["group2"],
            "n_proteins": protein["Protein"].nunique(),
            "prediction_file": str(prediction),
            "run_dir": str(run_dir),
        })

    proteins = pd.concat(all_proteins, ignore_index=True)
    stratum_summary, dataset_summary = summarize_groups(proteins)
    tests, paired = paired_quality_tests(dataset_summary)

    output = Path(args.output_dir).expanduser().resolve()
    output.mkdir(parents=True, exist_ok=True)
    proteins.to_csv(output / "mcp_unique_protein_quality.csv.gz", index=False, compression="gzip")
    stratum_summary.to_csv(output / "mcp_unique_group_summary_by_stratum.csv", index=False)
    dataset_summary.to_csv(output / "mcp_unique_group_summary_by_dataset.csv", index=False)
    paired.to_csv(output / "mcp_unique_paired_dataset_values.csv", index=False)
    tests.to_csv(output / "mcp_unique_quality_tests.csv", index=False)
    pd.DataFrame(audit_rows).to_csv(output / "input_audit.csv", index=False)
    summary = {
        "n_biological_datasets": int(selected["dataset"].nunique()),
        "n_platform_dea_strata": int(len(selected)),
        "primary_mcp_rule": f"q-like <= {args.fdr} and abs(log2FC) >= log2({args.fc_ratio})",
        "statistical_reference": (
            "union of four single-view calls; limma uses BH-FDR and ROTS uses native ROTS FDR"
        ),
        "sensitivity_rule": f"Probability >= 0.5 and abs(log2FC) >= log2({args.fc_ratio})",
        "missing_definition": "non-finite or blank" + (" plus exact zero" if args.zero_is_missing else ""),
        "inferential_unit": "seven biological datasets",
    }
    (output / "analysis_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"Completed MCP-unique DEP characterization: {output}")


if __name__ == "__main__":
    main()
