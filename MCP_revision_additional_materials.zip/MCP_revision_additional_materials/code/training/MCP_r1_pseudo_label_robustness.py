"""Generate and audit alternative pseudo-label strategies for MCP.

补做任务 3：伪标签来源、交集/并集、单视图及噪声标签稳健性分析。

Required source manifest columns
--------------------------------
dataset, source, label_file, protein_column, qvalue_column, log2fc_column

Optional columns
----------------
acquisition, platform, is_reference, true_label_column

Use ``source=hurdle`` for the hurdle result and set ``is_reference=1`` for the
default high-quality reference view (usually dLFQ). Generated label tables use
-1 for unlabeled proteins, matching the convention in the core MCP code.

With ``--run-manifest`` the script now creates label variants, expands one real
core MCP retraining per generated strategy, and summarizes downstream
stability in the same command. ``--prediction-manifest`` remains available for
already completed runs.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import cohen_kappa_score

from MCP_r1_mcp_experiment_runner import add_core_runner_arguments, execute_run_manifest

from MCP_r1_supplementary_analysis_utils import (
    binary_metrics,
    ensure_output_dir,
    prediction_column_map,
    ranking_metrics,
    read_table,
    resolve_path,
    seed_everything,
    standardize_prediction_table,
)


REQUIRED = [
    "dataset",
    "source",
    "label_file",
    "protein_column",
    "qvalue_column",
    "log2fc_column",
]


def source_labels(
    row: pd.Series,
    manifest_path: Path,
    q_threshold: float,
    fc_ratio: float,
) -> pd.DataFrame:
    path = resolve_path(manifest_path, row["label_file"])
    table = read_table(path)
    requested = [row["protein_column"], row["qvalue_column"], row["log2fc_column"]]
    missing = [column for column in requested if column not in table.columns]
    if missing:
        raise ValueError(f"{path} is missing columns {missing}")
    protein = table[row["protein_column"]].astype(str)
    qvalue = pd.to_numeric(table[row["qvalue_column"]], errors="coerce")
    log2fc = pd.to_numeric(table[row["log2fc_column"]], errors="coerce")
    label = ((qvalue <= q_threshold) & (np.abs(log2fc) >= np.log2(fc_ratio))).astype(float)
    label[qvalue.isna() | log2fc.isna()] = np.nan
    result = pd.DataFrame({"protein": protein, str(row["source"]): label})
    true_column = row.get("true_label_column", "")
    if isinstance(true_column, str) and true_column and true_column in table.columns:
        result["true_label"] = pd.to_numeric(table[true_column], errors="coerce")
    return result.drop_duplicates("protein")


def combine_sources(group: pd.DataFrame, manifest_path: Path, q_threshold: float, fc_ratio: float):
    label_tables: list[pd.DataFrame] = []
    source_names = group["source"].astype(str)
    if source_names.duplicated().any():
        duplicates = sorted(source_names[source_names.duplicated(keep=False)].unique())
        raise ValueError(f"Source names must be unique within each dataset; duplicates: {duplicates}")
    if "is_reference" in group.columns:
        reference_mask = pd.to_numeric(group["is_reference"], errors="coerce").fillna(0).astype(int) == 1
        reference_sources = group.loc[reference_mask, "source"].astype(str).tolist()
    else:
        reference_sources = []
    for _, row in group.iterrows():
        label_tables.append(source_labels(row, manifest_path, q_threshold, fc_ratio))
    merged = label_tables[0]
    for table in label_tables[1:]:
        true_columns = [column for column in table.columns if column == "true_label"]
        merged = merged.merge(table, on="protein", how="outer", suffixes=("", "_duplicate"))
        if true_columns and "true_label_duplicate" in merged:
            merged["true_label"] = merged.get("true_label").combine_first(merged["true_label_duplicate"])
            merged = merged.drop(columns=["true_label_duplicate"])
    sources = source_names.tolist()
    reference = reference_sources[0] if reference_sources else sources[0]
    hurdle = "hurdle" if "hurdle" in sources else None
    return merged, sources, reference, hurdle


def agreement_label(a: pd.Series, b: pd.Series) -> np.ndarray:
    values = np.full(len(a), -1, dtype=int)
    known = a.notna() & b.notna() & (a == b)
    values[known] = a[known].astype(int)
    return values


def generate_strategies(
    merged: pd.DataFrame,
    sources: list[str],
    reference: str,
    hurdle: str | None,
    noise_rates: list[float],
    noise_replicates: int,
    rng: np.random.Generator,
) -> dict[str, np.ndarray]:
    matrix = merged[sources]
    strategies: dict[str, np.ndarray] = {}
    for source in sources:
        strategies[f"single_{source}"] = matrix[source].fillna(-1).to_numpy(int)

    if hurdle is not None:
        base = agreement_label(matrix[reference], matrix[hurdle])
        strategies["reference_hurdle_agreement"] = base
    else:
        base = matrix[reference].fillna(-1).to_numpy(int)

    # Positive union: any positive is positive; only unanimous observed zeros
    # are negative. Ambiguous/missing cases remain unlabeled.
    any_positive = (matrix == 1).any(axis=1)
    all_zero = matrix.notna().all(axis=1) & (matrix == 0).all(axis=1)
    union = np.full(len(matrix), -1, dtype=int)
    union[any_positive] = 1
    union[all_zero] = 0
    strategies["union_positive"] = union

    intersection = np.full(len(matrix), -1, dtype=int)
    all_positive = matrix.notna().all(axis=1) & (matrix == 1).all(axis=1)
    intersection[all_positive] = 1
    intersection[all_zero] = 0
    strategies["intersection_positive"] = intersection

    observed_count = matrix.notna().sum(axis=1).to_numpy()
    positive_count = (matrix == 1).sum(axis=1).to_numpy()
    majority = np.full(len(matrix), -1, dtype=int)
    enough = observed_count >= 2
    majority[enough & (positive_count > observed_count / 2)] = 1
    majority[enough & (positive_count < observed_count / 2)] = 0
    strategies["majority_vote"] = majority

    for rate in noise_rates:
        if rate <= 0:
            continue
        for replicate in range(noise_replicates):
            noisy = base.copy()
            known = np.where(noisy >= 0)[0]
            n_flip = int(round(rate * len(known)))
            if n_flip:
                selected = rng.choice(known, size=n_flip, replace=False)
                noisy[selected] = 1 - noisy[selected]
            strategies[f"agreement_noise_{rate:.2f}_rep{replicate + 1}"] = noisy
    return strategies


def summarize_labels(dataset: str, merged: pd.DataFrame, strategies: dict[str, np.ndarray]) -> pd.DataFrame:
    rows: list[dict] = []
    truth_available = "true_label" in merged.columns and merged["true_label"].notna().any()
    for name, labels in strategies.items():
        known = labels >= 0
        row = {
            "dataset": dataset,
            "strategy": name,
            "n_total": len(labels),
            "n_labeled": int(known.sum()),
            "n_unlabeled": int((~known).sum()),
            "n_positive": int((labels == 1).sum()),
            "positive_fraction_among_labeled": float((labels[known] == 1).mean()) if known.any() else np.nan,
        }
        if truth_available:
            true = pd.to_numeric(merged["true_label"], errors="coerce").to_numpy()
            evaluable = known & np.isfinite(true) & np.isin(true, [0, 1])
            if evaluable.any():
                row.update({f"truth_{k}": v for k, v in binary_metrics(true[evaluable], labels[evaluable]).items()})
        rows.append(row)
    return pd.DataFrame(rows)


def pairwise_label_stability(dataset: str, strategies: dict[str, np.ndarray]) -> pd.DataFrame:
    rows: list[dict] = []
    names = list(strategies)
    for left_index, left in enumerate(names):
        for right in names[left_index + 1 :]:
            a, b = strategies[left], strategies[right]
            known = (a >= 0) & (b >= 0)
            a_pos = set(np.where(a == 1)[0])
            b_pos = set(np.where(b == 1)[0])
            union = a_pos | b_pos
            rows.append(
                {
                    "dataset": dataset,
                    "strategy_a": left,
                    "strategy_b": right,
                    "n_jointly_labeled": int(known.sum()),
                    "agreement": float((a[known] == b[known]).mean()) if known.any() else np.nan,
                    "cohen_kappa": cohen_kappa_score(a[known], b[known]) if known.sum() > 1 else np.nan,
                    "positive_jaccard": len(a_pos & b_pos) / len(union) if union else np.nan,
                }
            )
    return pd.DataFrame(rows)


def summarize_prediction_manifest(path: Path) -> pd.DataFrame:
    manifest = read_table(path)
    required = ["dataset", "strategy", "prediction_file"]
    missing = [column for column in required if column not in manifest.columns]
    if missing:
        raise ValueError(f"Prediction manifest missing columns: {missing}")
    if "method" in manifest.columns and "variant" in manifest.columns:
        # Generated core manifests also contain statistical reference blocks.
        # Pseudo-label robustness concerns the actually retrained MCP variant.
        manifest = manifest[
            manifest["method"].astype(str) == manifest["variant"].astype(str)
        ].copy()
    rows: list[dict] = []
    for _, record in manifest.iterrows():
        table = standardize_prediction_table(
            read_table(resolve_path(path, record["prediction_file"])),
            prediction_column_map(record),
        )
        called = (table["score"].to_numpy() >= 0.5).astype(int)
        rows.append(
            {
                "dataset": record["dataset"],
                "strategy": record["strategy"],
                "method": record.get("method", record.get("variant", "MCP")),
                **ranking_metrics(table["true_label"], table["score"]),
                **binary_metrics(table["true_label"], called),
            }
        )
    return pd.DataFrame(rows)


def expand_strategy_runs(
    base_manifest_path: Path,
    generated_labels: pd.DataFrame,
    label_file: Path,
    output_path: Path,
) -> Path:
    """Expand one core row into one real MCP retraining per pseudo-label strategy."""

    base = read_table(base_manifest_path)
    if "dataset" not in base.columns:
        raise ValueError("Pseudo-label --run-manifest must contain a dataset column")
    strategies = [
        column for column in generated_labels.columns
        if column not in {"dataset", "protein", "true_label"}
    ]
    if not strategies:
        raise ValueError("No generated pseudo-label strategy is available for MCP retraining")
    available = set(generated_labels["dataset"].astype(str))
    rows: list[dict] = []
    eligibility: list[dict] = []
    for _, source in base.iterrows():
        dataset = str(source["dataset"])
        if dataset not in available:
            raise ValueError(f"No generated pseudo labels match run-manifest dataset {dataset!r}")
        for strategy in strategies:
            values = pd.to_numeric(
                generated_labels.loc[
                    generated_labels["dataset"].astype(str) == dataset, strategy
                ],
                errors="coerce",
            )
            classes = set(values[values.isin([0, 1])].astype(int).tolist())
            eligible = classes == {0, 1}
            eligibility.append(
                {
                    "dataset": dataset,
                    "strategy": strategy,
                    "eligible_for_binary_mcp": eligible,
                    "observed_labeled_classes": ";".join(map(str, sorted(classes))),
                    "reason": "" if eligible else "needs both labeled classes 0 and 1",
                }
            )
            if not eligible:
                continue
            row = source.to_dict()
            for path_field in ["data_root", "r_code"]:
                path_value = row.get(path_field, "")
                if isinstance(path_value, str) and path_value.strip():
                    candidate = Path(path_value).expanduser()
                    if not candidate.is_absolute():
                        candidate = (base_manifest_path.resolve().parent / candidate).resolve()
                    row[path_field] = str(candidate)
            # Each strategy must have an isolated output directory.  Removing a
            # shared output_root lets the runner derive it from the unique ID.
            row.pop("output_root", None)
            base_id = str(
                row.get("run_id")
                or f"{dataset}_{row.get('platform', '')}_{row.get('views', '')}_s{row.get('seed', 2024)}"
            )
            row.update(
                {
                    "run_id": f"{base_id}__pseudo__{strategy}",
                    "strategy": strategy,
                    "pseudo_label_file": str(label_file.resolve()),
                    "pseudo_label_column": strategy,
                    "pseudo_label_protein_column": "protein",
                    "variant": str(row.get("variant", "full_mcp")),
                }
            )
            rows.append(row)
    pd.DataFrame(eligibility).drop_duplicates().to_csv(
        output_path.with_name("pseudo_label_strategy_run_eligibility.csv"), index=False
    )
    if not rows:
        raise ValueError("No pseudo-label strategy contains both training classes 0 and 1")
    pd.DataFrame(rows).to_csv(output_path, index=False)
    return output_path


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-manifest", required=True, type=Path)
    parser.add_argument("--prediction-manifest", type=Path, default=None)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--q-threshold", type=float, default=0.05)
    parser.add_argument("--fc-ratio", type=float, default=1.5)
    parser.add_argument("--noise-rates", default="0.05,0.10,0.20")
    parser.add_argument("--noise-replicates", type=int, default=5)
    parser.add_argument("--seed", type=int, default=2024)
    add_core_runner_arguments(parser)
    return parser


def main() -> None:
    args = build_parser().parse_args()
    out = ensure_output_dir(args.output_dir)
    rng = seed_everything(args.seed)
    manifest = read_table(args.source_manifest)
    missing = [column for column in REQUIRED if column not in manifest.columns]
    if missing:
        raise ValueError(f"Source manifest missing columns: {missing}")

    all_labels: list[pd.DataFrame] = []
    all_summary: list[pd.DataFrame] = []
    all_stability: list[pd.DataFrame] = []
    noise_rates = [float(value) for value in args.noise_rates.split(",") if value.strip()]
    if any(rate < 0 or rate > 1 for rate in noise_rates):
        raise ValueError("Every --noise-rates value must be in [0, 1]")
    if args.noise_replicates < 1:
        raise ValueError("--noise-replicates must be at least 1")
    if manifest.empty:
        raise ValueError("Source manifest is empty")
    for dataset, group in manifest.groupby("dataset", sort=False):
        merged, sources, reference, hurdle = combine_sources(
            group, args.source_manifest, args.q_threshold, args.fc_ratio
        )
        strategies = generate_strategies(
            merged, sources, reference, hurdle, noise_rates, args.noise_replicates, rng
        )
        label_table = pd.DataFrame({"dataset": dataset, "protein": merged["protein"]})
        if "true_label" in merged:
            label_table["true_label"] = merged["true_label"]
        for name, values in strategies.items():
            label_table[name] = values
        all_labels.append(label_table)
        all_summary.append(summarize_labels(dataset, merged, strategies))
        all_stability.append(pairwise_label_stability(dataset, strategies))

    generated_labels = pd.concat(all_labels, ignore_index=True)
    generated_label_file = out / "generated_pseudo_labels.csv"
    generated_labels.to_csv(generated_label_file, index=False)
    pd.concat(all_summary, ignore_index=True).to_csv(out / "pseudo_label_summary.csv", index=False)
    pd.concat(all_stability, ignore_index=True).to_csv(out / "pseudo_label_pairwise_stability.csv", index=False)
    prediction_manifest = args.prediction_manifest
    if args.run_manifest is not None:
        expanded_manifest = expand_strategy_runs(
            args.run_manifest,
            generated_labels,
            generated_label_file,
            out / "expanded_pseudo_label_run_manifest.csv",
        )
        core_output = args.core_output_dir or (out / "core_experiments")
        artifacts = execute_run_manifest(
            expanded_manifest,
            core_output,
            core_script=args.core_script,
            overrides={"force": True} if args.force_core else None,
            dry_run=args.dry_run_core,
            strict=not args.continue_on_core_error,
        )
        if args.dry_run_core:
            print(f"Pseudo-label core dry-run plan written to {artifacts.plan_path}")
            return
        if prediction_manifest is None:
            prediction_manifest = artifacts.prediction_manifest_path
    if prediction_manifest is not None:
        summarize_prediction_manifest(prediction_manifest).to_csv(
            out / "downstream_prediction_robustness.csv", index=False
        )
    print(f"Completed pseudo-label robustness analysis. Results: {out}")


if __name__ == "__main__":
    main()
