"""PyCharm entry point: multi-seed stability shard 5 on GPU 1."""

from MCP_r1_pycharm_run_multiseed_stability_shard import run_shard


if __name__ == "__main__":
    run_shard(5, 1, profile="main")

