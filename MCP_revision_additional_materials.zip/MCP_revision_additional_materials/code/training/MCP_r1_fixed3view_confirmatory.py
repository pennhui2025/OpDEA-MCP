"""Fixed-label confirmatory comparison of one prespecified 3-view MCP versus 4-view MCP.

Only the three-view model is fitted here.  It consumes the immutable four-view
bundle created by ``MCP_r1_fixed4label_ablation.py`` so that pseudo-labels,
classification mask, Protein-ID union, truth, sample order and fold change are
identical to the previously fitted four-view control. / 本模块只新增三视图训练；
四视图模型直接复用既有结果，因此整个新增实验严格为 28 次模型拟合。
"""

from __future__ import annotations

import json
import math
import os
import time
from pathlib import Path
from typing import Any, Mapping

import numpy as np
import pandas as pd

import MCP_r1_fixed4label_ablation as fixed4


SOURCE_VIEWS = fixed4.SOURCE_VIEWS
IMPLEMENTATION_SCHEMA_VERSION = "fixed3view_confirmatory_v1_20260906"
OUTPUT_PREDICTION_NAME = "fixed3view_DP_fdr_predictions.csv"
OUTPUT_METRICS_NAME = "fixed3view_metrics.csv"
OUTPUT_LATENT_NAME = "fixed3view_latent.npz"


def _array_fingerprint(value: np.ndarray) -> str:
    array = np.ascontiguousarray(value)
    header = fixed4._canonical_json(
        {"shape": list(array.shape), "dtype": str(array.dtype)}
    ).encode("utf-8")
    return fixed4._sha256_bytes(header + b"\0" + array.tobytes())


def _split_views(value: Any) -> tuple[str, ...]:
    views = tuple(view.lower() for view in fixed4._split(value))
    if len(views) != 3 or len(set(views)) != 3:
        raise ValueError(f"Exactly three distinct model_input_views are required; got {views}")
    if any(view not in SOURCE_VIEWS for view in views):
        raise ValueError(f"Views must be selected from {SOURCE_VIEWS}; got {views}")
    # Preserve the canonical source order.  This makes model specifications and
    # hashes deterministic even if a user writes the same set in another order.
    return tuple(view for view in SOURCE_VIEWS if view in set(views))


def _current_code_fingerprints(core_script: Path) -> dict[str, str]:
    """Bind each run to this implementation and every inherited training dependency."""

    inherited = fixed4._code_fingerprints(core_script)
    builder = Path(__file__).resolve().with_name(
        "MCP_r1_build_fixed3view_confirmatory_manifest.py"
    )
    if not builder.is_file():
        raise FileNotFoundError(f"Missing fixed3view manifest builder: {builder}")
    return {
        "fixed3view_implementation": fixed4.sha256_file(Path(__file__).resolve()),
        "fixed3view_manifest_builder": fixed4.sha256_file(builder),
        **{f"inherited_{name}": digest for name, digest in inherited.items()},
    }


def _validate_bundle(bundle_dir: Path, core_script: Path) -> dict[str, Any]:
    bundle_file = bundle_dir / "fixed4view_training_bundle.npz"
    audit_file = bundle_dir / "fixed_label_audit.csv"
    truth_file = bundle_dir / "evaluation_truth.csv"
    metadata_file = bundle_dir / "metadata.json"
    for path in (bundle_file, audit_file, truth_file, metadata_file):
        if not path.is_file():
            raise FileNotFoundError(
                f"Required fixed4 bundle file is absent: {path}. Run the matching "
                "MCP_r1_pycharm_fixed4label_ablation_shard_* script first."
            )
    metadata = json.loads(metadata_file.read_text(encoding="utf-8"))
    checks = {
        "status": metadata.get("status") == "completed",
        "experiment_schema": metadata.get("experiment_schema")
        == fixed4.IMPLEMENTATION_SCHEMA_VERSION,
        "bundle_sha256": metadata.get("bundle_sha256")
        == fixed4.sha256_file(bundle_file),
        "label_audit_sha256": metadata.get("label_audit_sha256")
        == fixed4.sha256_file(audit_file),
        "truth_sha256": metadata.get("truth_sha256") == fixed4.sha256_file(truth_file),
        "code_fingerprints": metadata.get("code_fingerprints")
        == fixed4._code_fingerprints(core_script),
        "source_file_hashes": fixed4._stored_sources_unchanged(metadata),
    }
    failed = [name for name, passed in checks.items() if not passed]
    if failed:
        raise ValueError(
            f"The fixed4 bundle is incomplete, stale, or was made with different code "
            f"({', '.join(failed)}): {bundle_dir}"
        )
    if tuple(str(v).lower() for v in metadata.get("source_views", [])) != SOURCE_VIEWS:
        raise ValueError(f"Bundle source-view order is not {SOURCE_VIEWS}: {bundle_dir}")
    return metadata


def _model_spec(
    spec: Mapping[str, Any],
    bundle_metadata: Mapping[str, Any],
    core_script: Path,
) -> dict[str, Any]:
    manifest_schema = str(
        fixed4._scalar(spec, "experiment_schema", IMPLEMENTATION_SCHEMA_VERSION)
    )
    if manifest_schema != IMPLEMENTATION_SCHEMA_VERSION:
        raise ValueError(
            f"Manifest schema {manifest_schema!r} does not match implementation "
            f"{IMPLEMENTATION_SCHEMA_VERSION!r}; rebuild the manifests"
        )
    selected_views = _split_views(spec.get("model_input_views", ""))
    if str(fixed4._scalar(spec, "variant", "three_view_mcp")) != "three_view_mcp":
        raise ValueError("This experiment requires variant=three_view_mcp")
    if str(fixed4._scalar(spec, "core_model_variant", "full_mcp")) != "full_mcp":
        raise ValueError("The three-view network must use core_model_variant=full_mcp")
    if str(fixed4._scalar(spec, "label_mode", "strict_shared_mask")) != "strict_shared_mask":
        raise ValueError("The confirmatory comparison requires label_mode=strict_shared_mask")
    if str(
        fixed4._scalar(
            spec, "availability_policy", "selected_views_union_noncall"
        )
    ) != "selected_views_union_noncall":
        raise ValueError(
            "The confirmatory comparison requires availability_policy="
            "selected_views_union_noncall"
        )
    if str(
        fixed4._scalar(spec, "shared_fc_policy", "fixed_four_view_log2fc")
    ) != "fixed_four_view_log2fc":
        raise ValueError("This controlled input ablation requires fixed_four_view_log2fc")
    if str(
        fixed4._scalar(
            spec, "analysis_role", "fixed_supervision_input_view_ablation"
        )
    ) != "fixed_supervision_input_view_ablation":
        raise ValueError("This runner only supports the fixed-supervision input ablation")
    source_views = tuple(
        view.lower()
        for view in fixed4._split(
            fixed4._scalar(spec, "source_views", "+".join(SOURCE_VIEWS))
        )
    )
    if source_views != SOURCE_VIEWS:
        raise ValueError(f"source_views must be {'+'.join(SOURCE_VIEWS)}")
    return {
        "experiment": "fixed3view_confirmatory",
        "experiment_schema": IMPLEMENTATION_SCHEMA_VERSION,
        "run_id": str(spec["run_id"]),
        "dataset": str(bundle_metadata["dataset"]),
        "platform": str(bundle_metadata["platform"]),
        "data_index": int(bundle_metadata["data_index"]),
        "dea_method": str(bundle_metadata["dea_method"]),
        "variant": "three_view_mcp",
        "core_model_variant": "full_mcp",
        "model_input_views": list(selected_views),
        "model_input_views_string": "+".join(selected_views),
        "label_mode": "strict_shared_mask",
        "availability_policy": "selected_views_union_noncall",
        "shared_fc_policy": "fixed_four_view_log2fc",
        "analysis_role": "fixed_supervision_input_view_ablation",
        "seed": int(fixed4._scalar(spec, "seed", 2024)),
        "runtime_seed_control": fixed4._as_bool(
            fixed4._scalar(spec, "runtime_seed_control", False)
        ),
        "num_trials": int(fixed4._scalar(spec, "num_trials", 30)),
        "q_threshold": float(fixed4._scalar(spec, "q_threshold", 0.05)),
        "fc_ratio": float(fixed4._scalar(spec, "fc_ratio", 1.5)),
        "score_type": str(fixed4._scalar(spec, "score_type", "q")),
        "legacy_augmentation": False,
        "legacy_fdr_implementation": False,
        "bundle_sha256": bundle_metadata["bundle_sha256"],
        "label_fingerprint": bundle_metadata["label_fingerprint"],
        "truth_sha256": bundle_metadata["truth_sha256"],
        "truth_fingerprint": bundle_metadata["truth_fingerprint"],
        "fixed4_bundle_schema": bundle_metadata["experiment_schema"],
        "code_fingerprints": _current_code_fingerprints(core_script),
        "test_type": "DP_fdr",
    }


def _artifact(run_dir: Path, metadata: Mapping[str, Any], status: str) -> dict[str, Any]:
    return {
        "run_id": metadata["run_id"],
        "status": status,
        "prediction_file": str(run_dir / OUTPUT_PREDICTION_NAME),
        "metrics_file": str(run_dir / OUTPUT_METRICS_NAME),
        "run_metadata_file": str(run_dir / "metadata.json"),
        "latent_file": str(run_dir / OUTPUT_LATENT_NAME),
        "label_fingerprint": metadata["label_fingerprint"],
        "training_label_fingerprint": metadata.get("training_label_fingerprint", ""),
        "dataset": metadata["dataset"],
        "data_index": metadata["data_index"],
        "platform": metadata["platform"],
        "dea_method": metadata["dea_method"],
        "variant": metadata["variant"],
        "core_model_variant": metadata["core_model_variant"],
        "model_input_views": metadata["model_input_views_string"],
        "label_mode": metadata["label_mode"],
        "N_union": metadata["N_union"],
        "runtime_seconds": metadata.get("runtime_seconds", np.nan),
        "parameter_count": metadata.get("parameter_count", np.nan),
        "test_type": "DP_fdr",
    }


def run_fixed3view_model(
    spec: Mapping[str, Any],
    core: Any,
    core_script: str | Path,
    bundle_dir: str | Path,
    run_dir: str | Path,
    force: bool = False,
) -> dict[str, Any]:
    """Fit one three-view full-MCP network from an existing fixed-four bundle."""

    core_script = Path(core_script).expanduser().resolve()
    bundle_dir = Path(bundle_dir).expanduser().resolve()
    run_dir = Path(run_dir).expanduser().resolve()
    run_dir.mkdir(parents=True, exist_ok=True)
    bundle_file = bundle_dir / "fixed4view_training_bundle.npz"
    truth_file = bundle_dir / "evaluation_truth.csv"
    bundle_metadata = _validate_bundle(bundle_dir, core_script)
    model_spec = _model_spec(spec, bundle_metadata, core_script)
    model_spec_hash = fixed4._sha256_bytes(
        fixed4._canonical_json(model_spec).encode("utf-8")
    )

    metadata_file = run_dir / "metadata.json"
    prediction_file = run_dir / OUTPUT_PREDICTION_NAME
    metrics_file = run_dir / OUTPUT_METRICS_NAME
    latent_file = run_dir / OUTPUT_LATENT_NAME
    force = force or fixed4._as_bool(fixed4._scalar(spec, "force", False))
    if not force and all(
        path.is_file()
        for path in (metadata_file, prediction_file, metrics_file, latent_file)
    ):
        old = json.loads(metadata_file.read_text(encoding="utf-8"))
        if (
            old.get("status") == "completed"
            and old.get("model_spec_hash") == model_spec_hash
            and old.get("bundle_sha256") == bundle_metadata["bundle_sha256"]
            and old.get("truth_sha256") == bundle_metadata["truth_sha256"]
            and old.get("truth_fingerprint") == bundle_metadata["truth_fingerprint"]
            and old.get("prediction_sha256") == fixed4.sha256_file(prediction_file)
            and old.get("metrics_sha256") == fixed4.sha256_file(metrics_file)
            and old.get("latent_sha256") == fixed4.sha256_file(latent_file)
        ):
            return _artifact(run_dir, old, "skipped_existing")

    with np.load(bundle_file, allow_pickle=False) as loaded:
        proteins = loaded["proteins"].astype(str)
        sample_class = np.asarray(loaded["sample_class"], dtype=float)
        fixed_labels = np.asarray(loaded["fixed_pro_lab"], dtype=np.int8).reshape(-1)
        p_score = np.asarray(loaded["fixed_p_score"], dtype=float).reshape(-1)
        q_score = np.asarray(loaded["fixed_q_score"], dtype=float).reshape(-1)
        full_log2fc = np.asarray(loaded["fixed_full_log2fc"], dtype=float).reshape(-1)
        availability = {
            view: np.asarray(loaded[f"available_{view}"], dtype=bool).reshape(-1)
            for view in SOURCE_VIEWS
        }
        cached_data = {
            view: np.asarray(loaded[f"data_{view}"], dtype=np.float32)
            for view in SOURCE_VIEWS
        }

    n_union = len(proteins)
    if n_union == 0 or any(len(value) != n_union for value in availability.values()):
        raise ValueError("Invalid or empty fixed-four union bundle")
    if fixed4._hash_protein_labels(proteins, fixed_labels) != bundle_metadata["label_fingerprint"]:
        raise ValueError("Protein/label fingerprint differs from bundle metadata")
    model_views = list(model_spec["model_input_views"])
    model_data = [cached_data[view].copy() for view in model_views]
    if len(model_data) != 3 or any(matrix.shape[0] != n_union for matrix in model_data):
        raise ValueError("Exactly three union-aligned model matrices are required")
    selected_available = np.logical_or.reduce(
        [availability[view] for view in model_views]
    )
    if not np.array_equal(
        selected_available,
        availability[model_views[0]]
        | availability[model_views[1]]
        | availability[model_views[2]],
    ):
        raise AssertionError("selected_view_available must be the OR of exactly three views")
    if not np.any(selected_available) or np.all(selected_available):
        # All-available is not mathematically invalid, but reporting this unusual
        # case helps detect an availability-mask construction regression.
        if not np.any(selected_available):
            raise ValueError("None of the union proteins is available in the selected views")

    # Strict shared-mask design: the exact fixed-four pseudo-label vector enters
    # both models.  No labels are regenerated after dropping the fourth view.
    training_labels = fixed_labels.copy()
    supervised = training_labels != -1
    if set(np.unique(training_labels[supervised])) != {0, 1}:
        raise ValueError("Training mask must retain both pseudo-label classes")
    calibration_mask = supervised & selected_available
    if set(np.unique(training_labels[calibration_mask])) != {0, 1}:
        raise ValueError(
            "Selected-view-available supervised proteins must contain both classes"
        )
    training_pro_lab = training_labels.astype(float)[:, None]
    training_label_fingerprint = fixed4._hash_protein_labels(proteins, training_labels)
    if training_label_fingerprint != model_spec["label_fingerprint"]:
        raise ValueError("strict_shared_mask did not preserve the fixed-four label vector")

    if model_spec["runtime_seed_control"]:
        os.environ["MCP_RUNTIME_SEED"] = str(model_spec["seed"])
    else:
        os.environ.pop("MCP_RUNTIME_SEED", None)
    # Scientific method = three_view_mcp; underlying network implementation =
    # full MCP with nview inferred as 3 from model_data.
    os.environ["MCP_MODEL_VARIANT"] = "full_mcp"
    os.environ["MCP_VERBOSE_TRAIN"] = "0"
    os.environ["MCP_LEGACY_AUGMENTATION"] = "0"
    os.environ["MCP_USE_LEGACY_FDR"] = "0"
    core.seed_torch(core.runtime_seed(1029))
    device = core.torch.device("cuda" if core.torch.cuda.is_available() else "cpu")
    if core.torch.cuda.is_available():
        core.torch.cuda.reset_peak_memory_stats(device)

    predictions_across_trials = {"aucs": [], "probs": [], "labs": []}
    started = time.time()
    (
        model,
        _loss,
        _pro_loss,
        _reconstruction,
        latent,
        pro_pred,
        _feature_importances,
        _view_contributions,
        _cross_matrices,
        _head_importance,
    ) = core.optuna_optimize_para(
        model_data,
        sample_class,
        training_pro_lab,
        p_score,
        q_score,
        device,
        model_spec["num_trials"],
        model_spec["score_type"],
        predictions_across_trials,
        str(run_dir / "best_param_fixed3view.txt"),
    )
    training_seconds = time.time() - started
    if int(getattr(model, "nview", -1)) != 3:
        raise AssertionError(f"Core model did not instantiate nview=3: {getattr(model, 'nview', None)}")
    if str(getattr(model, "variant", "")) != "full_mcp":
        raise AssertionError(
            f"Core model is not the full_mcp architecture: {getattr(model, 'variant', None)!r}"
        )

    raw_probability = np.asarray(
        1.0 - pro_pred.detach().cpu().numpy()[:, 0], dtype=float
    )
    latent_array = latent.detach().cpu().numpy().astype(np.float32)
    if len(raw_probability) != n_union or not np.all(np.isfinite(raw_probability)):
        raise FloatingPointError("Model returned invalid NaN/Inf or wrong-length probabilities")
    if np.any((raw_probability < 0) | (raw_probability > 1)):
        raise FloatingPointError("Model probabilities must lie in [0, 1]")
    if latent_array.shape[0] != n_union or not np.all(np.isfinite(latent_array)):
        raise FloatingPointError("Model returned invalid NaN/Inf or wrong-length latent values")

    # Availability-aware DP_fdr: unavailable zero rows cannot alter the selected
    # posterior-FDR set or threshold.  They are mapped back as score 0/non-DEP.
    posterior_fdr_selected = np.zeros(n_union, dtype=bool)
    posterior_fdr_selected[selected_available] = np.asarray(
        core._fdr_de_prediction(
            pd.Series(raw_probability[selected_available]),
            fdr=model_spec["q_threshold"],
        ),
        dtype=bool,
    )
    corrected_probability = np.zeros(n_union, dtype=float)
    corrected_available = raw_probability[selected_available].copy()
    selected_local = posterior_fdr_selected[selected_available]
    corrected_available[(~selected_local) & (corrected_available > 0.5)] = 0.499
    corrected_probability[selected_available] = corrected_available
    fixed_threshold = float(
        core._optimal_f1_threshold(
            training_labels[calibration_mask],
            corrected_probability[calibration_mask],
            default=0.5,
        )
    )
    if not np.isfinite(fixed_threshold):
        raise FloatingPointError("DP_fdr calibration returned a non-finite threshold")
    fc_threshold = math.log2(model_spec["fc_ratio"])
    called = (
        selected_available
        & (corrected_probability >= fixed_threshold)
        & (np.abs(full_log2fc) >= fc_threshold)
    )
    if np.any(called[~selected_available]) or np.any(
        corrected_probability[~selected_available] != 0
    ):
        raise AssertionError("Unavailable proteins must have score 0 and cannot be called")

    # Evaluation truth is opened only after fitting, thresholding and calls.
    truth = pd.read_csv(truth_file, dtype={"Protein": str})
    if truth["Protein"].duplicated().any():
        raise ValueError("Evaluation truth contains duplicate Protein IDs")
    aligned_truth = pd.DataFrame({"Protein": proteins}).merge(
        truth[["Protein", "True_lab"]], on="Protein", how="left", validate="one_to_one"
    )
    if aligned_truth["True_lab"].isna().any():
        raise ValueError("Truth does not cover the complete fixed-four union")
    true_labels = aligned_truth["True_lab"].astype(int).to_numpy()
    if fixed4._hash_protein_labels(proteins, true_labels) != bundle_metadata["truth_fingerprint"]:
        raise ValueError("Evaluation-truth fingerprint differs from bundle metadata")

    td_labels = np.full(n_union, -1, dtype=int)
    td_labels[(np.abs(full_log2fc) >= fc_threshold) & (corrected_probability > 0.5)] = 1
    qvalues = np.asarray(
        core.fdr(np.asarray(core.fdr_2qvalue(corrected_probability, td_labels)))[1]
    )
    if len(qvalues) != n_union or not np.all(np.isfinite(qvalues)):
        raise FloatingPointError("DP_fdr audit q-values are non-finite or wrong-length")
    if np.any((qvalues < 0) | (qvalues > 1)):
        raise FloatingPointError("DP_fdr audit q-values must lie in [0, 1]")
    prediction = pd.DataFrame(
        {
            "Protein": proteins,
            "True_lab": true_labels,
            "raw_probability": raw_probability,
            "posterior_fdr_selected": posterior_fdr_selected,
            "DP_fdr_probability_before_availability": corrected_probability,
            "DP_fdr_available_probability": corrected_probability,
            "DP_fdr_probability": corrected_probability,
            "DP_fdr_qvalue_audit": qvalues,
            "DP_fdr_threshold": fixed_threshold,
            "shared_full_log2fc": full_log2fc,
            "selected_view_available": selected_available,
            "called_DP_fdr": called,
            "fixed_pro_lab": fixed_labels,
            "is_fixed_pseudo_supervised": supervised,
            "training_pro_lab": training_labels,
            "used_for_classification_training": supervised,
            **{f"available_{view}": availability[view] for view in SOURCE_VIEWS},
        }
    )
    prediction.to_csv(prediction_file, index=False)
    np.savez_compressed(latent_file, proteins=proteins.astype(str), latent=latent_array)

    method = "three_view_mcp_" + "_".join(model_views)
    metric_base = {
        "run_id": model_spec["run_id"],
        "dataset": model_spec["dataset"],
        "data_index": model_spec["data_index"],
        "acquisition": "DIA",
        "platform": model_spec["platform"],
        "dea_method": model_spec["dea_method"],
        "method": method,
        "variant": "three_view_mcp",
        "core_model_variant": "full_mcp",
        "model_input_views": model_spec["model_input_views_string"],
        "label_mode": "strict_shared_mask",
        "test_type": "DP_fdr",
        "availability_policy": "selected_views_union_noncall",
        "seed": model_spec["seed"],
        "q_threshold": model_spec["q_threshold"],
        "fc_ratio": model_spec["fc_ratio"],
        "DP_fdr_threshold": fixed_threshold,
        "label_fingerprint": model_spec["label_fingerprint"],
        "training_label_fingerprint": training_label_fingerprint,
    }
    metrics = fixed4._evaluate_subsets(
        metric_base,
        true_labels,
        corrected_probability,
        called,
        fixed_labels,
        availability,
        selected_available,
    )
    metrics.to_csv(metrics_file, index=False)

    peak_memory_mb = (
        float(core.torch.cuda.max_memory_allocated(device)) / (1024.0**2)
        if core.torch.cuda.is_available()
        else 0.0
    )
    metadata = {
        **model_spec,
        "status": "completed",
        "model_spec_hash": model_spec_hash,
        "training_label_fingerprint": training_label_fingerprint,
        "model_views": model_views,
        "verified_core_nview": int(model.nview),
        "verified_core_variant": str(model.variant),
        "model_input_matrix_fingerprints": {
            view: _array_fingerprint(cached_data[view]) for view in model_views
        },
        "omitted_view": next(view for view in SOURCE_VIEWS if view not in model_views),
        "N_union": n_union,
        "N_training_positive": int(np.sum(training_labels == 1)),
        "N_training_negative": int(np.sum(training_labels == 0)),
        "N_training_unlabeled": int(np.sum(training_labels == -1)),
        "N_selected_view_available": int(np.sum(selected_available)),
        "N_selected_view_unavailable": int(np.sum(~selected_available)),
        "N_fixed_supervised_selected_available": int(
            np.sum(supervised & selected_available)
        ),
        "N_fixed_supervised_selected_unavailable": int(
            np.sum(supervised & ~selected_available)
        ),
        "N_fixed_positive_selected_unavailable": int(
            np.sum((training_labels == 1) & ~selected_available)
        ),
        "N_fixed_negative_selected_unavailable": int(
            np.sum((training_labels == 0) & ~selected_available)
        ),
        "fraction_fixed_supervised_selected_unavailable": float(
            np.sum(supervised & ~selected_available) / np.sum(supervised)
        ),
        "DP_fdr_threshold": fixed_threshold,
        "training_seconds": training_seconds,
        "runtime_seconds": training_seconds,
        "peak_memory_mb": peak_memory_mb,
        "parameter_count": int(sum(parameter.numel() for parameter in model.parameters())),
        "prediction_file": str(prediction_file),
        "metrics_file": str(metrics_file),
        "latent_file": str(latent_file),
        "prediction_sha256": fixed4.sha256_file(prediction_file),
        "metrics_sha256": fixed4.sha256_file(metrics_file),
        "latent_sha256": fixed4.sha256_file(latent_file),
        "completed_at_unix": time.time(),
    }
    fixed4._write_json_atomic(metadata_file, metadata)
    return _artifact(run_dir, metadata, "completed")


__all__ = [
    "IMPLEMENTATION_SCHEMA_VERSION",
    "OUTPUT_LATENT_NAME",
    "OUTPUT_METRICS_NAME",
    "OUTPUT_PREDICTION_NAME",
    "SOURCE_VIEWS",
    "run_fixed3view_model",
]
