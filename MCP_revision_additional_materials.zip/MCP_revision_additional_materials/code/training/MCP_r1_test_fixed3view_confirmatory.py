"""Fast synthetic integration test for the 28-run package (no real MCP fitting)."""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd

import MCP_r1_fixed4label_ablation as fixed4
from MCP_r1_build_fixed3view_confirmatory_manifest import build_rows
from MCP_r1_fixed3view_confirmatory import run_fixed3view_model
from MCP_r1_merge_fixed3view_confirmatory_shards import _derive_dp_fdr, merge_shards


class _FakeTensor:
    def __init__(self, value: np.ndarray):
        self.value = np.asarray(value)

    def detach(self):
        return self

    def cpu(self):
        return self

    def numpy(self):
        return self.value


class _FakeParameter:
    def numel(self):
        return 17


class _FakeModel:
    def __init__(self, nview: int):
        self.nview = nview
        self.variant = os.environ.get("MCP_MODEL_VARIANT")

    def parameters(self):
        return [_FakeParameter(), _FakeParameter()]


class _FakeCuda:
    @staticmethod
    def is_available():
        return False

    @staticmethod
    def reset_peak_memory_stats(_device):
        return None

    @staticmethod
    def max_memory_allocated(_device):
        return 0


class _FakeTorch:
    cuda = _FakeCuda()

    @staticmethod
    def device(value):
        return value


class _FakeCore:
    torch = _FakeTorch()

    @staticmethod
    def runtime_seed(default):
        return default

    @staticmethod
    def seed_torch(_seed):
        return None

    @staticmethod
    def _fdr_de_prediction(scores, fdr):
        from MCP_r1_merge_fixed4label_ablation_shards import _posterior_fdr_selection

        return _posterior_fdr_selection(np.asarray(scores, dtype=float), float(fdr))

    @staticmethod
    def _optimal_f1_threshold(labels, scores, default=0.5):
        from MCP_r1_merge_fixed4label_ablation_shards import _optimal_f1_threshold

        return _optimal_f1_threshold(np.asarray(labels), np.asarray(scores))

    @staticmethod
    def fdr_2qvalue(scores, _labels):
        return np.clip(1.0 - np.asarray(scores, dtype=float), 0, 1)

    @staticmethod
    def fdr(values):
        return True, np.clip(np.asarray(values, dtype=float), 0, 1)

    @staticmethod
    def optuna_optimize_para(
        model_data,
        _sample_class,
        _training_labels,
        _p_score,
        _q_score,
        _device,
        _num_trials,
        _score_type,
        _predictions,
        _log_path,
    ):
        n = model_data[0].shape[0]
        raw = np.linspace(0.91, 0.09, n)
        latent = np.column_stack([raw, 1.0 - raw]).astype(np.float32)
        return (
            _FakeModel(len(model_data)),
            0,
            0,
            None,
            _FakeTensor(latent),
            _FakeTensor((1.0 - raw)[:, None]),
            None,
            None,
            None,
            None,
        )


def _fixture_arrays():
    n = 12
    proteins = np.asarray([f"P{i:02d}" for i in range(n)], dtype=str)
    fixed_labels = np.asarray([1, 0, 1, 0, -1, -1, -1, -1, 1, 0, -1, -1], dtype=np.int8)
    truth = np.asarray([1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0], dtype=np.int8)
    availability = {
        "dlfq": np.asarray([1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0], dtype=bool),
        "maxlfq": np.asarray([1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 0], dtype=bool),
        "top3": np.asarray([1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0], dtype=bool),
        "top1": np.asarray([1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1], dtype=bool),
    }
    log2fc = np.asarray([1.2, 0.2, -1.1, -0.1, 1.0, 0.1, -0.9, 0.2, 1.4, 0.0, 1.1, 0.1])
    return proteins, fixed_labels, truth, availability, log2fc


def _make_bundle(bundle_dir: Path, row: dict[str, str], core_script: Path) -> dict:
    bundle_dir.mkdir(parents=True, exist_ok=True)
    proteins, labels, truth, availability, log2fc = _fixture_arrays()
    n = len(proteins)
    arrays = {
        "proteins": proteins,
        "sample_class": np.asarray([[0], [0], [1], [1]], dtype=float),
        "sample_names": np.asarray(["A1", "A2", "B1", "B2"]),
        "sample_condition": np.asarray(["A", "A", "B", "B"]),
        "fixed_pro_lab": labels,
        "fixed_p_score": np.where(labels == -1, -1.0, np.where(labels == 1, 0.98, 0.05)),
        "fixed_q_score": np.where(labels == -1, -1.0, np.where(labels == 1, 0.98, 0.05)),
        "fixed_full_log2fc": log2fc,
    }
    for index, view in enumerate(fixed4.SOURCE_VIEWS):
        matrix = (np.arange(n * 4, dtype=np.float32).reshape(n, 4) + index) / 10
        matrix[~availability[view], :] = 0
        arrays[f"data_{view}"] = matrix
        arrays[f"available_{view}"] = availability[view]
    bundle_file = bundle_dir / "fixed4view_training_bundle.npz"
    np.savez_compressed(bundle_file, **arrays)
    audit = pd.DataFrame(
        {
            "Protein": proteins,
            "fixed_pro_lab": labels,
            "is_supervised": labels != -1,
            "fixed_p_score": arrays["fixed_p_score"],
            "fixed_q_score": arrays["fixed_q_score"],
            "fixed_full_log2fc": log2fc,
            **{f"available_{view}": availability[view] for view in fixed4.SOURCE_VIEWS},
        }
    )
    audit["available_all_four"] = np.logical_and.reduce(list(availability.values()))
    audit_file = bundle_dir / "fixed_label_audit.csv"
    truth_file = bundle_dir / "evaluation_truth.csv"
    audit.to_csv(audit_file, index=False)
    pd.DataFrame({"Protein": proteins, "True_lab": truth}).to_csv(truth_file, index=False)
    metadata = {
        "status": "completed",
        "experiment_schema": fixed4.IMPLEMENTATION_SCHEMA_VERSION,
        "dataset": f"SYNTHETIC_DIA_{row['data_index']}",
        "data_index": int(row["data_index"]),
        "platform": row["platform"],
        "dea_method": row["dea_method"],
        "source_views": list(fixed4.SOURCE_VIEWS),
        "bundle_sha256": fixed4.sha256_file(bundle_file),
        "label_audit_sha256": fixed4.sha256_file(audit_file),
        "truth_sha256": fixed4.sha256_file(truth_file),
        "label_fingerprint": fixed4._hash_protein_labels(proteins, labels),
        "truth_fingerprint": fixed4._hash_protein_labels(proteins, truth),
        "code_fingerprints": fixed4._code_fingerprints(core_script),
        "source_file_hashes": {str(core_script): fixed4.sha256_file(core_script)},
        "N_union": n,
    }
    fixed4._write_json_atomic(bundle_dir / "metadata.json", metadata)
    return metadata


def _make_full_control(
    control_dir: Path,
    row: dict[str, str],
    bundle_metadata: dict,
    core_script: Path,
) -> None:
    control_dir.mkdir(parents=True, exist_ok=True)
    proteins, labels, truth, availability, log2fc = _fixture_arrays()
    raw = np.asarray([0.93, 0.07, 0.88, 0.10, 0.82, 0.15, 0.76, 0.22, 0.86, 0.12, 0.72, 0.18])
    full_available = np.logical_or.reduce(list(availability.values()))
    derived = _derive_dp_fdr(raw, full_available, labels, log2fc, 0.05, 1.5)
    pred = pd.DataFrame(
        {
            "Protein": proteins,
            "True_lab": truth,
            "raw_probability": raw,
            "posterior_fdr_selected": derived["posterior"],
            "DP_fdr_probability_before_availability": derived["score"],
            "DP_fdr_available_probability": derived["score"],
            "DP_fdr_probability": derived["score"],
            "DP_fdr_qvalue_audit": np.clip(1 - derived["score"], 0, 1),
            "DP_fdr_threshold": derived["threshold"],
            "shared_full_log2fc": log2fc,
            "selected_view_available": full_available,
            "called_DP_fdr": derived["called"],
            "fixed_pro_lab": labels,
            "is_fixed_pseudo_supervised": labels != -1,
            "training_pro_lab": labels,
            "used_for_classification_training": labels != -1,
            **{f"available_{view}": availability[view] for view in fixed4.SOURCE_VIEWS},
        }
    )
    prediction_file = control_dir / "fixed4label_DP_fdr_predictions.csv"
    metrics_file = control_dir / "fixed4label_metrics.csv"
    latent_file = control_dir / "fixed4label_latent.npz"
    pred.to_csv(prediction_file, index=False)
    pd.DataFrame({"test_type": ["DP_fdr"], "mcc": [0.5]}).to_csv(metrics_file, index=False)
    np.savez_compressed(latent_file, proteins=proteins, latent=np.zeros((len(proteins), 2)))
    control_spec = dict(row)
    control_spec.update(
        {
            "experiment_schema": fixed4.IMPLEMENTATION_SCHEMA_VERSION,
            "run_id": row["fixed4_control_run_id"],
            "variant": "full_mcp",
            "model_input_views": "all4",
            "availability_policy": "selected_view_noncall",
        }
    )
    expected_model_spec = fixed4._model_spec(control_spec, bundle_metadata, core_script)
    metadata = {
        **expected_model_spec,
        "status": "completed",
        "model_spec_hash": fixed4._sha256_bytes(
            fixed4._canonical_json(expected_model_spec).encode("utf-8")
        ),
        "prediction_sha256": fixed4.sha256_file(prediction_file),
        "metrics_sha256": fixed4.sha256_file(metrics_file),
        "latent_sha256": fixed4.sha256_file(latent_file),
    }
    fixed4._write_json_atomic(control_dir / "metadata.json", metadata)


def main() -> None:
    project_dir = Path(__file__).resolve().parent
    core_script = project_dir / "MCP_r1_mv_contrast_v6.0.3_4_linux_comb_exp_mcc2_new.py"
    rows = build_rows()
    fake_core = _FakeCore()
    with tempfile.TemporaryDirectory(prefix="mcp_fixed3_selftest_") as temporary:
        root = Path(temporary)
        fixed4_root = root / "fixed4" / "shards"
        new_root = root / "fixed3" / "shards"
        first_resume = None
        for shard_id in range(1, 8):
            ledger_rows = []
            manifest_rows = []
            metric_frames = []
            shard_rows = [row for row in rows if int(row["data_index"]) == shard_id - 1]
            for row in shard_rows:
                base_shard = fixed4_root / f"shard_{shard_id}"
                bundle_dir = base_shard / "bundles" / f"i{row['data_index']}_{row['platform']}_{row['dea_method']}"
                bundle_metadata = _make_bundle(bundle_dir, row, core_script)
                control_dir = base_shard / "runs" / row["fixed4_control_run_id"]
                _make_full_control(control_dir, row, bundle_metadata, core_script)
                run_dir = new_root / f"shard_{shard_id}" / "runs" / row["run_id"]
                artifact = run_fixed3view_model(row, fake_core, core_script, bundle_dir, run_dir)
                if first_resume is None:
                    first_resume = (row, bundle_dir, run_dir)
                ledger_rows.append({**row, **artifact})
                manifest_rows.append(
                    {
                        "run_id": row["run_id"],
                        "fixed4_control_run_id": row["fixed4_control_run_id"],
                        "dataset": artifact["dataset"],
                        "data_index": artifact["data_index"],
                        "platform": artifact["platform"],
                        "dea_method": artifact["dea_method"],
                        "variant": "three_view_mcp",
                        "core_model_variant": "full_mcp",
                        "model_input_views": artifact["model_input_views"],
                        "label_mode": "strict_shared_mask",
                        "test_type": "DP_fdr",
                        "seed": 2024,
                        "prediction_file": artifact["prediction_file"],
                        "run_metadata_file": artifact["run_metadata_file"],
                        "label_fingerprint": artifact["label_fingerprint"],
                    }
                )
                metric_frames.append(pd.read_csv(artifact["metrics_file"]))
            shard_dir = new_root / f"shard_{shard_id}"
            pd.DataFrame(ledger_rows).to_csv(shard_dir / "core_run_ledger.csv", index=False)
            pd.DataFrame(manifest_rows).to_csv(shard_dir / "generated_prediction_manifest.csv", index=False)
            pd.concat(metric_frames, ignore_index=True).to_csv(
                shard_dir / "generated_performance_wide.csv", index=False
            )
        assert first_resume is not None
        resume = run_fixed3view_model(
            first_resume[0], fake_core, core_script, first_resume[1], first_resume[2]
        )
        if resume["status"] != "skipped_existing":
            raise AssertionError("Resume validation did not skip the intact completed run")
        qc = merge_shards(new_root, fixed4_root, root / "merged")
        if qc["new_model_fits_observed"] != 28 or qc["four_view_controls_retrained_by_this_experiment"] != 0:
            raise AssertionError(f"Unexpected merge QC: {qc}")
        print("SYNTHETIC SELF-TEST PASSED: 28 new fits, resume, full QC, n=7 statistics")


if __name__ == "__main__":
    main()
