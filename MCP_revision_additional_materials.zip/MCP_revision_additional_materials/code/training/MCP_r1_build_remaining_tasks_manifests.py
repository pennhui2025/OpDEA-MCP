"""Build the incremental Task 5 manifests used by the seven DIA workers.

Only the three architecture-removal variants are new here.  The four-view
full MCP, simple early/late fusion and rank/p-value fusion controls are reused
from completed Tasks 1/2.  The 1/2/3/4-view full-MCP results are reused from
the completed view-combination experiment.

仅生成尚未运行的 Task 5 深度消融，避免重复计算已完成的 Task 1/2。
"""

from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


VIEWS = "dlfq+maxlfq+top3+top1"
VARIANTS = ("no_balancing", "no_contrastive", "no_cross_attention")


def dea_label(value: object) -> str:
    methods = [
        part.strip().upper() if part.strip().upper() == "ROTS" else part.strip().lower()
        for part in str(value).replace(",", "+").split("+")
        if part.strip()
    ]
    unique = list(dict.fromkeys(methods))
    if len(unique) != 1 or unique[0] not in {"limma", "ROTS"}:
        raise ValueError(f"Expected one uniform limma/ROTS method, got {value!r}")
    return unique[0]


def build(source_manifest: Path, output_dir: Path) -> pd.DataFrame:
    source_manifest = source_manifest.resolve()
    output_dir = output_dir.resolve()
    source = pd.read_csv(source_manifest)
    required = {
        "run_id", "acquisition", "platform", "data_index", "views",
        "variant", "dea_methods",
    }
    missing = sorted(required - set(source.columns))
    if missing:
        raise ValueError(f"{source_manifest} is missing columns: {missing}")

    template = source[
        source["acquisition"].astype(str).str.upper().eq("DIA")
        & source["variant"].astype(str).eq("full_mcp")
        & source["views"].astype(str).eq(VIEWS)
    ].copy()
    template["dea_method"] = template["dea_methods"].map(dea_label)
    key_columns = ["data_index", "platform", "dea_method"]
    counts = template.groupby(key_columns, dropna=False).size()
    if len(template) != 28 or not counts.eq(1).all():
        raise ValueError(
            "The source must expose exactly one four-view full_mcp template for "
            "7 data indices x 2 platforms x 2 DEA methods"
        )

    rows: list[dict[str, object]] = []
    for _, base in template.iterrows():
        for variant in VARIANTS:
            row = base.drop(labels=["dea_method"]).to_dict()
            row["run_id"] = f"{base['run_id']}__task5__{variant}"
            row["variant"] = variant
            row["gpu_id"] = "0"
            row["force"] = False
            row.pop("output_root", None)
            rows.append(row)
    result = pd.DataFrame(rows)
    result["_dea_sort"] = result["dea_methods"].map(dea_label)
    result = result.sort_values(
        ["data_index", "platform", "_dea_sort", "variant"], kind="stable"
    ).drop(columns="_dea_sort")

    if len(result) != 84 or not result["run_id"].is_unique:
        raise AssertionError("Expected 84 unique Task 5 incremental runs")
    for index in range(7):
        shard = result[pd.to_numeric(result["data_index"]).astype(int).eq(index)].copy()
        if len(shard) != 12:
            raise AssertionError(f"data_index={index} should have 12 rows, found {len(shard)}")
        coverage = (
            shard.assign(dea_method=shard["dea_methods"].map(dea_label))
            .groupby(["platform", "dea_method", "variant"])
            .size()
        )
        if len(coverage) != 12 or not coverage.eq(1).all():
            raise AssertionError(f"Invalid Task 5 coverage for data_index={index}")

    output_dir.mkdir(parents=True, exist_ok=True)
    master = output_dir / "MCP_r1_remaining_task5_deep_ablation_manifest.csv"
    result.to_csv(master, index=False)
    for shard_id in range(1, 8):
        shard = result[
            pd.to_numeric(result["data_index"]).astype(int).eq(shard_id - 1)
        ]
        shard.to_csv(
            output_dir / f"MCP_r1_remaining_task5_deep_ablation_shard_{shard_id}.csv",
            index=False,
        )
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--source-manifest",
        type=Path,
        default=Path(__file__).with_name("MCP_r1_task1_2_DIA_limma_ROTS_manifest.csv"),
    )
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    result = build(args.source_manifest, args.output_dir)
    print(
        "Prepared Task 5 incremental manifests: "
        f"{len(result)} runs, 12 runs in each of 7 shards."
    )


if __name__ == "__main__":
    main()
