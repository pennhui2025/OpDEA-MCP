"""PyCharm entry point: merge/QC all seven fixed4label ablation shards."""

from pathlib import Path

from MCP_r1_merge_fixed4label_ablation_shards import merge_shards


if __name__ == "__main__":
    project_dir = Path(__file__).resolve().parent
    base = project_dir / "revision_results" / "final_required" / "fixed4label_single_view_ablation"
    qc = merge_shards(base / "shards", base / "merged")
    print(qc)

