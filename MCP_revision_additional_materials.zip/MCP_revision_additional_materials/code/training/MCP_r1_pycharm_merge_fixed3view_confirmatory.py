"""PyCharm entry point: merge/QC the seven fixed3view 4-fit shards."""

from pathlib import Path

from MCP_r1_merge_fixed3view_confirmatory_shards import merge_shards


if __name__ == "__main__":
    project_dir = Path(__file__).resolve().parent
    final_root = project_dir / "revision_results" / "final_required"
    qc = merge_shards(
        final_root / "fixed3view_confirmatory" / "shards",
        final_root / "fixed4label_single_view_ablation" / "shards",
        final_root / "fixed3view_confirmatory" / "merged",
    )
    print(qc)
