"""Run fixed4label ablation shard 6 (data index 5) on physical GPU 1."""
from MCP_r1_pycharm_run_fixed4label_ablation_shard import run_shard

if __name__ == "__main__":
    run_shard(6, 1)
