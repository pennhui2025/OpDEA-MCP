library(samr)

args <- commandArgs(trailingOnly = TRUE)
print(args)

raw_file_path <- args[1]
platform <- args[2]
inten_type <- args[3]
imput <- args[4]
normal <- args[5]
dataset <- args[6]
save_fold <- args[7]
print_lab <- args[8]
true_organism <- args[9]
DE_organism <- args[10]
true_lgfc <- args[11]
logT <- args[12]
design_file_path <- args[13]
R_fold_path <- args[14]
true_lgfc <- paste0(R_fold_path, true_lgfc)

source(paste0(R_fold_path, '/preprocessing_pro_intensity.R'))
source(paste0(R_fold_path, '/utils.R'))

if (imput == 'blank') {
  imput <- ''
}

if (normal == 'blank') {
  normal <- ''
}


file_name <- raw_file_path
design_file <- design_file_path
designs <- read.table(design_file, sep = '\t', header = TRUE)

set.seed(123)

prepro_res <- preprocessing_raw(
  file_name,
  designs,
  platform,
  inten_type,
  imput = imput,
  normal = normal,
  log2 = logT
)

all_conts <- function(design_data) {
  conds <- design_data$condition
  uni_con <- unique(conds)
  conts <- c()
  groups <- vector()
  
  for (i in 1:(length(uni_con) - 1)) {
    for (j in (i + 1):length(uni_con)) {
      conts <- c(conts, paste0('condition', uni_con[j], '-', 'condition', uni_con[i]))
      groups <- rbind(groups, c(uni_con[i], uni_con[j]))
    }
  }
  
  return(list(conts = conts, groups = groups))
}

consts <- all_conts(designs)

# -------------------------------
# Helper function:
# Convert samr object to full result table
# -------------------------------
extract_sam_all_results <- function(
    samr.obj,
    data,
    intens.filter,
    contrast_name,
    target_fdr = 0.05
) {
  
  proteins <- rownames(intens.filter)
  
  sam_score <- samr.obj$tt
  
  sam_pvalue <- tryCatch(
    {
      samr.pvalues.from.perms(samr.obj$tt, samr.obj$ttstar)
    },
    error = function(e) {
      warning("samr.pvalues.from.perms failed: ", conditionMessage(e))
      rep(NA, length(proteins))
    }
  )
  
  idx1 <- which(data$y == 1)
  idx2 <- which(data$y == 2)
  
  mean_g1 <- rowMeans(data$x[, idx1, drop = FALSE], na.rm = TRUE)
  mean_g2 <- rowMeans(data$x[, idx2, drop = FALSE], na.rm = TRUE)
  
  if (isTRUE(data$logged2)) {
    logFC <- mean_g2 - mean_g1
  } else {
    logFC <- log2(mean_g2 + 1e-8) - log2(mean_g1 + 1e-8)
  }
  
  ave_expr <- rowMeans(data$x, na.rm = TRUE)
  
  # -------------------------------
  # Native SAM FDR by delta table
  # -------------------------------
  delta.table <- samr.compute.delta.table(samr.obj)
  
  # print(delta.table)
  # print(colnames(delta.table))
  
  delta_col <- which(colnames(delta.table) == "delta")
  fdr_col <- which(colnames(delta.table) == "median FDR")
  
  #fdr_col <- grep("median false discovery rate", colnames(delta.table), ignore.case = TRUE)
  
  if (length(fdr_col) != 1) {
    stop("Cannot identify median false discovery rate column in SAM delta table.")
  }
  
  #delta_col <- grep("^delta$", colnames(delta.table), ignore.case = TRUE)
  
  if (length(delta_col) != 1) {
    stop("Cannot identify delta column in SAM delta table.")
  }
  
  valid_delta <- delta.table[delta.table[, fdr_col] <= target_fdr, , drop = FALSE]
  
  SAM.significant <- rep(FALSE, length(proteins))
  selected_delta <- NA
  selected_fdr <- NA
  
  if (nrow(valid_delta) > 0) {
    
    # Choose the smallest delta satisfying target FDR.
    # This usually gives the largest number of significant proteins under target FDR.
    selected_delta <- valid_delta[1, delta_col]
    selected_fdr <- valid_delta[1, fdr_col]
    
    siggenes.table <- samr.compute.siggenes.table(
      samr.obj,
      del = selected_delta,
      data = data,
      delta.table = delta.table
    )
    
    sig_up <- siggenes.table$genes.up
    sig_down <- siggenes.table$genes.lo
    
    sig_proteins <- unique(c(sig_up[, "Gene ID"], sig_down[, "Gene ID"]))
    SAM.significant <- proteins %in% sig_proteins
    
  } else {
    warning(
      paste0(
        "No SAM delta reached target FDR = ",
        target_fdr,
        " for contrast ",
        contrast_name
      )
    )
  }
  #pvalue=data.frame(samr.pvalues.from.perms(samr.obj$tt, samr.obj$ttstar))
  #adj.pvalue=p.adjust(sam_pvalue, method = "BH")
  res <- data.frame(
    protein = proteins,
    logFC = as.numeric(logFC),
    AveExpr = as.numeric(ave_expr),
    SAM.score = as.numeric(sam_score),
    pvalue = as.numeric(sam_pvalue),
    SAM.significant = SAM.significant,
    SAM.selected.delta = selected_delta,
    SAM.delta.FDR = selected_fdr,
    #adj.pvalue = adj.pvalue,
    contrast = contrast_name,
    stringsAsFactors = FALSE
  )
  res$adj.pvalue <- ifelse(
    res$SAM.significant,
    res$SAM.delta.FDR,
    1
  )
  res <- res[order(res$pvalue, na.last = TRUE), ]
  
  return(res)
}

res_all <- vector()

for (i in 1:length(consts$conts)) {
  
  groups <- consts$groups
  g1 <- groups[i, ][1]
  g2 <- groups[i, ][2]
  
  sample_names1 <- designs$sample_name[grep(g1, designs$condition)]
  sample_names2 <- designs$sample_name[grep(g2, designs$condition)]
  
  idx_g1 <- match(sample_names1, colnames(prepro_res$normed))
  idx_g2 <- match(sample_names2, colnames(prepro_res$normed))
  
  intens <- prepro_res$normed[, c(idx_g1, idx_g2)]
  intens <- as.data.frame(intens)
  intens[intens == 0] <- NA
  
  # --------------------------------------------------
  # SAM cannot handle too many missing values directly.
  # Keep the same filtering logic as your limma script:
  # at least two observed values in each group
  # and less than 80% missing values overall.
  # --------------------------------------------------
  intens$na_g1 <- apply(intens[, 1:length(idx_g1), drop = FALSE], 1, function(x) sum(is.na(x)))
  intens$na_g2 <- apply(
    intens[, (length(idx_g1) + 1):(length(idx_g1) + length(idx_g2)), drop = FALSE],
    1,
    function(x) sum(is.na(x))
  )
  
  filter_idx <- which(
    (length(idx_g1) - intens$na_g1) >= 2 &
      (length(idx_g2) - intens$na_g2) >= 2
  )
  
  intens.filter <- intens[filter_idx, ][, 1:(ncol(intens) - 2), drop = FALSE]
  
  idx_retain <- which(
    apply(intens.filter, 1, function(x) sum(is.na(x))) < ncol(intens.filter) * 0.8
  )
  
  intens.filter <- intens.filter[idx_retain, , drop = FALSE]
  
  # --------------------------------------------------
  # SAM requires a complete matrix.
  # Here we perform simple row-median imputation after filtering.
  # This is conservative and keeps the script self-contained.
  # If your preprocessing_raw() already imputes missing values,
  # this step will have little or no effect.
  # --------------------------------------------------
  intens.sam <- as.matrix(intens.filter)
  
  row_median_impute <- function(x) {
    if (all(is.na(x))) {
      return(x)
    }
    x[is.na(x)] <- median(x, na.rm = TRUE)
    return(x)
  }
  
  intens.sam <- t(apply(intens.sam, 1, row_median_impute))
  
  # Remove rows that still contain NA or infinite values
  valid_idx <- which(
    apply(intens.sam, 1, function(x) all(is.finite(x)))
  )
  
  intens.sam <- intens.sam[valid_idx, , drop = FALSE]
  intens.filter <- intens.filter[valid_idx, , drop = FALSE]
  
  if (nrow(intens.sam) < 2) {
    warning(paste0("Too few proteins retained for contrast: ", consts$conts[i]))
    next
  }
  
  # --------------------------------------------------
  # SAM response vector:
  # y = 1 for group 1
  # y = 2 for group 2
  # This follows the samr two-class unpaired format.
  # --------------------------------------------------
  y <- c(rep(1, length(idx_g1)), rep(2, length(idx_g2)))
  
  # if(logT=='T'){
  #   logT=T
  # }else if(logT=='F'){
  #   logT=F
  # }
  # 
  sam_data <- list(
    x = intens.sam,
    y = y,
    geneid = rownames(intens.sam),
    genenames = rownames(intens.sam),
    logged2 = T
  )
  
  # --------------------------------------------------
  # Run SAM.
  # nperms can be increased to 500 or 1000 for final benchmark.
  # testStatistic = "standard" is closest to t-statistic-like DEA.
  # --------------------------------------------------
  samr.obj <- samr(
    data = sam_data,
    resp.type = "Two class unpaired",
    nperms = 1000,
    assay.type = "array",
    testStatistic = "standard",
    random.seed = 123
  )
  
  sam.results <- extract_sam_all_results(
    samr.obj = samr.obj,
    data = sam_data,
    intens.filter = intens.filter,
    contrast_name = consts$conts[i]
  )
  
  res_all <- rbind(res_all, sam.results)
}

res_all <- res_all[order(res_all$pvalue, na.last = TRUE), ]

if (print_lab == 'T') {
  true_organisms <- strsplit(true_organism, ';', fixed = TRUE)[[1]]
  DE_organisms <- strsplit(DE_organism, ';', fixed = TRUE)[[1]]
  
  labs <- get_labels(
    res_all,
    true_organisms,
    DE_organisms,
    true_lgfc,
    R_fold_path
  )
  
  res_all$organism <- labs$Organism
  res_all$label <- labs$DEP
  res_all$TlogFC <- labs$TlogFC
}

write.table(
  res_all,
  paste0(
    save_fold,
    dataset,
    '_SAMdelta_',
    platform,
    '_',
    inten_type,
    '_',
    imput,
    '_',
    normal,
    '.csv'
  ),
  sep = ',',
  row.names = TRUE,
  col.names = TRUE
)