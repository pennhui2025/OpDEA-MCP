"""Strict fixed-label, fixed-universe MCP view ablation.

This module implements the controlled experiment that the legacy
``single_view_mcp`` runs cannot provide.  For every
dataset x platform x DEA stratum it:

1. runs the original four-view preprocessing exactly once;
2. caches the four union-aligned matrices and the *actual* labels returned by
   ``preprocess_data`` (including the original high-missingness rule);
3. trains full MCP or a one-view MCP from that same cache; and
4. writes an unambiguous, clean ``DP_fdr`` prediction table.

因此，严格主分析中真正改变的只有模型可以看到的输入视图；Protein-ID union、
伪标签、监督掩码、样本顺序以及最终 log2FC 均保持一致。
"""

from __future__ import annotations

import hashlib
import importlib.util
import json
import math
import os
import re
import sys
import tempfile
import time
from pathlib import Path
from typing import Any, Mapping

import numpy as np
import pandas as pd


SOURCE_VIEWS = ("dlfq", "maxlfq", "top3", "top1")
IMPLEMENTATION_SCHEMA_VERSION = "fixed4label_v2_availability_aware_20260906"
METRIC_NAMES = (
    "accuracy",
    "precision",
    "recall",
    "f1",
    "mcc",
    "specificity",
    "auroc",
    "auprc",
    "pauc_0.01",
    "pauc_0.05",
    "pauc_0.10",
)


def _safe_id(value: Any) -> str:
    value = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(value)).strip("_")
    return value or "run"


def _scalar(spec: Mapping[str, Any], name: str, default: Any) -> Any:
    value = spec.get(name, default)
    if value is None:
        return default
    if isinstance(value, float) and np.isnan(value):
        return default
    if isinstance(value, str) and not value.strip():
        return default
    return value


def _as_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return False
    return str(value).strip().lower() in {"1", "true", "t", "yes", "y"}


def _split(value: Any) -> list[str]:
    if isinstance(value, (tuple, list)):
        return [str(item).strip() for item in value if str(item).strip()]
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return []
    return [part.strip() for part in re.split(r"[+,;]", str(value)) if part.strip()]


def _canonical_dea(value: Any) -> str:
    value = str(value).strip()
    return "ROTS" if value.upper() == "ROTS" else value.lower()


def _jsonable(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, Mapping):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(item) for item in value]
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def _canonical_json(value: Any) -> str:
    return json.dumps(_jsonable(value), ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_file(path: str | Path) -> str:
    path = Path(path)
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            block = handle.read(1024 * 1024)
            if not block:
                break
            digest.update(block)
    return digest.hexdigest()


def _hash_protein_labels(proteins: np.ndarray, labels: np.ndarray) -> str:
    digest = hashlib.sha256()
    for protein, label in zip(proteins.astype(str), labels.astype(np.int8)):
        digest.update(protein.encode("utf-8"))
        digest.update(b"\0")
        digest.update(np.asarray([label], dtype=np.int8).tobytes())
    return digest.hexdigest()


def _code_fingerprints(core_script: Path) -> dict[str, str]:
    """Hash every Python file that can change training/preprocessing semantics."""

    implementation = Path(__file__).resolve()
    candidates = {
        "fixed4label_implementation": implementation,
        "mcp_core": core_script,
        "mcp_regression": core_script.with_name("MCP_r1_MV_regression_DP.py"),
        "mcp_utils": core_script.with_name("MCP_r1_Utils.py"),
    }
    missing = [str(path) for path in candidates.values() if not path.is_file()]
    if missing:
        raise FileNotFoundError("Missing fixed-ablation code dependency: " + ", ".join(missing))
    return {name: sha256_file(path) for name, path in candidates.items()}


def _write_json_atomic(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(_jsonable(payload), indent=2, ensure_ascii=False), encoding="utf-8")
    os.replace(temporary, path)


def load_core(core_path: str | Path):
    """Import the accelerated MCP core without importing torch too early."""

    core_path = Path(core_path).expanduser().resolve()
    parent = str(core_path.parent)
    if parent not in sys.path:
        sys.path.insert(0, parent)
    module_name = "mcp_fixed4_core_" + hashlib.sha1(str(core_path).encode("utf-8")).hexdigest()[:10]
    spec = importlib.util.spec_from_file_location(module_name, core_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot import MCP core: {core_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    required = (
        "get_datasets_reproduce_mv",
        "preprocess_data",
        "optuna_optimize_para",
        "_fdr_de_prediction",
        "_optimal_f1_threshold",
        "fdr_2qvalue",
        "get_true_label",
    )
    missing = [name for name in required if not hasattr(module, name)]
    if missing:
        raise AttributeError(f"MCP core lacks required API(s): {missing}")
    return module


def _preparation_spec(spec: Mapping[str, Any], core_script: Path) -> dict[str, Any]:
    source_views = _split(_scalar(spec, "source_views", "+".join(SOURCE_VIEWS)))
    if tuple(view.lower() for view in source_views) != SOURCE_VIEWS:
        raise ValueError(
            "Fixed-label DIA ablation requires source_views=" + "+".join(SOURCE_VIEWS)
        )
    dea = _canonical_dea(_scalar(spec, "dea_method", "limma"))
    manifest_schema = str(
        _scalar(spec, "experiment_schema", IMPLEMENTATION_SCHEMA_VERSION)
    )
    if manifest_schema != IMPLEMENTATION_SCHEMA_VERSION:
        raise ValueError(
            f"Manifest schema {manifest_schema!r} does not match implementation "
            f"{IMPLEMENTATION_SCHEMA_VERSION!r}; rebuild the manifests"
        )
    return {
        "experiment": "fixed4label_single_view_ablation",
        "experiment_schema": IMPLEMENTATION_SCHEMA_VERSION,
        "acquisition": str(_scalar(spec, "acquisition", "DIA")).upper(),
        "platform": str(spec["platform"]),
        "data_index": int(spec["data_index"]),
        "group1": str(spec["group1"]),
        "group2": str(spec["group2"]),
        "source_views": source_views,
        "dea_method": dea,
        "log_transforms": _split(_scalar(spec, "log_transforms", "T+F+F+F")),
        "normalizations": _split(_scalar(spec, "normalizations", "blank+blank+blank+blank")),
        "imputations": _split(_scalar(spec, "imputations", "blank+blank+blank+blank")),
        "q_threshold": float(_scalar(spec, "q_threshold", 0.05)),
        "fc_ratio": float(_scalar(spec, "fc_ratio", 1.5)),
        "positive_strategy": str(_scalar(spec, "positive_strategy", "0_h")),
        "protein_group_type": str(_scalar(spec, "protein_group_type", "remove")),
        "cross_imputation": str(_scalar(spec, "cross_imputation", "none")),
        "seed": int(_scalar(spec, "seed", 2024)),
        "data_root": str(Path(str(spec["data_root"])).expanduser().resolve()),
        "core_script": str(core_script),
        "code_fingerprints": _code_fingerprints(core_script),
    }


def _validate_four_sequences(prep: Mapping[str, Any]) -> None:
    nview = len(SOURCE_VIEWS)
    for name in ("log_transforms", "normalizations", "imputations"):
        values = list(prep[name])
        if len(values) == 1:
            values *= nview
        if len(values) != nview:
            raise ValueError(f"{name} must contain one or four values; got {values}")
        prep[name][:] = values


def _source_hashes(paths: list[Path]) -> dict[str, str]:
    output: dict[str, str] = {}
    for path in paths:
        resolved = path.expanduser().resolve()
        if resolved.is_file():
            output[str(resolved)] = sha256_file(resolved)
    return output


def _stored_sources_unchanged(metadata: Mapping[str, Any]) -> bool:
    stored = metadata.get("source_file_hashes", {})
    if not isinstance(stored, Mapping) or not stored:
        return False
    for name, expected in stored.items():
        path = Path(str(name))
        if not path.is_file() or sha256_file(path) != str(expected):
            return False
    return True


def _bundle_artifact(bundle_dir: Path, metadata: Mapping[str, Any], status: str) -> dict[str, Any]:
    return {
        "status": status,
        "bundle_dir": str(bundle_dir),
        "bundle_file": str(bundle_dir / "fixed4view_training_bundle.npz"),
        "bundle_metadata_file": str(bundle_dir / "metadata.json"),
        "label_audit_file": str(bundle_dir / "fixed_label_audit.csv"),
        "truth_file": str(bundle_dir / "evaluation_truth.csv"),
        "bundle_sha256": metadata.get("bundle_sha256", ""),
        "label_fingerprint": metadata.get("label_fingerprint", ""),
        "dataset": metadata.get("dataset", ""),
        "platform": metadata.get("platform", ""),
        "dea_method": metadata.get("dea_method", ""),
        "N_union": metadata.get("N_union", np.nan),
    }


def prepare_fixed_bundle(
    spec: Mapping[str, Any],
    project_dir: str | Path,
    core: Any,
    core_script: str | Path,
    bundle_dir: str | Path,
    codes_dir: str | Path,
    rscript_path: str | Path,
    force: bool = False,
) -> dict[str, Any]:
    """Create one immutable four-view preprocessing/label cache.

    The NPZ deliberately excludes the organism truth labels.  Truth is written
    to a separate CSV and is opened only by the evaluation stage.
    """

    project_dir = Path(project_dir).expanduser().resolve()
    core_script = Path(core_script).expanduser().resolve()
    bundle_dir = Path(bundle_dir).expanduser().resolve()
    codes_dir = Path(codes_dir).expanduser().resolve()
    rscript_path = Path(rscript_path).expanduser().resolve()
    bundle_dir.mkdir(parents=True, exist_ok=True)
    bundle_file = bundle_dir / "fixed4view_training_bundle.npz"
    metadata_file = bundle_dir / "metadata.json"
    audit_file = bundle_dir / "fixed_label_audit.csv"
    truth_file = bundle_dir / "evaluation_truth.csv"

    prep = _preparation_spec(spec, core_script)
    prep["codes_dir"] = str(codes_dir)
    prep["rscript_executable"] = str(rscript_path)
    _validate_four_sequences(prep)
    prep_hash = _sha256_bytes(_canonical_json(prep).encode("utf-8"))
    force = force or _as_bool(_scalar(spec, "force", False))

    if not force and all(path.is_file() for path in (bundle_file, metadata_file, audit_file, truth_file)):
        metadata = json.loads(metadata_file.read_text(encoding="utf-8"))
        if (
            metadata.get("status") == "completed"
            and metadata.get("preparation_spec_hash") == prep_hash
            and metadata.get("bundle_sha256") == sha256_file(bundle_file)
            and metadata.get("label_audit_sha256") == sha256_file(audit_file)
            and metadata.get("truth_sha256") == sha256_file(truth_file)
            and _stored_sources_unchanged(metadata)
        ):
            return _bundle_artifact(bundle_dir, metadata, "skipped_existing")

    os.environ["MCP_DATA_ROOT"] = prep["data_root"]
    source_views = list(prep["source_views"])
    dea_methods = [prep["dea_method"]] * len(source_views)
    # Never reuse intermediate R outputs after a rebuild is requested.  The
    # legacy R wrappers do not propagate every non-zero exit code, so a fresh
    # attempt directory prevents a failed R call from silently reading stale
    # normalized/DEA files left by an earlier attempt.
    work_root = Path(
        tempfile.mkdtemp(
            prefix=f"preprocess_work_{prep_hash[:12]}_",
            dir=str(bundle_dir),
        )
    )
    save_data_root = str(work_root) + os.sep
    codes_value = str(codes_dir) + os.sep
    rscript_dir = str(rscript_path.parent) + os.sep
    flag = _safe_id(
        f"fixed4_{prep['platform']}_{prep['dea_method']}_i{prep['data_index']}"
    )

    returned = core.get_datasets_reproduce_mv(
        flag,
        prep["data_index"],
        prep["platform"],
        list(prep["normalizations"]),
        list(prep["imputations"]),
        prep["group1"],
        prep["group2"],
        prep["acquisition"],
        source_views,
        save_data_root,
        codes_value,
        dea_methods,
        list(prep["log_transforms"]),
        prep["seed"],
        prep["protein_group_type"],
        rscript_dir,
        prep["cross_imputation"],
    )
    (
        _res_ori,
        _res_intersect,
        _res_ci,
        native_views,
        _native_data,
        _views_intersection,
        _data_intersection,
        _views_ci,
        _data_ci,
        _save_folder,
        view_paths,
        res_union,
        views_union,
        _view_data_union,
    ) = returned

    logfc_threshold = math.log2(prep["fc_ratio"])
    os.environ["MCP_SKIP_TRUE_LABEL_DIAGNOSTIC"] = "1"
    (
        data,
        sample_class,
        pro_lab,
        p_score,
        q_score,
        _mms,
        full_log2fc,
        sample_names,
        sample_condition,
    ) = core.preprocess_data(
        views_union,
        prep["group2"],
        logfc_threshold,
        prep["q_threshold"],
        res_union,
        view_paths,
        prep["positive_strategy"],
    )

    proteins = views_union[0]["Protein"].astype(str).to_numpy()
    if len(np.unique(proteins)) != len(proteins):
        raise ValueError("Four-view union contains duplicate Protein IDs")
    n_union = len(proteins)
    if len(data) != len(source_views):
        raise ValueError(f"Expected four cached matrices; got {len(data)}")

    availability: dict[str, np.ndarray] = {}
    for index, view in enumerate(source_views):
        union_ids = views_union[index]["Protein"].astype(str).to_numpy()
        if not np.array_equal(proteins, union_ids):
            raise ValueError(f"Protein order differs in union-aligned view {view}")
        native_ids = native_views[index]["Protein"].astype(str).to_numpy()
        availability[view] = np.isin(proteins, native_ids)

    fixed_labels = np.asarray(pro_lab, dtype=float).reshape(-1)
    if len(fixed_labels) != n_union or not set(np.unique(fixed_labels)).issubset({-1.0, 0.0, 1.0}):
        raise ValueError("preprocess_data returned an invalid fixed pseudo-label vector")
    fixed_labels = fixed_labels.astype(np.int8)
    if set(np.unique(fixed_labels[fixed_labels != -1])) != {0, 1}:
        raise ValueError("Fixed pseudo labels must contain both supervised classes 0 and 1")
    full_log2fc = np.asarray(full_log2fc, dtype=float).reshape(-1)
    p_score = np.asarray(p_score, dtype=float).reshape(-1)
    q_score = np.asarray(q_score, dtype=float).reshape(-1)
    if not all(len(value) == n_union for value in (full_log2fc, p_score, q_score)):
        raise ValueError("Cached label/score/log2FC vectors do not match four-view union")

    arrays: dict[str, np.ndarray] = {
        "proteins": proteins.astype(str),
        "sample_class": np.asarray(sample_class, dtype=float),
        "sample_names": np.asarray(sample_names, dtype=str),
        "sample_condition": np.asarray(sample_condition, dtype=str),
        "fixed_pro_lab": fixed_labels,
        "fixed_p_score": p_score,
        "fixed_q_score": q_score,
        "fixed_full_log2fc": full_log2fc,
    }
    for index, view in enumerate(source_views):
        matrix = np.asarray(data[index], dtype=np.float32)
        if matrix.shape[0] != n_union:
            raise ValueError(f"Cached {view} matrix has {matrix.shape[0]} rows, expected {n_union}")
        arrays[f"data_{view}"] = matrix
        arrays[f"available_{view}"] = availability[view].astype(bool)

    temporary_bundle = bundle_file.with_suffix(".tmp.npz")
    np.savez_compressed(temporary_bundle, **arrays)
    os.replace(temporary_bundle, bundle_file)

    label_fingerprint = _hash_protein_labels(proteins, fixed_labels)
    audit = pd.DataFrame(
        {
            "Protein": proteins,
            "fixed_pro_lab": fixed_labels,
            "is_supervised": fixed_labels != -1,
            "fixed_p_score": p_score,
            "fixed_q_score": q_score,
            "fixed_full_log2fc": full_log2fc,
            **{f"available_{view}": availability[view] for view in source_views},
        }
    )
    audit["available_all_four"] = np.logical_and.reduce(
        [availability[view] for view in source_views]
    )
    audit.to_csv(audit_file, index=False)

    true_labels = np.asarray(
        core.get_true_label(proteins, view_paths["DE_organism"]), dtype=np.int8
    )
    if len(true_labels) != n_union or not set(np.unique(true_labels)).issubset({0, 1}):
        raise ValueError("Evaluation truth must contain one binary label for every union protein")
    truth_table = pd.DataFrame({"Protein": proteins, "True_lab": true_labels})
    truth_table.to_csv(truth_file, index=False)

    candidate_sources = [
        Path(str(view_paths[view])) for view in source_views
    ] + [
        Path(str(view_paths["design_file_path"])),
        Path(str(view_paths["dataset_info_path"])),
        Path(str(view_paths["all_candidate"])),
        core_script,
    ]
    for pattern in (
        "normalization_MVAE_R1.R",
        "limma_DE_rep.R",
        "ROTS_DE_rep.R",
        "Hurdle_rep.R",
        "Hurdle.R",
        "*hurdle*.R",
        "*Hurdle*.R",
    ):
        candidate_sources.extend(codes_dir.glob(pattern))
    candidate_sources.extend(
        [
            codes_dir / "ups1-ups2-sequences.fasta",
            core_script.parent / "ups1-ups2-sequences.fasta",
            core_script.parent / "codes" / "ups1-ups2-sequences.fasta",
        ]
    )
    source_hashes = _source_hashes(candidate_sources)

    metadata = {
        **prep,
        "status": "completed",
        "dataset": str(res_union[4]["dataset"]),
        "preparation_spec_hash": prep_hash,
        "bundle_sha256": sha256_file(bundle_file),
        "label_audit_sha256": sha256_file(audit_file),
        "truth_sha256": sha256_file(truth_file),
        "label_fingerprint": label_fingerprint,
        "truth_fingerprint": _hash_protein_labels(proteins, true_labels),
        "N_union": n_union,
        "N_labeled_positive": int(np.sum(fixed_labels == 1)),
        "N_labeled_negative": int(np.sum(fixed_labels == 0)),
        "N_unlabeled": int(np.sum(fixed_labels == -1)),
        "N_common_all_four": int(audit["available_all_four"].sum()),
        "available_supervised_counts": {
            view: {
                "positive": int(np.sum((fixed_labels == 1) & availability[view])),
                "negative": int(np.sum((fixed_labels == 0) & availability[view])),
                "unlabeled": int(np.sum((fixed_labels == -1) & availability[view])),
            }
            for view in source_views
        },
        "source_file_hashes": source_hashes,
        "bundle_file": str(bundle_file),
        "label_audit_file": str(audit_file),
        "truth_file": str(truth_file),
        "created_at_unix": time.time(),
    }
    _write_json_atomic(metadata_file, metadata)

    # The training NPZ never contains truth.  Drop the local vector before
    # returning the bundle artifact; model fitting later opens only the NPZ and
    # reads the separately hashed truth CSV after calls have been finalized.
    del true_labels
    return _bundle_artifact(bundle_dir, metadata, "completed")


def _model_spec(
    spec: Mapping[str, Any], bundle_metadata: Mapping[str, Any], core_script: Path
) -> dict[str, Any]:
    variant = str(_scalar(spec, "variant", "single_view_mcp"))
    selected = str(_scalar(spec, "model_input_views", "all4")).lower()
    if variant == "full_mcp":
        if selected not in {"all4", "+".join(SOURCE_VIEWS)}:
            raise ValueError("full_mcp fixed control requires model_input_views=all4")
        selected = "all4"
    elif variant == "single_view_mcp":
        if selected not in SOURCE_VIEWS:
            raise ValueError(f"single_view_mcp requires one of {SOURCE_VIEWS}; got {selected!r}")
    else:
        raise ValueError("Fixed4label experiment supports only full_mcp and single_view_mcp")
    label_mode = str(_scalar(spec, "label_mode", "strict_shared_mask"))
    if label_mode not in {"strict_shared_mask", "available_only_shared_labels"}:
        raise ValueError(f"Unsupported label_mode={label_mode!r}")
    if variant == "full_mcp" and label_mode != "strict_shared_mask":
        raise ValueError("The full MCP reference must use label_mode=strict_shared_mask")
    return {
        "experiment": "fixed4label_single_view_ablation",
        "experiment_schema": IMPLEMENTATION_SCHEMA_VERSION,
        "run_id": str(spec["run_id"]),
        "dataset": bundle_metadata["dataset"],
        "platform": bundle_metadata["platform"],
        "data_index": int(bundle_metadata["data_index"]),
        "dea_method": bundle_metadata["dea_method"],
        "variant": variant,
        "model_input_views": selected,
        "label_mode": label_mode,
        "availability_policy": str(
            _scalar(spec, "availability_policy", "selected_view_noncall")
        ),
        "seed": int(_scalar(spec, "seed", 2024)),
        "runtime_seed_control": _as_bool(_scalar(spec, "runtime_seed_control", True)),
        "num_trials": int(_scalar(spec, "num_trials", 30)),
        "q_threshold": float(_scalar(spec, "q_threshold", 0.05)),
        "fc_ratio": float(_scalar(spec, "fc_ratio", 1.5)),
        "score_type": str(_scalar(spec, "score_type", "q")),
        "bundle_sha256": bundle_metadata["bundle_sha256"],
        "label_fingerprint": bundle_metadata["label_fingerprint"],
        # Evaluation truth never enters fitting, but it is part of the saved
        # prediction/metric artifact identity.  If truth changes while the
        # training bundle stays identical, resume must recompute evaluation.
        "truth_sha256": bundle_metadata["truth_sha256"],
        "truth_fingerprint": bundle_metadata["truth_fingerprint"],
        "code_fingerprints": _code_fingerprints(core_script),
        "test_type": "DP_fdr",
    }


def _metric_row(
    y_true: np.ndarray,
    score: np.ndarray,
    called: np.ndarray,
    selected_available: np.ndarray,
) -> dict[str, Any]:
    from sklearn.metrics import (
        accuracy_score,
        average_precision_score,
        confusion_matrix,
        f1_score,
        matthews_corrcoef,
        precision_score,
        recall_score,
        roc_auc_score,
    )

    y_true = np.asarray(y_true, dtype=int)
    score = np.asarray(score, dtype=float)
    called = np.asarray(called, dtype=bool)
    selected_available = np.asarray(selected_available, dtype=bool)
    n = len(y_true)
    result: dict[str, Any] = {
        "N_evaluated": n,
        "N_true_DEP": int(np.sum(y_true == 1)),
        "N_true_nonDEP": int(np.sum(y_true == 0)),
        "N_selected_view_available": int(np.sum(selected_available)),
    }
    if n == 0:
        result.update({name: np.nan for name in METRIC_NAMES})
        result.update({"tn": 0, "fp": 0, "fn": 0, "tp": 0})
        return result
    tn, fp, fn, tp = confusion_matrix(y_true, called.astype(int), labels=[0, 1]).ravel()
    specificity = float(tn / (tn + fp)) if tn + fp else np.nan
    result.update(
        {
            "accuracy": accuracy_score(y_true, called),
            "precision": precision_score(y_true, called, zero_division=0),
            "recall": recall_score(y_true, called, zero_division=0),
            "f1": f1_score(y_true, called, zero_division=0),
            "mcc": matthews_corrcoef(y_true, called),
            "specificity": specificity,
            "tn": int(tn),
            "fp": int(fp),
            "fn": int(fn),
            "tp": int(tp),
        }
    )
    if len(np.unique(y_true)) < 2:
        for name in ("auroc", "auprc", "pauc_0.01", "pauc_0.05", "pauc_0.10"):
            result[name] = np.nan
    else:
        result.update(
            {
                "auroc": roc_auc_score(y_true, score),
                "auprc": average_precision_score(y_true, score),
                "pauc_0.01": roc_auc_score(y_true, score, max_fpr=0.01),
                "pauc_0.05": roc_auc_score(y_true, score, max_fpr=0.05),
                "pauc_0.10": roc_auc_score(y_true, score, max_fpr=0.10),
            }
        )
    return result


def _evaluate_subsets(
    base: Mapping[str, Any],
    true_labels: np.ndarray,
    score: np.ndarray,
    called: np.ndarray,
    fixed_labels: np.ndarray,
    availability: Mapping[str, np.ndarray],
    selected_available: np.ndarray,
) -> pd.DataFrame:
    common = np.logical_and.reduce([availability[view] for view in SOURCE_VIEWS])
    subsets = {
        "all_four_view_union": np.ones(len(true_labels), dtype=bool),
        # These proteins did not enter the classification loss, but they still
        # entered the autoencoder reconstruction: transductive, not held-out.
        "pseudo_label_excluded_transductive": fixed_labels == -1,
        "common_four_view_intersection": common,
        "selected_view_available": selected_available,
    }
    rows: list[dict[str, Any]] = []
    for subset_name, keep in subsets.items():
        metrics = _metric_row(
            true_labels[keep], score[keep], called[keep], selected_available[keep]
        )
        rows.append({**base, "evaluation_subset": subset_name, **metrics})
    return pd.DataFrame(rows)


def _completed_run_artifact(run_dir: Path, metadata: Mapping[str, Any], status: str) -> dict[str, Any]:
    return {
        "run_id": metadata["run_id"],
        "status": status,
        "prediction_file": str(run_dir / "fixed4label_DP_fdr_predictions.csv"),
        "metrics_file": str(run_dir / "fixed4label_metrics.csv"),
        "run_metadata_file": str(run_dir / "metadata.json"),
        "latent_file": str(run_dir / "fixed4label_latent.npz"),
        "label_fingerprint": metadata["label_fingerprint"],
        "training_label_fingerprint": metadata.get("training_label_fingerprint", ""),
        "dataset": metadata["dataset"],
        "data_index": metadata["data_index"],
        "platform": metadata["platform"],
        "dea_method": metadata["dea_method"],
        "variant": metadata["variant"],
        "model_input_views": metadata["model_input_views"],
        "label_mode": metadata["label_mode"],
        "N_union": metadata["N_union"],
        "runtime_seconds": metadata.get("runtime_seconds", np.nan),
        "parameter_count": metadata.get("parameter_count", np.nan),
        "test_type": "DP_fdr",
    }


def run_fixed_ablation_model(
    spec: Mapping[str, Any],
    core: Any,
    core_script: str | Path,
    bundle_dir: str | Path,
    run_dir: str | Path,
    force: bool = False,
) -> dict[str, Any]:
    """Train one full/fixed-single-view model and write clean DP_fdr outputs."""

    core_script = Path(core_script).expanduser().resolve()
    bundle_dir = Path(bundle_dir).expanduser().resolve()
    run_dir = Path(run_dir).expanduser().resolve()
    run_dir.mkdir(parents=True, exist_ok=True)
    bundle_file = bundle_dir / "fixed4view_training_bundle.npz"
    bundle_metadata_file = bundle_dir / "metadata.json"
    truth_file = bundle_dir / "evaluation_truth.csv"
    if not all(path.is_file() for path in (bundle_file, bundle_metadata_file, truth_file)):
        raise FileNotFoundError(f"Incomplete fixed bundle: {bundle_dir}")
    bundle_metadata = json.loads(bundle_metadata_file.read_text(encoding="utf-8"))
    if bundle_metadata.get("bundle_sha256") != sha256_file(bundle_file):
        raise ValueError(f"Bundle hash mismatch: {bundle_file}")
    audit_file = bundle_dir / "fixed_label_audit.csv"
    if (
        not audit_file.is_file()
        or bundle_metadata.get("label_audit_sha256") != sha256_file(audit_file)
    ):
        raise ValueError(f"Fixed-label audit hash mismatch: {audit_file}")
    if bundle_metadata.get("truth_sha256") != sha256_file(truth_file):
        raise ValueError(f"Evaluation-truth hash mismatch: {truth_file}")

    model_spec = _model_spec(spec, bundle_metadata, core_script)
    model_spec_hash = _sha256_bytes(_canonical_json(model_spec).encode("utf-8"))
    metadata_file = run_dir / "metadata.json"
    prediction_file = run_dir / "fixed4label_DP_fdr_predictions.csv"
    metrics_file = run_dir / "fixed4label_metrics.csv"
    latent_file = run_dir / "fixed4label_latent.npz"
    force = force or _as_bool(_scalar(spec, "force", False))
    if not force and all(path.is_file() for path in (metadata_file, prediction_file, metrics_file, latent_file)):
        old = json.loads(metadata_file.read_text(encoding="utf-8"))
        if (
            old.get("status") == "completed"
            and old.get("model_spec_hash") == model_spec_hash
            and old.get("bundle_sha256") == bundle_metadata["bundle_sha256"]
            and old.get("truth_sha256") == bundle_metadata["truth_sha256"]
            and old.get("truth_fingerprint") == bundle_metadata["truth_fingerprint"]
            and old.get("prediction_sha256") == sha256_file(prediction_file)
            and old.get("metrics_sha256") == sha256_file(metrics_file)
            and old.get("latent_sha256") == sha256_file(latent_file)
        ):
            return _completed_run_artifact(run_dir, old, "skipped_existing")

    with np.load(bundle_file, allow_pickle=False) as loaded:
        proteins = loaded["proteins"].astype(str)
        sample_class = np.asarray(loaded["sample_class"], dtype=float)
        fixed_labels = np.asarray(loaded["fixed_pro_lab"], dtype=np.int8).reshape(-1)
        p_score = np.asarray(loaded["fixed_p_score"], dtype=float).reshape(-1)
        q_score = np.asarray(loaded["fixed_q_score"], dtype=float).reshape(-1)
        full_log2fc = np.asarray(loaded["fixed_full_log2fc"], dtype=float).reshape(-1)
        sample_names = loaded["sample_names"].astype(str)
        availability = {
            view: np.asarray(loaded[f"available_{view}"], dtype=bool).reshape(-1)
            for view in SOURCE_VIEWS
        }
        cached_data = {
            view: np.asarray(loaded[f"data_{view}"], dtype=np.float32)
            for view in SOURCE_VIEWS
        }

    if _hash_protein_labels(proteins, fixed_labels) != bundle_metadata["label_fingerprint"]:
        raise ValueError("Protein/label fingerprint differs from bundle metadata")
    selected = model_spec["model_input_views"]
    if selected == "all4":
        model_views = list(SOURCE_VIEWS)
        selected_available = np.logical_or.reduce([availability[view] for view in SOURCE_VIEWS])
    else:
        model_views = [selected]
        selected_available = availability[selected].copy()
    model_data = [cached_data[view].copy() for view in model_views]

    training_labels = fixed_labels.copy()
    if model_spec["label_mode"] == "available_only_shared_labels":
        training_labels[~selected_available] = -1
    supervised = training_labels != -1
    if set(np.unique(training_labels[supervised])) != {0, 1}:
        raise ValueError("Training mask must retain both pseudo-label classes")
    calibration_mask = supervised & selected_available
    available_classes = set(np.unique(training_labels[calibration_mask]))
    if available_classes != {0, 1}:
        raise ValueError(
            "Selected-view-available supervised proteins must contain both classes "
            f"before training; run={model_spec['run_id']}, classes={sorted(available_classes)}"
        )
    training_pro_lab = training_labels.astype(float)[:, None]
    training_label_fingerprint = _hash_protein_labels(proteins, training_labels)

    if model_spec["runtime_seed_control"]:
        os.environ["MCP_RUNTIME_SEED"] = str(model_spec["seed"])
    else:
        os.environ.pop("MCP_RUNTIME_SEED", None)
    os.environ["MCP_MODEL_VARIANT"] = model_spec["variant"]
    os.environ.setdefault("MCP_VERBOSE_TRAIN", "0")
    os.environ.setdefault("MCP_LEGACY_AUGMENTATION", "0")
    os.environ.setdefault("MCP_USE_LEGACY_FDR", "0")
    core.seed_torch(core.runtime_seed(1029))
    device = core.torch.device("cuda" if core.torch.cuda.is_available() else "cpu")
    if core.torch.cuda.is_available():
        core.torch.cuda.reset_peak_memory_stats(device)

    predictions_across_trials = {"aucs": [], "probs": [], "labs": []}
    best_parameter_log = run_dir / "best_param_fixed4label.txt"
    started = time.time()
    (
        model,
        _loss,
        _pro_loss,
        _reconstruction,
        latent,
        pro_pred,
        _feature_importances,
        _view_contributions,
        _cross_matrices,
        _head_importance,
    ) = core.optuna_optimize_para(
        model_data,
        sample_class,
        training_pro_lab,
        p_score,
        q_score,
        device,
        model_spec["num_trials"],
        model_spec["score_type"],
        predictions_across_trials,
        str(best_parameter_log),
    )
    training_seconds = time.time() - started

    raw_probability = 1.0 - pro_pred.detach().cpu().numpy()[:, 0]
    raw_probability = np.asarray(raw_probability, dtype=float)
    if not np.all(np.isfinite(raw_probability)):
        raise FloatingPointError(
            "Model produced NaN/Inf probabilities; aborting instead of silently "
            "converting failed predictions to non-DEP"
        )
    latent_array = latent.detach().cpu().numpy().astype(np.float32)
    if not np.all(np.isfinite(latent_array)):
        raise FloatingPointError("Model produced NaN/Inf latent values")
    # Unavailable zero-feature rows must not influence the posterior-FDR set of
    # proteins that the selected method actually quantified.  Run DP_fdr only
    # on available rows, then map its result back to the fixed four-view union.
    posterior_fdr_selected = np.zeros(len(proteins), dtype=bool)
    posterior_fdr_selected[selected_available] = np.asarray(
        core._fdr_de_prediction(
            pd.Series(raw_probability[selected_available]),
            fdr=model_spec["q_threshold"],
        ),
        dtype=bool,
    )
    corrected_probability = np.zeros(len(proteins), dtype=float)
    corrected_available = raw_probability[selected_available].copy()
    selected_within_available = posterior_fdr_selected[selected_available]
    corrected_available[(~selected_within_available) & (corrected_available > 0.5)] = 0.499
    corrected_probability[selected_available] = corrected_available
    fixed_threshold = float(
        core._optimal_f1_threshold(
            training_labels[calibration_mask],
            corrected_probability[calibration_mask],
            default=0.5,
        )
    )

    # Coverage-aware union policy used by the manuscript benchmarking: a method
    # cannot call a protein that its selected input view never quantified.
    if model_spec["availability_policy"] != "selected_view_noncall":
        raise ValueError("Only availability_policy=selected_view_noncall is allowed")
    analysis_score = corrected_probability.copy()
    fc_threshold = math.log2(model_spec["fc_ratio"])
    called = (
        selected_available
        & (analysis_score >= fixed_threshold)
        & (np.abs(full_log2fc) >= fc_threshold)
    )

    # Truth is intentionally loaded only *after* fitting, threshold selection,
    # and final calls have been completed.  It cannot influence model training.
    truth = pd.read_csv(truth_file, dtype={"Protein": str})
    expected_truth = pd.DataFrame({"Protein": proteins}).merge(
        truth[["Protein", "True_lab"]], on="Protein", how="left", validate="one_to_one"
    )
    if expected_truth["True_lab"].isna().any():
        raise ValueError("Truth file does not cover the complete fixed union")
    true_labels = expected_truth["True_lab"].astype(int).to_numpy()

    td_labels = np.full(len(proteins), -1, dtype=int)
    td_labels[(np.abs(full_log2fc) >= fc_threshold) & (analysis_score > 0.5)] = 1
    qvalues = np.asarray(core.fdr(np.asarray(core.fdr_2qvalue(analysis_score, td_labels)))[1])

    prediction = pd.DataFrame(
        {
            "Protein": proteins,
            "True_lab": true_labels,
            "raw_probability": raw_probability,
            "posterior_fdr_selected": posterior_fdr_selected,
            "DP_fdr_probability_before_availability": corrected_probability,
            "DP_fdr_available_probability": analysis_score,
            "DP_fdr_probability": analysis_score,
            "DP_fdr_qvalue_audit": qvalues,
            "DP_fdr_threshold": fixed_threshold,
            "shared_full_log2fc": full_log2fc,
            "selected_view_available": selected_available,
            "called_DP_fdr": called,
            "fixed_pro_lab": fixed_labels,
            "is_fixed_pseudo_supervised": fixed_labels != -1,
            "training_pro_lab": training_labels,
            "used_for_classification_training": supervised,
            **{f"available_{view}": availability[view] for view in SOURCE_VIEWS},
        }
    )
    prediction.to_csv(prediction_file, index=False)
    np.savez_compressed(
        latent_file,
        proteins=proteins.astype(str),
        latent=latent_array,
    )

    method = "full_mcp" if selected == "all4" else f"single_view_mcp_{selected}"
    metric_base = {
        "run_id": model_spec["run_id"],
        "dataset": model_spec["dataset"],
        "data_index": model_spec["data_index"],
        "acquisition": "DIA",
        "platform": model_spec["platform"],
        "dea_method": model_spec["dea_method"],
        "method": method,
        "variant": model_spec["variant"],
        "model_input_views": selected,
        "label_mode": model_spec["label_mode"],
        "test_type": "DP_fdr",
        "availability_policy": model_spec["availability_policy"],
        "seed": model_spec["seed"],
        "q_threshold": model_spec["q_threshold"],
        "fc_ratio": model_spec["fc_ratio"],
        "DP_fdr_threshold": fixed_threshold,
        "label_fingerprint": model_spec["label_fingerprint"],
        "training_label_fingerprint": training_label_fingerprint,
    }
    metrics = _evaluate_subsets(
        metric_base,
        true_labels,
        analysis_score,
        called,
        fixed_labels,
        availability,
        selected_available,
    )
    metrics.to_csv(metrics_file, index=False)

    peak_memory_mb = (
        float(core.torch.cuda.max_memory_allocated(device)) / (1024.0**2)
        if core.torch.cuda.is_available()
        else 0.0
    )
    metadata = {
        **model_spec,
        "status": "completed",
        "model_spec_hash": model_spec_hash,
        "training_label_fingerprint": training_label_fingerprint,
        "model_views": model_views,
        "N_union": len(proteins),
        "N_training_positive": int(np.sum(training_labels == 1)),
        "N_training_negative": int(np.sum(training_labels == 0)),
        "N_training_unlabeled": int(np.sum(training_labels == -1)),
        "N_selected_view_available": int(np.sum(selected_available)),
        "DP_fdr_threshold": fixed_threshold,
        "training_seconds": training_seconds,
        "runtime_seconds": training_seconds,
        "peak_memory_mb": peak_memory_mb,
        "parameter_count": int(sum(parameter.numel() for parameter in model.parameters())),
        "prediction_file": str(prediction_file),
        "metrics_file": str(metrics_file),
        "latent_file": str(latent_file),
        "prediction_sha256": sha256_file(prediction_file),
        "metrics_sha256": sha256_file(metrics_file),
        "latent_sha256": sha256_file(latent_file),
        "completed_at_unix": time.time(),
    }
    _write_json_atomic(metadata_file, metadata)
    return _completed_run_artifact(run_dir, metadata, "completed")


__all__ = [
    "SOURCE_VIEWS",
    "load_core",
    "prepare_fixed_bundle",
    "run_fixed_ablation_model",
    "sha256_file",
]
