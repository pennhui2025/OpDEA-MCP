"""Audit and re-extract the canonical MCP row (DP_fdr) from completed runs.

This script is intentionally read-only with respect to the original run trees.
It locates every completed ``core_run_ledger.csv``, resolves the corresponding
``*__metrics_all_s.csv`` file in the downloaded local copy, and exports both
``DP_fdr`` (canonical MCP) and ``DP_direct`` (diagnostic operating rule).

中文说明
--------
MCP 的论文主结果对应 metrics 文件中的 ``DP_fdr`` 行，而不是
``DP_direct``。本脚本不会重新训练模型，也不会覆盖任何原始结果；它只从
已经完成的 metrics 文件中重新提取正确的行，并量化两种规则的差异。
"""

from __future__ import annotations

import argparse
import csv
import json
import os
from collections import defaultdict
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd


METRIC_ALIASES = {
    "accuracy": "Acc",
    "precision": "Prec",
    "recall": "Rec",
    "f1": "F1",
    "mcc": "Mcc",
    "pauc_0.01": "pauc001",
    "pauc_0.05": "pauc005",
    "pauc_0.10": "pauc01",
}


def collection_roots(project: Path) -> dict[str, Path]:
    nested = project / "revision_results" / "revision_results" / "revision_results"
    return {
        "task1_2_core": nested / "task1_2_shards",
        "view_combinations": nested / "view_combination_incremental_shards",
        "task3_pseudo_label": nested / "remaining_tasks_shards",
        "task5_model_complexity": nested / "remaining_tasks_shards",
        "multiseed_stability": project / "multiseed_stability_shards" / "multiseed_stability_shards",
    }


def keep_ledger(collection: str, path: Path) -> bool:
    text = str(path).lower()
    if collection == "task3_pseudo_label":
        return "task3_pseudo_label" in text
    if collection == "task5_model_complexity":
        return "task5_deep_ablation_core" in text
    return True


def windows_long_path(path: Path) -> str:
    """Return an extended-length path so downloaded Linux trees work on Windows."""

    value = str(path.resolve())
    if os.name == "nt" and not value.startswith("\\\\?\\"):
        return "\\\\?\\" + value
    return value


def local_metrics_for_ledger(ledger_path: Path) -> dict[str, list[Path]]:
    """Index metrics files by exact run-id directory below one ledger."""

    index: dict[str, list[Path]] = defaultdict(list)
    base = ledger_path.parent.resolve()
    long_base = windows_long_path(base)
    prefix = "\\\\?\\" if long_base.startswith("\\\\?\\") else ""
    for directory, _, files in os.walk(long_base):
        for filename in files:
            if not filename.endswith("__metrics_all_s.csv"):
                continue
            raw_path = os.path.join(directory, filename)
            normal = raw_path[len(prefix):] if prefix else raw_path
            path = Path(normal)
            relative_parts = path.relative_to(base).parts
        # The run_id is always a directory above the temporary output folder.
            for part in relative_parts[:-1]:
                index[part].append(path)
    return index


def select_unique_metrics(
    run_id: str,
    dataset: str,
    recorded_metrics_file: str,
    index: dict[str, list[Path]],
) -> tuple[Path | None, str]:
    candidates = list(dict.fromkeys(index.get(run_id, [])))
    # Resume runs can leave more than one temp directory below the same run_id.
    # The ledger's Linux path records the exact run-id-relative tail that won.
    server_parts = [part for part in str(recorded_metrics_file).replace("\\", "/").split("/") if part]
    if run_id in server_parts:
        tail = tuple(server_parts[server_parts.index(run_id) + 1 :])
        tail_matches = [p for p in candidates if tuple(p.parts[-len(tail):]) == tail] if tail else []
        if len(tail_matches) == 1:
            candidates = tail_matches
    if len(candidates) > 1:
        dataset_matches = [p for p in candidates if p.name == f"{dataset}__metrics_all_s.csv"]
        if len(dataset_matches) == 1:
            candidates = dataset_matches
    if len(candidates) == 1:
        return candidates[0], "ok"
    if not candidates:
        return None, "metrics file not found below ledger directory"
    return None, "multiple candidate metrics files: " + " | ".join(str(p) for p in candidates[:5])


def dea_method(row: pd.Series) -> str:
    value = str(row.get("dea_methods", ""))
    parts = [x for x in value.split("+") if x]
    return parts[0] if parts and len(set(parts)) == 1 else value


def extract_one_row(
    collection: str,
    ledger_path: Path,
    ledger_row: pd.Series,
    metrics_path: Path,
) -> tuple[list[dict[str, object]], dict[str, object]]:
    frame = pd.read_csv(windows_long_path(metrics_path))
    if "test_type" not in frame.columns:
        raise ValueError("missing test_type column")
    selected = frame[frame["test_type"].astype(str).isin(["DP_fdr", "DP_direct", "DP_05"])]
    found = set(selected["test_type"].astype(str))
    if "DP_fdr" not in found:
        raise ValueError("DP_fdr row is absent")

    common = {
        "collection": collection,
        "run_id": str(ledger_row.get("run_id", "")),
        "dataset": str(ledger_row.get("dataset", "")),
        "acquisition": str(ledger_row.get("acquisition", "")),
        "platform": str(ledger_row.get("platform", "")),
        "dea_method": dea_method(ledger_row),
        "variant": str(ledger_row.get("variant", "")),
        "strategy": str(ledger_row.get("strategy", "")),
        "view_set": str(ledger_row.get("views", ledger_row.get("view_set", ""))),
        "seed": ledger_row.get("seed", np.nan),
        "runtime_seconds": ledger_row.get("runtime_seconds", np.nan),
        "training_seconds": ledger_row.get("training_seconds", np.nan),
        "parameter_count": ledger_row.get("parameter_count", np.nan),
        "ledger_file": str(ledger_path),
        "metrics_file": str(metrics_path),
    }
    rows: list[dict[str, object]] = []
    for _, metric_row in selected.iterrows():
        test_type = str(metric_row["test_type"])
        for metric, source_column in METRIC_ALIASES.items():
            if source_column in frame.columns:
                rows.append(
                    {
                        **common,
                        "test_type": test_type,
                        "metric": metric,
                        "value": pd.to_numeric(metric_row[source_column], errors="coerce"),
                    }
                )
    audit = {
        "collection": collection,
        "run_id": common["run_id"],
        "dataset": common["dataset"],
        "ledger_file": str(ledger_path),
        "metrics_file": str(metrics_path),
        "status": "ok",
        "available_test_types": "+".join(sorted(found)),
        "message": "",
    }
    return rows, audit


def extract_collection(collection: str, root: Path) -> tuple[list[dict[str, object]], list[dict[str, object]]]:
    rows: list[dict[str, object]] = []
    audit: list[dict[str, object]] = []
    if not root.exists():
        return rows, [{"collection": collection, "status": "missing_root", "message": str(root)}]
    ledgers = [p for p in root.rglob("core_run_ledger.csv") if keep_ledger(collection, p)]
    for ledger_path in sorted(ledgers):
        ledger = pd.read_csv(ledger_path)
        index = local_metrics_for_ledger(ledger_path)
        for _, ledger_row in ledger.iterrows():
            run_id = str(ledger_row.get("run_id", ""))
            dataset = str(ledger_row.get("dataset", ""))
            metrics_path, message = select_unique_metrics(
                run_id,
                dataset,
                str(ledger_row.get("metrics_file", "")),
                index,
            )
            if metrics_path is None:
                audit.append(
                    {
                        "collection": collection,
                        "run_id": run_id,
                        "dataset": dataset,
                        "ledger_file": str(ledger_path),
                        "metrics_file": "",
                        "status": "error",
                        "available_test_types": "",
                        "message": message,
                    }
                )
                continue
            try:
                extracted, record = extract_one_row(collection, ledger_path, ledger_row, metrics_path)
                rows.extend(extracted)
                audit.append(record)
            except Exception as exc:  # keep a complete, inspectable audit ledger
                # Statistical single-view and rank/p-value aggregation runs do
                # not instantiate the MCP model and therefore cannot have a
                # DP_fdr row.  Record these as intentionally not applicable,
                # rather than as failed MCP extractions.
                variant = str(ledger_row.get("variant", ""))
                not_applicable = (
                    isinstance(exc, ValueError)
                    and "DP_fdr row is absent" in str(exc)
                    and variant in {"single_view_statistical", "rank_or_pvalue_fusion"}
                )
                audit.append(
                    {
                        "collection": collection,
                        "run_id": run_id,
                        "dataset": dataset,
                        "ledger_file": str(ledger_path),
                        "metrics_file": str(metrics_path),
                        "status": "not_applicable" if not_applicable else "error",
                        "available_test_types": "",
                        "message": repr(exc),
                    }
                )
    return rows, audit


def comparison_summary(long: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    key = [
        "collection", "run_id", "dataset", "platform", "dea_method", "variant",
        "strategy", "view_set", "seed", "metric",
    ]
    pivot = long.pivot_table(index=key, columns="test_type", values="value", aggfunc="first").reset_index()
    for column in ["DP_fdr", "DP_direct", "DP_05"]:
        if column not in pivot:
            pivot[column] = np.nan
    pivot["DP_fdr_minus_DP_direct"] = pivot["DP_fdr"] - pivot["DP_direct"]
    pivot["DP_fdr_minus_DP_05"] = pivot["DP_fdr"] - pivot["DP_05"]
    summary = (
        pivot.groupby(["collection", "metric"], as_index=False)
        .agg(
            n_runs=("run_id", "size"),
            n_fdr_direct_different=(
                "DP_fdr_minus_DP_direct",
                lambda x: int(np.sum(np.abs(pd.to_numeric(x, errors="coerce")) > 1e-12)),
            ),
            mean_fdr_minus_direct=("DP_fdr_minus_DP_direct", "mean"),
            max_abs_fdr_minus_direct=(
                "DP_fdr_minus_DP_direct",
                lambda x: float(np.nanmax(np.abs(pd.to_numeric(x, errors="coerce")))) if len(x) else np.nan,
            ),
            mean_fdr_minus_dp05=("DP_fdr_minus_DP_05", "mean"),
        )
    )
    return pivot, summary


def main() -> None:
    parser = argparse.ArgumentParser()
    project_default = Path(__file__).resolve().parent
    parser.add_argument("--project-dir", type=Path, default=project_default)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=project_default / "revision_results" / "dp_fdr_correction",
    )
    args = parser.parse_args()
    project = args.project_dir.expanduser().resolve()
    output = args.output_dir.expanduser().resolve()
    output.mkdir(parents=True, exist_ok=True)

    all_rows: list[dict[str, object]] = []
    all_audit: list[dict[str, object]] = []
    for name, root in collection_roots(project).items():
        rows, audit = extract_collection(name, root)
        all_rows.extend(rows)
        all_audit.extend(audit)

    long = pd.DataFrame(all_rows)
    audit = pd.DataFrame(all_audit)
    if long.empty:
        raise RuntimeError("No DP_fdr metrics were extracted; inspect the configured result roots")
    pivot, summary = comparison_summary(long)

    long.to_csv(output / "mcp_metrics_by_result_row_long.csv", index=False, quoting=csv.QUOTE_MINIMAL)
    long[long["test_type"].eq("DP_fdr")].to_csv(
        output / "canonical_mcp_dp_fdr_metrics_long.csv", index=False
    )
    pivot.to_csv(output / "dp_fdr_vs_alternative_rows_run_level.csv", index=False)
    summary.to_csv(output / "dp_fdr_vs_alternative_rows_summary.csv", index=False)
    audit.to_csv(output / "dp_fdr_extraction_audit.csv", index=False)

    payload = {
        "canonical_mcp_row": "DP_fdr",
        "diagnostic_rows": ["DP_direct", "DP_05"],
        "n_unique_runs": int(long[["collection", "run_id"]].drop_duplicates().shape[0]),
        "n_successful_audit_rows": int(audit["status"].eq("ok").sum()),
        "n_not_applicable_audit_rows": int(audit["status"].eq("not_applicable").sum()),
        "n_error_audit_rows": int(audit["status"].eq("error").sum()),
        "collections": {
            key: int(value)
            for key, value in long[long["test_type"].eq("DP_fdr")]
            .groupby("collection")["run_id"].nunique().items()
        },
    }
    (output / "dp_fdr_audit_summary.json").write_text(
        json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(payload, indent=2, ensure_ascii=False))
    print("\nDP_fdr versus DP_direct summary:")
    print(summary.to_string(index=False))


if __name__ == "__main__":
    main()
