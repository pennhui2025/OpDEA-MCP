"""IFN-gamma protein/pathway validation without list-size or nominal-p bias.

补做任务 7：IFN-γ数据库支持蛋白、等规模列表、ORA-FDR和pre-ranked GSEA分析。

Required ranking manifest columns
---------------------------------
method, result_file, protein_column, score_column

Optional columns
----------------
called_column, qvalue_column, log2fc_column, dataset, acquisition, platform

The supported-protein file must contain one protein per row.  Pathways use GMT
format: pathway<TAB>description<TAB>gene1<TAB>gene2...

Terminology note: STRING/GO-derived proteins are reported as
"database-supported", not "biologically validated".
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import hypergeom

from MCP_r1_mcp_experiment_runner import add_core_runner_arguments, run_core_from_args

from MCP_r1_supplementary_analysis_utils import bh_adjust, ensure_output_dir, read_table, resolve_path, seed_everything


REQUIRED = ["method", "result_file", "protein_column", "score_column"]


def parse_gmt(path: Path) -> dict[str, set[str]]:
    pathways: dict[str, set[str]] = {}
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            fields = line.rstrip("\n").split("\t")
            if len(fields) >= 3:
                pathways[fields[0]] = {gene for gene in fields[2:] if gene}
    if not pathways:
        raise ValueError(f"No pathway was parsed from {path}")
    return pathways


def load_supported(path: Path, protein_column: str | None) -> set[str]:
    frame = read_table(path)
    column = protein_column or frame.columns[0]
    if column not in frame.columns:
        raise ValueError(f"Supported-protein table has no column '{column}'")
    return set(frame[column].dropna().astype(str))


def load_method_result(
    row: pd.Series,
    manifest_path: Path,
    q_threshold: float,
    fc_ratio: float,
    fallback_top_n: int | None,
) -> pd.DataFrame:
    path = resolve_path(manifest_path, row["result_file"])
    frame = read_table(path)
    required_columns = [row["protein_column"], row["score_column"]]
    missing = [column for column in required_columns if column not in frame.columns]
    if missing:
        raise ValueError(f"{path} is missing columns {missing}")
    result = pd.DataFrame(
        {
            "protein": frame[row["protein_column"]].astype(str),
            "score": pd.to_numeric(frame[row["score_column"]], errors="coerce"),
        }
    ).dropna().sort_values("score", ascending=False).drop_duplicates("protein")

    called_column = row.get("called_column", "")
    q_column = row.get("qvalue_column", "")
    fc_column = row.get("log2fc_column", "")
    if isinstance(called_column, str) and called_column and called_column in frame.columns:
        calls = frame[[row["protein_column"], called_column]].copy()
        calls.columns = ["protein", "called"]
        calls["protein"] = calls["protein"].astype(str)
        calls["called"] = calls["called"].astype(str).str.lower().isin(["1", "true", "t", "yes", "dep"])
        result = result.merge(calls.drop_duplicates("protein"), on="protein", how="left")
        result["called"] = result["called"].fillna(False)
    elif (
        isinstance(q_column, str)
        and q_column
        and q_column in frame.columns
        and isinstance(fc_column, str)
        and fc_column
        and fc_column in frame.columns
    ):
        thresholds = pd.DataFrame(
            {
                "protein": frame[row["protein_column"]].astype(str),
                "qvalue": pd.to_numeric(frame[q_column], errors="coerce"),
                "log2fc": pd.to_numeric(frame[fc_column], errors="coerce"),
            }
        ).drop_duplicates("protein")
        result = result.merge(thresholds, on="protein", how="left")
        result["called"] = (result["qvalue"] <= q_threshold) & (
            np.abs(result["log2fc"]) >= np.log2(fc_ratio)
        )
    elif fallback_top_n is not None:
        result["called"] = False
        result.iloc[: min(fallback_top_n, len(result)), result.columns.get_loc("called")] = True
    else:
        raise ValueError(
            f"{path}: provide called_column, qvalue/log2fc columns, or --fallback-top-n"
        )
    return result


def support_metrics(
    dataset: str,
    method: str,
    genes: set[str],
    supported: set[str],
    universe: set[str],
    list_type: str,
) -> dict:
    overlap = genes & supported
    M = len(universe)
    n = len(supported & universe)
    N = len(genes & universe)
    k = len(overlap)
    enrichment_p = float(hypergeom.sf(k - 1, M, n, N)) if M and n and N else np.nan
    return {
        "dataset": dataset,
        "method": method,
        "list_type": list_type,
        "n_selected": len(genes),
        "n_database_supported": k,
        "universe_size": M,
        "n_database_supported_in_universe": n,
        "supported_precision": k / len(genes) if genes else np.nan,
        "supported_recall": k / n if n else np.nan,
        "hypergeometric_pvalue": enrichment_p,
    }


def ora(
    dataset: str,
    method: str,
    foreground: set[str],
    universe: set[str],
    pathways: dict[str, set[str]],
) -> pd.DataFrame:
    rows: list[dict] = []
    for pathway, genes in pathways.items():
        pathway_genes = genes & universe
        overlap = foreground & pathway_genes
        M, n, N, k = len(universe), len(pathway_genes), len(foreground), len(overlap)
        if n == 0 or N == 0:
            continue
        rows.append(
            {
                "dataset": dataset,
                "method": method,
                "pathway": pathway,
                "universe_size": M,
                "pathway_size": n,
                "selected_size": N,
                "overlap_size": k,
                "gene_ratio": k / N,
                "background_ratio": n / M,
                "pvalue": float(hypergeom.sf(k - 1, M, n, N)),
                "overlap_genes": ";".join(sorted(overlap)),
            }
        )
    result = pd.DataFrame(rows)
    if not result.empty:
        result["fdr_bh"] = bh_adjust(result["pvalue"])
    return result


def enrichment_score(scores: np.ndarray, hit_indices: np.ndarray, weight: float) -> float:
    n_genes = len(scores)
    n_hits = len(hit_indices)
    if n_hits == 0 or n_hits == n_genes:
        return np.nan
    hit_mask = np.zeros(n_genes, dtype=bool)
    hit_mask[hit_indices] = True
    hit_weights = np.abs(scores) ** weight
    hit_sum = hit_weights[hit_mask].sum()
    if hit_sum <= 0:
        hit_weights[hit_mask] = 1.0
        hit_sum = n_hits
    increments = np.where(hit_mask, hit_weights / hit_sum, -1.0 / (n_genes - n_hits))
    running = np.cumsum(increments)
    maximum, minimum = float(running.max()), float(running.min())
    return maximum if abs(maximum) >= abs(minimum) else minimum


def preranked_gsea(
    dataset: str,
    method: str,
    ranking: pd.DataFrame,
    pathways: dict[str, set[str]],
    rng: np.random.Generator,
    permutations: int,
    min_size: int,
    max_size: int,
    weight: float,
) -> pd.DataFrame:
    ranking = ranking.sort_values("score", ascending=False).drop_duplicates("protein")
    genes = ranking["protein"].to_numpy(str)
    scores = ranking["score"].to_numpy(float)
    index = {gene: position for position, gene in enumerate(genes)}
    rows: list[dict] = []
    for pathway, members in pathways.items():
        hits = np.array([index[gene] for gene in members if gene in index], dtype=int)
        if len(hits) < min_size or len(hits) > max_size:
            continue
        observed = enrichment_score(scores, hits, weight)
        null = np.array(
            [
                enrichment_score(scores, rng.choice(len(scores), size=len(hits), replace=False), weight)
                for _ in range(permutations)
            ]
        )
        if observed >= 0:
            same_sign = null[null >= 0]
            pvalue = (1 + (same_sign >= observed).sum()) / (1 + len(same_sign))
        else:
            same_sign = null[null < 0]
            pvalue = (1 + (same_sign <= observed).sum()) / (1 + len(same_sign))
        denominator = np.mean(np.abs(same_sign)) if len(same_sign) else np.nan
        rows.append(
            {
                "dataset": dataset,
                "method": method,
                "pathway": pathway,
                "pathway_size": len(hits),
                "enrichment_score": observed,
                "normalized_enrichment_score": observed / denominator if denominator and np.isfinite(denominator) else np.nan,
                "pvalue": pvalue,
            }
        )
    result = pd.DataFrame(rows)
    if not result.empty:
        result["fdr_bh"] = bh_adjust(result["pvalue"])
    return result


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ranking-manifest", type=Path, help="Existing ranking manifest; optional with --run-manifest")
    parser.add_argument("--supported-proteins", required=True, type=Path)
    parser.add_argument("--supported-protein-column", default=None)
    parser.add_argument("--gmt", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--q-threshold", type=float, default=0.05)
    parser.add_argument("--fc-ratio", type=float, default=1.5)
    parser.add_argument("--fallback-top-n", type=int, default=None)
    parser.add_argument("--matched-list-size", type=int, default=None)
    parser.add_argument(
        "--universe-policy",
        choices=["common", "union"],
        default="common",
        help="Use proteins shared by all methods (recommended) or their union as each dataset universe",
    )
    parser.add_argument("--permutations", type=int, default=1000)
    parser.add_argument("--min-pathway-size", type=int, default=10)
    parser.add_argument("--max-pathway-size", type=int, default=500)
    parser.add_argument("--gsea-weight", type=float, default=1.0)
    parser.add_argument("--seed", type=int, default=2024)
    add_core_runner_arguments(parser)
    return parser


def main() -> None:
    args = build_parser().parse_args()
    if args.matched_list_size is not None and args.matched_list_size < 1:
        raise ValueError("--matched-list-size must be a positive integer")
    if args.permutations < 1:
        raise ValueError("--permutations must be at least 1")
    if args.min_pathway_size < 1 or args.max_pathway_size < args.min_pathway_size:
        raise ValueError("Pathway-size bounds are invalid")
    out = ensure_output_dir(args.output_dir)
    core_artifacts = run_core_from_args(args, out)
    if args.dry_run_core and core_artifacts is not None:
        print(f"Core dry-run plan written to {core_artifacts.plan_path}")
        return
    ranking_manifest = args.ranking_manifest or (
        core_artifacts.prediction_manifest_path if core_artifacts is not None else None
    )
    if ranking_manifest is None:
        raise ValueError("Provide --ranking-manifest, or use --run-manifest to generate MCP rankings")
    rng = seed_everything(args.seed)
    manifest = read_table(ranking_manifest)
    missing = [column for column in REQUIRED if column not in manifest.columns]
    if missing:
        raise ValueError(f"Ranking manifest missing columns: {missing}")
    # Bulk and single-cell IFN-gamma resources must be evaluated independently.
    # A missing dataset column is treated as one legacy cohort for compatibility.
    if "dataset" not in manifest.columns:
        manifest["dataset"] = "IFNG"
    manifest["dataset"] = manifest["dataset"].fillna("IFNG").astype(str)
    supported = load_supported(args.supported_proteins, args.supported_protein_column)
    pathways = parse_gmt(args.gmt)

    method_results: dict[tuple[str, str], pd.DataFrame] = {}
    audit: list[dict] = []
    for _, row in manifest.iterrows():
        dataset = str(row["dataset"])
        method = str(row["method"])
        try:
            key = (dataset, method)
            if key in method_results:
                raise ValueError(f"Duplicate dataset/method entry: {dataset}/{method}")
            method_results[key] = load_method_result(
                row, ranking_manifest, args.q_threshold, args.fc_ratio, args.fallback_top_n
            )
            audit.append({"dataset": dataset, "method": method, "status": "ok", "message": ""})
        except Exception as exc:
            audit.append({"dataset": dataset, "method": method, "status": "error", "message": repr(exc)})
    pd.DataFrame(audit).to_csv(out / "input_audit.csv", index=False)
    if not method_results:
        raise RuntimeError("No IFN-gamma method result was loaded; inspect input_audit.csv")

    support_rows: list[dict] = []
    ora_rows: list[pd.DataFrame] = []
    gsea_rows: list[pd.DataFrame] = []
    for dataset in sorted({key[0] for key in method_results}):
        dataset_tables = {
            method: table
            for (current_dataset, method), table in method_results.items()
            if current_dataset == dataset
        }
        # Each external dataset has its own measured-protein universe and its own
        # equal list size. This prevents coverage differences from inflating overlap.
        protein_sets = [set(table["protein"]) for table in dataset_tables.values()]
        universe = (
            set.intersection(*protein_sets)
            if args.universe_policy == "common"
            else set.union(*protein_sets)
        )
        if not universe:
            raise ValueError(f"Dataset '{dataset}' has an empty {args.universe_policy} protein universe")
        comparable_tables = {
            method: table[table["protein"].isin(universe)].copy()
            for method, table in dataset_tables.items()
        }
        called_sizes = [
            int(table["called"].sum())
            for table in comparable_tables.values()
            if int(table["called"].sum()) > 0
        ]
        if args.matched_list_size is None and not called_sizes:
            raise ValueError(
                f"Dataset '{dataset}' has no positive calls; specify valid call columns "
                "or use --matched-list-size explicitly"
            )
        matched_size = args.matched_list_size or min(called_sizes)
        shortest_ranking = min(len(table) for table in comparable_tables.values())
        if matched_size > shortest_ranking:
            raise ValueError(
                f"Dataset '{dataset}' requested matched list size {matched_size}, but the shortest "
                f"ranking in the selected universe has only {shortest_ranking} proteins"
            )

        for method, table in comparable_tables.items():
            called = set(table.loc[table["called"], "protein"])
            matched = set(table.head(min(matched_size, len(table)))["protein"])
            original = support_metrics(dataset, method, called, supported, universe, "original_calls")
            equal_size = support_metrics(dataset, method, matched, supported, universe, "matched_top_ranked")
            original["matched_list_size_used"] = matched_size
            equal_size["matched_list_size_used"] = matched_size
            support_rows.extend([original, equal_size])
            ora_rows.append(ora(dataset, method, matched, universe, pathways))
            gsea_rows.append(
                preranked_gsea(
                    dataset,
                    method,
                    table[["protein", "score"]],
                    pathways,
                    rng,
                    args.permutations,
                    args.min_pathway_size,
                    args.max_pathway_size,
                    args.gsea_weight,
                )
            )

    support = pd.DataFrame(support_rows)
    support["enrichment_fdr_bh"] = support.groupby(
        ["dataset", "list_type"], sort=False
    )["hypergeometric_pvalue"].transform(lambda values: bh_adjust(values.to_numpy()))
    support.to_csv(out / "database_supported_protein_recovery.csv", index=False)
    pd.concat(ora_rows, ignore_index=True).to_csv(out / "matched_size_pathway_ora_bh.csv", index=False)
    pd.concat(gsea_rows, ignore_index=True).to_csv(out / "preranked_gsea_bh.csv", index=False)
    print(f"Completed IFN-gamma pathway validation. Results: {out}")


if __name__ == "__main__":
    main()
