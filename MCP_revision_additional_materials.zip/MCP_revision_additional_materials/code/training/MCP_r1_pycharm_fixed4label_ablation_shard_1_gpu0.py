"""Run fixed4label ablation shard 1 (data index 0) on physical GPU 0."""
from MCP_r1_pycharm_run_fixed4label_ablation_shard import run_shard

if __name__ == "__main__":
    run_shard(1, 0)
