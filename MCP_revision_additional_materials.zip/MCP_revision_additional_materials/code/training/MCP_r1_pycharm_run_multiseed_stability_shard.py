"""Run one of seven independent multi-seed shards from PyCharm or terminal."""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path

import pandas as pd

from MCP_r1_build_multiseed_stability_manifest import build
from MCP_r1_mcp_experiment_runner import execute_run_manifest


def run_shard(shard_id: int, gpu_id: int, profile: str = "main") -> None:
    if shard_id not in range(1, 8):
        raise ValueError("shard_id must be 1..7")
    project = Path(__file__).resolve().parent
    master = project / "MCP_r1_multiseed_stability_manifest.csv"
    if not master.exists():
        build(project, profile, master)
    manifest = pd.read_csv(master)
    profiles = set(manifest.get("multiseed_profile", pd.Series(dtype=str)).astype(str).unique())
    if profiles and profiles != {profile}:
        raise ValueError(
            f"Existing {master.name} contains profile {sorted(profiles)}, requested {profile}. "
            "Rebuild it with MCP_r1_build_multiseed_stability_manifest.py."
        )
    subset = manifest[pd.to_numeric(manifest["shard_id"], errors="coerce").eq(shard_id)].copy()
    if subset.empty:
        raise ValueError(f"No runs for shard {shard_id}")

    data_root = project / "data"
    if not data_root.exists():
        raise FileNotFoundError(
            f"{data_root}\nThe server copy must contain the original MCP data directory."
        )
    subset["data_root"] = str(data_root.resolve())
    subset["r_code"] = str(project.resolve())
    rscript = shutil.which("Rscript")
    if not rscript:
        raise FileNotFoundError("Put the intended Rscript on PATH before training.")
    subset["rscript_path"] = str(Path(rscript).resolve().parent) + "/"
    subset["gpu_id"] = str(gpu_id)
    subset["force"] = False

    output = project / "revision_results" / "multiseed_stability_shards" / f"shard_{shard_id}"
    output.mkdir(parents=True, exist_ok=True)
    # Portable paths only; do not change seeds, model settings, or labels.
    # The runner resolves relative output_root against the manifest directory.
    subset["output_root"] = [str((output / "core_runs" / str(r)).resolve())
                             for r in subset["run_id"]]
    subset_manifest = output / "shard_manifest.csv"
    subset.to_csv(subset_manifest, index=False)
    artifacts = execute_run_manifest(
        subset_manifest,
        output,
        core_script=project / "MCP_r1_mv_contrast_v6.0.3_4_linux_comb_exp_mcc2_new.py",
        strict=True,
    )
    print(f"Shard {shard_id} complete: {artifacts.ledger_path}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--shard-id", type=int, required=True)
    parser.add_argument("--gpu-id", type=int, required=True)
    parser.add_argument("--profile", choices=["main", "architecture"], default="main")
    args = parser.parse_args()
    run_shard(args.shard_id, args.gpu_id, args.profile)


if __name__ == "__main__":
    main()

