"""PyCharm entry point: multi-seed stability shard 3 on GPU 0."""

from MCP_r1_pycharm_run_multiseed_stability_shard import run_shard


if __name__ == "__main__":
    run_shard(3, 0, profile="main")

