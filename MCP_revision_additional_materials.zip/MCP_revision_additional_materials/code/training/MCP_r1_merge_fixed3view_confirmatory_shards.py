"""Strictly merge/QC 28 targeted 3-view fits against 28 existing 4-view controls."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

import MCP_r1_fixed4label_ablation as fixed4
from MCP_r1_build_fixed3view_confirmatory_manifest import build_rows, validate_view_choice
from MCP_r1_fixed3view_confirmatory import (
    IMPLEMENTATION_SCHEMA_VERSION,
    OUTPUT_LATENT_NAME,
    OUTPUT_METRICS_NAME,
    OUTPUT_PREDICTION_NAME,
    _array_fingerprint,
    _current_code_fingerprints,
    _model_spec,
    _validate_bundle,
)
from MCP_r1_merge_fixed4label_ablation_shards import (
    METRICS,
    _adjust_pvalues,
    _as_bool,
    _exact_signed_rank_p,
    _optimal_f1_threshold,
    _posterior_fdr_selection,
)
from MCP_r1_pycharm_run_fixed3view_confirmatory_shard import _validate_full_control


SUBSETS = (
    "all_four_view_union",
    "pseudo_label_excluded_transductive",
    "common_four_view_intersection",
    "common_three_view_support",
)


def _read_required(path: Path) -> pd.DataFrame:
    if not path.is_file():
        raise FileNotFoundError(path)
    table = pd.read_csv(path)
    if table.empty:
        raise ValueError(f"Required table is empty: {path}")
    return table


def _resolve_new_file(row: Any, new_shards_root: Path, filename: str, column: str) -> Path:
    value = str(getattr(row, column, ""))
    if value:
        candidate = Path(value)
        if candidate.is_file():
            return candidate
    fallback = (
        new_shards_root
        / f"shard_{int(row.shard_id)}"
        / "runs"
        / str(row.run_id)
        / filename
    )
    if not fallback.is_file():
        raise FileNotFoundError(fallback)
    return fallback


def _derive_dp_fdr(
    raw_probability: np.ndarray,
    available: np.ndarray,
    training_labels: np.ndarray,
    log2fc: np.ndarray,
    q_threshold: float,
    fc_ratio: float,
) -> dict[str, Any]:
    raw_probability = np.asarray(raw_probability, dtype=float)
    available = np.asarray(available, dtype=bool)
    training_labels = np.asarray(training_labels, dtype=np.int8)
    log2fc = np.asarray(log2fc, dtype=float)
    if not np.all(np.isfinite(raw_probability)) or np.any(
        (raw_probability < 0) | (raw_probability > 1)
    ):
        raise ValueError("Raw probabilities must be finite and lie in [0, 1]")
    if not np.any(available):
        raise ValueError("DP_fdr cannot be calibrated on an empty support")
    supervised = training_labels != -1
    calibration = supervised & available
    if set(np.unique(training_labels[calibration])) != {0, 1}:
        raise ValueError("DP_fdr calibration support does not contain both pseudo-label classes")
    posterior = np.zeros(len(raw_probability), dtype=bool)
    posterior[available] = _posterior_fdr_selection(
        raw_probability[available], q_threshold
    )
    score = np.zeros(len(raw_probability), dtype=float)
    score[available] = raw_probability[available]
    cap = available & (~posterior) & (score > 0.5)
    score[cap] = 0.499
    threshold = _optimal_f1_threshold(training_labels[calibration], score[calibration])
    called = (
        available
        & (score >= threshold)
        & (np.abs(log2fc) >= math.log2(fc_ratio))
    )
    return {
        "posterior": posterior,
        "score": score,
        "threshold": float(threshold),
        "called": called,
        "calibration": calibration,
    }


def _same_numeric(left: pd.Series, right: pd.Series, name: str) -> None:
    a = pd.to_numeric(left, errors="raise").to_numpy(float)
    b = pd.to_numeric(right, errors="raise").to_numpy(float)
    if not np.allclose(a, b, rtol=1e-10, atol=1e-12, equal_nan=True):
        raise ValueError(f"Paired three-/four-view predictions differ in shared {name}")


def _validate_saved_dp(
    pred: pd.DataFrame,
    derived: dict[str, Any],
    name: str,
) -> None:
    if not np.array_equal(
        _as_bool(pred["posterior_fdr_selected"]).to_numpy(), derived["posterior"]
    ):
        raise ValueError(f"{name}: posterior-FDR selection cannot be reproduced")
    for column in (
        "DP_fdr_probability_before_availability",
        "DP_fdr_available_probability",
        "DP_fdr_probability",
    ):
        saved = pd.to_numeric(pred[column], errors="raise").to_numpy(float)
        if not np.allclose(saved, derived["score"], rtol=1e-10, atol=1e-12):
            raise ValueError(f"{name}: {column} cannot be reproduced")
    thresholds = pd.to_numeric(pred["DP_fdr_threshold"], errors="raise").to_numpy(float)
    if not np.allclose(thresholds, derived["threshold"], rtol=1e-10, atol=1e-12):
        raise ValueError(f"{name}: DP_fdr threshold cannot be reproduced")
    if not np.array_equal(_as_bool(pred["called_DP_fdr"]).to_numpy(), derived["called"]):
        raise ValueError(f"{name}: called_DP_fdr cannot be reproduced")


def merge_shards(
    new_shards_root: Path,
    fixed4_shards_root: Path,
    output_dir: Path,
) -> dict[str, Any]:
    new_shards_root = new_shards_root.expanduser().resolve()
    fixed4_shards_root = fixed4_shards_root.expanduser().resolve()
    output_dir = output_dir.expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    expected_rows = build_rows()
    expected_by_id = {row["run_id"]: row for row in expected_rows}
    selected_views = validate_view_choice()
    selected_string = "+".join(selected_views)
    omitted_view = next(view for view in fixed4.SOURCE_VIEWS if view not in selected_views)

    ledgers: list[pd.DataFrame] = []
    manifests: list[pd.DataFrame] = []
    saved_new_metrics: list[pd.DataFrame] = []
    for shard_id in range(1, 8):
        shard_dir = new_shards_root / f"shard_{shard_id}"
        ledger = _read_required(shard_dir / "core_run_ledger.csv")
        manifest = _read_required(shard_dir / "generated_prediction_manifest.csv")
        metrics = _read_required(shard_dir / "generated_performance_wide.csv")
        if len(ledger) != 4 or len(manifest) != 4:
            raise ValueError(f"shard_{shard_id} must contain exactly 4 completed runs")
        ledger["shard_id"] = shard_id
        manifest["shard_id"] = shard_id
        metrics["shard_id"] = shard_id
        ledgers.append(ledger)
        manifests.append(manifest)
        saved_new_metrics.append(metrics)
    ledger = pd.concat(ledgers, ignore_index=True, sort=False)
    new_manifest = pd.concat(manifests, ignore_index=True, sort=False)
    saved_metrics = pd.concat(saved_new_metrics, ignore_index=True, sort=False)
    if len(ledger) != 28 or ledger["run_id"].astype(str).nunique() != 28:
        raise ValueError("Merged ledger must contain exactly 28 unique new fits")
    if set(ledger["run_id"].astype(str)) != set(expected_by_id):
        raise ValueError("New ledger run IDs do not match the current 28-run manifest")
    if len(new_manifest) != 28 or new_manifest["run_id"].astype(str).nunique() != 28:
        raise ValueError("Merged prediction manifest must contain exactly 28 unique runs")
    bad = ledger[~ledger["status"].astype(str).isin({"completed", "skipped_existing"})]
    if not bad.empty:
        raise ValueError(f"Merged ledger contains {len(bad)} incomplete/error runs")
    if set(new_manifest["test_type"].astype(str)) != {"DP_fdr"}:
        raise ValueError("Only DP_fdr is accepted as MCP output")
    if set(new_manifest["model_input_views"].astype(str)) != {selected_string}:
        raise ValueError("More than one or an incorrect three-view set was run")

    # Reject stale or hand-edited scientific settings.
    ignored = {"data_root", "r_code", "rscript_path", "gpu_id", "force", "dataset"}
    for row in ledger.itertuples(index=False):
        expected = expected_by_id[str(row.run_id)]
        for field, expected_value in expected.items():
            if field in ignored:
                continue
            raw = getattr(row, field)
            actual = "" if pd.isna(raw) else str(raw)
            if actual.lower() in {"true", "false"}:
                actual = actual.upper()
            if actual != str(expected_value):
                raise ValueError(
                    f"Run specification mismatch {row.run_id}/{field}: "
                    f"{actual!r} != {expected_value!r}"
                )

    project_dir = Path(__file__).resolve().parent
    core_script = project_dir / "MCP_r1_mv_contrast_v6.0.3_4_linux_comb_exp_mcc2_new.py"
    current_new_code = _current_code_fingerprints(core_script)
    metric_rows: list[dict[str, Any]] = []
    comparison_manifest_rows: list[dict[str, Any]] = []
    qc_rows: list[dict[str, Any]] = []
    coverage_rows: list[dict[str, Any]] = []
    raw_ranking_rows: list[dict[str, Any]] = []

    required_prediction_columns = {
        "Protein", "True_lab", "raw_probability", "posterior_fdr_selected",
        "DP_fdr_probability_before_availability", "DP_fdr_available_probability",
        "DP_fdr_probability", "DP_fdr_threshold", "shared_full_log2fc",
        "selected_view_available", "called_DP_fdr", "fixed_pro_lab",
        "training_pro_lab", "used_for_classification_training",
        "available_dlfq", "available_maxlfq", "available_top3", "available_top1",
    }
    for row in new_manifest.itertuples(index=False):
        expected = expected_by_id[str(row.run_id)]
        shard_id = int(row.shard_id)
        fixed4_shard = fixed4_shards_root / f"shard_{shard_id}"
        bundle_dir = (
            fixed4_shard
            / "bundles"
            / f"i{expected['data_index']}_{expected['platform']}_{expected['dea_method']}"
        )
        control_dir = fixed4_shard / "runs" / expected["fixed4_control_run_id"]
        bundle_metadata = _validate_bundle(bundle_dir, core_script)
        _validate_full_control(control_dir, bundle_metadata, core_script, expected)

        new_prediction_path = _resolve_new_file(
            row, new_shards_root, OUTPUT_PREDICTION_NAME, "prediction_file"
        )
        new_metadata_path = _resolve_new_file(
            row, new_shards_root, "metadata.json", "run_metadata_file"
        )
        new_metrics_path = new_prediction_path.with_name(OUTPUT_METRICS_NAME)
        new_latent_path = new_prediction_path.with_name(OUTPUT_LATENT_NAME)
        metadata = json.loads(new_metadata_path.read_text(encoding="utf-8"))
        expected_spec = _model_spec(expected, bundle_metadata, core_script)
        expected_spec_hash = fixed4._sha256_bytes(
            fixed4._canonical_json(expected_spec).encode("utf-8")
        )
        metadata_checks = {
            "status": metadata.get("status") == "completed",
            "schema": metadata.get("experiment_schema") == IMPLEMENTATION_SCHEMA_VERSION,
            "run_id": metadata.get("run_id") == expected["run_id"],
            "model_spec_hash": metadata.get("model_spec_hash") == expected_spec_hash,
            "code_fingerprints": metadata.get("code_fingerprints") == current_new_code,
            "model_views": metadata.get("model_views") == list(selected_views),
            "core_nview": int(metadata.get("verified_core_nview", -1)) == 3,
            "core_variant": metadata.get("verified_core_variant") == "full_mcp",
            "omitted_view": metadata.get("omitted_view") == omitted_view,
            "prediction_sha256": metadata.get("prediction_sha256")
            == fixed4.sha256_file(new_prediction_path),
            "metrics_sha256": metadata.get("metrics_sha256")
            == fixed4.sha256_file(new_metrics_path),
            "latent_sha256": metadata.get("latent_sha256")
            == fixed4.sha256_file(new_latent_path),
        }
        failed = [name for name, passed in metadata_checks.items() if not passed]
        if failed:
            raise ValueError(
                f"New run metadata is stale/incompatible ({', '.join(failed)}): "
                f"{new_metadata_path}"
            )
        for field, value in expected_spec.items():
            if metadata.get(field) != value:
                raise ValueError(f"New metadata differs from exact model spec: {row.run_id}/{field}")

        with np.load(bundle_dir / "fixed4view_training_bundle.npz", allow_pickle=False) as bundle:
            bundle_proteins = bundle["proteins"].astype(str)
            bundle_labels = np.asarray(bundle["fixed_pro_lab"], dtype=np.int8).reshape(-1)
            expected_matrix_hashes = {
                view: _array_fingerprint(np.asarray(bundle[f"data_{view}"], dtype=np.float32))
                for view in selected_views
            }
        if metadata.get("model_input_matrix_fingerprints") != expected_matrix_hashes:
            raise ValueError(f"Selected model matrix fingerprints are wrong: {row.run_id}")
        if omitted_view in metadata.get("model_input_matrix_fingerprints", {}):
            raise ValueError(f"Omitted view leaked into model inputs: {row.run_id}")

        new_pred = _read_required(new_prediction_path)
        full_prediction_path = control_dir / "fixed4label_DP_fdr_predictions.csv"
        full_pred = _read_required(full_prediction_path)
        for name, pred in (("three-view", new_pred), ("four-view", full_pred)):
            missing = sorted(required_prediction_columns - set(pred.columns))
            if missing:
                raise ValueError(f"{name} prediction lacks columns {missing}")
            if pred["Protein"].astype(str).duplicated().any():
                raise ValueError(f"{name} prediction contains duplicate Protein IDs")
        if not np.array_equal(
            new_pred["Protein"].astype(str).to_numpy(),
            full_pred["Protein"].astype(str).to_numpy(),
        ) or not np.array_equal(new_pred["Protein"].astype(str).to_numpy(), bundle_proteins):
            raise ValueError(f"Protein order/universe is not identical for {row.run_id}")
        for column in ("True_lab", "fixed_pro_lab", "training_pro_lab"):
            _same_numeric(new_pred[column], full_pred[column], column)
        _same_numeric(new_pred["shared_full_log2fc"], full_pred["shared_full_log2fc"], "log2FC")
        for view in fixed4.SOURCE_VIEWS:
            new_avail = _as_bool(new_pred[f"available_{view}"]).to_numpy()
            full_avail = _as_bool(full_pred[f"available_{view}"]).to_numpy()
            if not np.array_equal(new_avail, full_avail):
                raise ValueError(f"Availability mask {view} differs in paired predictions")

        fixed_labels = pd.to_numeric(new_pred["fixed_pro_lab"], errors="raise").to_numpy(np.int8)
        training_labels = pd.to_numeric(new_pred["training_pro_lab"], errors="raise").to_numpy(np.int8)
        used = _as_bool(new_pred["used_for_classification_training"]).to_numpy()
        if not np.array_equal(fixed_labels, bundle_labels):
            raise ValueError("Prediction labels differ from the immutable bundle")
        if not np.array_equal(training_labels, fixed_labels) or not np.array_equal(
            used, fixed_labels != -1
        ):
            raise ValueError("strict_shared_mask was not applied identically")
        availability = {
            view: _as_bool(new_pred[f"available_{view}"]).to_numpy()
            for view in fixed4.SOURCE_VIEWS
        }
        selected_available = np.logical_or.reduce(
            [availability[view] for view in selected_views]
        )
        full_available = np.logical_or.reduce(list(availability.values()))
        if not np.all(full_available):
            raise ValueError("A fixed-four union protein is absent from all four views")
        if not np.array_equal(
            _as_bool(new_pred["selected_view_available"]).to_numpy(), selected_available
        ):
            raise ValueError("Three-view selected availability is not the exact three-view OR")
        if not np.array_equal(
            _as_bool(full_pred["selected_view_available"]).to_numpy(), full_available
        ):
            raise ValueError("Four-view selected availability is not the exact four-view OR")

        true_labels = pd.to_numeric(new_pred["True_lab"], errors="raise").to_numpy(int)
        log2fc = pd.to_numeric(new_pred["shared_full_log2fc"], errors="raise").to_numpy(float)
        new_raw = pd.to_numeric(new_pred["raw_probability"], errors="raise").to_numpy(float)
        full_raw = pd.to_numeric(full_pred["raw_probability"], errors="raise").to_numpy(float)
        q_threshold = float(metadata["q_threshold"])
        fc_ratio = float(metadata["fc_ratio"])
        new_primary = _derive_dp_fdr(
            new_raw, selected_available, training_labels, log2fc, q_threshold, fc_ratio
        )
        full_primary = _derive_dp_fdr(
            full_raw, full_available, training_labels, log2fc, q_threshold, fc_ratio
        )
        _validate_saved_dp(new_pred, new_primary, "three-view")
        _validate_saved_dp(full_pred, full_primary, "four-view")
        # Recalibrate both already-trained models on the identical three-view
        # support; this is a no-retraining model-only sensitivity comparison.
        new_common = _derive_dp_fdr(
            new_raw, selected_available, training_labels, log2fc, q_threshold, fc_ratio
        )
        full_common = _derive_dp_fdr(
            full_raw, selected_available, training_labels, log2fc, q_threshold, fc_ratio
        )

        common_four = np.logical_and.reduce(list(availability.values()))
        supervised = training_labels != -1
        masks = {
            "all_four_view_union": np.ones(len(new_pred), dtype=bool),
            "pseudo_label_excluded_transductive": training_labels == -1,
            "common_four_view_intersection": common_four,
            "common_three_view_support": selected_available,
        }
        method_payloads = {
            "three_view_mcp_" + "_".join(selected_views): (new_primary, new_common),
            "four_view_mcp": (full_primary, full_common),
        }
        for method, (primary, common) in method_payloads.items():
            for subset, keep in masks.items():
                values = common if subset == "common_three_view_support" else primary
                metrics = fixed4._metric_row(
                    true_labels[keep],
                    values["score"][keep],
                    values["called"][keep],
                    selected_available[keep]
                    if method.startswith("three_view")
                    else full_available[keep],
                )
                metric_rows.append(
                    {
                        "data_index": int(expected["data_index"]),
                        "dataset": metadata["dataset"],
                        "platform": expected["platform"],
                        "dea_method": expected["dea_method"],
                        "method": method,
                        "model_input_views": selected_string if method.startswith("three_view") else "+".join(fixed4.SOURCE_VIEWS),
                        "evaluation_subset": subset,
                        "calibration_scope": (
                            "common_three_view_support"
                            if subset == "common_three_view_support"
                            else "method_available_support"
                        ),
                        "label_mode": "strict_shared_mask",
                        "test_type": "DP_fdr",
                        "seed": int(expected["seed"]),
                        "DP_fdr_threshold": values["threshold"],
                        **metrics,
                    }
                )
        # Pure ranking sensitivity: unlike DP_fdr metrics above, these AUROC/
        # AUPRC values use unmodified model probabilities on the exact same
        # three-view support for both already-trained networks.
        for method, raw in (
            ("three_view_mcp_" + "_".join(selected_views), new_raw),
            ("four_view_mcp", full_raw),
        ):
            raw_metrics = fixed4._metric_row(
                true_labels[selected_available],
                raw[selected_available],
                np.zeros(int(selected_available.sum()), dtype=bool),
                np.ones(int(selected_available.sum()), dtype=bool),
            )
            raw_ranking_rows.append(
                {
                    "data_index": int(expected["data_index"]),
                    "dataset": metadata["dataset"],
                    "platform": expected["platform"],
                    "dea_method": expected["dea_method"],
                    "method": method,
                    "support": "common_three_view_support",
                    "score_representation": "raw_probability",
                    "N_evaluated": raw_metrics["N_evaluated"],
                    "N_true_DEP": raw_metrics["N_true_DEP"],
                    "N_true_nonDEP": raw_metrics["N_true_nonDEP"],
                    **{
                        metric: raw_metrics[metric]
                        for metric in ("auroc", "auprc", "pauc_0.01", "pauc_0.05", "pauc_0.10")
                    },
                }
            )

        n_supervised = int(supervised.sum())
        n_supervised_unavailable = int(np.sum(supervised & ~selected_available))
        coverage_rows.append(
            {
                "data_index": int(expected["data_index"]),
                "dataset": metadata["dataset"],
                "platform": expected["platform"],
                "dea_method": expected["dea_method"],
                "selected_views": selected_string,
                "omitted_view": omitted_view,
                "N_union": len(new_pred),
                "N_selected_available": int(selected_available.sum()),
                "N_selected_unavailable": int((~selected_available).sum()),
                "N_fixed_supervised": n_supervised,
                "N_fixed_supervised_selected_available": int(np.sum(supervised & selected_available)),
                "N_fixed_supervised_selected_unavailable": n_supervised_unavailable,
                "N_fixed_positive_selected_unavailable": int(
                    np.sum((training_labels == 1) & ~selected_available)
                ),
                "N_fixed_negative_selected_unavailable": int(
                    np.sum((training_labels == 0) & ~selected_available)
                ),
                "fraction_fixed_supervised_selected_unavailable": (
                    n_supervised_unavailable / n_supervised if n_supervised else np.nan
                ),
            }
        )
        qc_rows.append(
            {
                "run_id": row.run_id,
                "fixed4_control_run_id": expected["fixed4_control_run_id"],
                "data_index": expected["data_index"],
                "dataset": metadata["dataset"],
                "platform": expected["platform"],
                "dea_method": expected["dea_method"],
                "N_union": len(new_pred),
                "N_selected_available": int(selected_available.sum()),
                "N_called_three_primary": int(new_primary["called"].sum()),
                "N_called_four_primary": int(full_primary["called"].sum()),
                "three_threshold_primary": new_primary["threshold"],
                "four_threshold_primary": full_primary["threshold"],
                "three_threshold_common_support": new_common["threshold"],
                "four_threshold_common_support": full_common["threshold"],
                "qc_passed": True,
            }
        )
        comparison_manifest_rows.extend(
            [
                {
                    "data_index": int(expected["data_index"]),
                    "dataset": metadata["dataset"],
                    "platform": expected["platform"],
                    "dea_method": expected["dea_method"],
                    "method": "three_view_mcp_" + "_".join(selected_views),
                    "prediction_file": str(new_prediction_path),
                },
                {
                    "data_index": int(expected["data_index"]),
                    "dataset": metadata["dataset"],
                    "platform": expected["platform"],
                    "dea_method": expected["dea_method"],
                    "method": "four_view_mcp",
                    "prediction_file": str(full_prediction_path),
                },
            ]
        )

    metrics_wide = pd.DataFrame(metric_rows)
    expected_metric_rows = 28 * 2 * len(SUBSETS)
    if len(metrics_wide) != expected_metric_rows:
        raise ValueError(f"Expected {expected_metric_rows} recomputed metric rows")
    pair_strata = ["data_index", "dataset", "platform", "dea_method", "evaluation_subset"]
    denominators = metrics_wide.groupby(pair_strata)["N_evaluated"].nunique()
    if (denominators != 1).any():
        raise ValueError("Three-/four-view paired comparisons have unequal protein denominators")
    dataset_map = metrics_wide[["data_index", "dataset"]].drop_duplicates()
    if (
        len(dataset_map) != 7
        or dataset_map["data_index"].nunique() != 7
        or dataset_map["dataset"].nunique() != 7
        or (dataset_map.groupby("data_index")["dataset"].nunique() != 1).any()
    ):
        raise ValueError(
            "The seven data_index values must map one-to-one to seven unique dataset labels"
        )

    id_columns = [
        "data_index", "dataset", "platform", "dea_method", "method", "model_input_views",
        "evaluation_subset", "calibration_scope", "label_mode", "test_type", "seed",
        "DP_fdr_threshold", "N_evaluated", "N_true_DEP", "N_true_nonDEP",
        "N_selected_view_available", "tn", "fp", "fn", "tp",
    ]
    metrics_long = metrics_wide.melt(
        id_vars=id_columns,
        value_vars=[metric for metric in METRICS if metric in metrics_wide.columns],
        var_name="metric",
        value_name="value",
    )
    pair_keys = [
        "data_index", "dataset", "platform", "dea_method", "evaluation_subset", "metric"
    ]
    three_method = "three_view_mcp_" + "_".join(selected_views)
    three = metrics_long[metrics_long["method"] == three_method][
        pair_keys + ["value", "N_evaluated"]
    ].rename(columns={"value": "three_view_value", "N_evaluated": "three_view_N"})
    four = metrics_long[metrics_long["method"] == "four_view_mcp"][
        pair_keys + ["value", "N_evaluated"]
    ].rename(columns={"value": "four_view_value", "N_evaluated": "four_view_N"})
    paired_stratum = three.merge(four, on=pair_keys, validate="one_to_one")
    if len(paired_stratum) != len(three) or (paired_stratum["three_view_N"] != paired_stratum["four_view_N"]).any():
        raise ValueError("Missing pairs or unequal denominators in stratum comparison")
    paired_stratum["delta_three_minus_four"] = (
        paired_stratum["three_view_value"] - paired_stratum["four_view_value"]
    )

    dataset_group = ["data_index", "dataset", "method", "evaluation_subset", "metric"]
    dataset_values = (
        metrics_long.groupby(dataset_group, as_index=False, dropna=False)
        .agg(
            value=("value", "mean"),
            N_finite_configurations=("value", lambda x: int(np.isfinite(x).sum())),
            N_total_configurations=("value", "size"),
        )
    )
    if set(dataset_values["N_total_configurations"].astype(int)) != {4}:
        raise ValueError("Every dataset/method/subset/metric must contain all 2x2 configurations")
    dataset_values.loc[dataset_values["N_finite_configurations"] != 4, "value"] = np.nan
    dataset_values["complete_four_configurations"] = (
        dataset_values["N_finite_configurations"] == 4
    )
    dataset_values["dataset_unit"] = "DIA_index_" + dataset_values["data_index"].astype(str)

    dataset_pair_keys = ["data_index", "dataset", "evaluation_subset", "metric"]
    d_three = dataset_values[dataset_values["method"] == three_method][
        dataset_pair_keys + ["value", "N_finite_configurations"]
    ].rename(
        columns={"value": "three_view_value", "N_finite_configurations": "three_N_configurations"}
    )
    d_four = dataset_values[dataset_values["method"] == "four_view_mcp"][
        dataset_pair_keys + ["value", "N_finite_configurations"]
    ].rename(
        columns={"value": "four_view_value", "N_finite_configurations": "four_N_configurations"}
    )
    paired_dataset = d_three.merge(d_four, on=dataset_pair_keys, validate="one_to_one")
    paired_dataset["dataset_unit"] = "DIA_index_" + paired_dataset["data_index"].astype(str)
    paired_dataset["delta_three_minus_four"] = (
        paired_dataset["three_view_value"] - paired_dataset["four_view_value"]
    )

    summary_rows: list[dict[str, Any]] = []
    for (subset, metric), group in paired_dataset.groupby(
        ["evaluation_subset", "metric"], dropna=False
    ):
        delta = group["delta_three_minus_four"].to_numpy(float)
        delta = delta[np.isfinite(delta)]
        summary_rows.append(
            {
                "three_view_method": three_method,
                "evaluation_subset": subset,
                "metric": metric,
                "N_paired_datasets": len(delta),
                "mean_delta_three_minus_four": float(np.mean(delta)) if len(delta) else np.nan,
                "median_delta_three_minus_four": float(np.median(delta)) if len(delta) else np.nan,
                "N_three_better": int(np.sum(delta > 0)),
                "N_equal": int(np.sum(delta == 0)),
                "N_four_better": int(np.sum(delta < 0)),
                "wilcoxon_p": _exact_signed_rank_p(delta) if len(delta) else np.nan,
            }
        )
    summary = _adjust_pvalues(pd.DataFrame(summary_rows))
    primary = summary[
        (summary["evaluation_subset"] == "all_four_view_union")
        & summary["metric"].isin({"mcc", "auroc", "auprc"})
    ]
    common_support = summary[
        (summary["evaluation_subset"] == "common_three_view_support")
        & summary["metric"].isin({"mcc", "auroc", "auprc"})
    ]
    if len(primary) != 3 or not (primary["N_paired_datasets"] == 7).all():
        raise ValueError("Primary union MCC/AUROC/AUPRC must each have exactly n=7 pairs")
    if len(common_support) != 3 or not (common_support["N_paired_datasets"] == 7).all():
        raise ValueError("Common-support MCC/AUROC/AUPRC must each have exactly n=7 pairs")

    # Dataset-level summary of raw-probability ranking on identical support.
    raw_ranking_wide = pd.DataFrame(raw_ranking_rows)
    if len(raw_ranking_wide) != 56:
        raise ValueError("Expected 28 strata x 2 raw-probability ranking rows")
    raw_rank_metrics = ("auroc", "auprc", "pauc_0.01", "pauc_0.05", "pauc_0.10")
    raw_ranking_long = raw_ranking_wide.melt(
        id_vars=[
            "data_index", "dataset", "platform", "dea_method", "method", "support",
            "score_representation", "N_evaluated", "N_true_DEP", "N_true_nonDEP",
        ],
        value_vars=list(raw_rank_metrics),
        var_name="metric",
        value_name="value",
    )
    raw_dataset = (
        raw_ranking_long.groupby(
            ["data_index", "dataset", "method", "support", "metric"],
            as_index=False,
            dropna=False,
        )
        .agg(
            value=("value", "mean"),
            N_finite_configurations=("value", lambda x: int(np.isfinite(x).sum())),
            N_total_configurations=("value", "size"),
        )
    )
    if set(raw_dataset["N_total_configurations"].astype(int)) != {4}:
        raise ValueError("Raw ranking summaries require all four configurations per dataset")
    raw_dataset.loc[raw_dataset["N_finite_configurations"] != 4, "value"] = np.nan
    raw_keys = ["data_index", "dataset", "support", "metric"]
    raw_three = raw_dataset[raw_dataset["method"] == three_method][
        raw_keys + ["value"]
    ].rename(columns={"value": "three_view_value"})
    raw_four = raw_dataset[raw_dataset["method"] == "four_view_mcp"][
        raw_keys + ["value"]
    ].rename(columns={"value": "four_view_value"})
    raw_paired = raw_three.merge(raw_four, on=raw_keys, validate="one_to_one")
    raw_paired["dataset_unit"] = "DIA_index_" + raw_paired["data_index"].astype(str)
    raw_paired["delta_three_minus_four"] = (
        raw_paired["three_view_value"] - raw_paired["four_view_value"]
    )
    raw_summary_rows: list[dict[str, Any]] = []
    for metric, group in raw_paired.groupby("metric", dropna=False):
        delta = group["delta_three_minus_four"].to_numpy(float)
        delta = delta[np.isfinite(delta)]
        raw_summary_rows.append(
            {
                "support": "common_three_view_support",
                "score_representation": "raw_probability",
                "metric": metric,
                "N_paired_datasets": len(delta),
                "mean_delta_three_minus_four": float(np.mean(delta)) if len(delta) else np.nan,
                "median_delta_three_minus_four": float(np.median(delta)) if len(delta) else np.nan,
                "N_three_better": int(np.sum(delta > 0)),
                "N_equal": int(np.sum(delta == 0)),
                "N_four_better": int(np.sum(delta < 0)),
                "wilcoxon_p": _exact_signed_rank_p(delta) if len(delta) else np.nan,
            }
        )
    raw_summary = _adjust_pvalues(pd.DataFrame(raw_summary_rows))

    ledger.to_csv(output_dir / "merged_new_core_run_ledger.csv", index=False)
    new_manifest.to_csv(output_dir / "merged_new_prediction_manifest.csv", index=False)
    saved_metrics.to_csv(output_dir / "merged_new_saved_metrics.csv", index=False)
    pd.DataFrame(comparison_manifest_rows).to_csv(
        output_dir / "comparison_prediction_manifest.csv", index=False
    )
    metrics_wide.to_csv(output_dir / "comparison_metrics_wide.csv", index=False)
    metrics_long.to_csv(output_dir / "comparison_metrics_long.csv", index=False)
    pd.DataFrame(qc_rows).to_csv(output_dir / "prediction_qc.csv", index=False)
    pd.DataFrame(coverage_rows).to_csv(output_dir / "supervised_unavailable_audit.csv", index=False)
    dataset_map.sort_values("data_index").to_csv(
        output_dir / "data_index_to_dataset_mapping.csv", index=False
    )
    paired_stratum.to_csv(output_dir / "paired_stratum_three_vs_four.csv", index=False)
    dataset_values.to_csv(output_dir / "dataset_aggregated_metrics_long.csv", index=False)
    paired_dataset.to_csv(output_dir / "paired_dataset_three_vs_four.csv", index=False)
    summary.to_csv(output_dir / "summary_three_vs_four.csv", index=False)
    raw_ranking_wide.to_csv(
        output_dir / "raw_probability_common_support_metrics_wide.csv", index=False
    )
    raw_ranking_long.to_csv(
        output_dir / "raw_probability_common_support_metrics_long.csv", index=False
    )
    raw_dataset.to_csv(
        output_dir / "raw_probability_common_support_dataset_values.csv", index=False
    )
    raw_paired.to_csv(
        output_dir / "raw_probability_common_support_paired.csv", index=False
    )
    raw_summary.to_csv(
        output_dir / "raw_probability_common_support_summary.csv", index=False
    )
    qc = {
        "status": "passed",
        "new_model_fits_expected": 28,
        "new_model_fits_observed": int(len(ledger)),
        "four_view_controls_retrained_by_this_experiment": 0,
        "four_view_controls_reused": 28,
        "selected_global_three_view_set": list(selected_views),
        "omitted_view": omitted_view,
        "scientific_scope": "fixed-four-view-supervision input-view ablation",
        "not_claimed_scope": "standalone end-to-end three-view MCP pipeline",
        "shared_fc_policy": "fixed_four_view_log2fc",
        "primary_universe": "all_four_view_union; unavailable three-view proteins are non-DEP",
        "common_support_sensitivity": "both trained models recalibrated on identical three-view support; no retraining; this remains a DP_fdr pipeline sensitivity",
        "raw_probability_ranking_sensitivity": "AUROC/AUPRC/pAUC from unmodified probabilities on identical three-view support",
        "data_index_dataset_mapping_check": "one-to-one mapping to seven unique dataset labels passed",
        "biological_independence_note": "unique labels are machine-checked; independence must also be confirmed from benchmark study design",
        "independent_statistical_unit": "data_index, conditional on study-design independence",
        "N_independent_datasets": 7,
        "within_dataset_aggregation": "equal mean of 2 platforms x 2 DEA methods; all four required",
        "paired_test": "exact two-sided sign-flip Wilcoxon signed-rank",
        "mcp_output": "DP_fdr",
        "selection_caveat": "targeted sensitivity analysis if chosen after inspecting this benchmark collection",
    }
    (output_dir / "merge_qc.json").write_text(
        json.dumps(qc, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return qc


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    default_project = Path(__file__).resolve().parent
    default_final = default_project / "revision_results" / "final_required"
    parser.add_argument(
        "--new-shards-root",
        type=Path,
        default=default_final / "fixed3view_confirmatory" / "shards",
    )
    parser.add_argument(
        "--fixed4-shards-root",
        type=Path,
        default=default_final / "fixed4label_single_view_ablation" / "shards",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=default_final / "fixed3view_confirmatory" / "merged",
    )
    args = parser.parse_args()
    print(json.dumps(merge_shards(args.new_shards_root, args.fixed4_shards_root, args.output_dir), indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
