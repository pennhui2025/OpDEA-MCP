"""Build an opt-in, genuinely seed-controlled MCP stability manifest.

Profiles:
  main (default): full MCP only, 5 seeds, 140 runs.
  architecture: full MCP, dLFQ single-view MCP, early/late neural fusion,
                no-contrastive and no-cross-attention, 840 runs.

The default profile is the minimum experiment needed to quantify uncertainty
of the main model.  The architecture profile is optional and substantially
more expensive.  Existing outputs are skipped because every seed has a unique
output directory and force=False.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


SEEDS = (2024, 2025, 2026, 2027, 2028)


def select_source_rows(project: Path, profile: str) -> pd.DataFrame:
    main = pd.read_csv(project / "MCP_r1_task1_2_DIA_limma_ROTS_manifest.csv")
    rows = [main[main["variant"].astype(str).eq("full_mcp")].copy()]
    if profile == "architecture":
        rows.extend([
            main[
                main["variant"].astype(str).eq("single_view_mcp")
                & main["views"].astype(str).eq("dlfq")
            ].copy(),
            main[main["variant"].astype(str).isin(["simple_early_fusion", "simple_late_fusion"])].copy(),
        ])
        task5 = pd.read_csv(project / "MCP_r1_remaining_task5_deep_ablation_manifest.csv")
        rows.append(task5[task5["variant"].astype(str).isin(["no_contrastive", "no_cross_attention"])].copy())
    selected = pd.concat(rows, ignore_index=True)
    expected = 28 if profile == "main" else 168
    if len(selected) != expected:
        raise ValueError(f"Profile {profile!r} expected {expected} source rows; found {len(selected)}")
    return selected


def build(project: Path, profile: str, output: Path) -> pd.DataFrame:
    source = select_source_rows(project, profile)
    rows: list[dict[str, object]] = []
    for source_record in source.to_dict("records"):
        data_index = int(source_record["data_index"])
        shard_id = data_index + 1
        gpu_id = 0 if shard_id <= 4 else 1
        for seed in SEEDS:
            record = dict(source_record)
            base_id = str(record["run_id"])
            run_id = f"{base_id}__runtime_seed_{seed}"
            record.update({
                "run_id": run_id,
                "seed": seed,
                "runtime_seed_control": True,
                "gpu_id": gpu_id,
                "r_code": ".",
                "output_root": (
                    f"revision_results/multiseed_stability_shards/shard_{shard_id}/"
                    f"core_runs/{run_id}"
                ),
                "force": False,
                "multiseed_profile": profile,
                "shard_id": shard_id,
            })
            rows.append(record)
    manifest = pd.DataFrame(rows)
    if manifest["run_id"].duplicated().any():
        raise ValueError("Generated run_id values are not unique")
    expected = (28 if profile == "main" else 168) * len(SEEDS)
    if len(manifest) != expected:
        raise AssertionError(f"Expected {expected} generated runs; found {len(manifest)}")
    output.parent.mkdir(parents=True, exist_ok=True)
    manifest.to_csv(output, index=False)
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--profile", choices=["main", "architecture"], default="main")
    parser.add_argument("--output", default="MCP_r1_multiseed_stability_manifest.csv")
    args = parser.parse_args()
    project = Path(__file__).resolve().parent
    output = Path(args.output).expanduser()
    if not output.is_absolute():
        output = project / output
    manifest = build(project, args.profile, output.resolve())
    print(f"Wrote {len(manifest)} runs to {output.resolve()}")
    print(manifest.groupby(["shard_id", "variant"]).size().to_string())


if __name__ == "__main__":
    main()

