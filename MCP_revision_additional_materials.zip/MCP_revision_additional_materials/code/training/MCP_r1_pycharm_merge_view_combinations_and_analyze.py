"""Merge the existing 336 runs plus 280 incremental runs, then analyze view count."""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pandas as pd


PROJECT_DIR = Path(__file__).resolve().parent
RESULT_ROOT = PROJECT_DIR / "revision_results"


def run(command: list[str], label: str) -> None:
    print(f"\n=== {label} ===", flush=True)
    subprocess.run(command, cwd=PROJECT_DIR, check=True)


def main() -> None:
    existing_merged = RESULT_ROOT / "task1_2_core_merged_limma_ROTS"
    incremental_merged = RESULT_ROOT / "view_combination_incremental_merged"
    analysis_output = RESULT_ROOT / "view_count_combination_analysis_limma_ROTS"

    # Rebuild the existing merged manifest from the seven completed 48-run
    # shards. This is read/merge work only; it does not rerun a model.
    run(
        [
            sys.executable,
            str(PROJECT_DIR / "MCP_r1_merge_task1_2_shards.py"),
            "--shards-root", str(RESULT_ROOT / "task1_2_shards"),
            "--output-dir", str(existing_merged),
            "--master-manifest",
            str(PROJECT_DIR / "MCP_r1_task1_2_DIA_limma_ROTS_manifest.csv"),
            "--expected-shards", "7",
        ],
        "Validate and merge the existing 336 limma+ROTS runs",
    )
    run(
        [
            sys.executable,
            str(PROJECT_DIR / "MCP_r1_merge_view_combination_incremental_shards.py"),
            "--shards-root", str(RESULT_ROOT / "view_combination_incremental_shards"),
            "--output-dir", str(incremental_merged),
            "--master-manifest",
            str(PROJECT_DIR / "MCP_r1_DIA_view_combinations_limma_ROTS_incremental_manifest.csv"),
            "--expected-shards", "7",
        ],
        "Validate and merge the 280 incremental 2/3-view runs",
    )
    run(
        [
            sys.executable,
            str(PROJECT_DIR / "MCP_r1_view_count_combination_analysis.py"),
            "--main-manifest", str(existing_merged / "generated_prediction_manifest.csv"),
            "--incremental-manifest",
            str(incremental_merged / "generated_prediction_manifest.csv"),
            "--output-dir", str(analysis_output),
            "--fdr-thresholds", "0.01,0.05,0.10",
            "--fc-ratios", "1.0,1.2,1.5",
            "--primary-fdr", "0.05",
            "--primary-fc", "1.5",
            "--bootstrap", "2000",
            "--seed", "2024",
        ],
        "Analyze all 15 view sets without dataset-level pseudoreplication",
    )

    incremental_ledger = pd.read_csv(incremental_merged / "core_run_ledger.csv")
    selected = pd.read_csv(analysis_output / "selected_mcp_prediction_manifest.csv")
    design_audit = pd.read_csv(analysis_output / "view_combination_design_audit.csv")
    input_audit = pd.read_csv(analysis_output / "input_audit.csv")
    if len(incremental_ledger) != 280 or not incremental_ledger["run_id"].is_unique:
        raise RuntimeError("Incremental merged ledger must contain 280 unique runs")
    if len(selected) != 420:
        raise RuntimeError("View-count analysis must select 420 MCP prediction rows")
    if len(design_audit) != 28 or not design_audit["status"].astype(str).eq("ok").all():
        raise RuntimeError("View-combination design audit is incomplete")
    if input_audit["status"].astype(str).str.lower().eq("error").any():
        raise RuntimeError("Prediction input audit contains errors")

    summary = json.loads((analysis_output / "analysis_summary.json").read_text(encoding="utf-8"))
    print("\nVIEW-COMBINATION INCREMENTAL ANALYSIS COMPLETED", flush=True)
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()

