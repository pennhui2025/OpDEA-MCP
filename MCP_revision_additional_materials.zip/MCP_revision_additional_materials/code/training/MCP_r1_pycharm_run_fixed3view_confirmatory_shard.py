"""Run/resume one 4-fit shard of the exactly-28 three-view experiment."""

from __future__ import annotations

import argparse
import csv
import importlib.util
import json
import os
import sys
import traceback
from pathlib import Path
from time import perf_counter
from typing import Any

import pandas as pd

from MCP_r1_build_fixed3view_confirmatory_manifest import SHARD_STEM, build, build_rows


DEFAULT_SHARD_ID = 1
DEFAULT_GPU_ID = 0


def _core_helpers(project_dir: Path) -> Any:
    helper_file = project_dir / "MCP_r1_pycharm_run_core_shard.py"
    spec = importlib.util.spec_from_file_location("_fixed3_core_helpers", helper_file)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load helpers from {helper_file}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _read_manifest(path: Path, expected_index: int) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    if len(rows) != 4 or {int(row["data_index"]) for row in rows} != {expected_index}:
        raise ValueError(f"{path} must contain exactly 4 runs for data_index={expected_index}")
    expected = {
        row["run_id"]: row
        for row in build_rows()
        if int(row["data_index"]) == expected_index
    }
    observed = {row["run_id"]: row for row in rows}
    if len(observed) != 4 or set(observed) != set(expected):
        raise ValueError(
            f"{path} is stale/edited; rerun MCP_r1_build_fixed3view_confirmatory_manifest.py"
        )
    # Only environment paths, GPU and explicit force may change outside builder.
    ignored = {"data_root", "r_code", "rscript_path", "gpu_id", "force"}
    for run_id, expected_row in expected.items():
        for field, expected_value in expected_row.items():
            if field not in ignored and observed[run_id].get(field, "") != expected_value:
                raise ValueError(
                    f"Outdated/edited scientific setting {run_id}/{field}: "
                    f"{observed[run_id].get(field)!r} != {expected_value!r}"
                )
    return rows


def _write_csv_atomic(path: Path, rows: list[dict[str, Any]]) -> None:
    fields = sorted({key for row in rows for key in row}) if rows else ["run_id", "status"]
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    os.replace(temporary, path)


def _validate_full_control(
    control_dir: Path,
    bundle_metadata: dict[str, Any],
    core_script: Path,
    expected: dict[str, str],
) -> None:
    import MCP_r1_fixed4label_ablation as fixed4

    metadata_file = control_dir / "metadata.json"
    prediction_file = control_dir / "fixed4label_DP_fdr_predictions.csv"
    metrics_file = control_dir / "fixed4label_metrics.csv"
    latent_file = control_dir / "fixed4label_latent.npz"
    for path in (metadata_file, prediction_file, metrics_file, latent_file):
        if not path.is_file():
            raise FileNotFoundError(
                f"Required matched four-view control is absent: {path}. First run the "
                f"matching MCP_r1_pycharm_fixed4label_ablation_shard script."
            )
    metadata = json.loads(metadata_file.read_text(encoding="utf-8"))
    control_spec = dict(expected)
    control_spec.update(
        {
            "experiment_schema": fixed4.IMPLEMENTATION_SCHEMA_VERSION,
            "run_id": expected["fixed4_control_run_id"],
            "variant": "full_mcp",
            "model_input_views": "all4",
            "availability_policy": "selected_view_noncall",
        }
    )
    expected_model_spec = fixed4._model_spec(control_spec, bundle_metadata, core_script)
    expected_model_hash = fixed4._sha256_bytes(
        fixed4._canonical_json(expected_model_spec).encode("utf-8")
    )
    semantic_checks = {
        "status": metadata.get("status") == "completed",
        "schema": metadata.get("experiment_schema") == fixed4.IMPLEMENTATION_SCHEMA_VERSION,
        "variant": metadata.get("variant") == "full_mcp",
        "model_input_views": metadata.get("model_input_views") == "all4",
        "label_mode": metadata.get("label_mode") == "strict_shared_mask",
        "test_type": metadata.get("test_type") == "DP_fdr",
        "data_index": int(metadata.get("data_index", -1)) == int(expected["data_index"]),
        "platform": str(metadata.get("platform")) == expected["platform"],
        "dea_method": str(metadata.get("dea_method")) == expected["dea_method"],
        "seed": int(metadata.get("seed", -1)) == int(expected["seed"]),
        "runtime_seed_control": metadata.get("runtime_seed_control") is False,
        "num_trials": int(metadata.get("num_trials", -1)) == int(expected["num_trials"]),
        "q_threshold": float(metadata.get("q_threshold", -1))
        == float(expected["q_threshold"]),
        "fc_ratio": float(metadata.get("fc_ratio", -1)) == float(expected["fc_ratio"]),
        "availability_policy": metadata.get("availability_policy")
        == "selected_view_noncall",
        "model_spec_hash": metadata.get("model_spec_hash") == expected_model_hash,
        "bundle_sha256": metadata.get("bundle_sha256") == bundle_metadata["bundle_sha256"],
        "label_fingerprint": metadata.get("label_fingerprint")
        == bundle_metadata["label_fingerprint"],
        "truth_sha256": metadata.get("truth_sha256") == bundle_metadata["truth_sha256"],
        "truth_fingerprint": metadata.get("truth_fingerprint")
        == bundle_metadata["truth_fingerprint"],
        "code_fingerprints": metadata.get("code_fingerprints")
        == fixed4._code_fingerprints(core_script),
        "prediction_sha256": metadata.get("prediction_sha256")
        == fixed4.sha256_file(prediction_file),
        "metrics_sha256": metadata.get("metrics_sha256") == fixed4.sha256_file(metrics_file),
        "latent_sha256": metadata.get("latent_sha256") == fixed4.sha256_file(latent_file),
    }
    failed = [name for name, passed in semantic_checks.items() if not passed]
    if failed:
        raise ValueError(
            f"Matched four-view control is stale/incompatible ({', '.join(failed)}): "
            f"{control_dir}"
        )
    for field, value in expected_model_spec.items():
        if metadata.get(field) != value:
            raise ValueError(
                f"Matched four-view control differs from its exact model spec: "
                f"{control_dir}/{field}"
            )


def run_shard(shard_id: int, gpu_id: int, result_root: Path | None = None) -> None:
    if shard_id not in range(1, 8):
        raise ValueError(f"shard_id must be 1..7; got {shard_id}")
    if gpu_id < 0:
        raise ValueError("gpu_id must be non-negative")
    project_dir = Path(__file__).resolve().parent
    os.chdir(project_dir)
    manifest = project_dir / f"{SHARD_STEM}_{shard_id}.csv"
    if not manifest.is_file():
        build(project_dir)
    rows = _read_manifest(manifest, shard_id - 1)

    helpers = _core_helpers(project_dir)
    helpers.validate_project(project_dir, manifest)
    core_script = project_dir / "MCP_r1_mv_contrast_v6.0.3_4_linux_comb_exp_mcc2_new.py"
    root = (result_root or project_dir / "revision_results").expanduser().resolve()
    fixed4_shard = (
        root
        / "final_required"
        / "fixed4label_single_view_ablation"
        / "shards"
        / f"shard_{shard_id}"
    )
    shard_root = (
        root
        / "final_required"
        / "fixed3view_confirmatory"
        / "shards"
        / f"shard_{shard_id}"
    )
    shard_root.mkdir(parents=True, exist_ok=True)

    # CUDA must be selected before importing the core/torch.
    os.environ["CUDA_VISIBLE_DEVICES"] = str(gpu_id)
    os.environ["MCP_VERBOSE_TRAIN"] = "0"
    if str(project_dir) not in sys.path:
        sys.path.insert(0, str(project_dir))
    import MCP_r1_fixed4label_ablation as fixed4
    from MCP_r1_fixed3view_confirmatory import _validate_bundle, run_fixed3view_model

    # Preflight every prerequisite before fitting any of the four new models.
    prerequisites: dict[str, tuple[Path, Path]] = {}
    preflight_errors: list[str] = []
    for row in rows:
        bundle_dir = (
            fixed4_shard
            / "bundles"
            / f"i{row['data_index']}_{row['platform']}_{row['dea_method']}"
        )
        control_dir = fixed4_shard / "runs" / row["fixed4_control_run_id"]
        try:
            bundle_metadata = _validate_bundle(bundle_dir, core_script)
            _validate_full_control(control_dir, bundle_metadata, core_script, row)
            prerequisites[row["run_id"]] = (bundle_dir, control_dir)
        except Exception as exc:
            preflight_errors.append(f"{row['run_id']}: {exc}")
    if preflight_errors:
        raise RuntimeError(
            "No three-view model was started because prerequisite fixed4 artifacts failed QC:\n  "
            + "\n  ".join(preflight_errors)
        )

    core = fixed4.load_core(core_script)
    ledger: list[dict[str, Any]] = []
    prediction_rows: list[dict[str, Any]] = []
    metrics_frames: list[pd.DataFrame] = []
    failures: list[str] = []
    ledger_path = shard_root / "core_run_ledger.csv"
    for row in rows:
        bundle_dir, control_dir = prerequisites[row["run_id"]]
        run_dir = shard_root / "runs" / row["run_id"]
        started = perf_counter()
        try:
            artifact = run_fixed3view_model(row, core, core_script, bundle_dir, run_dir)
            record = {
                **row,
                **artifact,
                "matched_fixed4_control_dir": str(control_dir),
                "stage": "run",
                "runner_runtime_seconds": round(perf_counter() - started, 3),
            }
            ledger.append(record)
            prediction_path = Path(artifact["prediction_file"]).resolve()
            metrics_path = Path(artifact["metrics_file"]).resolve()
            if not prediction_path.is_file() or not metrics_path.is_file():
                raise FileNotFoundError("Completed run did not produce prediction/metrics files")
            prediction_rows.append(
                {
                    "run_id": row["run_id"],
                    "fixed4_control_run_id": row["fixed4_control_run_id"],
                    "dataset": artifact["dataset"],
                    "data_index": artifact["data_index"],
                    "platform": artifact["platform"],
                    "dea_method": artifact["dea_method"],
                    "variant": "three_view_mcp",
                    "core_model_variant": "full_mcp",
                    "model_input_views": artifact["model_input_views"],
                    "label_mode": artifact["label_mode"],
                    "test_type": "DP_fdr",
                    "seed": int(row["seed"]),
                    "prediction_file": str(prediction_path),
                    "prediction_file_relative": str(
                        prediction_path.relative_to(shard_root.parent.parent)
                    ),
                    "run_metadata_file": artifact["run_metadata_file"],
                    "matched_fixed4_control_dir": str(control_dir),
                    "protein_column": "Protein",
                    "truth_column": "True_lab",
                    "score_column": "DP_fdr_probability",
                    "called_column": "called_DP_fdr",
                    "log2fc_column": "shared_full_log2fc",
                    "label_fingerprint": artifact["label_fingerprint"],
                }
            )
            metrics_frames.append(pd.read_csv(metrics_path))
        except Exception as exc:
            detail = "".join(traceback.format_exception_only(type(exc), exc)).strip()
            failures.append(f"{row['run_id']}: {detail}")
            ledger.append(
                {
                    **row,
                    "status": "error",
                    "stage": "run",
                    "error": detail,
                    "runner_runtime_seconds": round(perf_counter() - started, 3),
                }
            )
        finally:
            _write_csv_atomic(ledger_path, ledger)

    pd.DataFrame(prediction_rows).to_csv(
        shard_root / "generated_prediction_manifest.csv", index=False
    )
    if metrics_frames:
        pd.concat(metrics_frames, ignore_index=True, sort=False).to_csv(
            shard_root / "generated_performance_wide.csv", index=False
        )
    else:
        pd.DataFrame().to_csv(shard_root / "generated_performance_wide.csv", index=False)
    if len(ledger) != 4:
        failures.append(f"expected 4 ledger rows, found {len(ledger)}")
    if len(prediction_rows) != 4:
        failures.append(f"expected 4 completed prediction rows, found {len(prediction_rows)}")
    if failures:
        raise RuntimeError("Fixed3view shard completed with failures:\n  " + "\n  ".join(failures))
    print(
        f"SHARD {shard_id} COMPLETED: 4/4 new three-view fits; output={shard_root}",
        flush=True,
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--shard-id", type=int, default=DEFAULT_SHARD_ID)
    parser.add_argument("--gpu-id", type=int, default=DEFAULT_GPU_ID)
    parser.add_argument("--result-root", type=Path, default=None)
    args = parser.parse_args()
    run_shard(args.shard_id, args.gpu_id, args.result_root)


if __name__ == "__main__":
    main()
