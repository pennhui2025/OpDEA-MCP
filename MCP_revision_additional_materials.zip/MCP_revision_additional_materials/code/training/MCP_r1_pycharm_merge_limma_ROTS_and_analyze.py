"""Merge seven 48-run limma+ROTS shards and execute tasks 1 and 2.

七个 ``MCP_r1_pycharm_limma_ROTS_shard_*`` 均完成后，在 PyCharm 中直接运行。
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pandas as pd


PROJECT_DIR = Path(__file__).resolve().parent
RESULT_ROOT = PROJECT_DIR / "revision_results"


def run(command: list[str], label: str) -> None:
    print(f"\n=== {label} ===", flush=True)
    subprocess.run(command, cwd=PROJECT_DIR, check=True)


def main() -> None:
    merged = RESULT_ROOT / "task1_2_core_merged_limma_ROTS"
    task1 = RESULT_ROOT / "task1_fair_baseline_limma_ROTS"
    task2 = RESULT_ROOT / "task2_ranking_threshold_limma_ROTS"
    prediction_manifest = merged / "generated_prediction_manifest.csv"

    run(
        [
            sys.executable,
            str(PROJECT_DIR / "MCP_r1_merge_task1_2_shards.py"),
            "--shards-root", str(RESULT_ROOT / "task1_2_shards"),
            "--output-dir", str(merged),
            "--master-manifest",
            str(PROJECT_DIR / "MCP_r1_task1_2_DIA_limma_ROTS_manifest.csv"),
            "--expected-shards", "7",
        ],
        "Merge and validate 336 limma+ROTS runs",
    )
    run(
        [
            sys.executable,
            str(PROJECT_DIR / "MCP_r1_fair_baseline_benchmark.py"),
            "--manifest", str(prediction_manifest),
            "--output-dir", str(task1),
            "--fdr-thresholds", "0.01,0.05,0.10",
            "--fc-ratios", "1.0,1.2,1.5",
            "--primary-fdr", "0.05",
            "--primary-fc", "1.5",
            "--reference-method", "full_mcp",
            "--bootstrap", "2000",
            "--seed", "2024",
        ],
        "Task 1 stratified by DEA method",
    )
    run(
        [
            sys.executable,
            str(PROJECT_DIR / "MCP_r1_ranking_threshold_analysis.py"),
            "--manifest", str(prediction_manifest),
            "--output-dir", str(task2),
            "--validation-fraction", "0.30",
            "--calibration-bins", "10",
            "--seed", "2024",
        ],
        "Task 2 stratified by DEA method",
    )

    ledger = pd.read_csv(merged / "core_run_ledger.csv")
    if len(ledger) != 336 or not ledger["run_id"].is_unique:
        raise RuntimeError("Merged ledger must contain 336 unique runs")
    for audit_path in (task1 / "input_audit.csv", task2 / "input_audit.csv"):
        audit = pd.read_csv(audit_path)
        errors = audit[audit["status"].astype(str).str.lower().eq("error")]
        if not errors.empty:
            raise RuntimeError(f"{audit_path} contains {len(errors)} errors")

    print("\nLIMMA + ROTS TASK 1/2 COMPLETED", flush=True)


if __name__ == "__main__":
    main()
