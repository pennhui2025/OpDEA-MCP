"""Merge and validate all seven reviewer Task 3-5 workers.

Run this once after all seven ``MCP_r1_pycharm_remaining_tasks_shard_*`` files
finish.  It performs no model retraining.
"""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pandas as pd


PROJECT_DIR = Path(__file__).resolve().parent
RESULT_ROOT = PROJECT_DIR / "revision_results"
SHARDS_ROOT = RESULT_ROOT / "remaining_tasks_shards"
OUTPUT_DIR = RESULT_ROOT / "remaining_tasks_merged"
PLATFORMS = ("DIANN", "Spectronaut")
DEA_METHODS = ("limma", "ROTS")
TASK3_FILES = (
    "pseudo_label_summary.csv",
    "pseudo_label_pairwise_stability.csv",
    "downstream_prediction_robustness.csv",
    "pseudo_label_strategy_run_eligibility.csv",
)
TASK4_FILES = (
    "view_quality_summary.csv",
    "pairwise_complementarity.csv",
    "pairwise_unique_dep_truth.csv",
    "complementarity_vs_incremental_gain.csv",
    "input_audit.csv",
)
TASK5_VARIANTS = (
    "full_mcp",
    "simple_early_fusion",
    "simple_late_fusion",
    "rank_or_pvalue_fusion",
    "no_balancing",
    "no_contrastive",
    "no_cross_attention",
)


def read_required(path: Path) -> pd.DataFrame:
    if not path.is_file():
        raise FileNotFoundError(path)
    try:
        return pd.read_csv(path)
    except pd.errors.EmptyDataError:
        return pd.DataFrame()


def add_metadata(
    frame: pd.DataFrame,
    shard_id: int,
    platform: str | None = None,
    dea_method: str | None = None,
) -> pd.DataFrame:
    frame = frame.copy()
    frame.insert(0, "source_shard", shard_id)
    if "data_index" in frame.columns:
        values = pd.to_numeric(frame["data_index"], errors="coerce")
        if not values.eq(shard_id - 1).all():
            raise ValueError(f"Unexpected data_index values in shard {shard_id}")
    else:
        frame.insert(1, "data_index", shard_id - 1)
    if platform is not None:
        if "platform" in frame.columns:
            if not frame["platform"].astype(str).eq(platform).all():
                raise ValueError(f"Unexpected platform values in shard {shard_id}/{platform}")
        else:
            frame.insert(2, "platform", platform)
    if dea_method is not None:
        if "dea_method" in frame.columns:
            if not frame["dea_method"].astype(str).eq(dea_method).all():
                raise ValueError(f"Unexpected DEA values in shard {shard_id}/{dea_method}")
        else:
            location = 3 if "platform" in frame.columns else 2
            frame.insert(location, "dea_method", dea_method)
    return frame


def validate_core_ledger(ledger: pd.DataFrame, label: str, expected: int | None = None) -> None:
    if expected is not None and len(ledger) != expected:
        raise ValueError(f"{label} must contain {expected} rows; found {len(ledger)}")
    if ledger.empty:
        raise ValueError(f"{label} is empty")
    errors = ledger[ledger["status"].astype(str).eq("error")]
    if not errors.empty:
        examples = errors.get("message", pd.Series(dtype=str)).astype(str).head(3).tolist()
        raise RuntimeError(f"{label} contains {len(errors)} failures: {examples}")
    invalid = ledger[
        ~ledger["status"].astype(str).isin(["completed", "skipped_existing"])
    ]
    if not invalid.empty:
        raise RuntimeError(f"{label} contains unfinished rows")


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    task3_collected: dict[str, list[pd.DataFrame]] = {
        name: [] for name in TASK3_FILES
    }
    task3_ledgers: list[pd.DataFrame] = []
    task3_predictions: list[pd.DataFrame] = []
    task4_collected: dict[str, list[pd.DataFrame]] = {
        name: [] for name in TASK4_FILES
    }
    task5_ledgers: list[pd.DataFrame] = []
    task5_ablations: list[pd.DataFrame] = []
    shard_audit: list[dict[str, object]] = []

    for shard_id in range(1, 8):
        shard_dir = SHARDS_ROOT / f"shard_{shard_id}"
        status_path = shard_dir / "remaining_tasks_status.json"
        if not status_path.is_file():
            raise FileNotFoundError(status_path)
        status = json.loads(status_path.read_text(encoding="utf-8"))
        if status.get("stage") != "all" or status.get("status") != "complete":
            raise RuntimeError(f"shard_{shard_id} is not complete: {status}")

        task3_run_count = 0
        task3_strategy_count = 0
        for platform in PLATFORMS:
            for dea_method in DEA_METHODS:
                stratum = shard_dir / "task3_pseudo_label" / platform / dea_method
                summary = read_required(stratum / "pseudo_label_summary.csv")
                if len(summary) != 24 or summary["strategy"].astype(str).nunique() != 24:
                    raise ValueError(
                        f"shard_{shard_id}/{platform}/{dea_method} must contain "
                        "24 Task 3 label strategies"
                    )
                task3_strategy_count += len(summary)
                for name in TASK3_FILES:
                    task3_collected[name].append(
                        add_metadata(
                            read_required(stratum / name),
                            shard_id,
                            platform,
                            dea_method,
                        )
                    )
                ledger = read_required(stratum / "core_experiments" / "core_run_ledger.csv")
                validate_core_ledger(
                    ledger, f"Task 3 shard_{shard_id}/{platform}/{dea_method}"
                )
                task3_run_count += len(ledger)
                task3_ledgers.append(add_metadata(ledger, shard_id, platform, dea_method))
                task3_predictions.append(
                    add_metadata(
                        read_required(
                            stratum
                            / "core_experiments"
                            / "generated_prediction_manifest.csv"
                        ),
                        shard_id,
                        platform,
                        dea_method,
                    )
                )

        task4_dir = shard_dir / "task4_view_complementarity"
        task4_pairs = read_required(task4_dir / "pairwise_complementarity.csv")
        if len(task4_pairs) != 24:
            raise ValueError(f"shard_{shard_id} Task 4 must have 24 pair rows")
        for name in TASK4_FILES:
            task4_collected[name].append(
                add_metadata(read_required(task4_dir / name), shard_id)
            )

        task5_dir = shard_dir / "task5_deep_ablation_core"
        task5_ledger = read_required(task5_dir / "core_run_ledger.csv")
        validate_core_ledger(task5_ledger, f"Task 5 shard_{shard_id}", expected=12)
        task5_ledgers.append(add_metadata(task5_ledger, shard_id))
        task5_ablation = read_required(task5_dir / "generated_ablation_manifest.csv")
        if len(task5_ablation) != 12:
            raise ValueError(f"shard_{shard_id} Task 5 must have 12 ablation rows")
        task5_ablations.append(add_metadata(task5_ablation, shard_id))
        shard_audit.append(
            {
                "shard": shard_id,
                "data_index": shard_id - 1,
                "status": "ok",
                "task3_label_strategy_rows": task3_strategy_count,
                "task3_core_runs": task3_run_count,
                "task4_pair_rows": len(task4_pairs),
                "task5_new_core_runs": len(task5_ledger),
            }
        )

    task3_output = OUTPUT_DIR / "task3_pseudo_label_robustness"
    task3_output.mkdir(parents=True, exist_ok=True)
    for name, frames in task3_collected.items():
        pd.concat(frames, ignore_index=True, sort=False).to_csv(
            task3_output / name, index=False
        )
    merged_task3_ledger = pd.concat(task3_ledgers, ignore_index=True, sort=False)
    merged_task3_ledger.to_csv(task3_output / "task3_core_run_ledger.csv", index=False)
    pd.concat(task3_predictions, ignore_index=True, sort=False).to_csv(
        task3_output / "task3_generated_prediction_manifest.csv", index=False
    )

    task4_output = OUTPUT_DIR / "task4_view_complementarity"
    task4_output.mkdir(parents=True, exist_ok=True)
    for name, frames in task4_collected.items():
        pd.concat(frames, ignore_index=True, sort=False).to_csv(
            task4_output / name, index=False
        )

    task5_output = OUTPUT_DIR / "task5_model_complexity"
    task5_output.mkdir(parents=True, exist_ok=True)
    new_ledger = pd.concat(task5_ledgers, ignore_index=True, sort=False)
    if len(new_ledger) != 84 or not new_ledger["run_id"].astype(str).is_unique:
        raise ValueError("Merged Task 5 incremental ledger must contain 84 unique runs")
    new_ledger.to_csv(task5_output / "task5_new_core_run_ledger.csv", index=False)
    new_ablations = pd.concat(task5_ablations, ignore_index=True, sort=False)

    existing_path = (
        RESULT_ROOT
        / "task1_2_core_merged_limma_ROTS"
        / "generated_ablation_manifest.csv"
    )
    existing = read_required(existing_path)
    existing = existing[
        existing["variant"].astype(str).isin(TASK5_VARIANTS[:4])
        & existing["view_set"].astype(str).eq("dlfq+maxlfq+top3+top1")
    ].copy()
    if len(existing) != 112:
        raise ValueError(
            "Completed Task 1/2 should provide 28 strata x 4 existing "
            f"four-view controls = 112 rows; found {len(existing)}"
        )
    combined = pd.concat(
        [existing, new_ablations.drop(columns=["source_shard", "data_index"], errors="ignore")],
        ignore_index=True,
        sort=False,
    )
    combined = combined[combined["variant"].astype(str).isin(TASK5_VARIANTS)].copy()
    coverage = combined.groupby(
        ["dataset", "platform", "dea_method", "variant"], dropna=False
    ).size()
    if len(combined) != 196 or len(coverage) != 196 or not coverage.eq(1).all():
        raise ValueError(
            "Task 5 combined manifest must contain one row for each of "
            "7 datasets x 2 platforms x 2 DEA x 7 variants"
        )
    combined_manifest = task5_output / "task5_combined_ablation_manifest.csv"
    combined.to_csv(combined_manifest, index=False)

    subprocess.run(
        [
            sys.executable,
            str(PROJECT_DIR / "MCP_r1_model_complexity_ablation.py"),
            "--result-manifest", str(combined_manifest),
            "--output-dir", str(task5_output),
            "--bootstrap", "2000",
            "--seed", "2024",
        ],
        cwd=PROJECT_DIR,
        check=True,
    )
    task5_audit = read_required(task5_output / "input_audit.csv")
    if task5_audit["status"].astype(str).str.lower().eq("error").any():
        raise RuntimeError("Task 5 combined result manifest contains unreadable entries")

    pd.DataFrame(shard_audit).to_csv(
        OUTPUT_DIR / "remaining_tasks_merge_audit.csv", index=False
    )
    summary = {
        "status": "complete",
        "shards": 7,
        "task3_strata": 28,
        "task3_label_strategy_rows": 28 * 24,
        "task3_core_runs": len(merged_task3_ledger),
        "task4_pair_rows": sum(len(frame) for frame in task4_collected["pairwise_complementarity.csv"]),
        "task5_new_core_runs": len(new_ledger),
        "task5_combined_ablation_rows": len(combined),
        "task3_output": str(task3_output),
        "task4_output": str(task4_output),
        "task5_output": str(task5_output),
    }
    (OUTPUT_DIR / "remaining_tasks_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print("\nTASKS 3-5 MERGE AND VALIDATION COMPLETED", flush=True)
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
