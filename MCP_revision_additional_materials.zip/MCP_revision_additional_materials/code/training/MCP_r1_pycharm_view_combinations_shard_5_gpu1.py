"""Run missing DIA 2/3-view combinations for data index 4 on physical GPU 1."""
from pathlib import Path
from MCP_r1_pycharm_run_core_shard import run_shard

def main() -> None:
    run_shard(
        5, 1, Path(__file__).resolve().parent / "revision_results",
        manifest_stem="MCP_r1_DIA_view_combinations_limma_ROTS_incremental_shard",
        output_group="view_combination_incremental_shards",
        validation_profile="view_combination_incremental",
    )

if __name__ == "__main__":
    main()

