"""Build the exactly-28-run targeted fixed-supervision three-view experiment.

Edit ``THREE_VIEWS`` *before the first run* if a different single global
combination is scientifically justified, then run this builder once.  Do not
choose a different combination per dataset. / 如需更换唯一的全局三视图组合，
必须在首次运行前修改 THREE_VIEWS 并重新生成全部 manifest。
"""

from __future__ import annotations

import argparse
import csv
from pathlib import Path

from MCP_r1_fixed3view_confirmatory import IMPLEMENTATION_SCHEMA_VERSION, SOURCE_VIEWS


# 唯一需要修改的视图设置。默认删除 top1；总训练数始终为 28。
THREE_VIEWS = ("dlfq", "maxlfq", "top3")
PLATFORMS = ("DIANN", "Spectronaut")
DEA_METHODS = ("limma", "ROTS")
GROUPS = (("A", "B"), ("A", "C"), ("B", "E"), ("B", "E"), ("B", "D"), ("A", "C"), ("A", "B"))
MASTER_NAME = "MCP_r1_fixed3view_confirmatory_manifest.csv"
SHARD_STEM = "MCP_r1_fixed3view_confirmatory_shard"
FIELDS = [
    "experiment_schema", "run_id", "fixed4_control_run_id", "dataset", "acquisition",
    "platform", "data_index", "group1", "group2", "source_views", "model_input_views",
    "variant", "core_model_variant", "dea_method", "log_transforms", "normalizations",
    "imputations", "data_root", "r_code", "rscript_path", "gpu_id", "seed",
    "runtime_seed_control", "num_trials", "q_threshold", "fc_ratio", "positive_strategy",
    "label_mode", "availability_policy", "shared_fc_policy", "analysis_role", "test_type",
    "force",
]


def validate_view_choice() -> tuple[str, ...]:
    selected = tuple(str(view).strip().lower() for view in THREE_VIEWS)
    if len(selected) != 3 or len(set(selected)) != 3:
        raise ValueError(f"THREE_VIEWS must contain exactly three distinct views; got {selected}")
    if any(view not in SOURCE_VIEWS for view in selected):
        raise ValueError(f"THREE_VIEWS must be selected from {SOURCE_VIEWS}; got {selected}")
    canonical = tuple(view for view in SOURCE_VIEWS if view in set(selected))
    if selected != canonical:
        raise ValueError(
            f"Keep THREE_VIEWS in canonical order {SOURCE_VIEWS}; use {canonical}, not {selected}"
        )
    return selected


def build_rows() -> list[dict[str, str]]:
    """Create 28 fits: 7 datasets x 2 platforms x 2 DEA x one 3-view MCP."""
    selected = validate_view_choice()
    view_string = "+".join(selected)
    view_slug = "-".join(selected)
    rows: list[dict[str, str]] = []
    for data_index, (group1, group2) in enumerate(GROUPS):
        for platform in PLATFORMS:
            for dea_method in DEA_METHODS:
                dea_slug = dea_method.lower()
                rows.append(
                    {
                        "experiment_schema": IMPLEMENTATION_SCHEMA_VERSION,
                        "run_id": (
                            f"DIA_{platform}_i{data_index}_fixed4label_3v_"
                            f"{view_slug}_{dea_slug}"
                        ),
                        "fixed4_control_run_id": (
                            f"DIA_{platform}_i{data_index}_fixed4_all4_{dea_slug}"
                        ),
                        "dataset": f"AUTO_INDEX_{data_index}",
                        "acquisition": "DIA",
                        "platform": platform,
                        "data_index": str(data_index),
                        "group1": group1,
                        "group2": group2,
                        "source_views": "+".join(SOURCE_VIEWS),
                        "model_input_views": view_string,
                        "variant": "three_view_mcp",
                        "core_model_variant": "full_mcp",
                        "dea_method": dea_method,
                        "log_transforms": "T+F+F+F",
                        "normalizations": "",
                        "imputations": "",
                        "data_root": "data",
                        "r_code": "codes",
                        "rscript_path": "/usr/lib/R/bin/",
                        "gpu_id": "",
                        "seed": "2024",
                        # Preserve manuscript split seeds: model=1029, Optuna=2023.
                        "runtime_seed_control": "FALSE",
                        "num_trials": "30",
                        "q_threshold": "0.05",
                        "fc_ratio": "1.5",
                        "positive_strategy": "0_h",
                        "label_mode": "strict_shared_mask",
                        "availability_policy": "selected_views_union_noncall",
                        # Deliberately isolates classifier inputs; this is not a
                        # standalone three-view end-to-end pipeline.
                        "shared_fc_policy": "fixed_four_view_log2fc",
                        "analysis_role": "fixed_supervision_input_view_ablation",
                        "test_type": "DP_fdr",
                        "force": "FALSE",
                    }
                )
    return rows


def validate_rows(rows: list[dict[str, str]]) -> None:
    selected = "+".join(validate_view_choice())
    if len(rows) != 28:
        raise ValueError(f"Expected exactly 28 rows; found {len(rows)}")
    run_ids = [row["run_id"] for row in rows]
    if len(run_ids) != len(set(run_ids)):
        raise ValueError("run_id values must be unique")
    for data_index in range(7):
        shard = [row for row in rows if row["data_index"] == str(data_index)]
        if len(shard) != 4:
            raise ValueError(f"data_index={data_index} must have exactly 4 rows")
        observed = {(row["platform"], row["dea_method"]) for row in shard}
        expected = {(platform, dea) for platform in PLATFORMS for dea in DEA_METHODS}
        if observed != expected:
            raise ValueError(f"Incomplete platform x DEA design for data_index={data_index}")
    immutable_expected = {
        "acquisition": "DIA",
        "source_views": "+".join(SOURCE_VIEWS),
        "model_input_views": selected,
        "variant": "three_view_mcp",
        "core_model_variant": "full_mcp",
        "label_mode": "strict_shared_mask",
        "availability_policy": "selected_views_union_noncall",
        "shared_fc_policy": "fixed_four_view_log2fc",
        "analysis_role": "fixed_supervision_input_view_ablation",
        "test_type": "DP_fdr",
    }
    for row in rows:
        for field, value in immutable_expected.items():
            if row[field] != value:
                raise ValueError(f"Invalid {field} for {row['run_id']}: {row[field]!r}")


def write_csv(path: Path, rows: list[dict[str, str]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(rows)


def build(output_dir: Path) -> list[Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    rows = build_rows()
    validate_rows(rows)
    paths = [output_dir / MASTER_NAME]
    write_csv(paths[0], rows)
    for shard_id in range(1, 8):
        shard_rows = [row for row in rows if row["data_index"] == str(shard_id - 1)]
        path = output_dir / f"{SHARD_STEM}_{shard_id}.csv"
        write_csv(path, shard_rows)
        paths.append(path)
    return paths


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent)
    paths = build(parser.parse_args().output_dir.resolve())
    print(f"Selected global three-view set: {'+'.join(validate_view_choice())}")
    print("New model fits: 28 (7 shards x 4 fits); four-view controls are not rerun")
    for path in paths:
        print(path)


if __name__ == "__main__":
    main()
