from pathlib import Path
from MCP_r1_pycharm_run_fixed3view_confirmatory_shard import run_shard

if __name__ == "__main__":
    run_shard(3, 0, Path(__file__).resolve().parent / "revision_results")
