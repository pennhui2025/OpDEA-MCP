"""Run external-data reviewer Tasks 6 and 7 after their real inputs are supplied.

This entry intentionally refuses missing/placeholder inputs.  Clinical and
IFNG validation cannot be reconstructed from the seven benchmark DIA datasets.
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

import pandas as pd


PROJECT_DIR = Path(__file__).resolve().parent
DEFAULT_OUTPUT = PROJECT_DIR / "revision_results" / "remaining_tasks_merged"


def resolve_path(value: object, label: str, required: bool = False) -> Path | None:
    if value is None or not str(value).strip():
        if required:
            raise ValueError(f"External configuration requires '{label}'")
        return None
    path = Path(str(value)).expanduser()
    path = path.resolve() if path.is_absolute() else (PROJECT_DIR / path).resolve()
    if not path.is_file():
        raise FileNotFoundError(f"{label}: {path}")
    return path


def append_path(command: list[str], option: str, path: Path | None) -> None:
    if path is not None:
        command.extend([option, str(path)])


def run(command: list[str], label: str) -> None:
    print(f"\n=== {label} ===", flush=True)
    subprocess.run(command, cwd=PROJECT_DIR, check=True)


def task6_command(config: dict, output_root: Path) -> list[str]:
    classification = resolve_path(
        config.get("classification_manifest"), "task6.classification_manifest"
    )
    features = resolve_path(config.get("feature_manifest"), "task6.feature_manifest")
    survival = resolve_path(config.get("survival_file"), "task6.survival_file")
    if classification is None and features is None and survival is None:
        raise ValueError(
            "Task 6 requires a real classification manifest, feature manifest, "
            "or patient-level survival table."
        )
    command = [
        sys.executable,
        str(PROJECT_DIR / "MCP_r1_clinical_validation_analysis.py"),
        "--output-dir", str(output_root / "task6_clinical_validation"),
        "--score-threshold", str(config.get("score_threshold", 0.5)),
        "--bootstrap", str(config.get("bootstrap", 2000)),
        "--seed", str(config.get("seed", 2024)),
        "--time-column", str(config.get("time_column", "time")),
        "--event-column", str(config.get("event_column", "event")),
        "--covariates", str(config.get("covariates", "")),
    ]
    append_path(command, "--classification-manifest", classification)
    append_path(command, "--feature-manifest", features)
    append_path(command, "--survival-file", survival)
    survival_protein_file = resolve_path(
        config.get("survival_protein_file"), "task6.survival_protein_file"
    )
    append_path(command, "--survival-protein-file", survival_protein_file)
    if str(config.get("survival_proteins", "")).strip():
        command.extend(["--survival-proteins", str(config["survival_proteins"])])
    return command


def task7_command(config: dict, output_root: Path) -> list[str]:
    ranking = resolve_path(
        config.get("ranking_manifest"), "task7.ranking_manifest", required=True
    )
    supported = resolve_path(
        config.get("supported_proteins"), "task7.supported_proteins", required=True
    )
    gmt = resolve_path(config.get("gmt"), "task7.gmt", required=True)
    manifest = pd.read_csv(ranking)
    required = {"method", "result_file", "protein_column", "score_column"}
    missing = sorted(required - set(manifest.columns))
    if missing:
        raise ValueError(f"Task 7 ranking manifest is missing columns: {missing}")
    dataset = (
        manifest["dataset"].fillna("IFNG").astype(str)
        if "dataset" in manifest.columns
        else pd.Series(["IFNG"] * len(manifest))
    )
    duplicate = pd.DataFrame(
        {"dataset": dataset, "method": manifest["method"].astype(str)}
    ).duplicated()
    if duplicate.any():
        raise ValueError(
            "Task 7 ranking manifest has duplicate dataset/method rows. "
            "Use unique external cohort labels for bulk and single-cell resources."
        )
    command = [
        sys.executable,
        str(PROJECT_DIR / "MCP_r1_ifng_pathway_validation.py"),
        "--ranking-manifest", str(ranking),
        "--supported-proteins", str(supported),
        "--gmt", str(gmt),
        "--output-dir", str(output_root / "task7_ifng_pathway_validation"),
        "--q-threshold", str(config.get("q_threshold", 0.05)),
        "--fc-ratio", str(config.get("fc_ratio", 1.5)),
        "--universe-policy", str(config.get("universe_policy", "common")),
        "--permutations", str(config.get("permutations", 1000)),
        "--min-pathway-size", str(config.get("min_pathway_size", 10)),
        "--max-pathway-size", str(config.get("max_pathway_size", 500)),
        "--gsea-weight", str(config.get("gsea_weight", 1.0)),
        "--seed", str(config.get("seed", 2024)),
    ]
    if str(config.get("supported_protein_column", "")).strip():
        command.extend(
            ["--supported-protein-column", str(config["supported_protein_column"])]
        )
    if config.get("matched_list_size") not in (None, ""):
        command.extend(["--matched-list-size", str(config["matched_list_size"])])
    if config.get("fallback_top_n") not in (None, ""):
        command.extend(["--fallback-top-n", str(config["fallback_top_n"])])
    return command


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_DIR / "MCP_r1_external_tasks_6_7_config.json",
    )
    parser.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    config_path = args.config.expanduser().resolve()
    if not config_path.is_file():
        raise FileNotFoundError(
            f"{config_path}\nCopy MCP_r1_external_tasks_6_7_config.example.json "
            "to that name, then fill in real external-data paths."
        )
    config = json.loads(config_path.read_text(encoding="utf-8"))
    output_root = args.output_root.expanduser().resolve()
    output_root.mkdir(parents=True, exist_ok=True)
    performed = False
    task6 = config.get("task6", {})
    if bool(task6.get("enabled", False)):
        run(task6_command(task6, output_root), "Task 6: clinical validation")
        performed = True
    task7 = config.get("task7", {})
    if bool(task7.get("enabled", False)):
        run(task7_command(task7, output_root), "Task 7: IFNG pathway validation")
        performed = True
    if not performed:
        raise ValueError(
            "No external task is enabled. Set task6.enabled and/or task7.enabled "
            "to true only after supplying the corresponding real files."
        )
    print("\nENABLED EXTERNAL TASKS COMPLETED", flush=True)


if __name__ == "__main__":
    main()
