"""Shared utilities for the final NC revision experiments.

The downloaded ledgers contain absolute Linux paths.  These helpers rebase
those paths onto either the local canonical results tree or the corresponding
Linux results tree without silently choosing an unrelated file.
"""

from __future__ import annotations

import itertools
import os
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd


PROJECT_DIR = Path(__file__).resolve().parent
DEFAULT_RESULTS_ROOT = PROJECT_DIR / "revision_results" / "revision_results" / "revision_results"

# The core writer concatenates result blocks in this exact order:
# DP_direct, DP_05, DP_vote, DP_fdr.  pandas keeps the first column name and
# appends .1/.2/.3 to later duplicate names.  The manuscript/Fig. 2 definition
# of MCP is the fourth block (DP_fdr), not the first DP_direct block.
MCP_RESULT_BLOCK_SUFFIX = {
    "DP_direct": "",
    "DP_05": ".1",
    "DP_vote": ".2",
    "DP_fdr": ".3",
}


def _existing_path(path: Path) -> Path | None:
    """Return an existing path, adding the Windows long-path prefix if needed."""

    if path.exists():
        return path.resolve()
    if os.name == "nt":
        absolute = str(path.absolute())
        if not absolute.startswith("\\\\?\\"):
            long_path = Path("\\\\?\\" + absolute)
            if long_path.exists():
                return long_path
    return None


def resolve_results_root(value: str | Path | None = None) -> Path:
    root = Path(value).expanduser().resolve() if value else DEFAULT_RESULTS_ROOT.resolve()
    if not root.exists():
        raise FileNotFoundError(
            f"Results root does not exist: {root}\n"
            "Use --results-root to point to the directory containing "
            "task1_2_shards, remaining_tasks_merged, etc."
        )
    return root


def rebase_recorded_path(value: object, results_root: Path) -> Path:
    """Map a path stored on Linux to the downloaded/local results directory."""

    raw = str(value).strip()
    if not raw:
        raise FileNotFoundError("The ledger contains an empty artifact path")
    direct = Path(raw).expanduser()
    existing = _existing_path(direct)
    if existing is not None:
        return existing

    normal = raw.replace("\\", "/")
    marker = "/revision_results/"
    if marker in normal:
        suffix = normal.rsplit(marker, 1)[1]
        candidate = results_root / Path(*suffix.split("/"))
        existing = _existing_path(candidate)
        if existing is not None:
            return existing

    # Some manifests store a path starting at task1_2_shards rather than at
    # revision_results.  Only accept an exact suffix under the requested root.
    for anchor in (
        "task1_2_shards/",
        "view_combination_incremental_shards/",
        "remaining_tasks_shards/",
        "multiseed_stability_shards/",
    ):
        if anchor in normal:
            suffix = normal[normal.index(anchor) :]
            candidate = results_root / Path(*suffix.split("/"))
            existing = _existing_path(candidate)
            if existing is not None:
                return existing

    raise FileNotFoundError(
        f"Cannot rebase recorded path onto {results_root}:\n  {raw}"
    )


def extract_mcp_result_block(
    frame: pd.DataFrame,
    test_type: str = "DP_fdr",
) -> pd.DataFrame:
    """Extract one named MCP block from a combined ``*_DP_res_all.csv``.

    ``DP_fdr`` is the canonical MCP result used by the manuscript's Fig. 2.
    ``DP_direct`` and ``DP_05`` remain available only as explicitly named
    diagnostic/sensitivity operating rules.
    """

    if test_type not in MCP_RESULT_BLOCK_SUFFIX:
        raise ValueError(
            f"Unknown MCP result row {test_type!r}; expected one of "
            f"{sorted(MCP_RESULT_BLOCK_SUFFIX)}"
        )
    suffix = MCP_RESULT_BLOCK_SUFFIX[test_type]
    source = {
        "Protein": f"Protein{suffix}",
        "Probability": f"Probability{suffix}",
        "ori_logFC": f"ori_logFC{suffix}",
        "rec_logFC": f"rec_logFC{suffix}",
        "label_pred": f"label_pred{suffix}",
        "qvalue": f"qvalue{suffix}",
        "threshold": f"threshold{suffix}",
    }
    missing = [column for column in source.values() if column not in frame.columns]
    if missing:
        raise ValueError(
            f"Combined prediction table lacks the {test_type} block columns {missing}. "
            f"Available columns include {list(frame.columns)}"
        )
    output = frame[["True_lab", *source.values()]].copy()
    output = output.rename(columns={value: key for key, value in source.items()})
    output.insert(0, "mcp_test_type", test_type)
    return output


def bh_adjust(values: Iterable[float]) -> np.ndarray:
    p = np.asarray(list(values), dtype=float)
    out = np.full(p.shape, np.nan, dtype=float)
    valid = np.isfinite(p)
    if not valid.any():
        return out
    pv = p[valid]
    order = np.argsort(pv)
    ranked = pv[order]
    adjusted = ranked * len(ranked) / np.arange(1, len(ranked) + 1)
    adjusted = np.minimum.accumulate(adjusted[::-1])[::-1]
    adjusted = np.clip(adjusted, 0.0, 1.0)
    restored = np.empty_like(adjusted)
    restored[order] = adjusted
    out[valid] = restored
    return out


def exact_signflip_p(differences: Iterable[float]) -> float:
    """Two-sided exact sign-flip P value for the mean paired difference."""

    d = np.asarray(list(differences), dtype=float)
    d = d[np.isfinite(d)]
    if d.size == 0:
        return np.nan
    observed = abs(float(np.mean(d)))
    permuted = []
    for signs in itertools.product((-1.0, 1.0), repeat=d.size):
        permuted.append(abs(float(np.mean(d * np.asarray(signs)))))
    return float(np.mean(np.asarray(permuted) >= observed - 1e-15))


def bootstrap_mean_ci(
    values: Iterable[float], seed: int = 20240618, repetitions: int = 20000
) -> tuple[float, float]:
    """Dataset bootstrap CI; observations must already be independent datasets."""

    x = np.asarray(list(values), dtype=float)
    x = x[np.isfinite(x)]
    if x.size == 0:
        return np.nan, np.nan
    if x.size == 1:
        return float(x[0]), float(x[0])
    rng = np.random.default_rng(seed)
    indices = rng.integers(0, x.size, size=(repetitions, x.size))
    means = x[indices].mean(axis=1)
    low, high = np.quantile(means, [0.025, 0.975])
    return float(low), float(high)


def safe_numeric(series: pd.Series) -> pd.Series:
    return pd.to_numeric(series, errors="coerce")


def view_count(view_set: str) -> int:
    return len([item for item in str(view_set).split("+") if item])


def canonical_view_set(view_set: str) -> str:
    order = {name: index for index, name in enumerate(("dlfq", "maxlfq", "top3", "top1"))}
    items = [item.strip().lower() for item in str(view_set).split("+") if item.strip()]
    return "+".join(sorted(items, key=lambda item: order.get(item, 999)))
