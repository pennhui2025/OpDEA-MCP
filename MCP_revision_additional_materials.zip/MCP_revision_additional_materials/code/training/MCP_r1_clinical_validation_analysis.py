"""Reviewer-oriented validation for TPD classification and CRC survival.

补做任务 6：临床队列分类、等维度聚类、MCP-unique蛋白生存分析与多重校正。

Classification manifest columns
-------------------------------
cohort, method, prediction_file
Prediction files need sample ID, true_label, and score/probability.
Optional sample_column, true_label_column, score_column, and qvalue_column
fields disambiguate nonstandard exports.

Optional feature manifest columns
---------------------------------
cohort, method, feature_file, sample_column, label_column
Each feature file is sample-by-feature and must include its class label.

Survival table
--------------
One row per patient with time, event, candidate protein abundance columns, and
optional numeric/categorical covariates. Candidate proteins are supplied as a
comma-separated list or a one-column file.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import chi2, spearmanr
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score, silhouette_score
from sklearn.preprocessing import StandardScaler
from statsmodels.duration.hazard_regression import PHReg

from MCP_r1_mcp_experiment_runner import add_core_runner_arguments, run_core_from_args

from MCP_r1_supplementary_analysis_utils import (
    bh_adjust,
    binary_metrics,
    ensure_output_dir,
    find_column,
    percentile_interval,
    prediction_column_map,
    ranking_metrics,
    read_table,
    resolve_path,
    seed_everything,
)


def load_classification_predictions(path: Path, column_map: dict[str, str] | None = None) -> pd.DataFrame:
    frame = read_table(path)
    column_map = column_map or {}

    def select(canonical: str, required: bool = True) -> str | None:
        requested = column_map.get(canonical)
        if requested:
            if requested not in frame.columns:
                raise ValueError(f"{path} has no explicitly requested column '{requested}'")
            return requested
        return find_column(frame, canonical, required=required)

    sample_col = select("sample")
    true_col = select("true_label")
    score_col = select("score", required=False)
    q_col = select("qvalue", required=False)
    if score_col is None and q_col is None:
        raise ValueError(f"{path} needs a score/probability or q-value column")
    result = pd.DataFrame(
        {
            "sample": frame[sample_col],
            "true_label": pd.to_numeric(frame[true_col], errors="coerce"),
            "score": pd.to_numeric(frame[score_col], errors="coerce")
            if score_col is not None
            else 1.0 - pd.to_numeric(frame[q_col], errors="coerce"),
        }
    ).dropna()
    result = result[
        np.isfinite(result["true_label"])
        & np.isfinite(result["score"])
        & result["true_label"].isin([0, 1])
    ].copy()
    result["true_label"] = result["true_label"].astype(int)
    result["sample"] = result["sample"].astype(str).str.strip()
    result = result[(result["sample"] != "") & (result["sample"].str.lower() != "nan")]
    if result["sample"].duplicated().any():
        examples = result.loc[result["sample"].duplicated(keep=False), "sample"].unique()[:5]
        raise ValueError(f"Prediction table contains duplicate sample IDs: {examples.tolist()}")
    return result


def classification_bootstrap(
    predictions: pd.DataFrame,
    threshold: float,
    rng: np.random.Generator,
    iterations: int,
) -> tuple[dict, dict[str, tuple[float, float]]]:
    truth_all = predictions["true_label"].to_numpy(int)
    score_all = predictions["score"].to_numpy(float)
    calls = (score_all >= threshold).astype(int)
    # Threshold-free discrimination (AUROC/AUPRC/pAUC) and threshold-dependent
    # classification metrics are reported separately in the same tidy table.
    point = binary_metrics(truth_all, calls)
    point.update(ranking_metrics(truth_all, score_all))
    boot: dict[str, list[float]] = {key: [] for key in point if key not in {"tn", "fp", "fn", "tp"}}
    for _ in range(iterations):
        indices = rng.choice(len(predictions), size=len(predictions), replace=True)
        truth = truth_all[indices]
        pred = calls[indices]
        if len(np.unique(truth)) < 2:
            continue
        values = binary_metrics(truth, pred)
        values.update(ranking_metrics(truth, score_all[indices]))
        for key in boot:
            boot[key].append(values[key])
    intervals = {key: percentile_interval(values) for key, values in boot.items()}
    return point, intervals


def analyze_classification(
    manifest_path: Path,
    threshold: float,
    rng: np.random.Generator,
    bootstrap: int,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    manifest = read_table(manifest_path)
    required = ["cohort", "method", "prediction_file"]
    missing = [column for column in required if column not in manifest.columns]
    if missing:
        raise ValueError(f"Classification manifest missing columns: {missing}")
    method_tables: dict[tuple[str, str], pd.DataFrame] = {}
    summary_rows: list[dict] = []
    audit: list[dict] = []
    for _, row in manifest.iterrows():
        path = resolve_path(manifest_path, row["prediction_file"])
        try:
            table = load_classification_predictions(path, prediction_column_map(row))
            key = (str(row["cohort"]), str(row["method"]))
            if key in method_tables:
                raise ValueError(f"Duplicate cohort/method entry: {key[0]}/{key[1]}")
            method_tables[key] = table
            point, intervals = classification_bootstrap(table, threshold, rng, bootstrap)
            for metric, value in point.items():
                if metric in {"tn", "fp", "fn", "tp"}:
                    continue
                low, high = intervals.get(metric, (np.nan, np.nan))
                summary_rows.append(
                    {
                        "cohort": row["cohort"],
                        "method": row["method"],
                        "metric": metric,
                        "value": value,
                        "ci_low": low,
                        "ci_high": high,
                        "n_samples": len(table),
                    }
                )
            audit.append({"cohort": row["cohort"], "method": row["method"], "status": "ok", "message": ""})
        except Exception as exc:
            audit.append(
                {"cohort": row.get("cohort", ""), "method": row.get("method", ""), "status": "error", "message": repr(exc)}
            )

    paired_rows: list[dict] = []
    cohorts = sorted({key[0] for key in method_tables})
    for cohort in cohorts:
        methods = sorted(key[1] for key in method_tables if key[0] == cohort)
        for left_index, left_method in enumerate(methods):
            for right_method in methods[left_index + 1 :]:
                left = method_tables[(cohort, left_method)]
                right = method_tables[(cohort, right_method)]
                merged = left.merge(right, on="sample", suffixes=("_left", "_right"))
                if not np.array_equal(merged["true_label_left"], merged["true_label_right"]):
                    raise ValueError(f"Truth labels disagree between {left_method} and {right_method} in {cohort}")
                truth = merged["true_label_left"].to_numpy(int)
                left_calls = (merged["score_left"].to_numpy() >= threshold).astype(int)
                right_calls = (merged["score_right"].to_numpy() >= threshold).astype(int)
                # Paired resampling keeps the same patient/sample in both methods.
                # This is essential for valid AUC and classification comparisons.
                boot_diffs: dict[str, list[float]] = {
                    key: []
                    for key in ["accuracy", "precision", "recall", "f1", "mcc", "auroc", "auprc"]
                }
                for _ in range(bootstrap):
                    indices = rng.choice(len(merged), size=len(merged), replace=True)
                    if len(np.unique(truth[indices])) < 2:
                        continue
                    left_metrics = binary_metrics(truth[indices], left_calls[indices])
                    right_metrics = binary_metrics(truth[indices], right_calls[indices])
                    left_metrics.update(ranking_metrics(truth[indices], merged["score_left"].to_numpy()[indices]))
                    right_metrics.update(ranking_metrics(truth[indices], merged["score_right"].to_numpy()[indices]))
                    for metric in boot_diffs:
                        boot_diffs[metric].append(left_metrics[metric] - right_metrics[metric])
                for metric, differences in boot_diffs.items():
                    low, high = percentile_interval(differences)
                    paired_rows.append(
                        {
                            "cohort": cohort,
                            "method_a": left_method,
                            "method_b": right_method,
                            "metric": metric,
                            "mean_difference_a_minus_b": float(np.mean(differences)) if differences else np.nan,
                            "ci_low": low,
                            "ci_high": high,
                            "n_common_samples": len(merged),
                        }
                    )
    return pd.DataFrame(summary_rows), pd.DataFrame(paired_rows), pd.DataFrame(audit)


def feature_dimension_analysis(manifest_path: Path, seed: int) -> tuple[pd.DataFrame, pd.DataFrame]:
    manifest = read_table(manifest_path)
    required = ["cohort", "method", "feature_file", "sample_column", "label_column"]
    missing = [column for column in required if column not in manifest.columns]
    if missing:
        raise ValueError(f"Feature manifest missing columns: {missing}")
    loaded: dict[tuple[str, str], tuple[pd.DataFrame, np.ndarray]] = {}
    audit: list[dict] = []
    for _, row in manifest.iterrows():
        path = resolve_path(manifest_path, row["feature_file"])
        try:
            frame = read_table(path)
            sample_col, label_col = row["sample_column"], row["label_column"]
            feature_cols = [column for column in frame.columns if column not in {sample_col, label_col}]
            features = frame[feature_cols].apply(pd.to_numeric, errors="coerce")
            features = features.fillna(features.median()).fillna(0.0)
            features.index = frame[sample_col].astype(str)
            labels = pd.to_numeric(frame[label_col], errors="raise").to_numpy(int)
            if features.shape[0] < 3 or features.shape[1] < 1:
                raise ValueError("Feature table needs at least 3 samples and 1 numeric feature")
            if features.index.duplicated().any():
                raise ValueError("Feature table contains duplicate sample IDs")
            n_classes = len(np.unique(labels))
            if n_classes < 2 or n_classes >= len(labels):
                raise ValueError("Clustering labels need 2 to n_samples-1 distinct classes")
            key = (str(row["cohort"]), str(row["method"]))
            if key in loaded:
                raise ValueError(f"Duplicate cohort/method entry: {key[0]}/{key[1]}")
            loaded[key] = (features, labels)
            audit.append({"cohort": row["cohort"], "method": row["method"], "status": "ok", "message": ""})
        except Exception as exc:
            audit.append({"cohort": row.get("cohort", ""), "method": row.get("method", ""), "status": "error", "message": repr(exc)})

    rows: list[dict] = []
    for cohort in sorted({key[0] for key in loaded}):
        methods = [key[1] for key in loaded if key[0] == cohort]
        matched_dimension = min(
            min(loaded[(cohort, method)][0].shape[1], loaded[(cohort, method)][0].shape[0] - 1)
            for method in methods
        )
        if matched_dimension < 1:
            raise ValueError(f"No valid matched PCA dimension for cohort '{cohort}'")
        for method in methods:
            features, labels = loaded[(cohort, method)]
            scaled = StandardScaler().fit_transform(features)
            reduced = PCA(n_components=matched_dimension, random_state=seed).fit_transform(scaled)
            clusters = KMeans(n_clusters=len(np.unique(labels)), n_init=50, random_state=seed).fit_predict(reduced)
            rows.append(
                {
                    "cohort": cohort,
                    "method": method,
                    "n_samples": len(labels),
                    "original_feature_dimension": features.shape[1],
                    "matched_pca_dimension": matched_dimension,
                    "ari": adjusted_rand_score(labels, clusters),
                    "nmi": normalized_mutual_info_score(labels, clusters),
                    "silhouette": silhouette_score(reduced, clusters) if len(np.unique(clusters)) > 1 else np.nan,
                }
            )
    return pd.DataFrame(rows), pd.DataFrame(audit)


def load_protein_names(text: str | None, file_path: Path | None) -> list[str]:
    names = [item.strip() for item in (text or "").split(",") if item.strip()]
    if file_path is not None:
        frame = read_table(file_path)
        names.extend(frame.iloc[:, 0].dropna().astype(str).tolist())
    return list(dict.fromkeys(names))


def km_curve(time: np.ndarray, event: np.ndarray, group: np.ndarray, group_name: str) -> pd.DataFrame:
    rows: list[dict] = []
    selected_time = time[group]
    selected_event = event[group]
    survival = 1.0
    for event_time in np.sort(np.unique(selected_time[selected_event == 1])):
        at_risk = int((selected_time >= event_time).sum())
        events = int(((selected_time == event_time) & (selected_event == 1)).sum())
        censored = int(((selected_time == event_time) & (selected_event == 0)).sum())
        survival *= 1.0 - events / at_risk
        rows.append(
            {
                "group": group_name,
                "time": event_time,
                "survival_probability": survival,
                "n_at_risk": at_risk,
                "n_events": events,
                "n_censored": censored,
            }
        )
    return pd.DataFrame(rows)


def logrank_test(time: np.ndarray, event: np.ndarray, high_group: np.ndarray) -> tuple[float, float]:
    """Two-sided Mantel-Cox log-rank test for median-defined high/low groups."""

    observed_minus_expected = 0.0
    variance = 0.0
    for event_time in np.sort(np.unique(time[event == 1])):
        at_risk = time >= event_time
        n_total = int(at_risk.sum())
        n_high = int((at_risk & high_group).sum())
        deaths = (time == event_time) & (event == 1)
        d_total = int(deaths.sum())
        d_high = int((deaths & high_group).sum())
        if n_total <= 1 or d_total == 0:
            continue
        observed_minus_expected += d_high - d_total * n_high / n_total
        variance += (
            n_high
            * (n_total - n_high)
            * d_total
            * (n_total - d_total)
            / (n_total**2 * (n_total - 1))
        )
    if variance <= 0:
        return np.nan, np.nan
    statistic = observed_minus_expected**2 / variance
    return float(statistic), float(chi2.sf(statistic, df=1))


def survival_analysis(
    survival_path: Path,
    proteins: list[str],
    time_column: str,
    event_column: str,
    covariates: list[str],
) -> tuple[pd.DataFrame, pd.DataFrame]:
    frame = read_table(survival_path)
    missing = [column for column in [time_column, event_column, *proteins, *covariates] if column not in frame.columns]
    if missing:
        raise ValueError(f"Survival table missing columns: {missing}")
    result_rows: list[dict] = []
    km_rows: list[pd.DataFrame] = []
    for protein in proteins:
        columns = [time_column, event_column, protein, *covariates]
        data = frame[columns].copy()
        data[protein] = pd.to_numeric(data[protein], errors="coerce")
        data[time_column] = pd.to_numeric(data[time_column], errors="coerce")
        data[event_column] = pd.to_numeric(data[event_column], errors="coerce")
        design = pd.get_dummies(data[[protein, *covariates]], drop_first=True, dtype=float)
        combined = pd.concat([data[[time_column, event_column]], design], axis=1).dropna()
        combined = combined[
            (combined[time_column] > 0) & combined[event_column].isin([0, 1])
        ].copy()
        if len(combined) < 10 or combined[event_column].sum() < 3:
            result_rows.append(
                {
                    "protein": protein,
                    "n_patients": len(combined),
                    "n_events": int(combined[event_column].sum()),
                    "status": "skipped",
                    "message": "Need at least 10 complete patients and 3 events",
                }
            )
            continue
        protein_values = combined[protein].to_numpy(float)
        combined[protein] = (protein_values - protein_values.mean()) / max(protein_values.std(ddof=1), 1e-12)
        try:
            model = PHReg(
                combined[time_column].to_numpy(float),
                combined[design.columns].to_numpy(float),
                status=combined[event_column].to_numpy(int),
                ties="efron",
            ).fit(disp=0)
        except Exception as exc:
            result_rows.append(
                {
                    "protein": protein,
                    "n_patients": len(combined),
                    "n_events": int(combined[event_column].sum()),
                    "status": "error",
                    "message": repr(exc),
                }
            )
            continue
        coefficient = float(model.params[0])
        standard_error = float(model.bse[0])
        pvalue = float(model.pvalues[0])
        ph_rho, ph_pvalue = np.nan, np.nan
        try:
            residuals = np.asarray(model.schoenfeld_residuals)[:, 0]
            event_mask = combined[event_column].to_numpy(int) == 1
            valid_residuals = residuals[event_mask] if len(residuals) == len(combined) else residuals
            event_times = combined.loc[event_mask, time_column].to_numpy(float)
            if len(valid_residuals) == len(event_times) and len(event_times) >= 3:
                ph_rho, ph_pvalue = spearmanr(valid_residuals, np.log(np.maximum(event_times, 1e-12)))
        except Exception:
            pass
        median = float(np.median(protein_values))
        low_group = protein_values <= median
        high_group = protein_values > median
        logrank_statistic, logrank_pvalue = logrank_test(
            combined[time_column].to_numpy(float),
            combined[event_column].to_numpy(int),
            high_group,
        )
        result_rows.append(
            {
                "protein": protein,
                "n_patients": len(combined),
                "n_events": int(combined[event_column].sum()),
                "hazard_ratio_per_sd": float(np.exp(coefficient)),
                "ci_low": float(np.exp(coefficient - 1.96 * standard_error)),
                "ci_high": float(np.exp(coefficient + 1.96 * standard_error)),
                "pvalue": pvalue,
                "ph_schoenfeld_spearman_rho": ph_rho,
                "ph_assumption_pvalue": ph_pvalue,
                "logrank_statistic": logrank_statistic,
                "logrank_pvalue": logrank_pvalue,
                "covariates": ";".join(covariates),
                "status": "ok",
                "message": "",
            }
        )
        time = combined[time_column].to_numpy(float)
        event = combined[event_column].to_numpy(int)
        for table, name in [(low_group, "low"), (high_group, "high")]:
            curve = km_curve(time, event, table, name)
            curve.insert(0, "protein", protein)
            km_rows.append(curve)

    results = pd.DataFrame(result_rows)
    if not results.empty:
        if "pvalue" in results:
            results["cox_fdr_bh"] = bh_adjust(results["pvalue"])
            # Backward-compatible alias for tables drafted against the first version.
            results["fdr_bh"] = results["cox_fdr_bh"]
        if "logrank_pvalue" in results:
            results["logrank_fdr_bh"] = bh_adjust(results["logrank_pvalue"])
    km = pd.concat(km_rows, ignore_index=True) if km_rows else pd.DataFrame()
    return results, km


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--classification-manifest", type=Path, default=None)
    parser.add_argument("--feature-manifest", type=Path, default=None)
    parser.add_argument("--survival-file", type=Path, default=None)
    parser.add_argument("--survival-proteins", default="")
    parser.add_argument("--survival-protein-file", type=Path, default=None)
    parser.add_argument("--time-column", default="time")
    parser.add_argument("--event-column", default="event")
    parser.add_argument("--covariates", default="")
    parser.add_argument("--score-threshold", type=float, default=0.5)
    parser.add_argument("--bootstrap", type=int, default=2000)
    parser.add_argument("--seed", type=int, default=2024)
    parser.add_argument("--output-dir", required=True, type=Path)
    add_core_runner_arguments(parser)
    return parser


def main() -> None:
    args = build_parser().parse_args()
    out = ensure_output_dir(args.output_dir)
    core_artifacts = run_core_from_args(args, out)
    if args.dry_run_core and core_artifacts is not None:
        print(f"Core dry-run plan written to {core_artifacts.plan_path}")
        return
    rng = seed_everything(args.seed)
    performed = False
    if args.classification_manifest is not None:
        summary, paired, audit = analyze_classification(
            args.classification_manifest, args.score_threshold, rng, args.bootstrap
        )
        summary.to_csv(out / "classification_metrics_with_bootstrap_ci.csv", index=False)
        paired.to_csv(out / "paired_classification_metric_differences.csv", index=False)
        audit.to_csv(out / "classification_input_audit.csv", index=False)
        performed = True
    if args.feature_manifest is not None:
        clustering, audit = feature_dimension_analysis(args.feature_manifest, args.seed)
        clustering.to_csv(out / "matched_dimension_clustering_metrics.csv", index=False)
        audit.to_csv(out / "feature_input_audit.csv", index=False)
        performed = True
    if args.survival_file is not None:
        proteins = load_protein_names(args.survival_proteins, args.survival_protein_file)
        if not proteins:
            raise ValueError("Survival analysis requires --survival-proteins or --survival-protein-file")
        covariates = [item.strip() for item in args.covariates.split(",") if item.strip()]
        survival, km = survival_analysis(
            args.survival_file, proteins, args.time_column, args.event_column, covariates
        )
        survival.to_csv(out / "cox_models_with_bh_fdr.csv", index=False)
        km.to_csv(out / "kaplan_meier_curve_data_full_followup.csv", index=False)
        performed = True
    if not performed:
        raise ValueError(
            "Core MCP runs can be launched here, but independent clinical validation still "
            "requires --classification-manifest, --feature-manifest, or --survival-file"
        )
    print(f"Completed clinical validation analysis. Results: {out}")


if __name__ == "__main__":
    main()
