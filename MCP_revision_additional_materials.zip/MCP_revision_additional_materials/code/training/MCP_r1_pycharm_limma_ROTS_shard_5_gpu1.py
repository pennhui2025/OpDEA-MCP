"""Run combined limma+ROTS DIA shard 5 on physical GPU 1."""
from pathlib import Path
from MCP_r1_pycharm_run_core_shard import run_shard

def main() -> None:
    run_shard(5, 1, Path(__file__).resolve().parent / "revision_results",
              manifest_stem="MCP_r1_task1_2_DIA_limma_ROTS_shard")

if __name__ == "__main__":
    main()
