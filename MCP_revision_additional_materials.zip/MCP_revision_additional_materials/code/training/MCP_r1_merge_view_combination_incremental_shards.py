"""Merge and validate seven 40-run DIA 2/3-view incremental shards."""

from __future__ import annotations

import argparse
import json
from itertools import combinations
from pathlib import Path

import pandas as pd

from MCP_r1_merge_task1_2_shards import ARTIFACTS, dea_method_label, read_required


VIEWS = ("dlfq", "maxlfq", "top3", "top1")
EXPECTED_VIEW_SETS = {
    "+".join(values)
    for size in (2, 3)
    for values in combinations(VIEWS, size)
}


def view_count(value: object) -> int:
    return len([part for part in str(value).split("+") if part.strip()])


def merge_incremental_shards(
    shards_root: Path,
    output_dir: Path,
    master_manifest: Path,
    expected_shards: int = 7,
    check_prediction_files: bool = True,
) -> dict[str, object]:
    shards_root = shards_root.expanduser().resolve()
    output_dir = output_dir.expanduser().resolve()
    master_manifest = master_manifest.expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    master = read_required(master_manifest)
    if len(master) != 280 or "run_id" not in master or not master["run_id"].is_unique:
        raise ValueError("Incremental master manifest must contain 280 unique run_id values")
    if set(master["variant"].astype(str)) != {"full_mcp"}:
        raise ValueError("Every incremental run must use full_mcp")
    if set(master["views"].astype(str)) != EXPECTED_VIEW_SETS:
        raise ValueError("Incremental master does not contain the exact 2/3-view combinations")

    collected: dict[str, list[pd.DataFrame]] = {key: [] for key in ARTIFACTS}
    audit_rows: list[dict[str, object]] = []
    for shard_id in range(1, expected_shards + 1):
        shard_dir = shards_root / f"shard_{shard_id}"
        frames: dict[str, pd.DataFrame] = {}
        for key, filename in ARTIFACTS.items():
            frame = read_required(shard_dir / filename)
            frame.insert(0, "source_shard", shard_id)
            frames[key] = frame
            collected[key].append(frame)

        plan = frames["plan"]
        ledger = frames["ledger"]
        if len(plan) != 40 or len(ledger) != 40:
            raise ValueError(
                f"shard_{shard_id} must have 40 plan and ledger rows; "
                f"found {len(plan)}/{len(ledger)}"
            )
        for name, frame in (("plan", plan), ("ledger", ledger)):
            if "run_id" not in frame or not frame["run_id"].is_unique:
                raise ValueError(f"shard_{shard_id} {name} has missing/duplicate run_id values")
        expected_ids = set(
            master.loc[
                pd.to_numeric(master["data_index"]).astype(int).eq(shard_id - 1), "run_id"
            ].astype(str)
        )
        if set(ledger["run_id"].astype(str)) != expected_ids:
            raise ValueError(f"shard_{shard_id} run IDs do not match the incremental master")
        errors = ledger[ledger["status"].astype(str).eq("error")]
        if not errors.empty:
            examples = errors[["run_id", "message"]].head(3).to_dict("records")
            raise RuntimeError(f"shard_{shard_id} has {len(errors)} errors: {examples}")
        invalid = ledger[
            ~ledger["status"].astype(str).isin(["completed", "skipped_existing"])
        ]
        if not invalid.empty:
            raise RuntimeError(f"shard_{shard_id} contains unfinished runs")

        predictions = frames["predictions"]
        if predictions.empty:
            raise ValueError(f"shard_{shard_id} prediction manifest is empty")
        direct = predictions[
            predictions["variant"].astype(str).eq("full_mcp")
            & predictions["method"].astype(str).eq("full_mcp")
            & predictions["score_column"].astype(str).eq("Probability")
        ].copy()
        if len(direct) != 40:
            raise ValueError(
                f"shard_{shard_id} must expose 40 direct full_mcp predictions; found {len(direct)}"
            )
        direct["view_count"] = direct["view_set"].map(view_count)
        coverage = direct.groupby(["platform", "dea_method", "view_count"]).size().to_dict()
        expected_coverage = {
            (platform, dea, count): number
            for platform in ("DIANN", "Spectronaut")
            for dea in ("limma", "ROTS")
            for count, number in ((2, 6), (3, 4))
        }
        if coverage != expected_coverage:
            raise ValueError(f"shard_{shard_id} direct prediction coverage is invalid: {coverage}")
        if check_prediction_files:
            missing_files = [
                value for value in direct["prediction_file"].astype(str) if not Path(value).is_file()
            ]
            if missing_files:
                raise FileNotFoundError(
                    f"shard_{shard_id} has missing prediction files: {missing_files[:3]}"
                )
        audit_rows.append(
            {
                "shard": shard_id,
                "status": "ok",
                "ledger_rows": len(ledger),
                "direct_prediction_rows": len(direct),
                "data_index": shard_id - 1,
                "view2_runs": int((direct["view_count"] == 2).sum()),
                "view3_runs": int((direct["view_count"] == 3).sum()),
            }
        )

    merged = {
        key: pd.concat(values, ignore_index=True, sort=False)
        for key, values in collected.items()
    }
    ledger = merged["ledger"]
    if len(ledger) != 280 or not ledger["run_id"].is_unique:
        raise ValueError("Merged incremental ledger must contain 280 unique runs")
    if set(ledger["run_id"].astype(str)) != set(master["run_id"].astype(str)):
        raise ValueError("Merged incremental run IDs do not match the master manifest")

    predictions = merged["predictions"].copy()
    predictions["view_count"] = predictions["view_set"].map(view_count)
    predictions["combination_id"] = predictions["view_set"].astype(str).str.replace(
        "+", "_", regex=False
    )
    merged["predictions"] = predictions
    for key in ("plan", "ledger", "ablations", "performance"):
        if "views" in merged[key].columns:
            merged[key]["view_count"] = merged[key]["views"].map(view_count)
            merged[key]["combination_id"] = merged[key]["views"].astype(str).str.replace(
                "+", "_", regex=False
            )
        elif "view_set" in merged[key].columns:
            merged[key]["view_count"] = merged[key]["view_set"].map(view_count)
            merged[key]["combination_id"] = merged[key]["view_set"].astype(str).str.replace(
                "+", "_", regex=False
            )

    output_paths = {key: output_dir / filename for key, filename in ARTIFACTS.items()}
    for key, frame in merged.items():
        sort_columns = [
            column for column in
            ("source_shard", "platform", "dea_method", "dea_methods", "view_count", "view_set", "views")
            if column in frame.columns
        ]
        if sort_columns:
            frame = frame.sort_values(sort_columns, kind="stable")
        frame.to_csv(output_paths[key], index=False)
    audit_path = output_dir / "shard_merge_audit.csv"
    pd.DataFrame(audit_rows).to_csv(audit_path, index=False)

    direct_all = predictions[
        predictions["variant"].astype(str).eq("full_mcp")
        & predictions["method"].astype(str).eq("full_mcp")
        & predictions["score_column"].astype(str).eq("Probability")
    ]
    if len(direct_all) != 280:
        raise ValueError(f"Merged direct full_mcp rows must equal 280; found {len(direct_all)}")
    summary: dict[str, object] = {
        "status": "complete",
        "shards": expected_shards,
        "core_runs": len(ledger),
        "direct_prediction_rows": len(direct_all),
        "dea_methods": sorted(direct_all["dea_method"].astype(str).unique()),
        "view_counts": sorted(direct_all["view_count"].astype(int).unique().tolist()),
        "prediction_manifest": str(output_paths["predictions"]),
        "ledger": str(output_paths["ledger"]),
        "audit": str(audit_path),
    }
    with (output_dir / "merge_summary.json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--shards-root", type=Path,
        default=Path("revision_results/view_combination_incremental_shards"),
    )
    parser.add_argument(
        "--output-dir", type=Path,
        default=Path("revision_results/view_combination_incremental_merged"),
    )
    parser.add_argument(
        "--master-manifest", type=Path,
        default=Path("MCP_r1_DIA_view_combinations_limma_ROTS_incremental_manifest.csv"),
    )
    parser.add_argument("--expected-shards", type=int, default=7)
    args = parser.parse_args()
    summary = merge_incremental_shards(
        args.shards_root, args.output_dir, args.master_manifest, args.expected_shards
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

