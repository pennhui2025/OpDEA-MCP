"""Fair benchmark of MCP against statistical and simple multi-view baselines.

补做任务 1：建立公平、完整的基线体系。

The script can first call the original MCP core through ``--run-manifest``, or
consume an existing manifest with one row per dataset/method result. Each
``prediction_file`` must be a long table containing protein identifiers,
experimental ground truth, and either a DEP score/probability or q-value.
Column aliases used by the three core Python files (Protein, Probability,
true_label, logFC, qval, etc.) are recognized automatically.

Required manifest columns
-------------------------
dataset, acquisition, platform, method, view_set, prediction_file

Recommended optional columns
----------------------------
comparison_group, dea_method, correction, preprocessing, seed
protein_column, true_label_column, score_column, qvalue_column, log2fc_column

Explicit column names are recommended for the core ``*_DP_res_all.csv`` file,
which contains several method-specific ``score_*``/``logFC_*`` blocks.

Example
-------
python fair_baseline_benchmark.py --manifest benchmark_manifest.csv \
  --output-dir revision_results/fair_benchmark \
  --fdr-thresholds 0.01,0.05,0.10 --fc-ratios 1.0,1.2,1.5 \
  --reference-method MCP

Important: true labels must come from the spike-in design, never from the
tested method's q-values. / 真值必须来自spike-in实验设计。
"""

from __future__ import annotations

import argparse
import itertools
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import wilcoxon

from MCP_r1_mcp_experiment_runner import add_core_runner_arguments, run_core_from_args

from MCP_r1_supplementary_analysis_utils import (
    bh_adjust,
    binary_metrics,
    bootstrap_mean_ci,
    calls_from_thresholds,
    ensure_output_dir,
    parse_number_list,
    prediction_column_map,
    read_table,
    resolve_path,
    seed_everything,
    standardize_prediction_table,
)


REQUIRED_MANIFEST_COLUMNS = [
    "dataset",
    "acquisition",
    "platform",
    "method",
    "view_set",
    "prediction_file",
]


def evaluate_manifest(
    manifest_path: Path,
    fdr_thresholds: list[float],
    fc_ratios: list[float],
) -> tuple[pd.DataFrame, pd.DataFrame]:
    manifest = read_table(manifest_path)
    missing = [column for column in REQUIRED_MANIFEST_COLUMNS if column not in manifest.columns]
    if missing:
        raise ValueError(f"Manifest is missing required columns: {missing}")
    if "comparison_group" not in manifest.columns:
        # Methods with different view sets may still be compared within the same
        # dataset/platform. A custom comparison_group can enforce stricter pairing.
        manifest["comparison_group"] = (
            manifest["acquisition"].astype(str)
            + "|"
            + manifest["platform"].astype(str)
            + "|"
            + manifest["dataset"].astype(str)
            + "|"
            + manifest["view_set"].astype(str)
        )

    records: list[dict] = []
    audit: list[dict] = []
    for row_number, row in manifest.iterrows():
        result_path = resolve_path(manifest_path, row["prediction_file"])
        try:
            pred = standardize_prediction_table(
                read_table(result_path), prediction_column_map(row)
            )
            n_total = len(pred)
            n_positive = int(pred["true_label"].sum())
            for fdr_threshold, fc_ratio in itertools.product(fdr_thresholds, fc_ratios):
                calls = calls_from_thresholds(pred, fdr_threshold, fc_ratio)
                metrics = binary_metrics(pred["true_label"], calls)
                records.append(
                    {
                        **{column: row.get(column, "") for column in manifest.columns if column != "prediction_file"},
                        "prediction_file": str(result_path),
                        "fdr_threshold": fdr_threshold,
                        "fold_change_ratio": fc_ratio,
                        "n_proteins": n_total,
                        "n_true_deps": n_positive,
                        "n_called_deps": int(calls.sum()),
                        **metrics,
                    }
                )
            audit.append(
                {
                    "manifest_row": row_number + 2,
                    "dataset": row["dataset"],
                    "method": row["method"],
                    "status": "ok",
                    "prediction_file": str(result_path),
                    "n_proteins": n_total,
                    "n_true_deps": n_positive,
                    "has_qvalue": bool(pred["qvalue"].notna().any()),
                    "has_log2fc": bool(pred["log2fc"].notna().any()),
                    "message": "",
                }
            )
        except Exception as exc:  # Record failures; do not silently continue like the legacy loop.
            audit.append(
                {
                    "manifest_row": row_number + 2,
                    "dataset": row.get("dataset", ""),
                    "method": row.get("method", ""),
                    "status": "error",
                    "prediction_file": str(result_path),
                    "n_proteins": np.nan,
                    "n_true_deps": np.nan,
                    "has_qvalue": False,
                    "has_log2fc": False,
                    "message": repr(exc),
                }
            )
    return pd.DataFrame(records), pd.DataFrame(audit)


def aggregate_metrics(per_dataset: pd.DataFrame, rng: np.random.Generator, bootstrap: int) -> pd.DataFrame:
    metric_columns = ["precision", "recall", "specificity", "f1", "mcc", "balanced_accuracy"]
    group_columns = [
        "acquisition",
        "platform",
    ]
    if "dea_method" in per_dataset.columns:
        group_columns.append("dea_method")
    group_columns.extend(
        ["method", "view_set", "fdr_threshold", "fold_change_ratio"]
    )
    output: list[dict] = []
    for keys, group in per_dataset.groupby(group_columns, dropna=False):
        base = dict(zip(group_columns, keys))
        for metric in metric_columns:
            values = pd.to_numeric(group[metric], errors="coerce").dropna().to_numpy()
            mean, ci_low, ci_high = bootstrap_mean_ci(values, rng, bootstrap)
            output.append(
                {
                    **base,
                    "metric": metric,
                    "n_datasets": len(values),
                    "mean": mean,
                    "median": float(np.median(values)) if len(values) else np.nan,
                    "q1": float(np.quantile(values, 0.25)) if len(values) else np.nan,
                    "q3": float(np.quantile(values, 0.75)) if len(values) else np.nan,
                    "mean_ci_low": ci_low,
                    "mean_ci_high": ci_high,
                }
            )
    return pd.DataFrame(output)


def paired_comparisons(
    per_dataset: pd.DataFrame,
    reference_method: str,
    primary_fdr: float,
    primary_fc: float,
    rng: np.random.Generator,
    bootstrap: int,
) -> pd.DataFrame:
    primary = per_dataset[
        np.isclose(per_dataset["fdr_threshold"], primary_fdr)
        & np.isclose(per_dataset["fold_change_ratio"], primary_fc)
    ].copy()
    metrics = ["precision", "recall", "f1", "mcc", "balanced_accuracy"]
    output: list[dict] = []
    stratum_columns = ["acquisition", "platform"]
    if "dea_method" in primary.columns:
        stratum_columns.append("dea_method")
    for stratum_keys, platform_data in primary.groupby(stratum_columns, dropna=False):
        if not isinstance(stratum_keys, tuple):
            stratum_keys = (stratum_keys,)
        stratum = dict(zip(stratum_columns, stratum_keys))
        methods = sorted(platform_data["method"].astype(str).unique())
        if reference_method not in methods:
            continue
        for comparator in methods:
            if comparator == reference_method:
                continue
            for metric in metrics:
                # Aggregate repeated seeds/configurations within a comparison group first.
                paired = (
                    platform_data[platform_data["method"].isin([reference_method, comparator])]
                    .groupby(["comparison_group", "method"], as_index=False)[metric]
                    .mean()
                    .pivot(index="comparison_group", columns="method", values=metric)
                    .dropna()
                )
                if reference_method not in paired or comparator not in paired:
                    continue
                differences = paired[reference_method].to_numpy() - paired[comparator].to_numpy()
                mean, ci_low, ci_high = bootstrap_mean_ci(differences, rng, bootstrap)
                try:
                    pvalue = float(wilcoxon(differences).pvalue) if len(differences) >= 2 else np.nan
                except ValueError:
                    pvalue = 1.0  # All paired differences are exactly zero.
                output.append(
                    {
                        **stratum,
                        "reference_method": reference_method,
                        "comparator": comparator,
                        "metric": metric,
                        "n_pairs": len(differences),
                        "mean_paired_difference": mean,
                        "difference_ci_low": ci_low,
                        "difference_ci_high": ci_high,
                        "median_paired_difference": float(np.median(differences)) if len(differences) else np.nan,
                        "wilcoxon_pvalue": pvalue,
                    }
                )
    result = pd.DataFrame(output)
    if not result.empty:
        # Correct the family of baseline comparisons; retain raw p-values too.
        result["wilcoxon_fdr_bh"] = bh_adjust(result["wilcoxon_pvalue"])
    return result


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, help="Existing prediction manifest; optional with --run-manifest")
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--fdr-thresholds", default="0.01,0.05,0.10")
    parser.add_argument("--fc-ratios", default="1.0,1.2,1.5")
    parser.add_argument("--primary-fdr", type=float, default=0.05)
    parser.add_argument("--primary-fc", type=float, default=1.5)
    parser.add_argument("--reference-method", default="full_mcp")
    parser.add_argument("--bootstrap", type=int, default=2000)
    parser.add_argument("--seed", type=int, default=2024)
    add_core_runner_arguments(parser)
    return parser


def main() -> None:
    args = build_parser().parse_args()
    out = ensure_output_dir(args.output_dir)
    core_artifacts = run_core_from_args(args, out)
    if args.dry_run_core and core_artifacts is not None:
        print(f"Core dry-run plan written to {core_artifacts.plan_path}")
        return
    manifest_path = args.manifest or (
        core_artifacts.prediction_manifest_path if core_artifacts is not None else None
    )
    if manifest_path is None:
        raise ValueError("Provide --manifest, or provide --run-manifest to run original MCP first")
    rng = seed_everything(args.seed)
    fdr_thresholds = parse_number_list(args.fdr_thresholds)
    fc_ratios = parse_number_list(args.fc_ratios)
    if not fdr_thresholds or any(value <= 0 or value >= 1 for value in fdr_thresholds):
        raise ValueError("--fdr-thresholds must contain values strictly between 0 and 1")
    if not fc_ratios or any(value < 1 for value in fc_ratios):
        raise ValueError("--fc-ratios must contain values greater than or equal to 1")
    per_dataset, audit = evaluate_manifest(
        manifest_path,
        fdr_thresholds,
        fc_ratios,
    )
    audit.to_csv(out / "input_audit.csv", index=False)
    if per_dataset.empty:
        raise RuntimeError("No prediction table could be evaluated; inspect input_audit.csv")
    per_dataset.to_csv(out / "per_dataset_threshold_metrics.csv", index=False)
    aggregate_metrics(per_dataset, rng, args.bootstrap).to_csv(
        out / "aggregate_threshold_summary.csv", index=False
    )
    paired_comparisons(
        per_dataset,
        args.reference_method,
        args.primary_fdr,
        args.primary_fc,
        rng,
        args.bootstrap,
    ).to_csv(out / "paired_method_comparisons.csv", index=False)
    print(f"Completed fair baseline benchmark. Results: {out}")


if __name__ == "__main__":
    main()
