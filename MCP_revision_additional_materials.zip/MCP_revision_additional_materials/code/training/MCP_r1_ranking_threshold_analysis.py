"""Separate continuous DEP ranking performance from thresholded classification.

补做任务 2：明确MCP改善的是连续排序还是DEP判定阈值。

Input uses the same manifest schema as ``fair_baseline_benchmark.py``.  If a
``--run-manifest`` is supplied, original MCP predictions are generated first.
If a prediction table contains a ``split`` column with validation/test labels, the
decision threshold is selected only on validation proteins. Otherwise, a
reproducible stratified validation/test split is created and explicitly marked
as generated in the output.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import precision_recall_curve, roc_curve
from sklearn.model_selection import train_test_split

from MCP_r1_mcp_experiment_runner import add_core_runner_arguments, run_core_from_args

from MCP_r1_supplementary_analysis_utils import (
    binary_metrics,
    calibration_metrics,
    ensure_output_dir,
    prediction_column_map,
    ranking_metrics,
    read_table,
    resolve_path,
    seed_everything,
    standardize_prediction_table,
)


REQUIRED = ["dataset", "acquisition", "platform", "method", "view_set", "prediction_file"]


def select_partitions(
    table: pd.DataFrame, validation_fraction: float, seed: int
) -> tuple[pd.DataFrame, pd.DataFrame, str]:
    if "split" in table.columns:
        split = table["split"].str.lower()
        validation = table[split.isin(["validation", "valid", "val", "development", "dev"])]
        test = table[split.isin(["test", "heldout", "holdout"])]
        if len(validation) and len(test):
            return validation.copy(), test.copy(), "provided_split"

    # A generated split is acceptable for spike-in diagnostics, but manuscript
    # reporting must disclose it and repeat across seeds if used for inference.
    # Sort by stable protein ID so every method for the same benchmark receives
    # the same generated partition even when input row order differs.
    table = table.sort_values("protein").reset_index(drop=True)
    indices = np.arange(len(table))
    try:
        train_idx, test_idx = train_test_split(
            indices,
            test_size=1.0 - validation_fraction,
            random_state=seed,
            stratify=table["true_label"],
        )
        source = "generated_stratified_split"
    except ValueError:
        # Very small spike-in sets may not contain enough examples per class
        # for a stratified split; retain reproducibility and disclose fallback.
        train_idx, test_idx = train_test_split(
            indices,
            test_size=1.0 - validation_fraction,
            random_state=seed,
            stratify=None,
        )
        source = "generated_unstratified_fallback"
    return table.iloc[train_idx].copy(), table.iloc[test_idx].copy(), source


def choose_threshold(
    validation: pd.DataFrame, min_precision: float | None = None
) -> tuple[float, float, float, float]:
    precision, recall, thresholds = precision_recall_curve(
        validation["true_label"], validation["score"]
    )
    if len(thresholds) == 0:
        return 0.5, np.nan, np.nan, np.nan
    precision = precision[:-1]
    recall = recall[:-1]
    f1 = 2.0 * precision * recall / np.maximum(precision + recall, 1e-12)
    eligible = np.ones(len(thresholds), dtype=bool)
    if min_precision is not None:
        eligible &= precision >= min_precision
    if eligible.any():
        # Within a precision constraint, maximize recall then F1.
        candidates = np.where(eligible)[0]
        best = candidates[np.lexsort((f1[candidates], recall[candidates]))[-1]]
    else:
        best = int(np.nanargmax(f1))
    return float(thresholds[best]), float(precision[best]), float(recall[best]), float(f1[best])


def curve_rows(table: pd.DataFrame, metadata: dict) -> tuple[list[dict], list[dict]]:
    pr_precision, pr_recall, pr_threshold = precision_recall_curve(table["true_label"], table["score"])
    pr_rows = [
        {
            **metadata,
            "precision": float(pr_precision[index]),
            "recall": float(pr_recall[index]),
            "score_threshold": float(pr_threshold[index]) if index < len(pr_threshold) else np.nan,
        }
        for index in range(len(pr_precision))
    ]
    if table["true_label"].nunique() < 2:
        return pr_rows, []
    fpr, tpr, roc_threshold = roc_curve(table["true_label"], table["score"])
    roc_rows = [
        {
            **metadata,
            "fpr": float(fpr[index]),
            "tpr": float(tpr[index]),
            "score_threshold": float(roc_threshold[index]),
        }
        for index in range(len(fpr))
    ]
    return pr_rows, roc_rows


def analyze_manifest(
    manifest_path: Path,
    validation_fraction: float,
    seed: int,
    calibration_bins: int,
    min_precision: float | None,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    manifest = read_table(manifest_path)
    missing = [column for column in REQUIRED if column not in manifest.columns]
    if missing:
        raise ValueError(f"Manifest missing required columns: {missing}")

    ranking_rows: list[dict] = []
    threshold_rows: list[dict] = []
    pr_rows: list[dict] = []
    roc_rows: list[dict] = []
    audit_rows: list[dict] = []
    for row_number, row in manifest.iterrows():
        path = resolve_path(manifest_path, row["prediction_file"])
        metadata = {
            "dataset": row["dataset"],
            "acquisition": row["acquisition"],
            "platform": row["platform"],
            "method": row["method"],
            "view_set": row["view_set"],
        }
        if "dea_method" in manifest.columns:
            metadata["dea_method"] = row.get("dea_method", "")
        try:
            table = standardize_prediction_table(
                read_table(path), prediction_column_map(row)
            )
            validation, test, split_source = select_partitions(table, validation_fraction, seed)
            threshold, val_precision, val_recall, val_f1 = choose_threshold(validation, min_precision)
            test_calls = (test["score"].to_numpy() >= threshold).astype(int)
            test_binary = binary_metrics(test["true_label"], test_calls)
            test_ranking = ranking_metrics(test["true_label"], test["score"])
            test_calibration = calibration_metrics(test["true_label"], test["score"], calibration_bins)

            ranking_rows.append(
                {
                    **metadata,
                    "split_source": split_source,
                    "n_validation": len(validation),
                    "n_test": len(test),
                    **test_ranking,
                    **test_calibration,
                }
            )
            threshold_rows.append(
                {
                    **metadata,
                    "split_source": split_source,
                    "selected_threshold": threshold,
                    "validation_precision": val_precision,
                    "validation_recall": val_recall,
                    "validation_f1": val_f1,
                    **{f"test_{key}": value for key, value in test_binary.items()},
                }
            )
            current_pr, current_roc = curve_rows(test, metadata)
            pr_rows.extend(current_pr)
            roc_rows.extend(current_roc)
            audit_rows.append({**metadata, "status": "ok", "file": str(path), "message": ""})
        except Exception as exc:
            audit_rows.append({**metadata, "status": "error", "file": str(path), "message": repr(exc)})

    return (
        pd.DataFrame(ranking_rows),
        pd.DataFrame(threshold_rows),
        pd.DataFrame(pr_rows),
        pd.DataFrame(roc_rows),
        pd.DataFrame(audit_rows),
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, help="Existing prediction manifest; optional with --run-manifest")
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--validation-fraction", type=float, default=0.30)
    parser.add_argument("--min-precision", type=float, default=None)
    parser.add_argument("--calibration-bins", type=int, default=10)
    parser.add_argument("--seed", type=int, default=2024)
    add_core_runner_arguments(parser)
    return parser


def main() -> None:
    args = build_parser().parse_args()
    if not 0.05 <= args.validation_fraction <= 0.95:
        raise ValueError("--validation-fraction must be between 0.05 and 0.95")
    seed_everything(args.seed)
    out = ensure_output_dir(args.output_dir)
    core_artifacts = run_core_from_args(args, out)
    if args.dry_run_core and core_artifacts is not None:
        print(f"Core dry-run plan written to {core_artifacts.plan_path}")
        return
    manifest_path = args.manifest or (
        core_artifacts.prediction_manifest_path if core_artifacts is not None else None
    )
    if manifest_path is None:
        raise ValueError("Provide --manifest, or use --run-manifest to generate MCP predictions")
    ranking, thresholds, pr_curve, roc_curve_table, audit = analyze_manifest(
        manifest_path,
        args.validation_fraction,
        args.seed,
        args.calibration_bins,
        args.min_precision,
    )
    ranking.to_csv(out / "heldout_ranking_and_calibration.csv", index=False)
    thresholds.to_csv(out / "validation_selected_threshold_metrics.csv", index=False)
    pr_curve.to_csv(out / "precision_recall_curves.csv", index=False)
    roc_curve_table.to_csv(out / "roc_curves.csv", index=False)
    audit.to_csv(out / "input_audit.csv", index=False)
    if ranking.empty:
        raise RuntimeError("No valid prediction result was analyzed; inspect input_audit.csv")
    print(f"Completed ranking-versus-threshold analysis. Results: {out}")


if __name__ == "__main__":
    main()
