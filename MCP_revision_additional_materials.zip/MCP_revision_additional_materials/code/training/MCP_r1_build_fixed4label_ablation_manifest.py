"""Build fixed-four-label, single-view-ablation manifests.

Each data stratum keeps the same strict shared-feature label universe across
the all-four-view model and its four single-view ablations. / 每个分层均固定
四视图标签宇宙，并生成全视图和四个单视图消融实验。
"""

from __future__ import annotations

import argparse
import csv
from pathlib import Path

from MCP_r1_fixed4label_ablation import IMPLEMENTATION_SCHEMA_VERSION


VIEWS = ("dlfq", "maxlfq", "top3", "top1")
PLATFORMS = ("DIANN", "Spectronaut")
DEA_METHODS = ("limma", "ROTS")
GROUPS = (("A", "B"), ("A", "C"), ("B", "E"), ("B", "E"), ("B", "D"), ("A", "C"), ("A", "B"))
MASTER_NAME = "MCP_r1_fixed4label_ablation_manifest.csv"
SHARD_STEM = "MCP_r1_fixed4label_ablation_shard"
FIELDS = [
    "experiment_schema", "run_id", "dataset", "acquisition", "platform", "data_index", "group1", "group2",
    "source_views", "model_input_views", "variant", "dea_method", "log_transforms",
    "normalizations", "imputations", "data_root", "r_code", "rscript_path", "gpu_id",
    "seed", "runtime_seed_control", "num_trials", "q_threshold", "fc_ratio",
    "positive_strategy", "label_mode", "availability_policy", "test_type", "force",
]


def build_rows() -> list[dict[str, str]]:
    """Create 140 runs: 7 indices × 2 platforms × 2 DEA × (1 + 4 views)."""
    rows: list[dict[str, str]] = []
    source_views = "+".join(VIEWS)
    log_transforms = "T+F+F+F"
    for data_index, (group1, group2) in enumerate(GROUPS):
        for platform in PLATFORMS:
            for dea_method in DEA_METHODS:
                common = {
                    "experiment_schema": IMPLEMENTATION_SCHEMA_VERSION,
                    "dataset": f"AUTO_INDEX_{data_index}", "acquisition": "DIA",
                    "platform": platform, "data_index": str(data_index), "group1": group1,
                    "group2": group2, "source_views": source_views, "dea_method": dea_method,
                    "log_transforms": log_transforms, "normalizations": "", "imputations": "",
                    "data_root": "data", "r_code": "codes", "rscript_path": "/usr/lib/R/bin/",
                    # FALSE preserves the manuscript run's legacy split seeds:
                    # model/augmentation=1029 and Optuna sampler=2023.
                    "gpu_id": "", "seed": "2024", "runtime_seed_control": "FALSE",
                    "num_trials": "30", "q_threshold": "0.05", "fc_ratio": "1.5",
                    # Preserve the original four-view initialization exactly.
                    "positive_strategy": "0_h", "label_mode": "strict_shared_mask",
                    "availability_policy": "selected_view_noncall", "test_type": "DP_fdr",
                    "force": "FALSE",
                }
                method_slug = dea_method.lower()
                rows.append({
                    **common,
                    "run_id": f"DIA_{platform}_i{data_index}_fixed4_all4_{method_slug}",
                    "model_input_views": "all4", "variant": "full_mcp",
                })
                for view in VIEWS:
                    rows.append({
                        **common,
                        "run_id": f"DIA_{platform}_i{data_index}_fixed4_{view}_{method_slug}",
                        "model_input_views": view, "variant": "single_view_mcp",
                    })
    return rows


def validate_rows(rows: list[dict[str, str]]) -> None:
    if len(rows) != 140:
        raise ValueError(f"Expected 140 rows; found {len(rows)}")
    run_ids = [row["run_id"] for row in rows]
    if len(run_ids) != len(set(run_ids)):
        raise ValueError("run_id values must be unique")
    for data_index in range(7):
        shard = [row for row in rows if row["data_index"] == str(data_index)]
        if len(shard) != 20:
            raise ValueError(f"data_index={data_index} must have 20 rows; found {len(shard)}")
        for platform in PLATFORMS:
            for dea_method in DEA_METHODS:
                stratum = [row for row in shard if row["platform"] == platform and row["dea_method"] == dea_method]
                if len(stratum) != 5 or {row["model_input_views"] for row in stratum} != {"all4", *VIEWS}:
                    raise ValueError(f"Invalid fixed4label stratum {data_index}/{platform}/{dea_method}")
                if any(row["label_mode"] != "strict_shared_mask" for row in stratum):
                    raise ValueError("Fixed4label strata must use label_mode=strict_shared_mask")
                if any(row["availability_policy"] != "selected_view_noncall" for row in stratum):
                    raise ValueError("Fixed4label strata must use selected_view_noncall")


def write_csv(path: Path, rows: list[dict[str, str]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(rows)


def build(output_dir: Path) -> list[Path]:
    """Write one master manifest plus one 20-row manifest per data index."""
    output_dir.mkdir(parents=True, exist_ok=True)
    rows = build_rows()
    validate_rows(rows)
    paths = [output_dir / MASTER_NAME]
    write_csv(paths[0], rows)
    for shard_id in range(1, 8):
        shard_rows = [row for row in rows if row["data_index"] == str(shard_id - 1)]
        path = output_dir / f"{SHARD_STEM}_{shard_id}.csv"
        write_csv(path, shard_rows)
        paths.append(path)
    return paths


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent)
    for path in build(parser.parse_args().output_dir.resolve()):
        print(path)


if __name__ == "__main__":
    main()
