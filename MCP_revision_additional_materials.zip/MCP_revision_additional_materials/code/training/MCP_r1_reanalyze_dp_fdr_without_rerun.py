"""Rebuild reviewer-facing analyses with MCP defined as ``DP_fdr``.

No model is trained by this script.  It reads the fourth MCP block from every
completed ``*_DP_res_all.csv`` (``Probability.3``/``threshold.3`` after pandas
deduplicates column names) and the ``DP_fdr`` row from ``*_metrics_all_s.csv``.
Existing DP_direct/DP_05/q-like results are retained only as explicitly named
sensitivity analyses.

中文说明：本脚本不重跑模型，只从已完成输出中重新提取论文 Fig. 2 所用的
DP_fdr 结果，并重算 Task 1/3/5、视图选择、OpDEA、ridge fusion、
MCP-unique 与多随机种子汇总。
"""

from __future__ import annotations

import argparse
import json
import os
import re
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import (
    average_precision_score,
    cohen_kappa_score,
    confusion_matrix,
    matthews_corrcoef,
    precision_score,
    recall_score,
    roc_auc_score,
)

from MCP_r1_final_revision_utils import (
    bh_adjust,
    bootstrap_mean_ci,
    canonical_view_set,
    exact_signflip_p,
    extract_mcp_result_block,
    view_count,
)


MCP_TEST_TYPE = "DP_fdr"
FC_RATIO = 1.5
LOG2FC_CUTOFF = float(np.log2(FC_RATIO))
METRICS_FOR_INFERENCE = ("auroc", "auprc", "pauc_0.01", "precision", "recall", "mcc")
COMPLEXITY_RANK = {
    "simple_early_fusion": 3,
    "simple_late_fusion": 3,
    "no_balancing": 5,
    "no_contrastive": 5,
    "no_cross_attention": 5,
    "full_mcp": 6,
}

METRIC_COLUMNS = {
    "accuracy": "Acc",
    "precision": "Prec",
    "recall": "Rec",
    "f1": "F1",
    "mcc": "Mcc",
    "pauc_0.01": "pauc001",
    "pauc_0.05": "pauc005",
    "pauc_0.10": "pauc01",
}


def long_path(path: Path) -> str:
    value = str(path.resolve())
    if os.name == "nt" and not value.startswith("\\\\?\\"):
        return "\\\\?\\" + value
    return value


def read_csv(path: Path, **kwargs) -> pd.DataFrame:
    return pd.read_csv(long_path(path), **kwargs)


def prediction_path_from_metrics(metrics_file: object) -> Path:
    path = Path(str(metrics_file))
    marker = "__metrics_all_s.csv"
    if not path.name.endswith(marker):
        raise ValueError(f"Unexpected metrics filename: {path}")
    dataset = path.name[: -len(marker)]
    prediction = path.with_name(f"{dataset}_DP_res_all.csv")
    if not os.path.exists(long_path(prediction)):
        raise FileNotFoundError(prediction)
    return prediction


def dea_name(value: object) -> str:
    text = str(value)
    parts = [part for part in text.split("+") if part]
    return parts[0] if parts and len(set(parts)) == 1 else text


def read_dp_fdr_prediction(metrics_file: object) -> pd.DataFrame:
    prediction = prediction_path_from_metrics(metrics_file)
    table = read_csv(prediction)
    block = extract_mcp_result_block(table, MCP_TEST_TYPE)
    block["Protein"] = block["Protein"].astype(str)
    for column in ("True_lab", "Probability", "ori_logFC", "qvalue", "threshold"):
        block[column] = pd.to_numeric(block[column], errors="coerce")
    block = block.drop_duplicates("Protein")
    block["dp_fdr_call"] = (
        block["Probability"].ge(block["threshold"])
        & block["ori_logFC"].abs().ge(LOG2FC_CUTOFF)
    )
    block["common_0.5_call"] = (
        block["Probability"].ge(0.5)
        & block["ori_logFC"].abs().ge(LOG2FC_CUTOFF)
    )
    block["q_like_0.05_call"] = (
        block["qvalue"].le(0.05)
        & block["ori_logFC"].abs().ge(LOG2FC_CUTOFF)
    )
    block["prediction_file"] = str(prediction)
    return block


def evaluate(truth: np.ndarray, score: np.ndarray, called: np.ndarray) -> dict[str, float]:
    keep = np.isfinite(truth) & np.isfinite(score)
    y = truth[keep].astype(int)
    s = score[keep].astype(float)
    c = called[keep].astype(int)
    if len(np.unique(y)) != 2:
        raise ValueError("Both truth classes are required")
    tn, fp, fn, tp = confusion_matrix(y, c, labels=[0, 1]).ravel()
    return {
        "auroc": float(roc_auc_score(y, s)),
        "auprc": float(average_precision_score(y, s)),
        "pauc_0.01": float(roc_auc_score(y, s, max_fpr=0.01)),
        "precision": float(precision_score(y, c, zero_division=0)),
        "recall": float(recall_score(y, c, zero_division=0)),
        "mcc": float(matthews_corrcoef(y, c)),
        "n_proteins": int(len(y)),
        "tn": int(tn),
        "fp": int(fp),
        "fn": int(fn),
        "tp": int(tp),
    }


def dataset_average(frame: pd.DataFrame, extra: list[str]) -> pd.DataFrame:
    return (
        frame.groupby(["dataset", *extra, "metric"], as_index=False)
        .agg(value=("value", "mean"), n_platform_dea_strata=("value", "count"))
    )


def method_summary(dataset_metrics: pd.DataFrame, method_column: str = "method") -> pd.DataFrame:
    return (
        dataset_metrics.groupby([method_column, "metric"], as_index=False)
        .agg(
            n_biological_datasets=("dataset", "nunique"),
            mean=("value", "mean"),
            median=("value", "median"),
            minimum=("value", "min"),
            maximum=("value", "max"),
        )
    )


def paired_against(
    dataset_metrics: pd.DataFrame,
    reference: str,
    comparators: list[str],
    method_column: str = "method",
    family_label: str = "all listed method-by-metric contrasts",
) -> pd.DataFrame:
    ref = dataset_metrics[dataset_metrics[method_column].eq(reference)][
        ["dataset", "metric", "value"]
    ].rename(columns={"value": "reference_value"})
    rows: list[dict[str, object]] = []
    for comparator in comparators:
        other = dataset_metrics[dataset_metrics[method_column].eq(comparator)][
            ["dataset", "metric", "value"]
        ].rename(columns={"value": "comparator_value"})
        paired = ref.merge(other, on=["dataset", "metric"], validate="one_to_one")
        paired = paired[paired["metric"].isin(METRICS_FOR_INFERENCE)]
        for metric, block in paired.groupby("metric", sort=True):
            difference = (block["reference_value"] - block["comparator_value"]).to_numpy(float)
            low, high = bootstrap_mean_ci(difference)
            rows.append({
                "metric": metric,
                "method_a": reference,
                "method_b": comparator,
                "n_biological_datasets": len(difference),
                "mean_paired_difference": float(np.mean(difference)),
                "median_paired_difference": float(np.median(difference)),
                "bootstrap_95ci_low": low,
                "bootstrap_95ci_high": high,
                "exact_signflip_p": exact_signflip_p(difference),
                "multiplicity_family": family_label,
            })
    output = pd.DataFrame(rows)
    if not output.empty:
        output["bh_q"] = bh_adjust(output["exact_signflip_p"])
    return output


def build_full_prediction_table(canonical: pd.DataFrame) -> pd.DataFrame:
    runs = canonical[
        canonical["collection"].eq("task1_2_core")
        & canonical["variant"].eq("full_mcp")
    ][["run_id", "dataset", "platform", "dea_method", "metrics_file"]].drop_duplicates()
    if len(runs) != 28:
        raise ValueError(f"Expected 28 full-MCP DP_fdr runs; found {len(runs)}")
    blocks: list[pd.DataFrame] = []
    for record in runs.to_dict("records"):
        block = read_dp_fdr_prediction(record["metrics_file"])
        for column in ("dataset", "platform", "dea_method", "run_id"):
            block.insert(0, column, record[column])
        blocks.append(block)
    return pd.concat(blocks, ignore_index=True)


def full_mcp_metrics(full_predictions: pd.DataFrame, output: Path) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    call_columns = {
        "mcp_dp_fdr": "dp_fdr_call",
        "mcp_dp_fdr_common_0.5_sensitivity": "common_0.5_call",
        "mcp_dp_fdr_q_like_sensitivity": "q_like_0.05_call",
    }
    for keys, block in full_predictions.groupby(["dataset", "platform", "dea_method"]):
        truth = block["True_lab"].to_numpy(float)
        score = block["Probability"].to_numpy(float)
        for method, call_column in call_columns.items():
            for metric, value in evaluate(truth, score, block[call_column].to_numpy(bool)).items():
                rows.append({
                    "dataset": keys[0], "platform": keys[1], "dea_method": keys[2],
                    "method": method, "metric": metric, "value": value,
                })
    stratum = pd.DataFrame(rows)
    dataset = dataset_average(stratum, ["method"])
    stratum.to_csv(output / "task1_full_mcp_dp_fdr_metrics_by_stratum.csv", index=False)
    dataset.to_csv(output / "task1_full_mcp_dp_fdr_metrics_by_dataset.csv", index=False)
    method_summary(dataset).to_csv(output / "task1_full_mcp_dp_fdr_summary.csv", index=False)
    return dataset


def task5_analysis(canonical: pd.DataFrame, output: Path) -> None:
    chosen = canonical[
        (
            canonical["collection"].eq("task1_2_core")
            & canonical["variant"].isin(["full_mcp", "simple_early_fusion", "simple_late_fusion"])
        )
        | canonical["collection"].eq("task5_model_complexity")
    ].copy()
    stratum = (
        chosen.groupby(
            ["dataset", "platform", "dea_method", "variant", "metric"], as_index=False
        ).agg(value=("value", "first"))
    )
    dataset = dataset_average(stratum, ["variant"])
    summary = method_summary(dataset, "variant")
    tests = paired_against(
        dataset.rename(columns={"variant": "method"}),
        "full_mcp",
        sorted(set(dataset["variant"]) - {"full_mcp"}),
        family_label="five DP_fdr architecture variants x six inferential metrics",
    )

    means = (
        stratum[stratum["metric"].eq("mcc")]
        .groupby(["platform", "dea_method", "variant"], as_index=False)
        .agg(mean=("value", "mean"), standard_error=("value", lambda x: x.std(ddof=1) / np.sqrt(len(x))))
    )
    one_se_rows: list[dict[str, object]] = []
    for (platform, dea), block in means.groupby(["platform", "dea_method"]):
        best = block.loc[block["mean"].idxmax()]
        cutoff = float(best["mean"] - best["standard_error"])
        eligible = block[block["mean"].ge(cutoff)].copy()
        eligible["complexity_rank"] = eligible["variant"].map(COMPLEXITY_RANK).fillna(99)
        choice = eligible.sort_values(["complexity_rank", "mean"], ascending=[True, False]).iloc[0]
        one_se_rows.append({
            "platform": platform, "dea_method": dea,
            "best_variant": best["variant"], "best_mean_mcc": best["mean"],
            "one_se_cutoff": cutoff,
            "parsimonious_variant": choice["variant"],
            "parsimonious_mean_mcc": choice["mean"],
        })

    stratum.to_csv(output / "task5_dp_fdr_metrics_by_stratum.csv", index=False)
    dataset.to_csv(output / "task5_dp_fdr_metrics_by_dataset.csv", index=False)
    summary.to_csv(output / "task5_dp_fdr_summary.csv", index=False)
    tests.to_csv(output / "task5_dp_fdr_paired_tests_vs_full.csv", index=False)
    pd.DataFrame(one_se_rows).to_csv(output / "task5_dp_fdr_one_standard_error_selection.csv", index=False)


def multiseed_analysis(canonical: pd.DataFrame, output: Path) -> None:
    source = canonical[canonical["collection"].eq("multiseed_stability")].copy()
    if source[["run_id", "dataset"]].drop_duplicates().shape[0] != 140:
        raise ValueError("Expected 140 multi-seed DP_fdr runs")
    dataset_seed = (
        source.groupby(["dataset", "variant", "seed", "metric"], as_index=False)
        .agg(value=("value", "mean"), n_platform_dea_strata=("value", "count"))
    )
    by_dataset = (
        dataset_seed.groupby(["dataset", "variant", "metric"], as_index=False)
        .agg(
            mean_across_seeds=("value", "mean"),
            seed_sd=("value", "std"),
            seed_min=("value", "min"),
            seed_max=("value", "max"),
            n_seeds=("seed", "nunique"),
        )
    )
    by_dataset["seed_range"] = by_dataset["seed_max"] - by_dataset["seed_min"]
    summary = (
        by_dataset.groupby(["variant", "metric"], as_index=False)
        .agg(
            n_biological_datasets=("dataset", "nunique"),
            mean_performance=("mean_across_seeds", "mean"),
            mean_seed_sd=("seed_sd", "mean"),
            median_seed_sd=("seed_sd", "median"),
            maximum_seed_range=("seed_range", "max"),
        )
    )
    source.to_csv(output / "merged_performance_long_dp_fdr.csv", index=False)
    dataset_seed.to_csv(output / "dataset_seed_performance_dp_fdr.csv", index=False)
    by_dataset.to_csv(output / "seed_stability_by_dataset_dp_fdr.csv", index=False)
    summary.to_csv(output / "seed_stability_summary_dp_fdr.csv", index=False)


def view_count_and_loodo(canonical: pd.DataFrame, output: Path) -> None:
    single = canonical[
        canonical["collection"].eq("task1_2_core")
        & canonical["variant"].eq("single_view_mcp")
    ]
    full = canonical[
        canonical["collection"].eq("task1_2_core")
        & canonical["variant"].eq("full_mcp")
    ]
    combinations = canonical[canonical["collection"].eq("view_combinations")]
    all_views = pd.concat([single, combinations, full], ignore_index=True)
    all_views["view_set"] = all_views["view_set"].map(canonical_view_set)
    all_views["view_count"] = all_views["view_set"].map(view_count)
    stratum = (
        all_views.groupby(
            ["dataset", "platform", "dea_method", "view_set", "view_count", "metric"],
            as_index=False,
        ).agg(value=("value", "first"))
    )
    dataset = (
        stratum.groupby(["dataset", "view_set", "view_count", "metric"], as_index=False)
        .agg(value=("value", "mean"), n_platform_dea_strata=("value", "count"))
    )
    if dataset["view_set"].nunique() != 15 or dataset["dataset"].nunique() != 7:
        raise ValueError("DP_fdr view analysis must contain 15 exact view sets x seven datasets")
    count_summary = (
        dataset.groupby(["view_count", "metric"], as_index=False)
        .agg(n_view_dataset_rows=("value", "size"), mean=("value", "mean"), median=("value", "median"))
    )

    # Leave-one-dataset-out selection, using only the other six datasets.
    fixed = {
        "fixed_dlfq": "dlfq",
        "fixed_dlfq_maxlfq": "dlfq+maxlfq",
        "fixed_four_view": "dlfq+maxlfq+top3+top1",
    }
    holdout_rows: list[dict[str, object]] = []
    for metric, metric_block in dataset.groupby("metric"):
        for held_out in sorted(metric_block["dataset"].unique()):
            train = metric_block[metric_block["dataset"].ne(held_out)]
            train_means = train.groupby(["view_set", "view_count"], as_index=False)["value"].mean()
            best_value = float(train_means["value"].max())
            choice = train_means[np.isclose(train_means["value"], best_value)].sort_values(
                ["view_count", "view_set"]
            ).iloc[0]
            test = metric_block[metric_block["dataset"].eq(held_out)].set_index("view_set")["value"]
            selected_set = str(choice["view_set"])
            selected_value = float(test[selected_set])
            row: dict[str, object] = {
                "metric": metric,
                "held_out_dataset": held_out,
                "selected_view_set": selected_set,
                "selected_view_count": int(choice["view_count"]),
                "training_six_dataset_mean": best_value,
                "held_out_selected_value": selected_value,
                "held_out_oracle_value": float(test.max()),
                "top1_regret": float(test.max() - selected_value),
            }
            for label, view_set_name in fixed.items():
                value = float(test[view_set_name])
                row[f"{label}_value"] = value
                row[f"selected_minus_{label}"] = selected_value - value
            holdout_rows.append(row)
    holdout = pd.DataFrame(holdout_rows)
    comparisons: list[dict[str, object]] = []
    for metric, block in holdout.groupby("metric"):
        for baseline in fixed:
            difference = block[f"selected_minus_{baseline}"].to_numpy(float)
            low, high = bootstrap_mean_ci(difference)
            comparisons.append({
                "metric": metric, "method_a": "LOODO_selected", "method_b": baseline,
                "n_biological_datasets": len(difference),
                "mean_paired_difference": float(np.mean(difference)),
                "median_paired_difference": float(np.median(difference)),
                "bootstrap_95ci_low": low, "bootstrap_95ci_high": high,
                "exact_signflip_p": exact_signflip_p(difference),
            })
    frequency = (
        holdout.groupby(["metric", "selected_view_set", "selected_view_count"], as_index=False)
        .agg(n_selected_folds=("held_out_dataset", "count"))
    )
    stratum.to_csv(output / "view_dp_fdr_metrics_by_stratum.csv", index=False)
    dataset.to_csv(output / "view_dp_fdr_metrics_by_dataset.csv", index=False)
    count_summary.to_csv(output / "view_count_dp_fdr_summary.csv", index=False)
    holdout.to_csv(output / "loodo_dp_fdr_selection_per_dataset.csv", index=False)
    pd.DataFrame(comparisons).to_csv(output / "loodo_dp_fdr_paired_comparisons.csv", index=False)
    frequency.to_csv(output / "loodo_dp_fdr_selected_view_frequency.csv", index=False)


def task3_metrics(canonical: pd.DataFrame, output: Path) -> None:
    source = canonical[canonical["collection"].eq("task3_pseudo_label")].copy()
    if source[["run_id", "dataset"]].drop_duplicates().shape[0] != 672:
        raise ValueError("Expected 672 Task 3 DP_fdr runs")
    dataset = (
        source.groupby(["dataset", "strategy", "metric"], as_index=False)
        .agg(value=("value", "mean"), n_platform_dea_strata=("value", "count"))
    )
    summary = method_summary(dataset.rename(columns={"strategy": "method"}))
    source.to_csv(output / "task3_dp_fdr_metrics_by_stratum_long.csv", index=False)
    dataset.to_csv(output / "task3_dp_fdr_metrics_by_dataset_strategy.csv", index=False)
    summary.to_csv(output / "task3_dp_fdr_strategy_summary.csv", index=False)


def task3_protein_copy_audit(canonical: pd.DataFrame, output: Path) -> None:
    runs = canonical[
        canonical["collection"].eq("task3_pseudo_label")
        & canonical["strategy"].eq("reference_hurdle_agreement")
    ][["run_id", "dataset", "platform", "dea_method", "ledger_file", "metrics_file"]].drop_duplicates()
    if len(runs) != 28:
        raise ValueError(f"Expected 28 original-strategy Task 3 runs; found {len(runs)}")
    rows: list[dict[str, object]] = []
    for record in runs.to_dict("records"):
        prediction = read_dp_fdr_prediction(record["metrics_file"])
        ledger_path = Path(record["ledger_file"])
        label_path = ledger_path.parent.parent / "generated_pseudo_labels.csv"
        labels = read_csv(label_path)
        labels = labels[["protein", "true_label", "reference_hurdle_agreement"]].copy()
        labels["protein"] = labels["protein"].astype(str)
        merged = prediction.merge(labels, left_on="Protein", right_on="protein", how="inner")
        pseudo = pd.to_numeric(merged["reference_hurdle_agreement"], errors="coerce").to_numpy(float)
        truth = pd.to_numeric(merged["true_label"], errors="coerce").to_numpy(float)
        score = merged["Probability"].to_numpy(float)
        calls = {
            "DP_fdr_canonical": merged["dp_fdr_call"].to_numpy(int),
            "DP_fdr_common_0.5_sensitivity": merged["common_0.5_call"].to_numpy(int),
        }
        for rule, called in calls.items():
            known = np.isin(pseudo, [0, 1]) & np.isin(truth, [0, 1])
            erroneous = known & (pseudo != truth)
            correct = known & (pseudo == truth)
            unlabeled = (pseudo < 0) & np.isin(truth, [0, 1]) & np.isfinite(score)
            row = {
                **{key: record[key] for key in ("run_id", "dataset", "platform", "dea_method")},
                "calling_rule": rule,
                "n_known_pseudo_labels": int(known.sum()),
                "agreement_with_known_pseudo_labels": float((called[known] == pseudo[known]).mean()),
                "cohen_kappa_with_known_pseudo_labels": (
                    float(cohen_kappa_score(pseudo[known].astype(int), called[known])) if known.sum() > 1 else np.nan
                ),
                "pseudo_label_error_rate_on_known": float((pseudo[known] != truth[known]).mean()),
                "mcp_error_rate_on_known": float((called[known] != truth[known]).mean()),
                "fraction_erroneous_pseudo_labels_corrected": (
                    float((called[erroneous] == truth[erroneous]).mean()) if erroneous.any() else np.nan
                ),
                "fraction_correct_pseudo_labels_changed": (
                    float((called[correct] != truth[correct]).mean()) if correct.any() else np.nan
                ),
                "n_initially_unlabeled": int(unlabeled.sum()),
            }
            if unlabeled.any() and len(np.unique(truth[unlabeled])) == 2:
                row.update({
                    "unlabeled_auroc": float(roc_auc_score(truth[unlabeled], score[unlabeled])),
                    "unlabeled_auprc": float(average_precision_score(truth[unlabeled], score[unlabeled])),
                    "unlabeled_pauc_0.01": float(roc_auc_score(truth[unlabeled], score[unlabeled], max_fpr=0.01)),
                    "unlabeled_mcc": float(matthews_corrcoef(truth[unlabeled].astype(int), called[unlabeled])),
                })
            rows.append(row)
    stratum = pd.DataFrame(rows)
    numeric = [column for column in stratum.columns if column not in {
        "run_id", "dataset", "platform", "dea_method", "calling_rule"
    }]
    dataset = stratum.groupby(["dataset", "calling_rule"], as_index=False)[numeric].mean()
    summary = dataset.groupby("calling_rule", as_index=False)[numeric].mean()
    stratum.to_csv(output / "task3_protein_copy_audit_dp_fdr_by_stratum.csv", index=False)
    dataset.to_csv(output / "task3_protein_copy_audit_dp_fdr_by_dataset.csv", index=False)
    summary.to_csv(output / "task3_protein_copy_audit_dp_fdr_summary.csv", index=False)

    # Test the reviewer-relevant net-correction question at the biological-
    # dataset level.  Positive values mean MCP corrected more pseudo-label
    # errors than it introduced; this is intentionally not a protein-level
    # pseudoreplication test.
    correction = dataset[dataset["calling_rule"].eq("DP_fdr_canonical")].copy()
    difference = (
        correction["pseudo_label_error_rate_on_known"]
        - correction["mcp_error_rate_on_known"]
    ).to_numpy(float)
    ci_low, ci_high = bootstrap_mean_ci(difference)
    pd.DataFrame([{
        "contrast": "pseudo_label_error_rate_minus_MCP_DP_fdr_error_rate",
        "n_biological_datasets": len(difference),
        "mean_net_error_reduction": float(np.mean(difference)),
        "median_net_error_reduction": float(np.median(difference)),
        "bootstrap_95ci_low": ci_low,
        "bootstrap_95ci_high": ci_high,
        "exact_signflip_p": exact_signflip_p(difference),
    }]).to_csv(output / "task3_dp_fdr_net_label_correction_test.csv", index=False)


def sam_dp_fdr_analysis(canonical: pd.DataFrame, project: Path, output: Path) -> None:
    """Rebuild both SAM roles while keeping MCP fixed to DP_fdr.

    Native SAM is a standalone single-view reference.  The separate
    MCP(SAM-label) rows are a label-source sensitivity analysis, not another
    competing algorithm.
    """

    output.mkdir(parents=True, exist_ok=True)
    core = canonical[
        canonical["collection"].eq("task1_2_core")
        & canonical["variant"].eq("full_mcp")
    ][["dataset", "platform", "dea_method", "metric", "value"]].copy()
    core = core[core["dataset"].ne("HYE_SC")]

    native_path = (
        project / "revision_response_outputs" / "tables"
        / "sam_native_complete_per_stratum_metrics.csv"
    )
    native = pd.read_csv(native_path)
    native = native[native["dataset"].ne("HYE_SC")].copy()

    # Standalone comparison: average limma and ROTS within dataset/platform;
    # do not select the best SAM view on each dataset.
    full = (
        core[core["metric"].isin(["precision", "recall", "mcc", "pauc_0.01"])]
        .groupby(["dataset", "platform", "metric"], as_index=False)
        .agg(value=("value", "mean"))
        .pivot(index=["dataset", "platform"], columns="metric", values="value")
        .reset_index()
    )
    full["method_key"] = "full_mcp_dp_fdr"
    full["method_label"] = "Full MCP (DP_fdr; limma/ROTS averaged)"
    full["binary_rule"] = "MCP DP_fdr canonical operating rule"

    native_rows: list[dict[str, object]] = []
    for row in native.to_dict("records"):
        native_rows.append({
            "dataset": row["dataset"],
            "platform": row["platform"],
            "precision": row["precision"],
            "recall": row["recall"],
            "mcc": row["mcc"],
            "pauc_0.01": row["pauc_0.01_continuous_permutation_p"],
            "method_key": f"sam_{str(row['view']).lower()}",
            "method_label": f"Native SAM: {row['view']}",
            "binary_rule": "Native SAM median FDR<=0.05 + FC ratio 1.5",
        })
    reference = pd.concat([full, pd.DataFrame(native_rows)], ignore_index=True)
    reference.to_csv(output / "sam_reference_per_dataset_dp_fdr.csv", index=False)
    reference_summary = (
        reference.groupby(["platform", "method_key", "method_label", "binary_rule"], as_index=False)
        .agg(**{
            "n_biological_datasets": ("dataset", "nunique"),
            "mean_precision": ("precision", "mean"),
            "mean_recall": ("recall", "mean"),
            "mean_mcc": ("mcc", "mean"),
            "mean_pauc_0.01": ("pauc_0.01", "mean"),
        })
    )
    reference_summary.to_csv(output / "sam_reference_summary_dp_fdr.csv", index=False)

    primary_tests: list[dict[str, object]] = []
    for platform in ["DIANN", "Spectronaut"]:
        for comparator in ["sam_dlfq", "sam_maxlfq"]:
            a = reference[
                reference["platform"].eq(platform)
                & reference["method_key"].eq("full_mcp_dp_fdr")
            ][["dataset", "pauc_0.01"]].rename(columns={"pauc_0.01": "mcp"})
            b = reference[
                reference["platform"].eq(platform)
                & reference["method_key"].eq(comparator)
            ][["dataset", "pauc_0.01"]].rename(columns={"pauc_0.01": "sam"})
            paired = a.merge(b, on="dataset", validate="one_to_one")
            difference = paired["mcp"].to_numpy(float) - paired["sam"].to_numpy(float)
            low, high = bootstrap_mean_ci(difference)
            primary_tests.append({
                "platform": platform,
                "method_a": "full_mcp_dp_fdr",
                "method_b": comparator,
                "metric": "pauc_0.01",
                "n_biological_datasets": len(difference),
                "mean_paired_difference": float(np.mean(difference)),
                "bootstrap_95ci_low": low,
                "bootstrap_95ci_high": high,
                "exact_signflip_p": exact_signflip_p(difference),
                "multiplicity_family": "two platforms x SAM-dLFQ/SAM-MaxLFQ",
            })
    primary = pd.DataFrame(primary_tests)
    primary["bh_q"] = bh_adjust(primary["exact_signflip_p"])
    primary.to_csv(output / "sam_reference_primary_pauc_tests_dp_fdr.csv", index=False)

    # MCP label-source sensitivity.  SAM-label outputs are already completed
    # and each metrics file contains a DP_fdr row.
    sam_root = project / "4views_rev10.05_auc_blank_blank_remove_0_h"
    sam_rows: list[dict[str, object]] = []
    for metrics_path in sorted(sam_root.rglob("*__metrics_all_s.csv")):
        dataset = metrics_path.name.replace("__metrics_all_s.csv", "")
        if dataset == "HYE_SC":
            continue
        platform = "DIANN" if "SAMdelta_DIANN" in str(metrics_path) else "Spectronaut"
        frame = read_csv(metrics_path)
        selected = frame[frame["test_type"].astype(str).eq(MCP_TEST_TYPE)]
        if len(selected) != 1:
            raise ValueError(f"Expected one DP_fdr row in {metrics_path}; found {len(selected)}")
        row = selected.iloc[0]
        for metric, column in METRIC_COLUMNS.items():
            if metric not in {"precision", "recall", "f1", "mcc", "pauc_0.01"}:
                continue
            sam_rows.append({
                "dataset": dataset,
                "platform": platform,
                "label_source": "SAM",
                "metric": metric,
                "value": float(pd.to_numeric(row[column], errors="raise")),
                "source_file": str(metrics_path),
            })
    sam_long = pd.DataFrame(sam_rows)
    core_sources = core[
        core["dea_method"].isin(["limma", "ROTS"])
        & core["metric"].isin(["precision", "recall", "f1", "mcc", "pauc_0.01"])
    ].rename(columns={"dea_method": "label_source"})
    core_sources["source_file"] = "completed Task1/2 DP_fdr metrics"
    source_long = pd.concat([
        core_sources[["dataset", "platform", "label_source", "metric", "value", "source_file"]],
        sam_long,
    ], ignore_index=True)

    common_parts: list[pd.DataFrame] = []
    for platform, expected_n in [("DIANN", 7), ("Spectronaut", 4)]:
        available = set(sam_long.loc[sam_long["platform"].eq(platform), "dataset"])
        if len(available) != expected_n:
            raise ValueError(f"Expected {expected_n} MCP(SAM-label) datasets for {platform}; found {len(available)}")
        part = source_long[
            source_long["platform"].eq(platform)
            & source_long["dataset"].isin(available)
        ].copy()
        part["analysis_scope"] = f"{platform}_common_n{expected_n}"
        common_parts.append(part)
    source_long = pd.concat(common_parts, ignore_index=True)
    source_wide = source_long.pivot_table(
        index=["analysis_scope", "dataset", "platform", "label_source"],
        columns="metric", values="value", aggfunc="first",
    ).reset_index()
    source_wide["mcp_architecture"] = "full_four_view_MCP"
    source_wide["output_rule"] = "DP_fdr"
    source_wide.to_csv(output / "mcp_label_source_per_dataset_dp_fdr.csv", index=False)
    source_summary = (
        source_wide.groupby(["analysis_scope", "platform", "label_source"], as_index=False)
        .agg(**{
            "n_biological_datasets": ("dataset", "nunique"),
            "mean_precision": ("precision", "mean"),
            "mean_recall": ("recall", "mean"),
            "mean_f1": ("f1", "mean"),
            "mean_mcc": ("mcc", "mean"),
            "mean_pauc_0.01": ("pauc_0.01", "mean"),
        })
    )
    source_summary.to_csv(output / "mcp_label_source_summary_dp_fdr.csv", index=False)


def merge_dp_fdr_into_existing(
    base: pd.DataFrame,
    full_predictions: pd.DataFrame,
) -> pd.DataFrame:
    keys = ["dataset", "platform", "dea_method", "Protein"]
    add = full_predictions[keys + [
        "Probability", "ori_logFC", "qvalue", "threshold",
        "dp_fdr_call", "common_0.5_call", "q_like_0.05_call",
    ]].rename(columns={
        "Probability": "mcp_dp_fdr_probability",
        "ori_logFC": "mcp_dp_fdr_log2fc",
        "qvalue": "mcp_dp_fdr_q_like",
        "threshold": "mcp_dp_fdr_threshold",
    })
    base = base.copy()
    base["Protein"] = base["Protein"].astype(str)
    return base.merge(add, on=keys, how="inner", validate="many_to_one")


def matched_opdea_analysis(full_predictions: pd.DataFrame, project: Path, output: Path) -> None:
    source_path = project / "revision_results" / "final_required" / "matched_opdea_hurdle" / "matched_opdea_hurdle_predictions.csv.gz"
    source = pd.read_csv(source_path)
    combined = merge_dp_fdr_into_existing(source, full_predictions)
    rows: list[dict[str, object]] = []
    for keys, block in combined.groupby(["dataset", "platform", "dea_method"]):
        truth = pd.to_numeric(block["True_lab"], errors="coerce").to_numpy(float)
        methods = {
            "mcp_dp_fdr": (
                block["mcp_dp_fdr_probability"].to_numpy(float), block["dp_fdr_call"].to_numpy(bool)
            ),
            "mcp_dp_fdr_common_0.5_sensitivity": (
                block["mcp_dp_fdr_probability"].to_numpy(float), block["common_0.5_call"].to_numpy(bool)
            ),
            "mcp_dp_fdr_q_like_sensitivity": (
                block["mcp_dp_fdr_probability"].to_numpy(float), block["q_like_0.05_call"].to_numpy(bool)
            ),
            "opdea_official_hurdle_operator": (
                pd.to_numeric(block["score"], errors="coerce").to_numpy(float),
                (
                    pd.to_numeric(block["adj.pvalue"], errors="coerce").le(0.05)
                    & pd.to_numeric(block["logFC"], errors="coerce").abs().ge(LOG2FC_CUTOFF)
                ).to_numpy(bool),
            ),
        }
        for method, (score, called) in methods.items():
            for metric, value in evaluate(truth, score, called).items():
                rows.append({
                    "dataset": keys[0], "platform": keys[1], "dea_method": keys[2],
                    "method": method, "metric": metric, "value": value,
                })
    stratum = pd.DataFrame(rows)
    dataset = dataset_average(stratum, ["method"])
    tests = paired_against(
        dataset,
        "mcp_dp_fdr",
        ["opdea_official_hurdle_operator"],
        family_label="canonical MCP DP_fdr vs matched OpDEA across six inferential metrics",
    )
    output.mkdir(parents=True, exist_ok=True)
    combined.to_csv(output / "matched_opdea_hurdle_predictions_dp_fdr.csv.gz", index=False, compression="gzip")
    stratum.to_csv(output / "matched_opdea_hurdle_metrics_by_stratum_dp_fdr.csv", index=False)
    dataset.to_csv(output / "matched_opdea_hurdle_metrics_by_dataset_dp_fdr.csv", index=False)
    tests.to_csv(output / "mcp_dp_fdr_vs_matched_opdea_paired_tests.csv", index=False)
    method_summary(dataset).to_csv(output / "matched_opdea_hurdle_summary_dp_fdr.csv", index=False)


def linear_fusion_analysis(full_predictions: pd.DataFrame, project: Path, output: Path) -> None:
    source_path = project / "revision_results" / "final_required" / "linear_fusion_baselines" / "linear_fusion_predictions.csv.gz"
    source = pd.read_csv(source_path)
    combined = merge_dp_fdr_into_existing(source, full_predictions)
    rows: list[dict[str, object]] = []
    for keys, block in combined.groupby(["dataset", "platform", "dea_method"]):
        truth = pd.to_numeric(block["True_lab"], errors="coerce").to_numpy(float)
        fc_ok = block["mcp_dp_fdr_log2fc"].abs().ge(LOG2FC_CUTOFF).to_numpy(bool)
        methods = {
            "mcp_dp_fdr": (
                block["mcp_dp_fdr_probability"].to_numpy(float), block["dp_fdr_call"].to_numpy(bool)
            ),
            "mcp_dp_fdr_common_0.5_sensitivity": (
                block["mcp_dp_fdr_probability"].to_numpy(float), block["common_0.5_call"].to_numpy(bool)
            ),
            "ridge_early_fusion": (
                block["ridge_early_probability"].to_numpy(float),
                block["ridge_early_probability"].ge(0.5).to_numpy(bool) & fc_ok,
            ),
            "ridge_late_fusion": (
                block["ridge_late_probability"].to_numpy(float),
                block["ridge_late_probability"].ge(0.5).to_numpy(bool) & fc_ok,
            ),
            "statistical_union": (
                block["statistical_union_score"].to_numpy(float),
                block["statistical_union_call"].to_numpy(bool),
            ),
            "statistical_intersection": (
                block["statistical_intersection_score"].to_numpy(float),
                block["statistical_intersection_call"].to_numpy(bool),
            ),
        }
        for method, (score, called) in methods.items():
            for metric, value in evaluate(truth, score, called).items():
                rows.append({
                    "dataset": keys[0], "platform": keys[1], "dea_method": keys[2],
                    "method": method, "metric": metric, "value": value,
                })
    stratum = pd.DataFrame(rows)
    dataset = dataset_average(stratum, ["method"])
    ranking_tests = paired_against(
        dataset[dataset["metric"].isin(["auroc", "auprc", "pauc_0.01"])],
        "mcp_dp_fdr",
        ["ridge_early_fusion", "ridge_late_fusion"],
        family_label="DP_fdr ranking score vs two ridge models x three ranking metrics",
    )
    common_binary = dataset[dataset["metric"].isin(["precision", "recall", "mcc"])]
    binary_tests = paired_against(
        common_binary,
        "mcp_dp_fdr_common_0.5_sensitivity",
        ["ridge_early_fusion", "ridge_late_fusion"],
        family_label="common 0.5 sensitivity: MCP DP_fdr score vs two ridge models x three binary metrics",
    )
    output.mkdir(parents=True, exist_ok=True)
    combined.to_csv(output / "linear_fusion_predictions_dp_fdr.csv.gz", index=False, compression="gzip")
    stratum.to_csv(output / "linear_fusion_metrics_by_stratum_dp_fdr.csv", index=False)
    dataset.to_csv(output / "linear_fusion_metrics_by_dataset_dp_fdr.csv", index=False)
    method_summary(dataset).to_csv(output / "linear_fusion_summary_dp_fdr.csv", index=False)
    ranking_tests.to_csv(output / "mcp_dp_fdr_vs_ridge_ranking_paired_tests.csv", index=False)
    binary_tests.to_csv(output / "mcp_dp_fdr_vs_ridge_common05_binary_paired_tests.csv", index=False)


def mcp_unique_analysis(full_predictions: pd.DataFrame, project: Path, output: Path) -> None:
    from MCP_r1_mcp_unique_dep_characterization import paired_quality_tests, summarize_groups

    source_path = project / "revision_results" / "final_required" / "mcp_unique_dep" / "mcp_unique_protein_quality.csv.gz"
    source = pd.read_csv(source_path)
    keys = ["dataset", "platform", "dea_method", "Protein"]
    # The legacy file repeats each protein for two non-canonical call rules.
    base = source.sort_values("call_rule").drop_duplicates(keys).drop(
        columns=["call_rule", "mcp_call", "detection_category"], errors="ignore"
    )
    combined = merge_dp_fdr_into_existing(base, full_predictions)
    outputs: list[pd.DataFrame] = []
    rules = {
        "dp_fdr_canonical": "dp_fdr_call",
        "dp_fdr_common_0.5_sensitivity": "common_0.5_call",
        "dp_fdr_q_like_sensitivity": "q_like_0.05_call",
    }
    for rule, column in rules.items():
        block = combined.copy()
        mcp_call = block[column].fillna(False).astype(bool)
        stat_call = block["statistical_union_call"].fillna(False).astype(bool)
        block["call_rule"] = rule
        block["mcp_call"] = mcp_call
        block["detection_category"] = np.select(
            [mcp_call & ~stat_call, mcp_call & stat_call, ~mcp_call & stat_call],
            ["MCP_unique", "MCP_and_statistical", "statistical_only"],
            default="neither",
        )
        outputs.append(block)
    proteins = pd.concat(outputs, ignore_index=True)
    stratum, dataset = summarize_groups(proteins)
    tests, paired = paired_quality_tests(dataset)
    output.mkdir(parents=True, exist_ok=True)
    proteins.to_csv(output / "mcp_unique_protein_quality_dp_fdr.csv.gz", index=False, compression="gzip")
    stratum.to_csv(output / "mcp_unique_group_summary_by_stratum_dp_fdr.csv", index=False)
    dataset.to_csv(output / "mcp_unique_group_summary_by_dataset_dp_fdr.csv", index=False)
    paired.to_csv(output / "mcp_unique_paired_dataset_values_dp_fdr.csv", index=False)
    tests.to_csv(output / "mcp_unique_quality_tests_dp_fdr.csv", index=False)

    canonical_groups = dataset[
        dataset["call_rule"].eq("dp_fdr_canonical")
        & dataset["detection_category"].isin(["MCP_unique", "MCP_and_statistical"])
    ][["dataset", "detection_category", "truth_positive_fraction"]]
    truth = canonical_groups.pivot(
        index="dataset", columns="detection_category", values="truth_positive_fraction"
    ).dropna()
    difference = (
        truth["MCP_unique"] - truth["MCP_and_statistical"]
    ).to_numpy(float)
    low, high = bootstrap_mean_ci(difference)
    pd.DataFrame([{
        "contrast": "MCP_unique_minus_MCP_and_statistical_truth_positive_fraction",
        "n_biological_datasets": len(difference),
        "mean_unique": float(truth["MCP_unique"].mean()),
        "mean_overlap": float(truth["MCP_and_statistical"].mean()),
        "mean_paired_difference": float(np.mean(difference)),
        "bootstrap_95ci_low": low,
        "bootstrap_95ci_high": high,
        "exact_signflip_p": exact_signflip_p(difference),
    }]).to_csv(output / "mcp_unique_truth_fraction_test_dp_fdr.csv", index=False)


def original_fig2_audit(project: Path, output: Path) -> None:
    output.mkdir(parents=True, exist_ok=True)
    source = project / "MCP_r1_R_reanalysis" / "original_fig2_stats2"
    pattern = re.compile(
        r"^stats_(DDA|DIA)_(FragPipe|Maxquant|DIANN|Spectronaut)_(MCC|Prec|Rec|F1|pAUC)_(mean|median)\.csv$"
    )
    blocks: list[pd.DataFrame] = []
    for path in sorted(source.glob("*.csv")):
        hit = pattern.match(path.name)
        if not hit:
            continue
        matrix = pd.read_csv(path, index_col=0)
        matrix.index.name = "view_combination"
        long = matrix.reset_index().melt(id_vars="view_combination", var_name="method", value_name="value")
        long[["acquisition", "platform", "metric", "summary_statistic"]] = hit.groups()
        long["source_file"] = path.name
        blocks.append(long)
    data = pd.concat(blocks, ignore_index=True)
    data["method"] = data["method"].replace({"MVDEA": "MCP_DP_fdr", "DMVLC": "DMVLS"})
    data.to_csv(output / "original_fig2_matrices_long.csv", index=False)

    median = data[data["summary_statistic"].eq("median")]
    precision = median[median["metric"].eq("Prec")].pivot(
        index=["acquisition", "platform", "view_combination"], columns="method", values="value"
    ).add_prefix("precision_")
    recall = median[median["metric"].eq("Rec")].pivot(
        index=["acquisition", "platform", "view_combination"], columns="method", values="value"
    ).add_prefix("recall_")
    claim = precision.join(recall).reset_index()
    single_columns = [
        column for column in ("recall_dlfq", "recall_maxlfq", "recall_top0", "recall_top3", "recall_top1", "recall_count")
        if column in claim
    ]
    claim["best_included_single_view_recall"] = claim[single_columns].max(axis=1, skipna=True)
    claim["mcp_precision_gt_0.90"] = claim["precision_MCP_DP_fdr"].gt(0.90)
    claim["mcp_precision_ge_0.90"] = claim["precision_MCP_DP_fdr"].ge(0.90)
    for baseline in ("best_included_single_view", "hurdle", "ETMC", "DMVLS"):
        denominator = (
            claim["best_included_single_view_recall"] if baseline == "best_included_single_view"
            else claim[f"recall_{baseline}"]
        )
        claim[f"relative_recall_gain_vs_{baseline}"] = (
            claim["recall_MCP_DP_fdr"] - denominator
        ) / denominator
        claim[f"absolute_recall_gain_vs_{baseline}"] = claim["recall_MCP_DP_fdr"] - denominator
    claim["joint_gt90_precision_and_gt20pct_recall_vs_best_single"] = (
        claim["mcp_precision_gt_0.90"]
        & claim["relative_recall_gain_vs_best_included_single_view"].gt(0.20)
    )
    claim.to_csv(output / "original_fig2_claim_scope_audit_median.csv", index=False)
    counts = (
        claim.groupby(["acquisition", "platform"], as_index=False)
        .agg(**{
            "n_view_combinations": ("view_combination", "size"),
            "n_precision_gt_0.90": ("mcp_precision_gt_0.90", "sum"),
            "n_precision_ge_0.90": ("mcp_precision_ge_0.90", "sum"),
            "n_joint_claim_settings": ("joint_gt90_precision_and_gt20pct_recall_vs_best_single", "sum"),
            "min_mcp_precision": ("precision_MCP_DP_fdr", "min"),
            "max_mcp_precision": ("precision_MCP_DP_fdr", "max"),
            "min_relative_recall_gain_vs_best_single": ("relative_recall_gain_vs_best_included_single_view", "min"),
            "max_relative_recall_gain_vs_best_single": ("relative_recall_gain_vs_best_included_single_view", "max"),
            "min_absolute_recall_gain_vs_hurdle": ("absolute_recall_gain_vs_hurdle", "min"),
            "max_absolute_recall_gain_vs_hurdle": ("absolute_recall_gain_vs_hurdle", "max"),
        })
    )
    counts.to_csv(output / "original_fig2_claim_scope_counts.csv", index=False)


def main() -> None:
    parser = argparse.ArgumentParser()
    project_default = Path(__file__).resolve().parent
    parser.add_argument("--project-dir", type=Path, default=project_default)
    parser.add_argument(
        "--audit-long",
        type=Path,
        default=project_default / "revision_results" / "dp_fdr_correction" / "canonical_mcp_dp_fdr_metrics_long.csv",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=project_default / "revision_results" / "dp_fdr_correction" / "reanalyzed",
    )
    args = parser.parse_args()
    project = args.project_dir.expanduser().resolve()
    output = args.output_dir.expanduser().resolve()
    output.mkdir(parents=True, exist_ok=True)
    canonical = pd.read_csv(args.audit_long)

    full_predictions = build_full_prediction_table(canonical)
    full_predictions.to_csv(output / "full_mcp_dp_fdr_predictions_28_strata.csv.gz", index=False, compression="gzip")
    full_mcp_metrics(full_predictions, output)
    task5_analysis(canonical, output)
    multiseed_analysis(canonical, output)
    view_count_and_loodo(canonical, output)
    task3_metrics(canonical, output)
    task3_protein_copy_audit(canonical, output)
    sam_dp_fdr_analysis(canonical, project, output / "sam")
    matched_opdea_analysis(full_predictions, project, output / "matched_opdea_hurdle")
    linear_fusion_analysis(full_predictions, project, output / "linear_fusion_baselines")
    mcp_unique_analysis(full_predictions, project, output / "mcp_unique_dep")
    original_fig2_audit(project, output / "original_fig2")

    summary = {
        "canonical_mcp_definition": "DP_fdr",
        "models_retrained": 0,
        "source": "completed metrics_all_s.csv DP_fdr rows and DP_res_all.csv fourth MCP blocks",
        "diagnostic_only": ["DP_direct", "DP_05", "exported q-like<=0.05"],
    }
    (output / "analysis_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    print(f"Corrected outputs: {output}")


if __name__ == "__main__":
    main()
