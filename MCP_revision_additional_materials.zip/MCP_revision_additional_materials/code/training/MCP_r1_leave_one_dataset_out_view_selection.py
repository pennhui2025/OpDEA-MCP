"""Leave-one-biological-dataset-out validation of DIA view-set selection.

This script uses the already completed 1/2/3/4-view experiments.  For each
held-out biological dataset, it selects one fixed view set using only the other
six datasets, then evaluates that selection on the held-out dataset.  It never
uses held-out truth for selection and does not rerun MCP.

Important: this validates a cross-dataset empirical selection rule, not the
paper's feature-based recommender.  If that recommender is retained as a strong
claim, it still needs its own held-out predictions.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from MCP_r1_final_revision_utils import (
    bootstrap_mean_ci,
    canonical_view_set,
    exact_signflip_p,
    rebase_recorded_path,
    resolve_results_root,
    view_count,
)


EXPECTED_VIEW_SETS = {
    "dlfq", "maxlfq", "top3", "top1",
    "dlfq+maxlfq", "dlfq+top3", "dlfq+top1", "maxlfq+top3",
    "maxlfq+top1", "top3+top1",
    "dlfq+maxlfq+top3", "dlfq+maxlfq+top1", "dlfq+top3+top1",
    "maxlfq+top3+top1", "dlfq+maxlfq+top3+top1",
}


def ranking_metrics(manifest: pd.DataFrame, results_root: Path) -> pd.DataFrame:
    # Only prediction-level rescoring needs sklearn; saved-metric LOODO does not.
    from sklearn.metrics import average_precision_score, roc_auc_score
    rows: list[dict[str, object]] = []
    cache: dict[tuple[str, str, str], dict[str, float]] = {}
    for record in manifest.to_dict("records"):
        path = rebase_recorded_path(record["prediction_file"], results_root)
        score_column = str(record["score_column"])
        truth_column = str(record["true_label_column"])
        key = (str(path), score_column, truth_column)
        if key not in cache:
            table = pd.read_csv(path)
            if score_column not in table or truth_column not in table:
                raise ValueError(f"Missing score/truth columns in {path}")
            score = pd.to_numeric(table[score_column], errors="coerce").to_numpy(float)
            truth = pd.to_numeric(table[truth_column], errors="coerce").to_numpy(float)
            keep = np.isfinite(score) & np.isfinite(truth)
            score, truth = score[keep], truth[keep].astype(int)
            if len(np.unique(truth)) != 2:
                raise ValueError(f"Both truth classes are required: {path}")
            cache[key] = {
                "auroc": float(roc_auc_score(truth, score)),
                "auprc": float(average_precision_score(truth, score)),
                "pauc_0.01": float(roc_auc_score(truth, score, max_fpr=0.01)),
            }
        for metric, value in cache[key].items():
            rows.append({
                "dataset": record["dataset"],
                "platform": record["platform"],
                "dea_method": record["dea_method"],
                "view_set": canonical_view_set(record["view_set"]),
                "metric": metric,
                "value": value,
            })
    return pd.DataFrame(rows)


def threshold_metrics(path: Path, fdr: float, fc_ratio: float) -> pd.DataFrame:
    table = pd.read_csv(path)
    required = {"dataset", "platform", "dea_method", "view_set", "fdr_threshold", "fold_change_ratio"}
    missing = required - set(table.columns)
    if missing:
        raise ValueError(f"Threshold table is missing columns: {sorted(missing)}")
    selected = table[
        np.isclose(pd.to_numeric(table["fdr_threshold"], errors="coerce"), fdr)
        & np.isclose(pd.to_numeric(table["fold_change_ratio"], errors="coerce"), fc_ratio)
    ].copy()
    metric_columns = [name for name in ("mcc", "precision", "recall", "f1") if name in selected]
    long = selected.melt(
        id_vars=["dataset", "platform", "dea_method", "view_set"],
        value_vars=metric_columns,
        var_name="metric", value_name="value",
    )
    long["view_set"] = long["view_set"].map(canonical_view_set)
    long["value"] = pd.to_numeric(long["value"], errors="coerce")
    return long


def validate_design(long: pd.DataFrame) -> pd.DataFrame:
    counts = (
        long.groupby(["metric", "dataset", "view_set"], as_index=False)
        .agg(n_strata=("value", "count"))
    )
    observed_sets = set(long["view_set"].dropna().unique())
    if observed_sets != EXPECTED_VIEW_SETS:
        raise ValueError(
            "Expected all 15 exact DIA view sets; missing="
            f"{sorted(EXPECTED_VIEW_SETS - observed_sets)}, extra={sorted(observed_sets - EXPECTED_VIEW_SETS)}"
        )
    n_datasets = long["dataset"].nunique()
    if n_datasets != 7:
        raise ValueError(f"Expected seven biological DIA datasets; found {n_datasets}")
    if (counts["n_strata"] != 4).any():
        bad = counts[counts["n_strata"] != 4].head(10)
        raise ValueError(f"Each dataset/view set needs 2 platforms x 2 DEA strata:\n{bad}")
    return counts


def choose_view_set(training: pd.DataFrame) -> tuple[str, float]:
    scores = training.groupby("view_set", as_index=False)["value"].mean()
    best = float(scores["value"].max())
    tied = scores[np.isclose(scores["value"], best, rtol=0.0, atol=1e-12)].copy()
    tied["view_count"] = tied["view_set"].map(view_count)
    # Parsimony is pre-specified: fewer views first, then canonical name.
    selected = tied.sort_values(["view_count", "view_set"]).iloc[0]
    return str(selected["view_set"]), float(selected["value"])


def run_loodo(dataset_level: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    fixed = {
        "fixed_dlfq": "dlfq",
        "fixed_dlfq_maxlfq": "dlfq+maxlfq",
        "fixed_four_view": "dlfq+maxlfq+top3+top1",
    }
    for metric, block in dataset_level.groupby("metric", sort=True):
        datasets = sorted(block["dataset"].unique())
        for holdout in datasets:
            train = block[block["dataset"] != holdout]
            test = block[block["dataset"] == holdout]
            selected_view, training_score = choose_view_set(train)
            lookup = test.set_index("view_set")["value"]
            selected_value = float(lookup[selected_view])
            oracle_value = float(lookup.max())
            oracle_candidates = lookup[np.isclose(lookup, oracle_value, atol=1e-12, rtol=0.0)].index
            oracle_view = sorted(oracle_candidates, key=lambda x: (view_count(x), x))[0]
            selected_rank = 1 + int((lookup > selected_value + 1e-12).sum())
            row: dict[str, object] = {
                "metric": metric,
                "held_out_dataset": holdout,
                "selected_view_set": selected_view,
                "selected_view_count": view_count(selected_view),
                "training_six_dataset_mean": training_score,
                "held_out_selected_value": selected_value,
                "held_out_rank": selected_rank,
                "held_out_top3_hit": selected_rank <= 3,
                "held_out_oracle_view_set": oracle_view,
                "held_out_oracle_value": oracle_value,
                "top1_regret": oracle_value - selected_value,
            }
            for label, view_set in fixed.items():
                row[label + "_view_set"] = view_set
                row[label + "_value"] = float(lookup[view_set])
                row["selected_minus_" + label] = selected_value - float(lookup[view_set])
            rows.append(row)
    return pd.DataFrame(rows)


def paired_summary(holdout: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for metric, block in holdout.groupby("metric", sort=True):
        for baseline in ("fixed_dlfq", "fixed_dlfq_maxlfq", "fixed_four_view"):
            differences = block["selected_minus_" + baseline].to_numpy(float)
            low, high = bootstrap_mean_ci(differences)
            rows.append({
                "metric": metric,
                "method_a": "LOODO_selected",
                "method_b": baseline,
                "n_biological_datasets": int(np.isfinite(differences).sum()),
                "mean_paired_difference": float(np.nanmean(differences)),
                "median_paired_difference": float(np.nanmedian(differences)),
                "bootstrap_95ci_low": low,
                "bootstrap_95ci_high": high,
                "exact_signflip_p": exact_signflip_p(differences),
            })
    return pd.DataFrame(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results-root", default=None)
    parser.add_argument("--output-dir", default="revision_results/final_required/loodo_view_selection")
    parser.add_argument("--fdr", type=float, default=0.05)
    parser.add_argument("--fc-ratio", type=float, default=1.5)
    args = parser.parse_args()

    results_root = resolve_results_root(args.results_root)
    source = results_root / "view_count_combination_analysis_limma_ROTS"
    threshold_file = source / "per_combination_threshold_metrics.csv"
    prediction_manifest = source / "selected_mcp_prediction_manifest.csv"
    if not threshold_file.exists() or not prediction_manifest.exists():
        raise FileNotFoundError(
            "Run/merge the completed view-combination analysis first; required files:\n"
            f"  {threshold_file}\n  {prediction_manifest}"
        )

    threshold = threshold_metrics(threshold_file, args.fdr, args.fc_ratio)
    ranking = ranking_metrics(pd.read_csv(prediction_manifest), results_root)
    long = pd.concat([threshold, ranking], ignore_index=True)
    audit = validate_design(long)

    # Platform and DEA are technical/analysis strata, not independent biology.
    dataset_level = (
        long.groupby(["metric", "dataset", "view_set"], as_index=False)
        .agg(value=("value", "mean"), n_platform_dea_strata=("value", "count"))
    )
    holdout = run_loodo(dataset_level)
    comparisons = paired_summary(holdout)
    frequency = (
        holdout.groupby(["metric", "selected_view_set", "selected_view_count"], as_index=False)
        .agg(n_selected_folds=("held_out_dataset", "count"))
    )

    output = Path(args.output_dir).expanduser().resolve()
    output.mkdir(parents=True, exist_ok=True)
    long.to_csv(output / "all_stratum_metrics_used.csv", index=False)
    dataset_level.to_csv(output / "dataset_level_view_metrics.csv", index=False)
    holdout.to_csv(output / "loodo_selection_per_dataset.csv", index=False)
    comparisons.to_csv(output / "loodo_paired_comparisons.csv", index=False)
    frequency.to_csv(output / "loodo_selected_view_frequency.csv", index=False)
    audit.to_csv(output / "input_design_audit.csv", index=False)
    summary = {
        "n_biological_datasets": int(dataset_level["dataset"].nunique()),
        "n_exact_view_sets": int(dataset_level["view_set"].nunique()),
        "selection_unit": "biological dataset; platform and DEA averaged within dataset",
        "selection_rule": "maximum six-dataset mean; ties prefer fewer views then canonical name",
        "important_limitation": (
            "This validates a cross-dataset empirical selector, not the manuscript's "
            "feature-based view recommender."
        ),
    }
    (output / "analysis_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(f"Completed LOODO view-set analysis: {output}")


if __name__ == "__main__":
    main()

