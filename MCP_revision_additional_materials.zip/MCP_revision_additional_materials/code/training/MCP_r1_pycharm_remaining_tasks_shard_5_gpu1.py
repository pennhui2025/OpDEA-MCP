"""Run reviewer Tasks 3-5 for DIA data_index=4 on physical GPU 1."""
from pathlib import Path
from MCP_r1_pycharm_run_remaining_tasks_shard import run_shard


if __name__ == "__main__":
    run_shard(5, 1, Path(__file__).resolve().parent / "revision_results")
