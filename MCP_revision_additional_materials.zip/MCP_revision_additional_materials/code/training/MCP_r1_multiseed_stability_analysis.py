"""Merge seven multi-seed shards and quantify run-to-run MCP stability.

Seeds are repeated algorithmic runs, not independent biological replicates.
This script first aggregates platform/DEA strata within dataset and seed, uses
seed SD/range only as stability descriptors, and performs any paired inference
across the seven biological datasets.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from MCP_r1_final_revision_utils import (
    bh_adjust,
    bootstrap_mean_ci,
    exact_signflip_p,
)


EXPECTED_SEEDS = {2024, 2025, 2026, 2027, 2028}
PAIRED_TEST_COLUMNS = [
    "metric",
    "method_a",
    "method_b",
    "n_biological_datasets",
    "mean_paired_difference",
    "median_paired_difference",
    "bootstrap_95ci_low",
    "bootstrap_95ci_high",
    "exact_signflip_p",
    "bh_q_across_variant_metric_tests",
]


def load_shards(root: Path) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    ledgers, performance, predictions = [], [], []
    missing: list[str] = []
    for shard_id in range(1, 8):
        shard = root / f"shard_{shard_id}"
        paths = {
            "ledger": shard / "core_run_ledger.csv",
            "performance": shard / "generated_performance_long.csv",
            "predictions": shard / "generated_prediction_manifest.csv",
        }
        shard_missing = [str(path) for path in paths.values() if not path.exists()]
        if shard_missing:
            missing.extend(shard_missing)
            continue
        ledger = pd.read_csv(paths["ledger"])
        perf = pd.read_csv(paths["performance"])
        pred = pd.read_csv(paths["predictions"])
        empty = [
            label for label, table in {
                "core_run_ledger.csv": ledger,
                "generated_performance_long.csv": perf,
                "generated_prediction_manifest.csv": pred,
            }.items() if table.empty
        ]
        if empty:
            raise ValueError(
                f"shard_{shard_id} contains empty input table(s): {', '.join(empty)}. "
                "The core runs or result extraction did not complete correctly."
            )
        ledger.insert(0, "source_shard", shard_id)
        perf.insert(0, "source_shard", shard_id)
        pred.insert(0, "source_shard", shard_id)
        ledgers.append(ledger)
        performance.append(perf)
        predictions.append(pred)
    if missing:
        raise FileNotFoundError("Missing multi-seed shard artifacts:\n  " + "\n  ".join(missing))
    return (
        pd.concat(ledgers, ignore_index=True),
        pd.concat(performance, ignore_index=True),
        pd.concat(predictions, ignore_index=True),
    )


def validate(ledger: pd.DataFrame, performance: pd.DataFrame) -> str:
    bad = ledger[~ledger["status"].astype(str).isin(["completed", "skipped_existing"])]
    if not bad.empty:
        raise ValueError(f"{len(bad)} runs are incomplete/error; inspect merged_core_run_ledger.csv")
    seeds = set(pd.to_numeric(ledger["seed"], errors="coerce").dropna().astype(int))
    if seeds != EXPECTED_SEEDS:
        raise ValueError(f"Expected seeds {sorted(EXPECTED_SEEDS)}; found {sorted(seeds)}")
    if "runtime_seed_control" not in ledger or not ledger["runtime_seed_control"].astype(str).str.lower().isin(
        ["true", "1", "yes"]
    ).all():
        raise ValueError("Every row must have runtime_seed_control=True; nominal manifest seeds alone are invalid")
    profiles = set(ledger.get("multiseed_profile", pd.Series(["unknown"])).astype(str).unique())
    profile = next(iter(profiles)) if len(profiles) == 1 else "mixed"
    expected_variants = {"full_mcp"} if profile == "main" else {
        "full_mcp", "single_view_mcp", "simple_early_fusion", "simple_late_fusion",
        "no_contrastive", "no_cross_attention",
    }
    variants = set(ledger["variant"].astype(str))
    if variants != expected_variants:
        raise ValueError(f"Profile {profile}: expected variants {sorted(expected_variants)}; found {sorted(variants)}")

    expected_ledger_rows = 140 if profile == "main" else 840
    if len(ledger) != expected_ledger_rows:
        raise ValueError(
            f"Profile {profile}: expected {expected_ledger_rows} completed/skipped core runs; "
            f"found {len(ledger)}"
        )
    if ledger["run_id"].astype(str).duplicated().any():
        examples = ledger.loc[ledger["run_id"].astype(str).duplicated(), "run_id"].head(5).tolist()
        raise ValueError(f"Duplicate run_id values were merged: {examples}")
    expected_per_shard = expected_ledger_rows // 7
    shard_counts = ledger.groupby("source_shard").size()
    if len(shard_counts) != 7 or not shard_counts.eq(expected_per_shard).all():
        raise ValueError(
            f"Profile {profile}: every shard must contain {expected_per_shard} core runs; found\n"
            + shard_counts.to_string()
        )

    coverage = (
        performance.groupby(["dataset", "variant", "metric"], as_index=False)
        .agg(n_seeds=("seed", "nunique"), n_rows=("value", "size"))
    )
    if (coverage["n_seeds"] != 5).any() or (coverage["n_rows"] != 20).any():
        bad_coverage = coverage[(coverage["n_seeds"] != 5) | (coverage["n_rows"] != 20)].head(20)
        raise ValueError(
            "Each dataset/variant/metric needs 5 seeds x 2 platforms x 2 DEA = 20 rows:\n"
            + bad_coverage.to_string(index=False)
        )
    if performance["dataset"].nunique() != 7:
        raise ValueError(f"Expected seven biological datasets; found {performance['dataset'].nunique()}")
    return profile


def paired_variant_tests(dataset_seed: pd.DataFrame) -> pd.DataFrame:
    # Seeds are averaged before model comparisons; n remains seven datasets.
    dataset_variant = (
        dataset_seed.groupby(["dataset", "variant", "metric"], as_index=False)
        .agg(value=("value", "mean"))
    )
    full = dataset_variant[dataset_variant["variant"].eq("full_mcp")][
        ["dataset", "metric", "value"]
    ].rename(columns={"value": "full_mcp"})
    rows: list[dict[str, object]] = []
    for variant in sorted(set(dataset_variant["variant"]) - {"full_mcp"}):
        other = dataset_variant[dataset_variant["variant"].eq(variant)][
            ["dataset", "metric", "value"]
        ].rename(columns={"value": "comparator"})
        paired = full.merge(other, on=["dataset", "metric"], how="inner", validate="one_to_one")
        for metric, block in paired.groupby("metric", sort=True):
            differences = (block["full_mcp"] - block["comparator"]).to_numpy(float)
            low, high = bootstrap_mean_ci(differences)
            rows.append({
                "metric": metric,
                "method_a": "full_mcp",
                "method_b": variant,
                "n_biological_datasets": len(differences),
                "mean_paired_difference": float(np.mean(differences)),
                "median_paired_difference": float(np.median(differences)),
                "bootstrap_95ci_low": low,
                "bootstrap_95ci_high": high,
                "exact_signflip_p": exact_signflip_p(differences),
            })
    output = pd.DataFrame(rows, columns=PAIRED_TEST_COLUMNS[:-1])
    if not output.empty:
        output["bh_q_across_variant_metric_tests"] = bh_adjust(output["exact_signflip_p"])
    else:
        # Keep column headers so an intentionally non-applicable comparison is
        # distinguishable from a failed/blank file.
        output["bh_q_across_variant_metric_tests"] = pd.Series(dtype=float)
    return output


def build_input_audit(
    ledger: pd.DataFrame,
    performance: pd.DataFrame,
    predictions: pd.DataFrame,
) -> pd.DataFrame:
    """Count the artifacts actually loaded from each shard / 汇总每个分片的实际输入。"""
    rows: list[dict[str, object]] = []
    for shard_id in range(1, 8):
        ledger_block = ledger[ledger["source_shard"].eq(shard_id)]
        perf_block = performance[performance["source_shard"].eq(shard_id)]
        pred_block = predictions[predictions["source_shard"].eq(shard_id)]
        rows.append({
            "source_shard": shard_id,
            "core_run_rows": len(ledger_block),
            "completed_rows": int(ledger_block["status"].astype(str).eq("completed").sum()),
            "skipped_existing_rows": int(
                ledger_block["status"].astype(str).eq("skipped_existing").sum()
            ),
            "performance_rows": len(perf_block),
            "prediction_manifest_rows": len(pred_block),
            "n_seeds": int(pd.to_numeric(ledger_block["seed"], errors="coerce").nunique()),
        })
    return pd.DataFrame(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    project = Path(__file__).resolve().parent
    parser.add_argument(
        "--shards-root",
        default=str(project / "revision_results" / "multiseed_stability_shards"),
    )
    parser.add_argument(
        "--output-dir",
        default=str(project / "revision_results" / "final_required" / "multiseed_stability"),
    )
    args = parser.parse_args()
    shards_root = Path(args.shards_root).expanduser().resolve()
    output = Path(args.output_dir).expanduser().resolve()
    output.mkdir(parents=True, exist_ok=True)

    ledger, performance, predictions = load_shards(shards_root)
    profile = validate(ledger, performance)
    performance["seed"] = pd.to_numeric(performance["seed"], errors="raise").astype(int)
    performance["value"] = pd.to_numeric(performance["value"], errors="coerce")
    input_audit = build_input_audit(ledger, performance, predictions)

    # Technical/analysis strata are averaged inside dataset and seed.
    dataset_seed = (
        performance.groupby(["dataset", "variant", "seed", "metric"], as_index=False)
        .agg(value=("value", "mean"), n_platform_dea_strata=("value", "count"))
    )
    seed_stability_by_dataset = (
        dataset_seed.groupby(["dataset", "variant", "metric"], as_index=False)
        .agg(
            mean_across_seeds=("value", "mean"),
            seed_sd=("value", "std"),
            seed_min=("value", "min"),
            seed_max=("value", "max"),
            n_seeds=("seed", "nunique"),
        )
    )
    seed_stability_by_dataset["seed_range"] = (
        seed_stability_by_dataset["seed_max"] - seed_stability_by_dataset["seed_min"]
    )
    stability_summary = (
        seed_stability_by_dataset.groupby(["variant", "metric"], as_index=False)
        .agg(
            n_biological_datasets=("dataset", "nunique"),
            mean_performance=("mean_across_seeds", "mean"),
            mean_seed_sd=("seed_sd", "mean"),
            median_seed_sd=("seed_sd", "median"),
            maximum_seed_range=("seed_range", "max"),
        )
    )
    variant_tests = paired_variant_tests(dataset_seed)

    ledger.to_csv(output / "merged_core_run_ledger.csv", index=False)
    performance.to_csv(output / "merged_performance_long.csv", index=False)
    predictions.to_csv(output / "merged_prediction_manifest.csv", index=False)
    input_audit.to_csv(output / "input_coverage_by_shard.csv", index=False)
    dataset_seed.to_csv(output / "dataset_seed_performance.csv", index=False)
    seed_stability_by_dataset.to_csv(output / "seed_stability_by_dataset.csv", index=False)
    stability_summary.to_csv(output / "seed_stability_summary.csv", index=False)
    variant_tests.to_csv(output / "full_mcp_vs_variants_paired_tests.csv", index=False)
    summary = {
        "profile": profile,
        "seeds": sorted(EXPECTED_SEEDS),
        "n_biological_datasets": 7,
        "seed_role": "algorithmic repeat, not an independent replicate",
        "aggregation": "platform/DEA averaged within dataset and seed; seeds then summarized",
        "runtime_seed_control_verified": True,
        "shards_root": str(shards_root),
        "output_dir": str(output),
        "input_rows": {
            "core_run_ledger": len(ledger),
            "performance_long": len(performance),
            "prediction_manifest": len(predictions),
        },
        "analysis_rows": {
            "dataset_seed_performance": len(dataset_seed),
            "seed_stability_by_dataset": len(seed_stability_by_dataset),
            "seed_stability_summary": len(stability_summary),
            "paired_variant_tests": len(variant_tests),
        },
        "paired_variant_test_status": (
            "not_applicable_main_profile_full_mcp_only"
            if profile == "main"
            else "completed"
        ),
    }
    (output / "analysis_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    readme = f"""Multi-seed stability analysis / 多随机种子稳定性分析

Input root: {shards_root}
Profile: {profile}
Loaded: {len(ledger)} core runs, {len(performance)} performance rows, """ \
        f"""{len(predictions)} prediction-manifest rows.

Primary result tables:
- seed_stability_summary.csv: summary across seven biological datasets.
- seed_stability_by_dataset.csv: stability for each dataset and metric.
- dataset_seed_performance.csv: performance for every dataset x seed x metric.
- input_coverage_by_shard.csv: verifies that all seven shards were loaded.

full_mcp_vs_variants_paired_tests.csv is intentionally header-only for the
'main' profile because that profile contains full_mcp only. It is populated
only for the optional 'architecture' profile and is not the main stability result.
"""
    (output / "README_multiseed_analysis.txt").write_text(readme, encoding="utf-8")

    print(f"Completed multi-seed stability analysis: {output}")
    print(
        f"Loaded {len(ledger)} core runs, {len(performance)} performance rows, "
        f"and {len(predictions)} prediction-manifest rows."
    )
    print(
        f"Produced {len(dataset_seed)} dataset-seed rows, "
        f"{len(seed_stability_by_dataset)} dataset-level stability rows, and "
        f"{len(stability_summary)} overall stability rows."
    )
    if variant_tests.empty:
        print(
            "NOTE: full_mcp_vs_variants_paired_tests.csv has headers only because "
            "profile='main' contains no comparator variants. This is expected."
        )
    print("\nSeed-stability summary:\n" + stability_summary.to_string(index=False))


if __name__ == "__main__":
    main()
