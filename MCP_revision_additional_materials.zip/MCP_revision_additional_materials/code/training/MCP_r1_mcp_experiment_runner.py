"""Run the original MCP pipeline from a reproducible experiment manifest.

This is the bridge between the three core source files and the seven
reviewer-requested analyses.  One manifest row describes one complete run;
the runner calls ``single_run`` in the accelerated original model, records
success/failure explicitly, and emits result manifests consumable by the
analysis scripts.

最少必需列：acquisition, platform, data_index, group1, group2, views。
``views`` 使用 ``+``、逗号或分号分隔，例如 ``dlfq+maxlfq+top3``。
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import re
import sys
import time
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

import numpy as np
import pandas as pd


REQUIRED_COLUMNS = ["acquisition", "platform", "data_index", "group1", "group2", "views"]
SUPPORTED_VARIANTS = {
    "full_mcp",
    "single_view_mcp",
    "no_contrastive",
    "no_cross_attention",
    "no_balancing",
    "simple_early_fusion",
    "simple_late_fusion",
    "single_view_statistical",
    "rank_or_pvalue_fusion",
}
METRIC_ALIASES = {
    "accuracy": "Acc",
    "precision": "Prec",
    "recall": "Rec",
    "f1": "F1",
    "mcc": "Mcc",
    "pauc_0.01": "pauc001",
    "pauc_0.05": "pauc005",
    "pauc_0.10": "pauc01",
}


@dataclass(frozen=True)
class RunnerArtifacts:
    ledger_path: Path
    prediction_manifest_path: Path
    ablation_manifest_path: Path
    performance_path: Path
    plan_path: Path


def read_table(path: Path) -> pd.DataFrame:
    if path.suffix.lower() in {".xlsx", ".xls"}:
        return pd.read_excel(path)
    if path.suffix.lower() in {".tsv", ".txt"}:
        return pd.read_csv(path, sep="\t")
    return pd.read_csv(path)


def split_values(value: Any) -> list[str]:
    if isinstance(value, (list, tuple)):
        return [str(item).strip() for item in value if str(item).strip()]
    if pd.isna(value):
        return []
    return [item.strip() for item in re.split(r"[+,;]", str(value)) if item.strip()]


def dea_method_label(value: Any) -> str:
    """Return one stable DEA stratum label for downstream pairing."""

    methods = [item.upper() if item.upper() == "ROTS" else item.lower() for item in split_values(value)]
    unique = list(dict.fromkeys(methods))
    return unique[0] if len(unique) == 1 else "+".join(unique)


def scalar(row: Mapping[str, Any], name: str, default: Any) -> Any:
    value = row.get(name, default)
    return default if pd.isna(value) or (isinstance(value, str) and not value.strip()) else value


def as_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return False
    return str(value).strip().lower() in {"1", "true", "t", "yes", "y"}


def resolve_from(base: Path, value: Any, default: Path | None = None) -> Path | None:
    if value is None or (isinstance(value, float) and np.isnan(value)) or not str(value).strip():
        return default.resolve() if default is not None else None
    path = Path(str(value)).expanduser()
    return path.resolve() if path.is_absolute() else (base / path).resolve()


def default_dea_and_log(acquisition: str, views: list[str]) -> tuple[list[str], list[str]]:
    acquisition = acquisition.upper()
    deas = ["limma"] * len(views)
    logs = ["F"] * len(views) if acquisition == "DIA" else ["T"] * len(views)
    for index, view in enumerate(views):
        if view.lower() == "count":
            deas[index] = "edgeR"
            logs[index] = "F"
        elif acquisition == "DIA" and view.lower() == "dlfq":
            logs[index] = "T"
    return deas, logs


def _safe_id(value: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9_.-]+", "_", value).strip("_")
    return cleaned or "run"


def _load_core(core_script: Path):
    core_parent = str(core_script.parent)
    if core_parent not in sys.path:
        sys.path.insert(0, core_parent)
    spec = importlib.util.spec_from_file_location("mcp_core_runtime", core_script)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot import MCP core: {core_script}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if not hasattr(module, "single_run"):
        raise AttributeError(f"{core_script} does not expose single_run()")
    return module


def normalize_run_plan(
    manifest_path: Path,
    output_dir: Path,
    core_script: Path,
    overrides: Mapping[str, Any] | None = None,
) -> pd.DataFrame:
    manifest = read_table(manifest_path)
    missing = [column for column in REQUIRED_COLUMNS if column not in manifest.columns]
    if missing:
        raise ValueError(f"Run manifest is missing required columns: {missing}")
    base = manifest_path.parent.resolve()
    overrides = dict(overrides or {})
    rows: list[dict[str, Any]] = []
    for index, source in manifest.iterrows():
        row = source.to_dict()
        row.update({key: value for key, value in overrides.items() if value is not None})
        views = split_values(row["views"])
        if not views:
            raise ValueError(f"Manifest row {index + 2} has no views")
        variant = str(scalar(row, "variant", "full_mcp"))
        if variant not in SUPPORTED_VARIANTS:
            raise ValueError(f"Manifest row {index + 2}: unsupported variant {variant!r}")
        if variant in {"single_view_mcp", "single_view_statistical"} and len(views) != 1:
            raise ValueError(f"Manifest row {index + 2}: {variant} needs exactly one view")
        default_deas, default_logs = default_dea_and_log(str(row["acquisition"]), views)
        deas = split_values(scalar(row, "dea_methods", "+".join(default_deas)))
        logs = split_values(scalar(row, "log_transforms", "+".join(default_logs)))
        if len(deas) == 1:
            deas *= len(views)
        if len(logs) == 1:
            logs *= len(views)
        if len(deas) != len(views) or len(logs) != len(views):
            raise ValueError(f"Manifest row {index + 2}: DEA/log list length must match views")
        dataset_hint = str(scalar(row, "dataset", f"index{int(row['data_index'])}"))
        run_id = str(scalar(
            row,
            "run_id",
            f"{row['acquisition']}_{row['platform']}_{dataset_hint}_{variant}_{'+'.join(views)}_s{int(scalar(row, 'seed', 2024))}",
        ))
        run_output = resolve_from(base, row.get("output_root"))
        if run_output is None:
            run_output = (output_dir / "core_runs" / _safe_id(run_id)).resolve()
        data_root = resolve_from(base, row.get("data_root"), manifest_path.parent / "data")
        r_code = resolve_from(base, row.get("r_code"), core_script.parent / "codes")
        pseudo_file = resolve_from(base, row.get("pseudo_label_file"))
        rows.append(
            {
                **row,
                "manifest_row": index + 2,
                "run_id": run_id,
                "dataset": dataset_hint,
                "views": "+".join(views),
                "variant": variant,
                "dea_methods": "+".join(deas),
                "log_transforms": "+".join(logs),
                "data_root": str(data_root),
                "output_root": str(run_output),
                "r_code": str(r_code),
                "rscript_path": str(scalar(row, "rscript_path", "/usr/lib/R/bin/")),
                "pseudo_label_file": str(pseudo_file) if pseudo_file else "",
                "seed": int(scalar(row, "seed", 2024)),
                # Opt-in only: old manifests retain the exact legacy hard-coded
                # model/Optuna/CV seeds.  New multi-seed manifests set this true.
                "runtime_seed_control": as_bool(scalar(row, "runtime_seed_control", False)),
                "num_trials": int(scalar(row, "num_trials", 30)),
                "q_threshold": float(scalar(row, "q_threshold", 0.05)),
                "fc_ratio": float(scalar(row, "fc_ratio", 1.5)),
                "gpu_id": str(scalar(row, "gpu_id", "1")),
                "force": as_bool(scalar(row, "force", False)),
            }
        )
    plan = pd.DataFrame(rows)
    if plan["run_id"].astype(str).duplicated().any():
        duplicates = sorted(
            plan.loc[plan["run_id"].astype(str).duplicated(keep=False), "run_id"]
            .astype(str)
            .unique()
        )
        raise ValueError(f"run_id must be unique; duplicates: {duplicates[:10]}")
    return plan


def _prediction_rows(ledger_row: Mapping[str, Any]) -> list[dict[str, Any]]:
    path = Path(str(ledger_row["prediction_file"]))
    if not path.exists():
        return []
    frame = pd.read_csv(path)
    columns = list(frame.columns)
    variant = str(ledger_row["variant"])
    selected_views = str(ledger_row["views"])
    dea_method = dea_method_label(ledger_row.get("dea_methods", ""))
    # Keep the four single-view controls distinct in downstream tables. Without
    # the view suffix, dlfq/maxlfq/top3/top1 would all be pooled under one method.
    variant_method = variant
    if variant in {"single_view_mcp", "single_view_statistical"}:
        variant_method = f"{variant}_{_safe_id(selected_views)}"
    base = {
        "dataset": ledger_row["dataset"],
        "acquisition": ledger_row["acquisition"],
        "platform": ledger_row["platform"],
        "dea_method": dea_method,
        "view_set": ledger_row["views"],
        "variant": ledger_row["variant"],
        "strategy": ledger_row.get("strategy", ledger_row.get("pseudo_label_column", "")),
        "seed": ledger_row.get("seed", np.nan),
        "prediction_file": str(path),
        "result_file": str(path),
        "protein_column": "Protein",
        "true_label_column": "True_lab",
        # Dataset-level grouping permits paired full-MCP versus single-view
        # comparisons; the method name above still identifies the exact view.
        "comparison_group": "|".join(
            [
                str(ledger_row["acquisition"]),
                str(ledger_row["platform"]),
                str(ledger_row["dataset"]),
                dea_method,
            ]
        ),
    }
    output: list[dict[str, Any]] = []
    if "Probability" in columns:
        # The legacy combined CSV concatenates the direct MCP block beside the
        # reference-method block.  Merge by protein ID here instead of assuming
        # both blocks use the same row order.
        direct_protein = "Protein.1" if "Protein.1" in columns else "Protein"
        direct_columns = [
            column for column in [
                direct_protein, "Probability", "ori_logFC", "qvalue", "label_pred"
            ]
            if column in columns
        ]
        direct = frame[direct_columns].copy().rename(columns={direct_protein: "Protein"})
        truth = frame[["Protein", "True_lab"]].copy()
        direct["Protein"] = direct["Protein"].astype(str)
        truth["Protein"] = truth["Protein"].astype(str)
        direct = direct.drop_duplicates("Protein").merge(
            truth.drop_duplicates("Protein"), on="Protein", how="inner", validate="one_to_one"
        )
        direct_path = path.with_name(path.stem + "__" + _safe_id(variant) + "_direct.csv")
        direct.to_csv(direct_path, index=False)
        output.append(
            {
                **base,
                "method": variant_method,
                "prediction_file": str(direct_path),
                "result_file": str(direct_path),
                "score_column": "Probability",
                "qvalue_column": "qvalue" if "qvalue" in direct.columns else "",
                "log2fc_column": "ori_logFC" if "ori_logFC" in direct.columns else "",
                # Legacy label_pred stores the continuous probability in this
                # block, despite its name. Let consumers call by q-value+FC.
                "called_column": "",
            }
        )
    score_columns = [column for column in columns if column.startswith("score_")]
    # Reference score blocks are duplicated inside every trained-variant CSV.
    # Emit them once from full_mcp; statistical variants have their own sole
    # score column and must always be emitted.
    if variant not in {"full_mcp", "single_view_statistical", "rank_or_pvalue_fusion"}:
        score_columns = []
    for score_column in score_columns:
        suffix = score_column[len("score_") :]
        method = variant_method if suffix == variant else suffix
        log_column = "logFC_" + suffix
        called_column = "lab_" + suffix
        output.append(
            {
                **base,
                "method": method,
                "score_column": score_column,
                "qvalue_column": "",
                "log2fc_column": log_column if log_column in columns else "",
                "called_column": called_column if called_column in columns else "",
            }
        )
    # De-duplicate a statistical row if its sole score was already represented.
    return list({(row["method"], row["score_column"]): row for row in output}.values())


def _performance_rows(ledger_row: Mapping[str, Any]) -> list[dict[str, Any]]:
    path = Path(str(ledger_row["metrics_file"]))
    if not path.exists():
        return []
    table = pd.read_csv(path)
    type_column = "test_type" if "test_type" in table.columns else "method"
    # Fig. 2 and the manuscript define MCP as the DP_fdr result row.  Keep
    # DP_direct available only when a manifest requests it explicitly.
    wanted_raw = ledger_row.get("test_type", "DP_fdr")
    wanted = "DP_fdr" if pd.isna(wanted_raw) or not str(wanted_raw).strip() else str(wanted_raw).strip()
    selected = table[table[type_column].astype(str) == wanted]
    if selected.empty:
        return []
    record = selected.iloc[0]
    rows: list[dict[str, Any]] = []
    for canonical, actual in METRIC_ALIASES.items():
        if actual in table.columns:
            rows.append(
                {
                    "dataset": ledger_row["dataset"],
                    "acquisition": ledger_row["acquisition"],
                    "platform": ledger_row["platform"],
                    "dea_method": dea_method_label(ledger_row.get("dea_methods", "")),
                    "variant": ledger_row["variant"],
                    "view_set": ledger_row["views"],
                    "seed": ledger_row.get("seed", np.nan),
                    "metric": canonical,
                    "value": pd.to_numeric(record[actual], errors="coerce"),
                }
            )
    return rows


def execute_run_manifest(
    manifest_path: str | Path,
    output_dir: str | Path,
    core_script: str | Path | None = None,
    overrides: Mapping[str, Any] | None = None,
    dry_run: bool = False,
    strict: bool = True,
) -> RunnerArtifacts:
    manifest_path = Path(manifest_path).expanduser().resolve()
    output_dir = Path(output_dir).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    core_script = Path(core_script or Path(__file__).with_name(
        "MCP_r1_mv_contrast_v6.0.3_4_linux_comb_exp_mcc2_new.py"
    )).expanduser().resolve()
    if not manifest_path.exists():
        raise FileNotFoundError(manifest_path)
    if not core_script.exists():
        raise FileNotFoundError(core_script)

    plan = normalize_run_plan(manifest_path, output_dir, core_script, overrides)
    plan_path = output_dir / "core_run_plan.csv"
    plan.to_csv(plan_path, index=False)
    ledger_path = output_dir / "core_run_ledger.csv"
    prediction_manifest_path = output_dir / "generated_prediction_manifest.csv"
    ablation_manifest_path = output_dir / "generated_ablation_manifest.csv"
    performance_path = output_dir / "generated_performance_long.csv"
    if dry_run:
        dry = plan.copy()
        dry["status"] = "planned_dry_run"
        dry["message"] = ""
        dry.to_csv(ledger_path, index=False)
        pd.DataFrame().to_csv(prediction_manifest_path, index=False)
        pd.DataFrame().to_csv(ablation_manifest_path, index=False)
        pd.DataFrame().to_csv(performance_path, index=False)
        return RunnerArtifacts(ledger_path, prediction_manifest_path, ablation_manifest_path, performance_path, plan_path)

    core = _load_core(core_script)
    ledger: list[dict[str, Any]] = []
    for index, row in plan.iterrows():
        views = split_values(row["views"])
        config = {
            key: row[key]
            for key in [
                "variant", "data_root", "output_root", "r_code", "rscript_path", "gpu_id",
                "seed", "runtime_seed_control", "num_trials", "q_threshold", "fc_ratio", "normalizations", "imputations",
                "cross_imputation", "hc_threshold", "min_positive", "operation_type",
                "protein_group_type", "positive_strategy", "pseudo_label_file",
                "pseudo_label_column", "pseudo_label_protein_column", "statistical_fusion", "test_type",
            ]
            if key in row and not pd.isna(row[key]) and str(row[key]).strip()
        }
        config["force"] = bool(row["force"])
        started = time.time()
        try:
            result = core.single_run(
                int(index), str(row["platform"]), int(row["data_index"]),
                str(row["group1"]), str(row["group2"]), str(row["acquisition"]),
                views, split_values(row["log_transforms"]), split_values(row["dea_methods"]),
                runtime_config=config,
            )
            if not isinstance(result, dict):
                raise RuntimeError("Core single_run() returned no artifact record")
            record = {**row.to_dict(), **result, "message": ""}
        except Exception as exc:
            error_traceback = traceback.format_exc()
            print(
                f"ERROR in run_id={row['run_id']} variant={row['variant']} "
                f"views={row['views']}:\n{error_traceback}",
                flush=True,
            )
            record = {
                **row.to_dict(),
                "status": "error",
                "runtime_seconds": time.time() - started,
                "prediction_file": "",
                "metrics_file": "",
                "latent_file": "",
                "message": repr(exc),
                "traceback": error_traceback,
            }
        ledger.append(record)
        pd.DataFrame(ledger).to_csv(ledger_path, index=False)

    ledger_table = pd.DataFrame(ledger)
    good = ledger_table[ledger_table["status"].isin(["completed", "skipped_existing"])]
    prediction_rows: list[dict[str, Any]] = []
    performance_rows: list[dict[str, Any]] = []
    ablation_rows: list[dict[str, Any]] = []
    for _, row in good.iterrows():
        prediction_rows.extend(_prediction_rows(row))
        performance_rows.extend(_performance_rows(row))
        ablation_rows.append(
            {
                "dataset": row["dataset"], "acquisition": row["acquisition"],
                "platform": row["platform"], "variant": row["variant"],
                "dea_method": dea_method_label(row.get("dea_methods", "")),
                "view_set": row["views"], "result_file": row["metrics_file"],
                "test_type": (
                    "DP_fdr"
                    if pd.isna(row.get("test_type", np.nan))
                    or not str(row.get("test_type", "")).strip()
                    else str(row.get("test_type")).strip()
                ),
                "seed": row.get("seed", np.nan),
                "runtime_seconds": row.get("runtime_seconds", np.nan),
                "peak_memory_mb": row.get("peak_memory_mb", np.nan),
                "parameter_count": row.get("parameter_count", np.nan),
            }
        )
    pd.DataFrame(prediction_rows).to_csv(prediction_manifest_path, index=False)
    pd.DataFrame(ablation_rows).to_csv(ablation_manifest_path, index=False)
    pd.DataFrame(performance_rows).to_csv(performance_path, index=False)
    errors = ledger_table[ledger_table["status"] == "error"]
    if strict and not errors.empty:
        examples = "; ".join(errors["message"].astype(str).head(3))
        raise RuntimeError(f"{len(errors)} core run(s) failed. See {ledger_path}. {examples}")
    return RunnerArtifacts(ledger_path, prediction_manifest_path, ablation_manifest_path, performance_path, plan_path)


def add_core_runner_arguments(parser: argparse.ArgumentParser) -> None:
    group = parser.add_argument_group("optional original-MCP execution / 可选原模型运行")
    group.add_argument("--run-manifest", type=Path, help="Run original MCP experiments before this analysis")
    group.add_argument("--core-script", type=Path, default=Path(__file__).with_name("MCP_r1_mv_contrast_v6.0.3_4_linux_comb_exp_mcc2_new.py"))
    group.add_argument("--core-output-dir", type=Path, help="Core run ledger/result-manifest directory")
    group.add_argument("--dry-run-core", action="store_true", help="Validate and write the run plan without training")
    group.add_argument("--continue-on-core-error", action="store_true", help="Complete other rows and retain an error ledger")
    group.add_argument("--force-core", action="store_true", help="Re-run even if output metrics already exist")


def run_core_from_args(args: argparse.Namespace, analysis_output: Path) -> RunnerArtifacts | None:
    if not getattr(args, "run_manifest", None):
        return None
    core_output = getattr(args, "core_output_dir", None) or (analysis_output / "core_experiments")
    return execute_run_manifest(
        args.run_manifest,
        core_output,
        core_script=args.core_script,
        overrides={"force": True} if getattr(args, "force_core", False) else None,
        dry_run=getattr(args, "dry_run_core", False),
        strict=not getattr(args, "continue_on_core_error", False),
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--core-script", type=Path, default=Path(__file__).with_name("MCP_r1_mv_contrast_v6.0.3_4_linux_comb_exp_mcc2_new.py"))
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--continue-on-error", action="store_true")
    parser.add_argument("--force", action="store_true")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    artifacts = execute_run_manifest(
        args.manifest,
        args.output_dir,
        core_script=args.core_script,
        overrides={"force": True} if args.force else None,
        dry_run=args.dry_run,
        strict=not args.continue_on_error,
    )
    print(json.dumps({key: str(value) for key, value in artifacts.__dict__.items()}, indent=2))


if __name__ == "__main__":
    main()
