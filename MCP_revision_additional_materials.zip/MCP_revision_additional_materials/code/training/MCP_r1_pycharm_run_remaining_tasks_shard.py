"""Run reviewer Tasks 3-5 for one of the seven DIA data indices.

Each worker:
1. derives native limma/ROTS pseudo-label sources from the completed four-view
   Task 1/2 result;
2. analyzes view complementarity using the raw matrices and all six pairwise
   two-view MCP gains;
3. retrains MCP for every eligible pseudo-label strategy;
4. runs only the three still-missing four-view architecture ablations.

已完成的核心模型结果会通过 MCP_FAST_RESUME 自动跳过。本脚本不会伪造
Task 6/7 所需的临床队列或 IFNG 外部数据库输入。
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

import numpy as np
import pandas as pd

from MCP_r1_pycharm_run_core_shard import (
    locate_codes_dir,
    locate_rscript,
    validate_dependencies,
)


VIEWS = ("dlfq", "maxlfq", "top3", "top1")
FULL_VIEW_SET = "+".join(VIEWS)
PLATFORMS = ("DIANN", "Spectronaut")
DEA_METHODS = ("limma", "ROTS")


def dea_label(value: object) -> str:
    values = [
        part.strip().upper() if part.strip().upper() == "ROTS" else part.strip().lower()
        for part in str(value).replace(",", "+").split("+")
        if part.strip()
    ]
    unique = list(dict.fromkeys(values))
    if len(unique) != 1 or unique[0] not in DEA_METHODS:
        raise ValueError(f"Expected one uniform limma/ROTS method, got {value!r}")
    return unique[0]


def read_required(path: Path) -> pd.DataFrame:
    if not path.is_file():
        raise FileNotFoundError(path)
    try:
        return pd.read_csv(path)
    except pd.errors.EmptyDataError:
        return pd.DataFrame()


def write_status(path: Path, shard_id: int, stage: str, status: str, **details: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "shard_id": shard_id,
        "data_index": shard_id - 1,
        "stage": stage,
        "status": status,
        **details,
    }
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def validate_project(project_dir: Path, task5_manifest: Path) -> Path:
    required_files = [
        task5_manifest,
        project_dir / "MCP_r1_task1_2_DIA_limma_ROTS_manifest.csv",
        project_dir / "MCP_r1_pseudo_label_robustness.py",
        project_dir / "MCP_r1_view_complementarity_noise_analysis.py",
        project_dir / "MCP_r1_mcp_experiment_runner.py",
        project_dir / "MCP_r1_mv_contrast_v6.0.3_4_linux_comb_exp_mcc2_new.py",
        project_dir / "MCP_r1_MV_regression_DP.py",
        project_dir / "MCP_r1_Utils.py",
        project_dir / "data" / "DIA_DIANN.txt",
        project_dir / "data" / "DIA_spt.txt",
    ]
    missing = [str(path) for path in required_files if not path.is_file()]
    for relative in (Path("data/DIA/DIANN"), Path("data/DIA/Spectronaut")):
        if not (project_dir / relative).is_dir():
            missing.append(str(project_dir / relative))
    if missing:
        raise FileNotFoundError(
            "Required project inputs are missing / 缺少必需项目输入:\n  "
            + "\n  ".join(missing)
        )
    return locate_codes_dir(project_dir)


def metadata_for_index(project_dir: Path, platform: str, data_index: int) -> pd.Series:
    filename = "DIA_DIANN.txt" if platform == "DIANN" else "DIA_spt.txt"
    path = project_dir / "data" / filename
    table = pd.read_csv(path, sep="\t")
    if "dataset" not in table.columns or data_index >= len(table):
        raise ValueError(f"Cannot resolve data_index={data_index} from {path}")
    return table.iloc[data_index]


def matrix_paths(project_dir: Path, platform: str, dataset: str) -> tuple[dict[str, Path], Path]:
    folder = project_dir / "data" / "DIA" / platform
    slug = "spt" if platform == "Spectronaut" else "DIANN"
    matrices = {
        view: folder / f"{dataset}_{slug}_{view}.tsv"
        for view in VIEWS
    }
    design = folder / f"{dataset}_{slug}_design.tsv"
    missing = [str(path) for path in [*matrices.values(), design] if not path.is_file()]
    if missing:
        raise FileNotFoundError(
            f"Dataset {dataset}/{platform} is missing matrix/design files:\n  "
            + "\n  ".join(missing)
        )
    return matrices, design


def select_full_result(
    ledger: pd.DataFrame,
    data_index: int,
    platform: str,
    dea_method: str,
) -> pd.Series:
    required = {"data_index", "platform", "variant", "views", "dea_methods", "status"}
    missing = sorted(required - set(ledger.columns))
    if missing:
        raise ValueError(f"Completed Task 1/2 ledger is missing columns: {missing}")
    normalized_dea = ledger["dea_methods"].map(dea_label)
    selected = ledger[
        pd.to_numeric(ledger["data_index"], errors="coerce").eq(data_index)
        & ledger["platform"].astype(str).eq(platform)
        & ledger["variant"].astype(str).eq("full_mcp")
        & ledger["views"].astype(str).eq(FULL_VIEW_SET)
        & normalized_dea.eq(dea_method)
        & ledger["status"].astype(str).isin(["completed", "skipped_existing"])
    ]
    if len(selected) != 1:
        raise ValueError(
            f"Expected one completed Task 1/2 full_mcp result for "
            f"index={data_index}, platform={platform}, DEA={dea_method}; found {len(selected)}"
        )
    row = selected.iloc[0]
    result_file = Path(str(row.get("prediction_file", ""))).expanduser()
    if not result_file.is_file():
        raise FileNotFoundError(result_file)
    return row


def build_label_sources(
    full_result: pd.Series,
    output_dir: Path,
    platform: str,
    dea_method: str,
) -> tuple[Path, Path, str]:
    """Convert core score=1-FDR blocks into Task 3/4 native q-value inputs."""

    result_file = Path(str(full_result["prediction_file"])).resolve()
    frame = pd.read_csv(result_file)
    required = ["Protein", "True_lab"]
    for source in (*VIEWS, "hurdle"):
        suffix = f"DP{source}" if source != "hurdle" else "DP_hurdle"
        required.extend([f"score_{suffix}", f"logFC_{suffix}"])
    missing = [column for column in required if column not in frame.columns]
    if missing:
        raise ValueError(
            f"{result_file} does not contain the native DEA blocks required by Task 3/4: {missing}"
        )

    dataset = str(full_result["dataset"])
    derived = pd.DataFrame(
        {
            "Protein": frame["Protein"].astype(str),
            "True_lab": pd.to_numeric(frame["True_lab"], errors="coerce"),
        }
    )
    source_rows: list[dict[str, object]] = []
    for source in (*VIEWS, "hurdle"):
        suffix = f"DP{source}" if source != "hurdle" else "DP_hurdle"
        score = pd.to_numeric(frame[f"score_{suffix}"], errors="coerce")
        # Core reference score is exactly 1-adjusted-p/FDR.  Therefore this
        # reconstruction preserves native limma BH-FDR or native ROTS FDR.
        derived[f"qvalue_{source}"] = (1.0 - score).clip(0.0, 1.0)
        derived[f"log2fc_{source}"] = pd.to_numeric(
            frame[f"logFC_{suffix}"], errors="coerce"
        )
    derived = derived.drop_duplicates("Protein")
    output_dir.mkdir(parents=True, exist_ok=True)
    label_file = output_dir / "native_dea_label_sources.csv"
    derived.to_csv(label_file, index=False)

    for source in (*VIEWS, "hurdle"):
        source_rows.append(
            {
                "dataset": dataset,
                "acquisition": "DIA",
                "platform": platform,
                "dea_method": dea_method,
                "source": source,
                "label_file": str(label_file.resolve()),
                "protein_column": "Protein",
                "qvalue_column": f"qvalue_{source}",
                "log2fc_column": f"log2fc_{source}",
                "true_label_column": "True_lab",
                "is_reference": 1 if source == "dlfq" else 0,
            }
        )
    source_manifest = output_dir / "pseudo_label_source_manifest.csv"
    pd.DataFrame(source_rows).to_csv(source_manifest, index=False)
    return source_manifest, label_file, dataset


def select_base_template(
    project_dir: Path,
    data_index: int,
    platform: str,
    dea_method: str,
    dataset: str,
    codes_dir: Path,
    rscript: Path,
    output_path: Path,
) -> Path:
    source = pd.read_csv(project_dir / "MCP_r1_task1_2_DIA_limma_ROTS_manifest.csv")
    normalized_dea = source["dea_methods"].map(dea_label)
    selected = source[
        pd.to_numeric(source["data_index"], errors="coerce").eq(data_index)
        & source["platform"].astype(str).eq(platform)
        & source["variant"].astype(str).eq("full_mcp")
        & source["views"].astype(str).eq(FULL_VIEW_SET)
        & normalized_dea.eq(dea_method)
    ]
    if len(selected) != 1:
        raise ValueError(
            f"Cannot find one Task 3 base template for index={data_index}, "
            f"platform={platform}, DEA={dea_method}"
        )
    row = selected.iloc[0].to_dict()
    row.update(
        {
            "run_id": f"DIA_{platform}_i{data_index}_task3_full4_{dea_method}",
            "dataset": dataset,
            "data_root": str((project_dir / "data").resolve()),
            "r_code": str(codes_dir.resolve()),
            "rscript_path": str(rscript.parent.resolve()) + os.sep,
            # Physical GPU visibility is set before subprocess import; the core
            # sees that device as local CUDA device 0.
            "gpu_id": "0",
            "force": False,
        }
    )
    row.pop("output_root", None)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame([row]).to_csv(output_path, index=False)
    return output_path


def build_task4_manifest(
    project_dir: Path,
    data_index: int,
    source_records: dict[tuple[str, str], tuple[Path, str, str, str]],
    output_path: Path,
) -> Path:
    rows: list[dict[str, object]] = []
    for platform in PLATFORMS:
        metadata = metadata_for_index(project_dir, platform, data_index)
        dataset = str(metadata["dataset"])
        matrices, design = matrix_paths(project_dir, platform, dataset)
        for dea_method in DEA_METHODS:
            label_file, label_dataset, group1, group2 = source_records[
                (platform, dea_method)
            ]
            if label_dataset != dataset:
                raise ValueError(
                    f"Dataset mismatch for {platform}/{dea_method}: "
                    f"metadata={dataset}, completed result={label_dataset}"
                )
            for view in VIEWS:
                rows.append(
                    {
                        "dataset": dataset,
                        "acquisition": "DIA",
                        "platform": platform,
                        "dea_method": dea_method,
                        "view": view,
                        "matrix_file": str(matrices[view].resolve()),
                        "protein_column": "Protein",
                        "design_file": str(design.resolve()),
                        "sample_column": "sample_name",
                        "condition_column": "condition",
                        "group1": group1,
                        "group2": group2,
                        "dea_file": str(label_file.resolve()),
                        "dea_protein_column": "Protein",
                        "dea_qvalue_column": f"qvalue_{view}",
                        "dea_log2fc_column": f"log2fc_{view}",
                        "dea_true_label_column": "True_lab",
                    }
                )
    manifest = pd.DataFrame(rows)
    if len(manifest) != 16:
        raise AssertionError("Task 4 should contain 2 platforms x 2 DEA x 4 views")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    manifest.to_csv(output_path, index=False)
    return output_path


def build_task4_performance(
    main_performance: Path,
    incremental_performance: Path,
    datasets: dict[str, str],
    output_path: Path,
) -> Path:
    combined = pd.concat(
        [read_required(main_performance), read_required(incremental_performance)],
        ignore_index=True,
        sort=False,
    )
    selected_parts = []
    for platform, dataset in datasets.items():
        selected_parts.append(
            combined[
                combined["platform"].astype(str).eq(platform)
                & combined["dataset"].astype(str).eq(dataset)
                & combined["dea_method"].astype(str).isin(DEA_METHODS)
            ]
        )
    selected = pd.concat(selected_parts, ignore_index=True, sort=False)
    if selected.empty:
        raise ValueError("No completed performance rows match this Task 4 shard")

    for platform, dataset in datasets.items():
        for dea_method in DEA_METHODS:
            block = selected[
                selected["platform"].astype(str).eq(platform)
                & selected["dataset"].astype(str).eq(dataset)
                & selected["dea_method"].astype(str).eq(dea_method)
            ]
            for metric in block["metric"].dropna().astype(str).unique():
                metric_block = block[block["metric"].astype(str).eq(metric)]
                pairs = metric_block[
                    metric_block["variant"].astype(str).eq("full_mcp")
                    & metric_block["view_set"].astype(str).map(
                        lambda value: len(value.split("+")) == 2
                    )
                ]
                singles = metric_block[
                    metric_block["variant"].astype(str).eq("single_view_mcp")
                ]
                if len(pairs) != 6 or set(singles["view_set"].astype(str)) != set(VIEWS):
                    raise ValueError(
                        f"Incomplete Task 4 performance coverage for "
                        f"{dataset}/{platform}/{dea_method}/{metric}: "
                        f"pair rows={len(pairs)}, single views={sorted(singles['view_set'].astype(str).unique())}"
                    )
    output_path.parent.mkdir(parents=True, exist_ok=True)
    selected.to_csv(output_path, index=False)
    return output_path


def prepare_task5_runtime_manifest(
    source: Path,
    target: Path,
    data_index: int,
    codes_dir: Path,
    rscript: Path,
    project_dir: Path,
) -> Path:
    table = pd.read_csv(source)
    if len(table) != 12:
        raise ValueError(f"{source} must contain 12 Task 5 runs; found {len(table)}")
    if set(pd.to_numeric(table["data_index"]).astype(int)) != {data_index}:
        raise ValueError(f"{source} does not exclusively contain data_index={data_index}")
    expected = {
        (platform, dea, variant)
        for platform in PLATFORMS
        for dea in DEA_METHODS
        for variant in ("no_balancing", "no_contrastive", "no_cross_attention")
    }
    observed = {
        (str(row.platform), dea_label(row.dea_methods), str(row.variant))
        for row in table.itertuples()
    }
    if observed != expected or set(table["views"].astype(str)) != {FULL_VIEW_SET}:
        raise ValueError(f"{source} has invalid Task 5 platform/DEA/variant coverage")
    table["data_root"] = str((project_dir / "data").resolve())
    table["r_code"] = str(codes_dir.resolve())
    table["rscript_path"] = str(rscript.parent.resolve()) + os.sep
    table["gpu_id"] = "0"
    table["force"] = False
    if "output_root" in table.columns:
        table = table.drop(columns=["output_root"])
    table.to_csv(target, index=False)
    return target


def run_command(command: list[str], label: str, project_dir: Path, env: dict[str, str]) -> None:
    print(f"\n=== {label} ===", flush=True)
    print(" ".join(command), flush=True)
    subprocess.run(command, cwd=project_dir, env=env, check=True)


def validate_core_ledger(path: Path, expected_rows: int | None = None) -> pd.DataFrame:
    ledger = read_required(path)
    if expected_rows is not None and len(ledger) != expected_rows:
        raise RuntimeError(f"{path} must have {expected_rows} rows; found {len(ledger)}")
    if ledger.empty:
        raise RuntimeError(f"{path} is empty")
    errors = ledger[ledger["status"].astype(str).eq("error")]
    if not errors.empty:
        examples = errors.get("message", pd.Series(dtype=str)).astype(str).head(3).tolist()
        raise RuntimeError(f"{path} contains {len(errors)} failed runs: {examples}")
    unfinished = ledger[
        ~ledger["status"].astype(str).isin(["completed", "skipped_existing"])
    ]
    if not unfinished.empty:
        raise RuntimeError(f"{path} contains unfinished runs")
    return ledger


def run_shard(shard_id: int, gpu_id: int, result_root: Path) -> None:
    if shard_id not in range(1, 8):
        raise ValueError(f"shard_id must be 1-7; got {shard_id}")
    if gpu_id < 0:
        raise ValueError(f"gpu_id must be non-negative; got {gpu_id}")
    project_dir = Path(__file__).resolve().parent
    os.chdir(project_dir)
    data_index = shard_id - 1
    task5_source = project_dir / f"MCP_r1_remaining_task5_deep_ablation_shard_{shard_id}.csv"
    codes_dir = validate_project(project_dir, task5_source)
    rscript = locate_rscript()
    validate_dependencies()

    result_root = result_root.expanduser().resolve()
    shard_output = result_root / "remaining_tasks_shards" / f"shard_{shard_id}"
    shard_output.mkdir(parents=True, exist_ok=True)
    status_path = shard_output / "remaining_tasks_status.json"

    main_merged = result_root / "task1_2_core_merged_limma_ROTS"
    incremental_merged = result_root / "view_combination_incremental_merged"
    main_ledger_path = main_merged / "core_run_ledger.csv"
    main_performance = main_merged / "generated_performance_long.csv"
    incremental_performance = incremental_merged / "generated_performance_long.csv"
    for required in (main_ledger_path, main_performance, incremental_performance):
        if not required.is_file():
            raise FileNotFoundError(
                f"{required}\nRun MCP_r1_pycharm_merge_limma_ROTS_and_analyze.py and "
                "MCP_r1_pycharm_merge_view_combinations_and_analyze.py first."
            )

    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = str(gpu_id)
    env.setdefault("MCP_VERBOSE_TRAIN", "0")
    env.setdefault("MCP_LEGACY_AUGMENTATION", "0")
    env.setdefault("MCP_USE_LEGACY_FDR", "0")
    env.setdefault("MCP_FAST_RESUME", "1")
    python = sys.executable
    core_script = project_dir / "MCP_r1_mv_contrast_v6.0.3_4_linux_comb_exp_mcc2_new.py"
    main_ledger = read_required(main_ledger_path)

    print(
        f"Remaining-tasks shard {shard_id}: data_index={data_index}, "
        f"physical GPU={gpu_id}",
        flush=True,
    )
    write_status(status_path, shard_id, "prepare_inputs", "running")
    task3_inputs: dict[tuple[str, str], tuple[Path, Path]] = {}
    source_records: dict[tuple[str, str], tuple[Path, str, str, str]] = {}
    datasets: dict[str, str] = {}
    for platform in PLATFORMS:
        expected_dataset = str(metadata_for_index(project_dir, platform, data_index)["dataset"])
        datasets[platform] = expected_dataset
        for dea_method in DEA_METHODS:
            stratum_dir = (
                shard_output / "task3_pseudo_label" / platform / dea_method
            )
            full_result = select_full_result(
                main_ledger, data_index, platform, dea_method
            )
            source_manifest, label_file, dataset = build_label_sources(
                full_result, stratum_dir, platform, dea_method
            )
            if dataset != expected_dataset:
                raise ValueError(
                    f"Completed full result dataset {dataset!r} does not match "
                    f"metadata {expected_dataset!r} for {platform}/index={data_index}"
                )
            base_manifest = select_base_template(
                project_dir,
                data_index,
                platform,
                dea_method,
                dataset,
                codes_dir,
                rscript,
                stratum_dir / "pseudo_label_base_run.csv",
            )
            task3_inputs[(platform, dea_method)] = (source_manifest, base_manifest)
            source_records[(platform, dea_method)] = (
                label_file,
                dataset,
                str(full_result["group1"]),
                str(full_result["group2"]),
            )

    task4_dir = shard_output / "task4_view_complementarity"
    task4_manifest = build_task4_manifest(
        project_dir,
        data_index,
        source_records,
        task4_dir / "task4_matrix_manifest.csv",
    )
    task4_performance = build_task4_performance(
        main_performance,
        incremental_performance,
        datasets,
        task4_dir / "task4_completed_performance.csv",
    )
    write_status(status_path, shard_id, "task4", "running")
    run_command(
        [
            python,
            str(project_dir / "MCP_r1_view_complementarity_noise_analysis.py"),
            "--manifest", str(task4_manifest),
            "--performance-file", str(task4_performance),
            "--output-dir", str(task4_dir),
            "--q-threshold", "0.05",
            "--fc-ratio", "1.5",
        ],
        "Task 4: view complementarity and noise",
        project_dir,
        env,
    )
    task4_pairs = read_required(task4_dir / "pairwise_complementarity.csv")
    if len(task4_pairs) != 24:
        raise RuntimeError(
            f"Task 4 should produce 2 platforms x 2 DEA x 6 pairs = 24 rows; "
            f"found {len(task4_pairs)}"
        )

    write_status(status_path, shard_id, "task3", "running")
    for platform in PLATFORMS:
        for dea_method in DEA_METHODS:
            source_manifest, base_manifest = task3_inputs[(platform, dea_method)]
            stratum_dir = source_manifest.parent
            run_command(
                [
                    python,
                    str(project_dir / "MCP_r1_pseudo_label_robustness.py"),
                    "--source-manifest", str(source_manifest),
                    "--run-manifest", str(base_manifest),
                    "--core-script", str(core_script),
                    "--core-output-dir", str(stratum_dir / "core_experiments"),
                    "--output-dir", str(stratum_dir),
                    "--q-threshold", "0.05",
                    "--fc-ratio", "1.5",
                    "--noise-rates", "0.05,0.10,0.20",
                    "--noise-replicates", "5",
                    "--seed", "2024",
                ],
                f"Task 3: pseudo labels [{platform}/{dea_method}]",
                project_dir,
                env,
            )
            eligibility = read_required(
                stratum_dir / "pseudo_label_strategy_run_eligibility.csv"
            )
            expected_eligible = int(
                eligibility["eligible_for_binary_mcp"]
                .astype(str)
                .str.lower()
                .isin(["true", "1"])
                .sum()
            )
            validate_core_ledger(
                stratum_dir / "core_experiments" / "core_run_ledger.csv",
                expected_rows=expected_eligible,
            )
            if not (stratum_dir / "downstream_prediction_robustness.csv").is_file():
                raise FileNotFoundError(
                    stratum_dir / "downstream_prediction_robustness.csv"
                )

    write_status(status_path, shard_id, "task5", "running")
    task5_dir = shard_output / "task5_deep_ablation_core"
    task5_dir.mkdir(parents=True, exist_ok=True)
    task5_runtime = prepare_task5_runtime_manifest(
        task5_source,
        task5_dir / f"task5_shard_{shard_id}.runtime.csv",
        data_index,
        codes_dir,
        rscript,
        project_dir,
    )
    run_command(
        [
            python,
            str(project_dir / "MCP_r1_mcp_experiment_runner.py"),
            "--manifest", str(task5_runtime),
            "--output-dir", str(task5_dir),
            "--core-script", str(core_script),
        ],
        "Task 5: three missing four-view architecture ablations",
        project_dir,
        env,
    )
    validate_core_ledger(task5_dir / "core_run_ledger.csv", expected_rows=12)
    ablations = read_required(task5_dir / "generated_ablation_manifest.csv")
    if len(ablations) != 12:
        raise RuntimeError(
            f"Task 5 should expose 12 ablation rows; found {len(ablations)}"
        )

    write_status(
        status_path,
        shard_id,
        "all",
        "complete",
        task4_pair_rows=len(task4_pairs),
        task5_core_runs=12,
        output_dir=str(shard_output),
    )
    print(
        f"\nREMAINING TASKS SHARD {shard_id} COMPLETED: {shard_output}",
        flush=True,
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--shard-id", type=int, default=1)
    parser.add_argument("--gpu-id", type=int, default=0)
    parser.add_argument(
        "--result-root",
        type=Path,
        default=Path(__file__).resolve().parent / "revision_results",
    )
    return parser


def main() -> None:
    args = build_parser().parse_args()
    run_shard(args.shard_id, args.gpu_id, args.result_root)


if __name__ == "__main__":
    main()
