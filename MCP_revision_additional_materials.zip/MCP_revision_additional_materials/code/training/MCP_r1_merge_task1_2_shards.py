"""Merge seven parallel MCP core shards for supplementary tasks 1 and 2.

The script refuses to produce a merged manifest unless all 7 shards contain
the expected successful rows and jointly match every run ID in the selected
master manifest. / 只有 7 个分片全部成功时才会生成正式合并结果。
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd


ARTIFACTS = {
    "plan": "core_run_plan.csv",
    "ledger": "core_run_ledger.csv",
    "predictions": "generated_prediction_manifest.csv",
    "ablations": "generated_ablation_manifest.csv",
    "performance": "generated_performance_long.csv",
}


def read_required(path: Path) -> pd.DataFrame:
    if not path.is_file():
        raise FileNotFoundError(path)
    try:
        return pd.read_csv(path)
    except pd.errors.EmptyDataError:
        return pd.DataFrame()


def dea_method_label(value: object) -> str:
    values = [part.strip() for part in str(value).replace(",", "+").split("+") if part.strip()]
    normalized = [part.upper() if part.upper() == "ROTS" else part.lower() for part in values]
    unique = list(dict.fromkeys(normalized))
    return unique[0] if len(unique) == 1 else "+".join(unique)


def merge_shards(
    shards_root: Path,
    output_dir: Path,
    master_manifest: Path,
    expected_shards: int = 7,
) -> dict[str, object]:
    shards_root = shards_root.expanduser().resolve()
    output_dir = output_dir.expanduser().resolve()
    master_manifest = master_manifest.expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    master = read_required(master_manifest)
    if (
        master.empty
        or len(master) % expected_shards != 0
        or "run_id" not in master.columns
        or not master["run_id"].is_unique
    ):
        raise ValueError(
            "Master manifest must contain unique run_id values and an equal number of rows per shard"
        )
    expected_per_shard = len(master) // expected_shards

    collected: dict[str, list[pd.DataFrame]] = {key: [] for key in ARTIFACTS}
    audit_rows: list[dict[str, object]] = []
    for shard_id in range(1, expected_shards + 1):
        shard_dir = shards_root / f"shard_{shard_id}"
        frames: dict[str, pd.DataFrame] = {}
        for key, filename in ARTIFACTS.items():
            frame = read_required(shard_dir / filename)
            frame.insert(0, "source_shard", shard_id)
            frames[key] = frame
            collected[key].append(frame)

        ledger = frames["ledger"]
        plan = frames["plan"]
        if len(plan) != expected_per_shard or len(ledger) != expected_per_shard:
            raise ValueError(
                f"shard_{shard_id} must have {expected_per_shard} plan/ledger rows; "
                f"found plan={len(plan)}, ledger={len(ledger)}"
            )
        if "run_id" not in ledger.columns or not ledger["run_id"].is_unique:
            raise ValueError(f"shard_{shard_id} ledger run_id values are missing or duplicated")
        errors = ledger[ledger["status"].astype(str).eq("error")]
        if not errors.empty:
            examples = errors.get("message", pd.Series(dtype=str)).astype(str).head(3).tolist()
            raise RuntimeError(
                f"shard_{shard_id} contains {len(errors)} failed runs: {examples}"
            )
        invalid_status = ledger[
            ~ledger["status"].astype(str).isin(["completed", "skipped_existing"])
        ]
        if not invalid_status.empty:
            raise RuntimeError(
                f"shard_{shard_id} contains unfinished statuses: "
                f"{sorted(invalid_status['status'].astype(str).unique())}"
            )
        if frames["predictions"].empty:
            raise ValueError(f"shard_{shard_id} prediction manifest is empty")
        missing_predictions = [
            value
            for value in frames["predictions"]["prediction_file"].astype(str)
            if not Path(value).is_file()
        ]
        if missing_predictions:
            raise FileNotFoundError(
                f"shard_{shard_id} references missing prediction files: "
                f"{missing_predictions[:3]}"
            )
        audit_rows.append(
            {
                "shard": shard_id,
                "status": "ok",
                "ledger_rows": len(ledger),
                "prediction_rows": len(frames["predictions"]),
                "data_indices": "+".join(
                    map(str, sorted(pd.to_numeric(ledger["data_index"]).astype(int).unique()))
                ),
                "platforms": "+".join(sorted(ledger["platform"].astype(str).unique())),
            }
        )

    merged = {
        key: pd.concat(frames, ignore_index=True, sort=False)
        for key, frames in collected.items()
    }
    ledger = merged["ledger"]
    plan = merged["plan"]
    if len(ledger) != len(master) or len(plan) != len(master):
        raise ValueError(
            f"Merged plan/ledger must each have {len(master)} rows; got {len(plan)}/{len(ledger)}"
        )
    if not ledger["run_id"].is_unique or not plan["run_id"].is_unique:
        raise ValueError("Merged plan or ledger contains duplicate run_id values")

    expected_ids = set(master["run_id"].astype(str))
    ledger_ids = set(ledger["run_id"].astype(str))
    if ledger_ids != expected_ids:
        missing = sorted(expected_ids - ledger_ids)
        unexpected = sorted(ledger_ids - expected_ids)
        raise ValueError(
            f"Merged run IDs do not match master manifest; missing={missing[:10]}, "
            f"unexpected={unexpected[:10]}"
        )

    predictions = merged["predictions"]
    required_methods = {
        "full_mcp",
        "single_view_mcp_dlfq",
        "single_view_mcp_maxlfq",
        "single_view_mcp_top3",
        "single_view_mcp_top1",
        "simple_early_fusion",
        "simple_late_fusion",
        "single_view_statistical_dlfq",
        "single_view_statistical_maxlfq",
        "single_view_statistical_top3",
        "single_view_statistical_top1",
        "rank_or_pvalue_fusion",
    }
    observed_methods = set(predictions["method"].astype(str))
    missing_methods = sorted(required_methods - observed_methods)
    if missing_methods:
        raise ValueError(f"Merged prediction manifest is missing methods: {missing_methods}")
    expected_dea_methods = sorted(
        {dea_method_label(value) for value in master["dea_methods"]}
    )
    if "dea_method" not in predictions.columns:
        if len(expected_dea_methods) != 1:
            raise ValueError("Merged prediction manifest lacks dea_method for a multi-DEA experiment")
        predictions["dea_method"] = expected_dea_methods[0]
        merged["predictions"] = predictions
    method_counts = predictions.groupby(["dea_method", "method"]).size()
    insufficient = {}
    for dea_method in expected_dea_methods:
        for method in required_methods:
            count = int(method_counts.get((dea_method, method), 0))
            if count < 14:
                insufficient[f"{dea_method}:{method}"] = count
    if insufficient:
        raise ValueError(
            f"Methods do not cover all 7 datasets × 2 platforms within each DEA stratum: {insufficient}"
        )

    output_paths = {
        "plan": output_dir / ARTIFACTS["plan"],
        "ledger": output_dir / ARTIFACTS["ledger"],
        "predictions": output_dir / ARTIFACTS["predictions"],
        "ablations": output_dir / ARTIFACTS["ablations"],
        "performance": output_dir / ARTIFACTS["performance"],
        "audit": output_dir / "shard_merge_audit.csv",
    }
    sort_columns = {
        "plan": ["data_index", "platform", "dea_methods", "variant", "views"],
        "ledger": ["data_index", "platform", "dea_methods", "variant", "views"],
        "predictions": ["dataset", "platform", "dea_method", "method", "view_set"],
        "ablations": ["dataset", "platform", "dea_method", "variant", "view_set"],
        "performance": ["dataset", "platform", "dea_method", "variant", "metric"],
    }
    for key in ARTIFACTS:
        frame = merged[key]
        available = [column for column in sort_columns[key] if column in frame.columns]
        if available:
            frame = frame.sort_values(available, kind="stable", na_position="last")
        frame.to_csv(output_paths[key], index=False)
    pd.DataFrame(audit_rows).to_csv(output_paths["audit"], index=False)

    summary: dict[str, object] = {
        "status": "complete",
        "shards": expected_shards,
        "core_runs": len(ledger),
        "dea_methods": expected_dea_methods,
        "prediction_rows": len(predictions),
        "methods": sorted(observed_methods),
        "output_dir": str(output_dir),
        "prediction_manifest": str(output_paths["predictions"]),
        "ledger": str(output_paths["ledger"]),
        "audit": str(output_paths["audit"]),
    }
    with (output_dir / "merge_summary.json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)
    return summary


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--shards-root", type=Path, default=Path("revision_results/task1_2_shards")
    )
    parser.add_argument(
        "--output-dir", type=Path, default=Path("revision_results/task1_2_core_merged")
    )
    parser.add_argument(
        "--master-manifest", type=Path, default=Path("MCP_r1_task1_2_DIA_manifest.csv")
    )
    parser.add_argument("--expected-shards", type=int, default=7)
    return parser


def main() -> None:
    args = build_parser().parse_args()
    summary = merge_shards(
        args.shards_root, args.output_dir, args.master_manifest, args.expected_shards
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
