"""Collect and normalize the outputs of the seven supplementary analyses.

This script solves two related revision tasks:

1. collect the standard CSV outputs produced by the seven independent
   supplementary-analysis scripts and create comparison-ready long/wide tables;
2. optionally scan the original MCP result tree for ``*_metrics_all_s.csv`` and
   ``*_DP_res_all.csv`` files, reproducing the style of the previous result
   comparison while also creating a starter manifest for protein-level analyses.

The collector never changes the original result files.  It writes a new audit,
combined tables, and normalized comparisons under ``--output-dir``.

中文说明：本脚本只读原始结果，不覆盖任何实验输出。推荐优先使用
``--collection-manifest`` 明确登记每次运行的结果目录；目录结构完全标准时，
也可以直接使用 ``--results-root`` 自动发现七项分析。
"""

from __future__ import annotations

import argparse
import json
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Mapping, Sequence

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class ResultFileSpec:
    """Description of one standard output table from an analysis script."""

    required: bool = False
    primary: bool = False
    kind: str = "summary"  # summary, audit, curve, raw, design


ANALYSIS_REGISTRY: dict[str, dict] = {
    "fair_baseline": {
        "script": "fair_baseline_benchmark.py",
        "directory_aliases": ["fair_baseline", "fair_benchmark"],
        "files": {
            "input_audit.csv": ResultFileSpec(kind="audit"),
            "per_dataset_threshold_metrics.csv": ResultFileSpec(True, True),
            "aggregate_threshold_summary.csv": ResultFileSpec(True, True),
            "paired_method_comparisons.csv": ResultFileSpec(True, True),
        },
    },
    "ranking_threshold": {
        "script": "ranking_threshold_analysis.py",
        "directory_aliases": ["ranking_threshold", "ranking_threshold_analysis"],
        "files": {
            "input_audit.csv": ResultFileSpec(kind="audit"),
            "heldout_ranking_and_calibration.csv": ResultFileSpec(True, True),
            "validation_selected_threshold_metrics.csv": ResultFileSpec(True, True),
            "precision_recall_curves.csv": ResultFileSpec(kind="curve"),
            "roc_curves.csv": ResultFileSpec(kind="curve"),
        },
    },
    "pseudo_label_robustness": {
        "script": "pseudo_label_robustness.py",
        "directory_aliases": ["pseudo_label_robustness", "pseudo_labels"],
        "files": {
            "generated_pseudo_labels.csv": ResultFileSpec(True, kind="raw"),
            "pseudo_label_summary.csv": ResultFileSpec(True, True),
            "pseudo_label_pairwise_stability.csv": ResultFileSpec(True, True),
            "downstream_prediction_robustness.csv": ResultFileSpec(primary=True),
        },
    },
    "view_complementarity_noise": {
        "script": "view_complementarity_noise_analysis.py",
        "directory_aliases": ["view_complementarity_noise", "view_complementarity"],
        "files": {
            "input_audit.csv": ResultFileSpec(kind="audit"),
            "view_quality_summary.csv": ResultFileSpec(True, True),
            "pairwise_complementarity.csv": ResultFileSpec(True, True),
            "pairwise_unique_dep_truth.csv": ResultFileSpec(primary=True),
            "complementarity_vs_incremental_gain.csv": ResultFileSpec(primary=True),
        },
    },
    "model_complexity_ablation": {
        "script": "model_complexity_ablation.py",
        "directory_aliases": ["model_complexity_ablation", "model_ablation"],
        "files": {
            "recommended_experiment_design.csv": ResultFileSpec(True, kind="design"),
            "input_audit.csv": ResultFileSpec(kind="audit"),
            "ablation_metrics_long.csv": ResultFileSpec(True, True),
            "ablation_summary.csv": ResultFileSpec(True, True),
            "paired_differences_vs_full_mcp.csv": ResultFileSpec(True, True),
            "one_standard_error_selection.csv": ResultFileSpec(True, True),
        },
    },
    "clinical_validation": {
        "script": "clinical_validation_analysis.py",
        "directory_aliases": ["clinical_validation", "clinical"],
        # Clinical sub-analyses are optional independently. At least one primary
        # table is checked after collection rather than marking every file required.
        "files": {
            "classification_metrics_with_bootstrap_ci.csv": ResultFileSpec(primary=True),
            "paired_classification_metric_differences.csv": ResultFileSpec(primary=True),
            "classification_input_audit.csv": ResultFileSpec(kind="audit"),
            "matched_dimension_clustering_metrics.csv": ResultFileSpec(primary=True),
            "feature_input_audit.csv": ResultFileSpec(kind="audit"),
            "cox_models_with_bh_fdr.csv": ResultFileSpec(primary=True),
            "kaplan_meier_curve_data_full_followup.csv": ResultFileSpec(kind="curve"),
        },
    },
    "ifng_pathway_validation": {
        "script": "ifng_pathway_validation.py",
        "directory_aliases": ["ifng_pathway_validation", "ifng_validation"],
        "files": {
            "input_audit.csv": ResultFileSpec(kind="audit"),
            "database_supported_protein_recovery.csv": ResultFileSpec(True, True),
            "matched_size_pathway_ora_bh.csv": ResultFileSpec(True, True),
            "preranked_gsea_bh.csv": ResultFileSpec(True, True),
        },
    },
}


ANALYSIS_ALIASES: dict[str, str] = {
    alias: canonical
    for canonical, config in ANALYSIS_REGISTRY.items()
    for alias in [canonical, config["script"], Path(config["script"]).stem, *config["directory_aliases"]]
}


RUN_METADATA_COLUMNS = ["run_id", "scope", "acquisition", "platform", "view_set", "notes"]
PRIMARY_ID_COLUMNS = [
    "dataset",
    "cohort",
    "acquisition",
    "platform",
    "method",
    "reference_method",
    "comparator",
    "method_a",
    "method_b",
    "variant",
    "strategy",
    "view_set",
    "view",
    "view_a",
    "view_b",
    "unique_to",
    "list_type",
    "pathway",
    "protein",
    "test_type",
    "split_source",
    "group",
]
CONTEXT_COLUMNS = [
    "fdr_threshold",
    "fold_change_ratio",
    "selected_threshold",
    "matched_list_size_used",
    "n_validation",
    "n_test",
    "n_samples",
    "n_datasets",
    "n_pairs",
]


# Curated metric columns used to build the main reviewer-facing comparison table.
PRIMARY_COLUMN_METRICS: dict[tuple[str, str], Sequence[str]] = {
    ("fair_baseline", "per_dataset_threshold_metrics.csv"): [
        "accuracy", "balanced_accuracy", "precision", "recall", "specificity", "f1", "mcc"
    ],
    ("ranking_threshold", "heldout_ranking_and_calibration.csv"): [
        "auroc", "auprc", "pauc_0.01", "pauc_0.05", "brier", "ece"
    ],
    ("ranking_threshold", "validation_selected_threshold_metrics.csv"): [
        "test_accuracy", "test_balanced_accuracy", "test_precision", "test_recall",
        "test_specificity", "test_f1", "test_mcc"
    ],
    ("pseudo_label_robustness", "pseudo_label_summary.csv"): [
        "positive_fraction_among_labeled", "truth_accuracy", "truth_balanced_accuracy",
        "truth_precision", "truth_recall", "truth_specificity", "truth_f1", "truth_mcc"
    ],
    ("pseudo_label_robustness", "pseudo_label_pairwise_stability.csv"): [
        "agreement", "cohen_kappa", "positive_jaccard"
    ],
    ("pseudo_label_robustness", "downstream_prediction_robustness.csv"): [
        "auroc", "auprc", "pauc_0.01", "pauc_0.05", "accuracy", "balanced_accuracy",
        "precision", "recall", "specificity", "f1", "mcc"
    ],
    ("view_complementarity_noise", "view_quality_summary.csv"): [
        "missing_rate", "median_protein_cv", "dynamic_range_q95_q05"
    ],
    ("view_complementarity_noise", "pairwise_complementarity.csv"): [
        "fraction_both_observed", "fraction_a_only", "fraction_b_only", "missing_complementarity",
        "pearson_flat", "spearman_flat", "pearson_protein_mean", "spearman_protein_mean"
    ],
    ("view_complementarity_noise", "pairwise_unique_dep_truth.csv"): [
        "n_unique_deps", "unique_dep_true_positive_fraction"
    ],
    ("view_complementarity_noise", "complementarity_vs_incremental_gain.csv"): [
        "pair_performance", "best_single_performance", "incremental_gain"
    ],
    ("model_complexity_ablation", "one_standard_error_selection.csv"): [
        "best_mean", "one_se_cutoff", "parsimonious_mean", "complexity_rank"
    ],
    ("clinical_validation", "matched_dimension_clustering_metrics.csv"): ["ari", "nmi", "silhouette"],
    ("clinical_validation", "cox_models_with_bh_fdr.csv"): [
        "hazard_ratio_per_sd", "ph_schoenfeld_spearman_rho", "logrank_statistic"
    ],
    ("ifng_pathway_validation", "database_supported_protein_recovery.csv"): [
        "supported_precision", "supported_recall", "n_database_supported"
    ],
    ("ifng_pathway_validation", "matched_size_pathway_ora_bh.csv"): [
        "gene_ratio", "background_ratio", "overlap_size"
    ],
    ("ifng_pathway_validation", "preranked_gsea_bh.csv"): [
        "enrichment_score", "normalized_enrichment_score"
    ],
}


# Tables that already encode their metric name in a ``metric`` column.
PRIMARY_LONG_SPECS: dict[tuple[str, str], dict[str, str | None]] = {
    ("fair_baseline", "aggregate_threshold_summary.csv"): {
        "value": "mean", "ci_low": "mean_ci_low", "ci_high": "mean_ci_high"
    },
    ("fair_baseline", "paired_method_comparisons.csv"): {
        "value": "mean_paired_difference", "ci_low": "difference_ci_low",
        "ci_high": "difference_ci_high", "pvalue": "wilcoxon_pvalue", "fdr": "wilcoxon_fdr_bh"
    },
    ("model_complexity_ablation", "ablation_metrics_long.csv"): {"value": "value"},
    ("model_complexity_ablation", "ablation_summary.csv"): {
        "value": "mean", "ci_low": "mean_ci_low", "ci_high": "mean_ci_high"
    },
    ("model_complexity_ablation", "paired_differences_vs_full_mcp.csv"): {
        "value": "mean_full_minus_comparator", "ci_low": "ci_low", "ci_high": "ci_high",
        "pvalue": "wilcoxon_pvalue", "fdr": "wilcoxon_fdr_bh"
    },
    ("clinical_validation", "classification_metrics_with_bootstrap_ci.csv"): {
        "value": "value", "ci_low": "ci_low", "ci_high": "ci_high"
    },
    ("clinical_validation", "paired_classification_metric_differences.csv"): {
        "value": "mean_difference_a_minus_b", "ci_low": "ci_low", "ci_high": "ci_high"
    },
}


METRIC_ALIASES: Mapping[str, str] = {
    "Acc": "accuracy",
    "Prec": "precision",
    "Rec": "recall",
    "F1": "f1",
    "F1w": "weighted_f1",
    "Mcc": "mcc",
    "nMcc": "normalized_mcc",
    "geomean": "geometric_mean",
    "pauc001": "pauc_0.01",
    "pauc005": "pauc_0.05",
    "pauc01": "pauc_0.10",
}


def read_table(path: Path) -> pd.DataFrame:
    """Read a delimited/Excel table based on its suffix."""

    suffix = path.suffix.lower()
    if suffix in {".xlsx", ".xls"}:
        return pd.read_excel(path)
    if suffix in {".tsv", ".txt"}:
        return pd.read_csv(path, sep="\t")
    return pd.read_csv(path)


def resolve_relative(base_file: Path, value: str | Path) -> Path:
    path = Path(value).expanduser()
    return path.resolve() if path.is_absolute() else (base_file.resolve().parent / path).resolve()


def normalize_analysis(value: str) -> str:
    key = value.strip()
    if key in ANALYSIS_ALIASES:
        return ANALYSIS_ALIASES[key]
    lower_aliases = {alias.lower(): target for alias, target in ANALYSIS_ALIASES.items()}
    if key.lower() in lower_aliases:
        return lower_aliases[key.lower()]
    raise ValueError(
        f"Unknown analysis {value!r}. Accepted canonical names: {sorted(ANALYSIS_REGISTRY)}"
    )


def manifest_template() -> pd.DataFrame:
    """Return a portable template for explicitly registering result directories."""

    rows = []
    for key, config in ANALYSIS_REGISTRY.items():
        external = key in {"clinical_validation", "ifng_pathway_validation"}
        rows.append(
            {
                "analysis": key,
                "result_dir": f"revision_results/{config['directory_aliases'][0]}",
                "run_id": f"external_{'clinical' if key == 'clinical_validation' else 'ifng'}"
                if external
                else "dia_primary",
                "scope": "external_validation" if external else "DIA-only",
                "acquisition": "" if external else "DIA",
                "platform": "",
                "view_set": "",
                "notes": "Edit paths/metadata before collection",
            }
        )
    return pd.DataFrame(rows)


def runs_from_manifest(path: Path) -> pd.DataFrame:
    manifest = read_table(path)
    required = ["analysis", "result_dir"]
    missing = [column for column in required if column not in manifest.columns]
    if missing:
        raise ValueError(f"Collection manifest is missing columns: {missing}")
    manifest = manifest.copy()
    manifest["analysis"] = manifest["analysis"].astype(str).map(normalize_analysis)
    manifest["result_dir"] = manifest["result_dir"].map(lambda value: str(resolve_relative(path, value)))
    for column in RUN_METADATA_COLUMNS:
        if column not in manifest.columns:
            manifest[column] = ""
    for index in manifest.index:
        if not str(manifest.at[index, "run_id"]).strip():
            manifest.at[index, "run_id"] = Path(manifest.at[index, "result_dir"]).name
    return manifest[["analysis", "result_dir", *RUN_METADATA_COLUMNS]]


def discover_runs(root: Path) -> pd.DataFrame:
    """Discover standard analysis directories beneath a result root."""

    root = root.expanduser().resolve()
    rows: list[dict] = []
    seen: set[tuple[str, Path]] = set()
    for analysis, config in ANALYSIS_REGISTRY.items():
        for alias in config["directory_aliases"]:
            candidates = [root / alias, *root.glob(f"*/{alias}")]
            for candidate in candidates:
                candidate = candidate.resolve()
                key = (analysis, candidate)
                if candidate.is_dir() and key not in seen:
                    seen.add(key)
                    rows.append(
                        {
                            "analysis": analysis,
                            "result_dir": str(candidate),
                            "run_id": candidate.parent.name if candidate.parent != root else candidate.name,
                            "scope": "",
                            "acquisition": "",
                            "platform": "",
                            "view_set": "",
                            "notes": "auto-discovered",
                        }
                    )
    return pd.DataFrame(rows, columns=["analysis", "result_dir", *RUN_METADATA_COLUMNS])


def provenance_columns(run: pd.Series, source: Path) -> dict[str, object]:
    result = {
        "_analysis": run["analysis"],
        "_run_id": run.get("run_id", ""),
        "_source_file": str(source),
        "_source_dir": str(source.parent),
    }
    for column in ["scope", "acquisition", "platform", "view_set", "notes"]:
        value = run.get(column, "")
        if pd.notna(value) and str(value).strip():
            result[f"_run_{column}"] = value
    return result


def collect_analysis_tables(
    runs: pd.DataFrame,
) -> tuple[dict[tuple[str, str], list[pd.DataFrame]], pd.DataFrame]:
    """Load registered result files and return lossless combined-table inputs."""

    loaded: dict[tuple[str, str], list[pd.DataFrame]] = {}
    inventory: list[dict] = []
    for _, run in runs.iterrows():
        analysis = str(run["analysis"])
        result_dir = Path(run["result_dir"]).expanduser().resolve()
        config = ANALYSIS_REGISTRY[analysis]
        registered = config["files"]
        present_primary = 0
        for filename, spec in registered.items():
            path = result_dir / filename
            base = {
                "analysis": analysis,
                "script": config["script"],
                "run_id": run.get("run_id", ""),
                "result_dir": str(result_dir),
                "result_file": filename,
                "required": spec.required,
                "primary": spec.primary,
                "kind": spec.kind,
            }
            if not path.exists():
                inventory.append(
                    {
                        **base,
                        "status": "missing_required" if spec.required else "missing_optional",
                        "n_rows": np.nan,
                        "n_columns": np.nan,
                        "message": "",
                    }
                )
                continue
            try:
                frame = read_table(path)
                enriched = frame.copy()
                for column, value in provenance_columns(run, path).items():
                    enriched[column] = value
                loaded.setdefault((analysis, filename), []).append(enriched)
                if spec.primary:
                    present_primary += 1
                inventory.append(
                    {
                        **base,
                        "status": "ok",
                        "n_rows": len(frame),
                        "n_columns": len(frame.columns),
                        "message": "",
                    }
                )
            except Exception as exc:
                inventory.append(
                    {
                        **base,
                        "status": "read_error",
                        "n_rows": np.nan,
                        "n_columns": np.nan,
                        "message": repr(exc),
                    }
                )

        # Record unregistered CSVs so no newly added result is silently ignored.
        if result_dir.is_dir():
            for path in sorted(result_dir.glob("*.csv")):
                if path.name not in registered:
                    inventory.append(
                        {
                            "analysis": analysis,
                            "script": config["script"],
                            "run_id": run.get("run_id", ""),
                            "result_dir": str(result_dir),
                            "result_file": path.name,
                            "required": False,
                            "primary": False,
                            "kind": "unregistered",
                            "status": "unregistered_present",
                            "n_rows": np.nan,
                            "n_columns": np.nan,
                            "message": "File preserved in place; add it to the registry if it should be normalized",
                        }
                    )
        if analysis == "clinical_validation" and present_primary == 0:
            inventory.append(
                {
                    "analysis": analysis,
                    "script": config["script"],
                    "run_id": run.get("run_id", ""),
                    "result_dir": str(result_dir),
                    "result_file": "<at least one clinical primary table>",
                    "required": True,
                    "primary": True,
                    "kind": "summary",
                    "status": "missing_required",
                    "n_rows": np.nan,
                    "n_columns": np.nan,
                    "message": "Run at least one classification, clustering, or survival branch",
                }
            )
    return loaded, pd.DataFrame(inventory)


def first_existing(row: pd.Series, names: Iterable[str]) -> object:
    for name in names:
        if name in row.index and pd.notna(row[name]):
            return row[name]
    return np.nan


def primary_base(
    analysis: str, filename: str, row: pd.Series, metric: str, source_file: str
) -> dict[str, object]:
    base: dict[str, object] = {
        "analysis": analysis,
        "result_table": filename,
        "run_id": row.get("_run_id", ""),
        "scope": first_existing(row, ["scope", "_run_scope"]),
        "metric": metric,
        "source_file": source_file,
    }
    for column in PRIMARY_ID_COLUMNS:
        value = first_existing(row, [column, f"_run_{column}"])
        base[column] = value
    context = {
        column: row[column]
        for column in CONTEXT_COLUMNS
        if column in row.index and pd.notna(row[column])
    }
    base["parameter_context"] = json.dumps(context, ensure_ascii=False, default=str, sort_keys=True)
    return base


def available_numeric(row: pd.Series, column: str | None) -> float:
    if not column or column not in row.index:
        return np.nan
    value = pd.to_numeric(pd.Series([row[column]]), errors="coerce").iloc[0]
    return float(value) if pd.notna(value) else np.nan


def normalize_primary_table(analysis: str, filename: str, frame: pd.DataFrame) -> pd.DataFrame:
    """Convert one known summary table to a common metric/value schema."""

    rows: list[dict] = []
    source_file = str(frame["_source_file"].iloc[0]) if "_source_file" in frame and len(frame) else ""
    long_spec = PRIMARY_LONG_SPECS.get((analysis, filename))
    if long_spec is not None and "metric" in frame.columns:
        for _, row in frame.iterrows():
            metric = str(row["metric"])
            record = primary_base(analysis, filename, row, metric, str(row.get("_source_file", source_file)))
            record.update(
                {
                    "value": available_numeric(row, long_spec.get("value")),
                    "ci_low": available_numeric(row, long_spec.get("ci_low")),
                    "ci_high": available_numeric(row, long_spec.get("ci_high")),
                    "pvalue": available_numeric(row, long_spec.get("pvalue")),
                    "fdr": available_numeric(row, long_spec.get("fdr")),
                }
            )
            rows.append(record)

    for metric_column in PRIMARY_COLUMN_METRICS.get((analysis, filename), []):
        if metric_column not in frame.columns:
            continue
        for _, row in frame.iterrows():
            record = primary_base(
                analysis, filename, row, metric_column, str(row.get("_source_file", source_file))
            )
            # Pathway and survival tables carry table-level statistical columns.
            pvalue_column = None
            fdr_column = None
            if filename == "matched_size_pathway_ora_bh.csv":
                pvalue_column, fdr_column = "pvalue", "fdr_bh"
            elif filename == "preranked_gsea_bh.csv":
                pvalue_column, fdr_column = "pvalue", "fdr_bh"
            elif filename == "database_supported_protein_recovery.csv":
                pvalue_column, fdr_column = "hypergeometric_pvalue", "enrichment_fdr_bh"
            elif filename == "cox_models_with_bh_fdr.csv":
                if metric_column == "ph_schoenfeld_spearman_rho":
                    pvalue_column, fdr_column = "ph_assumption_pvalue", None
                elif metric_column == "logrank_statistic":
                    pvalue_column, fdr_column = "logrank_pvalue", "logrank_fdr_bh"
                else:
                    pvalue_column, fdr_column = "pvalue", "cox_fdr_bh"
            record.update(
                {
                    "value": available_numeric(row, metric_column),
                    "ci_low": available_numeric(row, "ci_low")
                    if metric_column == "hazard_ratio_per_sd"
                    else np.nan,
                    "ci_high": available_numeric(row, "ci_high")
                    if metric_column == "hazard_ratio_per_sd"
                    else np.nan,
                    "pvalue": available_numeric(row, pvalue_column),
                    "fdr": available_numeric(row, fdr_column),
                }
            )
            rows.append(record)

    return pd.DataFrame(rows)


def all_numeric_long(loaded: dict[tuple[str, str], list[pd.DataFrame]]) -> pd.DataFrame:
    """Create a broad, machine-readable numeric-cell table for secondary checks."""

    rows: list[dict] = []
    for (analysis, filename), frames in loaded.items():
        spec = ANALYSIS_REGISTRY[analysis]["files"].get(filename, ResultFileSpec())
        if spec.kind in {"audit", "curve", "raw", "design"}:
            continue
        for frame in frames:
            for row_index, row in frame.reset_index(drop=True).iterrows():
                ids = {
                    column: row[column]
                    for column in PRIMARY_ID_COLUMNS
                    if column in row.index and pd.notna(row[column])
                }
                for column in frame.columns:
                    if column.startswith("_") or column in PRIMARY_ID_COLUMNS:
                        continue
                    value = pd.to_numeric(pd.Series([row[column]]), errors="coerce").iloc[0]
                    if pd.isna(value):
                        continue
                    metric_name = (
                        str(row["metric"])
                        if column == "value" and "metric" in row.index and pd.notna(row["metric"])
                        else column
                    )
                    rows.append(
                        {
                            "analysis": analysis,
                            "result_table": filename,
                            "run_id": row.get("_run_id", ""),
                            "source_file": row.get("_source_file", ""),
                            "row_index": row_index,
                            "measure": metric_name,
                            "value": float(value),
                            "identifiers": json.dumps(ids, ensure_ascii=False, default=str, sort_keys=True),
                        }
                    )
    return pd.DataFrame(rows)


def combined_audits(loaded: dict[tuple[str, str], list[pd.DataFrame]]) -> pd.DataFrame:
    frames: list[pd.DataFrame] = []
    for (_, filename), table_list in loaded.items():
        if "audit" in filename:
            frames.extend(table_list)
    return pd.concat(frames, ignore_index=True, sort=False) if frames else pd.DataFrame()


def collection_summary(inventory: pd.DataFrame, primary: pd.DataFrame, audits: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict] = []
    for analysis in sorted(inventory["analysis"].unique()) if not inventory.empty else []:
        subset = inventory[inventory["analysis"] == analysis]
        audit_errors = 0
        if not audits.empty and "_analysis" in audits and "status" in audits:
            current = audits[audits["_analysis"] == analysis]
            audit_errors = int(current["status"].astype(str).str.lower().eq("error").sum())
        rows.append(
            {
                "analysis": analysis,
                "n_runs": subset["run_id"].nunique(dropna=False),
                "n_files_ok": int((subset["status"] == "ok").sum()),
                "n_missing_required": int((subset["status"] == "missing_required").sum()),
                "n_read_errors": int((subset["status"] == "read_error").sum()),
                "n_input_audit_errors": audit_errors,
                "n_primary_metric_rows": int((primary["analysis"] == analysis).sum())
                if not primary.empty
                else 0,
            }
        )
    return pd.DataFrame(rows)


def clean_dataset_name(path: Path) -> str:
    name = path.name
    name = re.sub(r"_+metrics_all_s\.csv$", "", name, flags=re.IGNORECASE)
    name = re.sub(r"_+metrics_all\.csv$", "", name, flags=re.IGNORECASE)
    return name or path.parent.name


def core_metric_files(root: Path) -> list[Path]:
    candidates = set(root.rglob("*_metrics_all_s.csv"))
    candidates.update(root.rglob("*_metrics_all.csv"))
    return sorted(path.resolve() for path in candidates if path.is_file())


def scan_core_results(root: Path, output_dir: Path) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Collect legacy/core metric files and build a protein-result manifest starter."""

    root = root.expanduser().resolve()
    wide_rows: list[pd.DataFrame] = []
    long_rows: list[dict] = []
    audit: list[dict] = []
    for path in core_metric_files(root):
        try:
            frame = read_table(path)
            method_column = "test_type" if "test_type" in frame.columns else "method" if "method" in frame.columns else None
            if method_column is None:
                raise ValueError("No test_type or method column")
            metadata = {
                "dataset": clean_dataset_name(path),
                "result_file": str(path),
                "relative_result_file": os.path.relpath(path, root),
                "configuration_path": os.path.relpath(path.parent, root),
            }
            current = frame.copy()
            current.insert(0, "configuration_path", metadata["configuration_path"])
            current.insert(0, "relative_result_file", metadata["relative_result_file"])
            current.insert(0, "result_file", metadata["result_file"])
            current.insert(0, "dataset", metadata["dataset"])
            wide_rows.append(current)
            for _, row in frame.iterrows():
                for column in frame.columns:
                    if column == method_column:
                        continue
                    value = pd.to_numeric(pd.Series([row[column]]), errors="coerce").iloc[0]
                    if pd.isna(value):
                        continue
                    long_rows.append(
                        {
                            **metadata,
                            "test_type": row[method_column],
                            "metric": METRIC_ALIASES.get(column, column),
                            "original_metric_column": column,
                            "value": float(value),
                        }
                    )
            audit.append({"file_type": "metrics", "file": str(path), "status": "ok", "message": ""})
        except Exception as exc:
            audit.append(
                {"file_type": "metrics", "file": str(path), "status": "error", "message": repr(exc)}
            )

    starter_rows: list[dict] = []
    for path in sorted(root.rglob("*_DP_res_all.csv")):
        try:
            header = pd.read_csv(path, nrows=0)
            columns = list(header.columns)
            protein_column = "Protein" if "Protein" in columns else "protein" if "protein" in columns else ""
            truth_column = next(
                (candidate for candidate in ["True_lab", "true_lab", "true_label"] if candidate in columns), ""
            )
            score_columns = [column for column in columns if str(column).startswith("score_")]
            for score_column in score_columns:
                suffix = str(score_column)[len("score_") :]
                log_candidates = [f"logFC_{suffix}", f"log2fc_{suffix}", f"log2FC_{suffix}"]
                q_candidates = [f"qval_{suffix}", f"qvalue_{suffix}"]
                log_column = next((column for column in log_candidates if column in columns), "")
                q_column = next((column for column in q_candidates if column in columns), "")
                starter_rows.append(
                    {
                        "dataset": path.parent.name or clean_dataset_name(path),
                        "acquisition": "",
                        "platform": "",
                        "method": suffix,
                        "view_set": "",
                        "comparison_group": "",
                        "prediction_file": os.path.relpath(path.resolve(), output_dir.resolve()),
                        "protein_column": protein_column,
                        "true_label_column": truth_column,
                        "score_column": score_column,
                        "qvalue_column": q_column,
                        "log2fc_column": log_column,
                    }
                )
            audit.append(
                {
                    "file_type": "protein_predictions",
                    "file": str(path),
                    "status": "ok" if score_columns else "warning",
                    "message": "" if score_columns else "No score_* columns were found",
                }
            )
        except Exception as exc:
            audit.append(
                {
                    "file_type": "protein_predictions",
                    "file": str(path),
                    "status": "error",
                    "message": repr(exc),
                }
            )
    wide = pd.concat(wide_rows, ignore_index=True, sort=False) if wide_rows else pd.DataFrame()
    return wide, pd.DataFrame(long_rows), pd.DataFrame(starter_rows), pd.DataFrame(audit)


def safe_excel_sheet(frame: pd.DataFrame, writer: pd.ExcelWriter, name: str) -> bool:
    # Excel supports 1,048,576 rows including the header.
    if len(frame) > 1_048_575:
        return False
    frame.to_excel(writer, sheet_name=name[:31], index=False)
    return True


def write_excel(
    path: Path,
    inventory: pd.DataFrame,
    summary: pd.DataFrame,
    primary: pd.DataFrame,
    primary_wide: pd.DataFrame,
    audits: pd.DataFrame,
    core_wide: pd.DataFrame,
    core_long: pd.DataFrame,
    core_starter: pd.DataFrame,
) -> None:
    with pd.ExcelWriter(path) as writer:
        wrote_sheet = False
        for name, frame in [
            ("collection_summary", summary),
            ("inventory", inventory),
            ("primary_long", primary),
            ("primary_wide", primary_wide),
            ("input_audits", audits),
            ("core_metrics_wide", core_wide),
            ("core_metrics_long", core_long),
            ("core_manifest_starter", core_starter),
        ]:
            if not frame.empty:
                wrote_sheet = safe_excel_sheet(frame, writer, name) or wrote_sheet
        if not wrote_sheet:
            pd.DataFrame(
                {"message": ["No result table was available when this workbook was created."]}
            ).to_excel(writer, sheet_name="collection_status", index=False)


def make_primary_wide(primary: pd.DataFrame) -> pd.DataFrame:
    if primary.empty:
        return pd.DataFrame()
    index_columns = [
        "analysis", "result_table", "run_id", "scope", "dataset", "cohort", "acquisition",
        "platform", "method", "reference_method", "comparator", "method_a", "method_b",
        "variant", "strategy", "view_set", "view", "view_a", "view_b", "unique_to",
        "list_type", "pathway", "protein", "test_type", "split_source", "group",
        "parameter_context", "source_file",
    ]
    available = [column for column in index_columns if column in primary.columns]
    prepared = primary.copy()
    # Empty identifier cells must use a stable placeholder or pivot_table drops them.
    prepared[available] = prepared[available].fillna("").astype(str)
    return (
        prepared.pivot_table(index=available, columns="metric", values="value", aggfunc="mean")
        .reset_index()
        .rename_axis(columns=None)
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--collection-manifest",
        type=Path,
        default=None,
        help="CSV/TSV/XLSX with analysis,result_dir and optional run metadata",
    )
    parser.add_argument(
        "--results-root",
        type=Path,
        default=None,
        help="Auto-discover standard result subdirectories beneath this root",
    )
    parser.add_argument(
        "--core-results-root",
        type=Path,
        default=None,
        help="Optional recursive scan for *_metrics_all[_s].csv and *_DP_res_all.csv",
    )
    parser.add_argument("--output-dir", type=Path, default=Path("revision_results/collected_results"))
    parser.add_argument(
        "--write-manifest-template",
        type=Path,
        default=None,
        help="Write a collection-manifest template. If no input root/manifest is supplied, exit afterwards",
    )
    parser.add_argument("--excel", action="store_true", help="Also write a multi-sheet XLSX workbook")
    parser.add_argument(
        "--strict",
        action="store_true",
        help="Return an error after writing audits if any required file is missing or unreadable",
    )
    return parser


def main() -> None:
    args = build_parser().parse_args()
    if args.write_manifest_template is not None:
        template_path = args.write_manifest_template.expanduser().resolve()
        template_path.parent.mkdir(parents=True, exist_ok=True)
        manifest_template().to_csv(template_path, index=False)
        print(f"Wrote collection-manifest template: {template_path}")
        if args.collection_manifest is None and args.results_root is None and args.core_results_root is None:
            return

    out = args.output_dir.expanduser().resolve()
    out.mkdir(parents=True, exist_ok=True)
    if args.collection_manifest is not None:
        runs = runs_from_manifest(args.collection_manifest)
    elif args.results_root is not None:
        runs = discover_runs(args.results_root)
        if runs.empty:
            raise RuntimeError(
                "No standard result directory was found. Use --collection-manifest for custom directory names."
            )
    else:
        runs = pd.DataFrame(columns=["analysis", "result_dir", *RUN_METADATA_COLUMNS])

    loaded: dict[tuple[str, str], list[pd.DataFrame]] = {}
    inventory = pd.DataFrame()
    primary = pd.DataFrame()
    numeric_long = pd.DataFrame()
    audits = pd.DataFrame()
    if not runs.empty:
        loaded, inventory = collect_analysis_tables(runs)
        primary_frames = [
            normalize_primary_table(analysis, filename, pd.concat(frames, ignore_index=True, sort=False))
            for (analysis, filename), frames in loaded.items()
        ]
        primary_frames = [frame for frame in primary_frames if not frame.empty]
        primary = pd.concat(primary_frames, ignore_index=True, sort=False) if primary_frames else pd.DataFrame()
        numeric_long = all_numeric_long(loaded)
        audits = combined_audits(loaded)

        combined_dir = out / "combined_tables"
        combined_dir.mkdir(parents=True, exist_ok=True)
        for (analysis, filename), frames in loaded.items():
            combined = pd.concat(frames, ignore_index=True, sort=False)
            combined.to_csv(combined_dir / f"{analysis}__{filename}", index=False)

    primary_wide = make_primary_wide(primary)
    summary = collection_summary(inventory, primary, audits) if not inventory.empty else pd.DataFrame()
    core_wide = pd.DataFrame()
    core_long = pd.DataFrame()
    core_starter = pd.DataFrame()
    core_audit = pd.DataFrame()
    if args.core_results_root is not None:
        core_wide, core_long, core_starter, core_audit = scan_core_results(args.core_results_root, out)

    output_tables = {
        "collection_inventory.csv": inventory,
        "collection_summary.csv": summary,
        "primary_results_comparison.csv": primary,
        "primary_results_comparison_wide.csv": primary_wide,
        "all_numeric_results_long.csv": numeric_long,
        "combined_input_audits.csv": audits,
        "core_metrics_wide.csv": core_wide,
        "core_metrics_long.csv": core_long,
        "core_prediction_manifest_starter.csv": core_starter,
        "core_collection_audit.csv": core_audit,
    }
    for filename, frame in output_tables.items():
        if not frame.empty:
            frame.to_csv(out / filename, index=False)

    if args.excel:
        write_excel(
            out / "supplementary_results_collection.xlsx",
            inventory,
            summary,
            primary,
            primary_wide,
            audits,
            core_wide,
            core_long,
            core_starter,
        )

    metadata = {
        "collection_manifest": str(args.collection_manifest.resolve()) if args.collection_manifest else None,
        "results_root": str(args.results_root.resolve()) if args.results_root else None,
        "core_results_root": str(args.core_results_root.resolve()) if args.core_results_root else None,
        "n_registered_runs": len(runs),
        "n_primary_rows": len(primary),
        "n_core_metric_rows": len(core_long),
        "excel_written": bool(args.excel),
    }
    (out / "collection_metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    has_errors = False
    if not inventory.empty:
        has_errors = inventory["status"].isin(["missing_required", "read_error"]).any()
    if not core_audit.empty:
        has_errors = has_errors or core_audit["status"].eq("error").any()
    print(f"Collected supplementary/core results into: {out}")
    if args.strict and has_errors:
        raise RuntimeError("Strict collection found missing/unreadable results; inspect collection audits")


if __name__ == "__main__":
    main()
