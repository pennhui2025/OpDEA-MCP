"""Merge and quality-control the seven fixed4label ablation shards.

Run this only after all seven ``MCP_r1_pycharm_fixed4label_ablation_shard_*``
scripts finish.  It refuses partial, mixed-universe, non-DP_fdr, or label-hash
mismatched results instead of silently producing a table.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from scipy.stats import rankdata
from statsmodels.stats.multitest import multipletests

from MCP_r1_build_fixed4label_ablation_manifest import build_rows
from MCP_r1_fixed4label_ablation import (
    IMPLEMENTATION_SCHEMA_VERSION,
    _canonical_json,
    _code_fingerprints,
    _metric_row,
    _model_spec,
    _sha256_bytes,
    _stored_sources_unchanged,
    sha256_file,
)


METHODS = (
    "full_mcp",
    "single_view_mcp_dlfq",
    "single_view_mcp_maxlfq",
    "single_view_mcp_top3",
    "single_view_mcp_top1",
)
FIXED_SUBSETS = (
    "all_four_view_union",
    "pseudo_label_excluded_transductive",
    "common_four_view_intersection",
)
METRICS = (
    "accuracy",
    "precision",
    "recall",
    "f1",
    "mcc",
    "specificity",
    "auroc",
    "auprc",
    "pauc_0.01",
    "pauc_0.05",
    "pauc_0.10",
)


def _read_required(path: Path) -> pd.DataFrame:
    if not path.is_file():
        raise FileNotFoundError(path)
    table = pd.read_csv(path)
    if table.empty:
        raise ValueError(f"Required table is empty: {path}")
    return table


def _as_bool(series: pd.Series) -> pd.Series:
    if pd.api.types.is_bool_dtype(series):
        return series.fillna(False)
    return series.astype(str).str.strip().str.lower().isin({"1", "true", "t", "yes", "y"})


def _adjust_pvalues(summary: pd.DataFrame) -> pd.DataFrame:
    summary = summary.copy()
    summary["p_holm"] = np.nan
    valid = summary["wilcoxon_p"].notna()
    if valid.any():
        summary.loc[valid, "p_holm"] = multipletests(
            summary.loc[valid, "wilcoxon_p"].astype(float), method="holm"
        )[1]
    return summary


def _exact_signed_rank_p(delta: np.ndarray) -> float:
    """Exact two-sided sign-flip Wilcoxon p-value, also valid with tied ranks.

    Zero differences are removed.  For the remaining m<=7 dataset differences,
    all 2**m sign allocations are enumerated, making Python and R definitions
    explicit and identical (no asymptotic/continuity-correction ambiguity).
    """

    values = np.asarray(delta, dtype=float)
    values = values[np.isfinite(values)]
    values = values[values != 0]
    if len(values) == 0:
        return 1.0
    ranks = rankdata(np.abs(values), method="average")
    total = float(np.sum(ranks))
    observed = float(np.sum(ranks[values > 0]))
    distance = abs(observed - total / 2.0)
    permuted = np.empty(2 ** len(values), dtype=float)
    for bitmask in range(2 ** len(values)):
        selected = [index for index in range(len(values)) if bitmask & (1 << index)]
        permuted[bitmask] = float(np.sum(ranks[selected])) if selected else 0.0
    return float(np.mean(np.abs(permuted - total / 2.0) >= distance - 1e-12))


def _protein_label_fingerprint(proteins: pd.Series, labels: pd.Series) -> str:
    digest = hashlib.sha256()
    for protein, label in zip(proteins.astype(str), pd.to_numeric(labels).astype(np.int8)):
        digest.update(protein.encode("utf-8"))
        digest.update(b"\0")
        digest.update(np.asarray([label], dtype=np.int8).tobytes())
    return digest.hexdigest()


def _protein_float_fingerprint(proteins: pd.Series, values: pd.Series) -> str:
    digest = hashlib.sha256()
    for protein, value in zip(proteins.astype(str), pd.to_numeric(values).astype(np.float64)):
        digest.update(protein.encode("utf-8"))
        digest.update(b"\0")
        digest.update(np.asarray([value], dtype=np.float64).tobytes())
    return digest.hexdigest()


def _posterior_fdr_selection(scores: np.ndarray, fdr: float) -> np.ndarray:
    scores = np.asarray(scores, dtype=float)
    original = pd.Series(scores)
    sorted_scores = original.sort_values(ascending=False)
    cumulative_fdr = (1.0 - sorted_scores).cumsum() / (
        1.0 + np.arange(len(sorted_scores))
    )
    count = int(np.sum(cumulative_fdr <= fdr))
    selected = pd.Series(np.zeros(len(scores), dtype=bool), index=sorted_scores.index)
    selected.iloc[:count] = True
    return selected.loc[original.index].to_numpy(dtype=bool)


def _optimal_f1_threshold(labels: np.ndarray, scores: np.ndarray) -> float:
    from sklearn.metrics import precision_recall_curve

    precision, recall, thresholds = precision_recall_curve(labels, scores)
    if len(thresholds) == 0:
        return 0.5
    f1 = 2.0 * precision * recall / (precision + recall + 1e-7)
    return float(thresholds[min(int(np.argmax(f1)), len(thresholds) - 1)])


def _metadata_path(row: Any, shards_root: Path) -> Path:
    candidate = Path(str(getattr(row, "run_metadata_file", "")))
    if candidate.is_file():
        return candidate
    return (
        shards_root
        / f"shard_{int(row.shard_id)}"
        / "runs"
        / str(row.run_id)
        / "metadata.json"
    )


def merge_shards(shards_root: Path, output_dir: Path) -> dict[str, Any]:
    shards_root = shards_root.expanduser().resolve()
    output_dir = output_dir.expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    ledgers: list[pd.DataFrame] = []
    manifests: list[pd.DataFrame] = []
    performance: list[pd.DataFrame] = []

    for shard_id in range(1, 8):
        shard = shards_root / f"shard_{shard_id}"
        ledger = _read_required(shard / "core_run_ledger.csv")
        prediction_manifest = _read_required(shard / "generated_prediction_manifest.csv")
        metrics = _read_required(shard / "generated_performance_wide.csv")
        if len(ledger) != 20:
            raise ValueError(f"shard_{shard_id}: expected 20 ledger rows, found {len(ledger)}")
        if len(prediction_manifest) != 20:
            raise ValueError(
                f"shard_{shard_id}: expected 20 prediction rows, found {len(prediction_manifest)}"
            )
        ledger["shard_id"] = shard_id
        prediction_manifest["shard_id"] = shard_id
        metrics["shard_id"] = shard_id
        ledgers.append(ledger)
        manifests.append(prediction_manifest)
        performance.append(metrics)

    ledger = pd.concat(ledgers, ignore_index=True, sort=False)
    prediction_manifest = pd.concat(manifests, ignore_index=True, sort=False)
    metrics_wide = pd.concat(performance, ignore_index=True, sort=False)
    if len(ledger) != 140 or ledger["run_id"].astype(str).nunique() != 140:
        raise ValueError("Merged ledger must contain 140 unique runs")
    bad_status = ledger[~ledger["status"].astype(str).isin({"completed", "skipped_existing"})]
    if not bad_status.empty:
        raise ValueError(f"Merged ledger contains {len(bad_status)} incomplete/error run(s)")
    if set(metrics_wide["test_type"].astype(str)) != {"DP_fdr"}:
        raise ValueError("Only test_type=DP_fdr is allowed in this experiment")
    if set(metrics_wide["label_mode"].astype(str)) != {"strict_shared_mask"}:
        raise ValueError("Primary merge accepts only strict_shared_mask results")

    # Refuse an outdated or hand-edited run plan. Runtime-only paths/GPU/force
    # are excluded; every scientific manifest field must match the versioned
    # master specification generated with this code.
    expected_by_id = {row["run_id"]: row for row in build_rows()}
    if set(ledger["run_id"].astype(str)) != set(expected_by_id):
        raise ValueError("Ledger run IDs do not match the versioned 140-run master manifest")
    ignored_spec_fields = {"data_root", "r_code", "rscript_path", "gpu_id", "force", "dataset"}
    for row in ledger.itertuples(index=False):
        expected = expected_by_id[str(row.run_id)]
        for field, expected_value in expected.items():
            if field in ignored_spec_fields:
                continue
            raw_actual = getattr(row, field)
            actual = "" if pd.isna(raw_actual) else str(raw_actual)
            if actual.lower() in {"true", "false"}:
                actual = actual.upper()
            if actual != str(expected_value):
                raise ValueError(
                    f"Run specification mismatch for {row.run_id}/{field}: "
                    f"{actual!r} != {expected_value!r}"
                )

    strata = ["data_index", "dataset", "platform", "dea_method", "label_mode"]
    for key, group in prediction_manifest.groupby(strata, dropna=False):
        observed = set(
            "full_mcp"
            if row.variant == "full_mcp"
            else f"single_view_mcp_{row.model_input_views}"
            for row in group.itertuples()
        )
        if observed != set(METHODS) or len(group) != 5:
            raise ValueError(f"Stratum {key} does not contain exactly the five required methods")
        if group["label_fingerprint"].astype(str).nunique() != 1:
            raise ValueError(f"Stratum {key} does not use one identical fixed label vector")

    # Inspect every per-protein table.  This catches accidental use of old
    # single-view outputs and enforces the union missing-as-non-DEP convention.
    project_dir = Path(__file__).resolve().parent
    core_script = project_dir / "MCP_r1_mv_contrast_v6.0.3_4_linux_comb_exp_mcc2_new.py"
    current_code_fingerprints = _code_fingerprints(core_script)
    bundle_cache: dict[tuple[int, str, str], dict[str, Any]] = {}
    protein_fingerprints: dict[tuple[Any, ...], str] = {}
    truth_fingerprints: dict[tuple[Any, ...], str] = {}
    label_fingerprints: dict[tuple[Any, ...], str] = {}
    logfc_fingerprints: dict[tuple[Any, ...], str] = {}
    prediction_qc_rows: list[dict[str, Any]] = []
    for row in prediction_manifest.itertuples(index=False):
        path = Path(str(row.prediction_file))
        if not path.is_file():
            # Support a complete result tree copied from Linux to Windows.
            path = (
                shards_root
                / f"shard_{int(row.shard_id)}"
                / "runs"
                / str(row.run_id)
                / "fixed4label_DP_fdr_predictions.csv"
            )
        pred = _read_required(path)
        required = {
            "Protein",
            "True_lab",
            "raw_probability",
            "posterior_fdr_selected",
            "DP_fdr_probability_before_availability",
            "DP_fdr_available_probability",
            "DP_fdr_probability",
            "DP_fdr_threshold",
            "shared_full_log2fc",
            "selected_view_available",
            "called_DP_fdr",
            "fixed_pro_lab",
            "training_pro_lab",
            "used_for_classification_training",
            "available_dlfq",
            "available_maxlfq",
            "available_top3",
            "available_top1",
        }
        missing = sorted(required - set(pred.columns))
        if missing:
            raise ValueError(f"{path} lacks required columns {missing}")
        if pred["Protein"].astype(str).duplicated().any():
            raise ValueError(f"Duplicate Protein IDs in {path}")
        metadata_path = _metadata_path(row, shards_root)
        if not metadata_path.is_file():
            raise FileNotFoundError(metadata_path)
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        if metadata.get("status") != "completed" or metadata.get("test_type") != "DP_fdr":
            raise ValueError(f"Invalid run metadata status/test_type: {metadata_path}")
        if metadata.get("experiment_schema") != IMPLEMENTATION_SCHEMA_VERSION:
            raise ValueError(f"Outdated experiment schema in {metadata_path}")
        if str(metadata.get("run_id")) != str(row.run_id):
            raise ValueError(f"run_id mismatch between metadata and manifest: {row.run_id}")
        if metadata.get("code_fingerprints") != current_code_fingerprints:
            raise ValueError(f"Run was produced by different Python code: {metadata_path}")
        if metadata.get("prediction_sha256") != sha256_file(path):
            raise ValueError(f"Prediction hash mismatch: {path}")
        metrics_path = path.with_name("fixed4label_metrics.csv")
        latent_path = path.with_name("fixed4label_latent.npz")
        if metadata.get("metrics_sha256") != sha256_file(metrics_path):
            raise ValueError(f"Metrics hash mismatch: {metrics_path}")
        if metadata.get("latent_sha256") != sha256_file(latent_path):
            raise ValueError(f"Latent hash mismatch: {latent_path}")

        bundle_key = (int(row.data_index), str(row.platform), str(row.dea_method))
        if bundle_key not in bundle_cache:
            bundle_dir = (
                shards_root
                / f"shard_{int(row.shard_id)}"
                / "bundles"
                / f"i{int(row.data_index)}_{row.platform}_{row.dea_method}"
            )
            bundle_metadata_path = bundle_dir / "metadata.json"
            bundle_file = bundle_dir / "fixed4view_training_bundle.npz"
            audit_file = bundle_dir / "fixed_label_audit.csv"
            truth_file = bundle_dir / "evaluation_truth.csv"
            for required_file in (bundle_metadata_path, bundle_file, audit_file, truth_file):
                if not required_file.is_file():
                    raise FileNotFoundError(required_file)
            bundle_metadata = json.loads(bundle_metadata_path.read_text(encoding="utf-8"))
            if bundle_metadata.get("status") != "completed":
                raise ValueError(f"Incomplete bundle metadata: {bundle_metadata_path}")
            if bundle_metadata.get("experiment_schema") != IMPLEMENTATION_SCHEMA_VERSION:
                raise ValueError(f"Outdated bundle schema: {bundle_metadata_path}")
            if bundle_metadata.get("code_fingerprints") != current_code_fingerprints:
                raise ValueError(f"Bundle was produced by different Python code: {bundle_metadata_path}")
            if bundle_metadata.get("bundle_sha256") != sha256_file(bundle_file):
                raise ValueError(f"Bundle hash mismatch: {bundle_file}")
            if bundle_metadata.get("label_audit_sha256") != sha256_file(audit_file):
                raise ValueError(f"Bundle label-audit hash mismatch: {audit_file}")
            if bundle_metadata.get("truth_sha256") != sha256_file(truth_file):
                raise ValueError(f"Bundle truth hash mismatch: {truth_file}")
            if not _stored_sources_unchanged(bundle_metadata):
                raise ValueError(f"A source/preprocessing file changed after bundle creation: {bundle_dir}")
            bundle_audit = _read_required(audit_file)
            bundle_truth = _read_required(truth_file)
            audit_label_hash = _protein_label_fingerprint(
                bundle_audit["Protein"], bundle_audit["fixed_pro_lab"]
            )
            truth_hash = _protein_label_fingerprint(
                bundle_truth["Protein"], bundle_truth["True_lab"]
            )
            if audit_label_hash != str(bundle_metadata.get("label_fingerprint")):
                raise ValueError(f"Bundle label fingerprint is wrong: {bundle_dir}")
            if truth_hash != str(bundle_metadata.get("truth_fingerprint")):
                raise ValueError(f"Bundle truth fingerprint is wrong: {bundle_dir}")
            bundle_cache[bundle_key] = {
                "metadata": bundle_metadata,
                "audit": bundle_audit,
                "truth": bundle_truth,
            }
        cached_bundle = bundle_cache[bundle_key]
        bundle_metadata = cached_bundle["metadata"]
        if (
            str(metadata.get("bundle_sha256")) != str(bundle_metadata.get("bundle_sha256"))
            or str(metadata.get("label_fingerprint"))
            != str(bundle_metadata.get("label_fingerprint"))
            or str(metadata.get("truth_sha256")) != str(bundle_metadata.get("truth_sha256"))
            or str(metadata.get("truth_fingerprint"))
            != str(bundle_metadata.get("truth_fingerprint"))
        ):
            raise ValueError(f"Run metadata does not bind the expected bundle/truth: {metadata_path}")
        expected_model_spec = _model_spec(
            expected_by_id[str(row.run_id)], bundle_metadata, core_script
        )
        expected_model_hash = _sha256_bytes(
            _canonical_json(expected_model_spec).encode("utf-8")
        )
        if metadata.get("model_spec_hash") != expected_model_hash:
            raise ValueError(f"Model-spec hash mismatch: {metadata_path}")
        for field, expected_value in expected_model_spec.items():
            if metadata.get(field) != expected_value:
                raise ValueError(f"Run metadata field differs from model spec: {row.run_id}/{field}")

        available = _as_bool(pred["selected_view_available"]).to_numpy()
        called = _as_bool(pred["called_DP_fdr"])
        score = pd.to_numeric(pred["DP_fdr_probability"], errors="raise").to_numpy(float)
        if ((~available) & ((score != 0) | called)).any():
            raise ValueError(f"Unavailable selected-view proteins are not zero/non-call in {path}")
        availability = {
            view: _as_bool(pred[f"available_{view}"]).to_numpy()
            for view in ("dlfq", "maxlfq", "top3", "top1")
        }
        if str(row.variant) == "full_mcp":
            expected_available = np.logical_or.reduce(list(availability.values()))
            if not np.all(expected_available):
                raise ValueError(f"Full MCP union contains a protein absent from all views: {path}")
        else:
            selected_view = str(row.model_input_views)
            if selected_view not in availability:
                raise ValueError(f"Invalid selected view in manifest: {selected_view}")
            expected_available = availability[selected_view]
        if not np.array_equal(available, expected_available):
            raise ValueError(f"selected_view_available is inconsistent in {path}")

        bundle_audit = cached_bundle["audit"]
        bundle_truth = cached_bundle["truth"]
        if not np.array_equal(
            pred["Protein"].astype(str).to_numpy(),
            bundle_audit["Protein"].astype(str).to_numpy(),
        ):
            raise ValueError(f"Prediction Protein order differs from fixed bundle audit: {path}")
        if not np.array_equal(
            pred["Protein"].astype(str).to_numpy(),
            bundle_truth["Protein"].astype(str).to_numpy(),
        ):
            raise ValueError(f"Prediction Protein order differs from fixed bundle truth: {path}")
        for view, values in availability.items():
            audit_values = _as_bool(bundle_audit[f"available_{view}"]).to_numpy()
            if not np.array_equal(values, audit_values):
                raise ValueError(f"Availability {view} differs from fixed bundle audit: {path}")

        fixed_labels = pd.to_numeric(pred["fixed_pro_lab"], errors="raise").to_numpy(np.int8)
        training_labels = pd.to_numeric(pred["training_pro_lab"], errors="raise").to_numpy(np.int8)
        used = _as_bool(pred["used_for_classification_training"]).to_numpy()
        if not np.array_equal(training_labels, fixed_labels):
            raise ValueError(f"strict_shared_mask was not applied in {path}")
        if not np.array_equal(used, fixed_labels != -1):
            raise ValueError(f"Classification-training mask is inconsistent in {path}")
        audit_fixed_labels = pd.to_numeric(
            bundle_audit["fixed_pro_lab"], errors="raise"
        ).to_numpy(np.int8)
        if not np.array_equal(fixed_labels, audit_fixed_labels):
            raise ValueError(f"Prediction labels differ from fixed bundle audit: {path}")
        reported_truth = pd.to_numeric(pred["True_lab"], errors="raise").to_numpy(int)
        bundle_truth_values = pd.to_numeric(
            bundle_truth["True_lab"], errors="raise"
        ).to_numpy(int)
        if not np.array_equal(reported_truth, bundle_truth_values):
            raise ValueError(f"Prediction truth differs from the hashed bundle truth: {path}")
        calculated_label_hash = _protein_label_fingerprint(pred["Protein"], fixed_labels)
        if (
            calculated_label_hash != str(row.label_fingerprint)
            or calculated_label_hash != str(metadata.get("label_fingerprint"))
        ):
            raise ValueError(f"Self-reported label fingerprint is wrong in {path}")

        raw_probability = pd.to_numeric(pred["raw_probability"], errors="raise").to_numpy(float)
        if not np.all(np.isfinite(raw_probability)):
            raise ValueError(f"Non-finite raw probabilities in {path}")
        expected_posterior = np.zeros(len(pred), dtype=bool)
        expected_posterior[available] = _posterior_fdr_selection(
            raw_probability[available], float(metadata["q_threshold"])
        )
        reported_posterior = _as_bool(pred["posterior_fdr_selected"]).to_numpy()
        if not np.array_equal(expected_posterior, reported_posterior):
            raise ValueError(f"posterior-FDR selection cannot be reproduced for {path}")
        expected_score = np.zeros(len(pred), dtype=float)
        expected_score[available] = raw_probability[available]
        cap = available & (~expected_posterior) & (expected_score > 0.5)
        expected_score[cap] = 0.499
        for score_column in (
            "DP_fdr_probability_before_availability",
            "DP_fdr_available_probability",
            "DP_fdr_probability",
        ):
            reported = pd.to_numeric(pred[score_column], errors="raise").to_numpy(float)
            if not np.allclose(reported, expected_score, rtol=1e-10, atol=1e-12):
                raise ValueError(f"{score_column} cannot be reproduced for {path}")
        calibration = used & available
        expected_threshold = _optimal_f1_threshold(
            training_labels[calibration], expected_score[calibration]
        )
        thresholds = pd.to_numeric(pred["DP_fdr_threshold"], errors="raise").to_numpy(float)
        if not np.allclose(thresholds, expected_threshold, rtol=1e-10, atol=1e-12):
            raise ValueError(f"DP_fdr threshold cannot be reproduced for {path}")
        logfc = pd.to_numeric(pred["shared_full_log2fc"], errors="coerce").to_numpy(float)
        audit_logfc = pd.to_numeric(
            bundle_audit["fixed_full_log2fc"], errors="coerce"
        ).to_numpy(float)
        if not np.allclose(logfc, audit_logfc, rtol=1e-10, atol=1e-12, equal_nan=True):
            raise ValueError(f"Shared full log2FC differs from fixed bundle audit: {path}")
        expected_call = (
            available
            & (expected_score >= expected_threshold)
            & (np.abs(logfc) >= math.log2(float(metadata["fc_ratio"])))
        )
        if not np.array_equal(called.to_numpy(), expected_call):
            raise ValueError(f"called_DP_fdr cannot be reproduced for {path}")

        key = (
            int(row.data_index), str(row.dataset), str(row.platform), str(row.dea_method)
        )
        protein_hash = hashlib.sha256(
            pd.util.hash_pandas_object(
                pred["Protein"].astype(str), index=False
            ).values.tobytes()
        ).hexdigest()
        truth_hash = hashlib.sha256(
            pd.util.hash_pandas_object(
                pred[["Protein", "True_lab"]].astype({"Protein": str}), index=False
            ).values.tobytes()
        ).hexdigest()
        logfc_hash = _protein_float_fingerprint(pred["Protein"], pred["shared_full_log2fc"])
        if key in protein_fingerprints and protein_fingerprints[key] != protein_hash:
            raise ValueError(f"Protein order/universe differs among methods in stratum {key}")
        if key in truth_fingerprints and truth_fingerprints[key] != truth_hash:
            raise ValueError(f"Truth vector differs among methods in stratum {key}")
        if key in label_fingerprints and label_fingerprints[key] != calculated_label_hash:
            raise ValueError(f"Fixed label vector differs among methods in stratum {key}")
        if key in logfc_fingerprints and logfc_fingerprints[key] != logfc_hash:
            raise ValueError(f"Shared full log2FC differs among methods in stratum {key}")
        protein_fingerprints[key] = protein_hash
        truth_fingerprints[key] = truth_hash
        label_fingerprints[key] = calculated_label_hash
        logfc_fingerprints[key] = logfc_hash

        # Independently recompute all saved performance rows from proteins.
        common = np.logical_and.reduce(list(availability.values()))
        subset_masks = {
            "all_four_view_union": np.ones(len(pred), dtype=bool),
            "pseudo_label_excluded_transductive": fixed_labels == -1,
            "common_four_view_intersection": common,
            "selected_view_available": available,
        }
        truth_values = reported_truth
        for subset_name, keep in subset_masks.items():
            recomputed = _metric_row(
                truth_values[keep], expected_score[keep], expected_call[keep], available[keep]
            )
            saved = metrics_wide[
                (metrics_wide["run_id"].astype(str) == str(row.run_id))
                & (metrics_wide["evaluation_subset"].astype(str) == subset_name)
            ]
            if len(saved) != 1:
                raise ValueError(f"Missing/duplicate metric row for {row.run_id}/{subset_name}")
            saved_row = saved.iloc[0]
            for field in (
                "N_evaluated", "N_true_DEP", "N_true_nonDEP",
                "N_selected_view_available", "tn", "fp", "fn", "tp",
            ):
                if int(saved_row[field]) != int(recomputed[field]):
                    raise ValueError(f"Metric count {field} is wrong for {row.run_id}/{subset_name}")
            for field in METRICS:
                left, right = float(saved_row[field]), float(recomputed[field])
                if not np.isclose(left, right, rtol=1e-10, atol=1e-12, equal_nan=True):
                    raise ValueError(f"Metric {field} is wrong for {row.run_id}/{subset_name}")
        prediction_qc_rows.append(
            {
                "run_id": row.run_id,
                "dataset": row.dataset,
                "data_index": row.data_index,
                "platform": row.platform,
                "dea_method": row.dea_method,
                "variant": row.variant,
                "model_input_views": row.model_input_views,
                "N_union": len(pred),
                "N_available": int(available.sum()),
                "N_called": int(called.sum()),
                "N_fixed_supervised": int((pd.to_numeric(pred["fixed_pro_lab"]) != -1).sum()),
            }
        )

    count_check = metrics_wide.groupby(
        strata + ["evaluation_subset"], dropna=False
    )["method"].agg(list)
    for key, method_values in count_check.items():
        if set(method_values) != set(METHODS) or len(method_values) != 5:
            raise ValueError(f"Metrics stratum {key} lacks the five required methods")

    # For pre-defined fixed subsets every method must use the same denominator.
    fixed = metrics_wide[metrics_wide["evaluation_subset"].isin(FIXED_SUBSETS)]
    denominators = fixed.groupby(
        strata + ["evaluation_subset"], dropna=False
    )["N_evaluated"].nunique()
    if (denominators != 1).any():
        raise ValueError("At least one fixed evaluation subset has unequal denominators")

    id_columns = [
        "run_id",
        "data_index",
        "dataset",
        "acquisition",
        "platform",
        "dea_method",
        "method",
        "variant",
        "model_input_views",
        "label_mode",
        "evaluation_subset",
        "test_type",
        "seed",
        "N_evaluated",
        "N_true_DEP",
        "N_true_nonDEP",
        "N_selected_view_available",
        "tn",
        "fp",
        "fn",
        "tp",
        "label_fingerprint",
    ]
    metric_columns = [column for column in METRICS if column in metrics_wide.columns]
    metrics_long = metrics_wide.melt(
        id_vars=[column for column in id_columns if column in metrics_wide.columns],
        value_vars=metric_columns,
        var_name="metric",
        value_name="value",
    )

    pair_source = metrics_long[
        metrics_long["evaluation_subset"].isin(FIXED_SUBSETS)
    ].copy()
    # Keep the 28 platform x DEA strata as a descriptive sensitivity analysis,
    # but do not treat them as 28 independent biological datasets.  The primary
    # paired inference first averages the four configurations within each of the
    # seven DIA data indices and therefore has n=7 independent pairs.
    stratum_pair_keys = [
        "data_index",
        "dataset",
        "platform",
        "dea_method",
        "label_mode",
        "evaluation_subset",
        "seed",
        "metric",
    ]
    full = pair_source[pair_source["method"] == "full_mcp"][
        stratum_pair_keys + ["value", "N_evaluated"]
    ].rename(columns={"value": "full_mcp_value", "N_evaluated": "full_N"})
    singles = pair_source[pair_source["method"] != "full_mcp"][
        stratum_pair_keys + ["method", "value", "N_evaluated"]
    ].rename(columns={"value": "single_view_value", "N_evaluated": "single_N"})
    paired_stratum = singles.merge(
        full, on=stratum_pair_keys, how="inner", validate="many_to_one"
    )
    if len(paired_stratum) != len(singles):
        raise ValueError("Not all single-view results have a paired full MCP control")
    if (paired_stratum["single_N"] != paired_stratum["full_N"]).any():
        raise ValueError("Paired fixed-subset comparisons have unequal protein counts")
    paired_stratum["delta_single_minus_full"] = (
        pd.to_numeric(paired_stratum["single_view_value"], errors="coerce")
        - pd.to_numeric(paired_stratum["full_mcp_value"], errors="coerce")
    )

    dataset_group_keys = [
        "data_index",
        "method",
        "label_mode",
        "evaluation_subset",
        "seed",
        "metric",
    ]
    dataset_values = (
        pair_source.groupby(dataset_group_keys, dropna=False, as_index=False)
        .agg(
            value=("value", "mean"),
            N_configurations=("value", lambda x: int(x.notna().sum())),
            N_total_configurations=("value", "size"),
        )
    )
    if set(dataset_values["N_total_configurations"].astype(int)) != {4}:
        raise ValueError(
            "Each data_index/method/subset/metric must contain exactly "
            "2 platforms x 2 DEA configurations"
        )
    # Never average only the successful/non-NA subset of the four configurations.
    # A dataset-level metric is eligible for inference only when all 2x2
    # platform/DEA values are finite. Sensitivity subsets therefore report their
    # actual complete-case dataset count rather than being mislabeled as n=7.
    dataset_values.loc[
        dataset_values["N_configurations"].astype(int) != 4, "value"
    ] = np.nan
    dataset_values["complete_four_configurations"] = (
        dataset_values["N_configurations"].astype(int) == 4
    )
    dataset_values["dataset_unit"] = (
        "DIA_index_" + dataset_values["data_index"].astype(int).astype(str)
    )

    dataset_pair_keys = [
        "data_index",
        "label_mode",
        "evaluation_subset",
        "seed",
        "metric",
    ]
    dataset_full = dataset_values[dataset_values["method"] == "full_mcp"][
        dataset_pair_keys + ["value", "N_configurations"]
    ].rename(
        columns={
            "value": "full_mcp_value",
            "N_configurations": "full_N_configurations",
        }
    )
    dataset_singles = dataset_values[dataset_values["method"] != "full_mcp"][
        dataset_pair_keys + ["method", "value", "N_configurations"]
    ].rename(
        columns={
            "value": "single_view_value",
            "N_configurations": "single_N_configurations",
        }
    )
    paired = dataset_singles.merge(
        dataset_full, on=dataset_pair_keys, how="inner", validate="many_to_one"
    )
    if len(paired) != len(dataset_singles):
        raise ValueError("Not all dataset-level single-view results have a full MCP pair")
    paired["dataset_unit"] = "DIA_index_" + paired["data_index"].astype(int).astype(str)
    paired["delta_single_minus_full"] = (
        pd.to_numeric(paired["single_view_value"], errors="coerce")
        - pd.to_numeric(paired["full_mcp_value"], errors="coerce")
    )

    summary_rows: list[dict[str, Any]] = []
    summary_groups = ["method", "label_mode", "evaluation_subset", "metric"]
    for key, group in paired.groupby(summary_groups, dropna=False):
        delta = group["delta_single_minus_full"].dropna().astype(float).to_numpy()
        pvalue = _exact_signed_rank_p(delta) if len(delta) else np.nan
        summary_rows.append(
            {
                **dict(zip(summary_groups, key)),
                "N_paired_datasets": len(delta),
                "mean_delta_single_minus_full": float(np.mean(delta)) if len(delta) else np.nan,
                "median_delta_single_minus_full": float(np.median(delta)) if len(delta) else np.nan,
                "N_single_better": int(np.sum(delta > 0)),
                "N_equal": int(np.sum(delta == 0)),
                "N_full_better": int(np.sum(delta < 0)),
                "wilcoxon_p": pvalue,
            }
        )
    summary = _adjust_pvalues(pd.DataFrame(summary_rows))
    primary_check = summary[
        (summary["evaluation_subset"] == "all_four_view_union")
        & (summary["metric"].isin({"mcc", "auroc", "auprc"}))
    ]
    if len(primary_check) != 12 or not (
        primary_check["N_paired_datasets"].astype(int) == 7
    ).all():
        raise ValueError(
            "Primary union MCC/AUROC/AUPRC must have seven complete data-index pairs "
            "for each of four single-view models"
        )

    ledger.to_csv(output_dir / "merged_core_run_ledger.csv", index=False)
    prediction_manifest.to_csv(output_dir / "merged_prediction_manifest.csv", index=False)
    metrics_wide.to_csv(output_dir / "merged_metrics_wide.csv", index=False)
    metrics_long.to_csv(output_dir / "merged_metrics_long.csv", index=False)
    pd.DataFrame(prediction_qc_rows).to_csv(output_dir / "prediction_qc.csv", index=False)
    paired_stratum.to_csv(output_dir / "paired_stratum_descriptive.csv", index=False)
    dataset_values.to_csv(output_dir / "dataset_aggregated_metrics_long.csv", index=False)
    paired.to_csv(output_dir / "paired_single_vs_full.csv", index=False)
    summary.to_csv(output_dir / "summary_single_vs_full.csv", index=False)
    qc = {
        "status": "passed",
        "expected_runs": 140,
        "observed_runs": len(ledger),
        "observed_strata": len(protein_fingerprints),
        "expected_strata": 28,
        "independent_statistical_unit": "data_index",
        "N_independent_datasets": 7,
        "platform_x_dea_strata_use": "descriptive sensitivity analysis only",
        "dataset_aggregation": "equal mean of four finite platform x DEA configurations",
        "incomplete_configuration_policy": "dataset metric excluded; actual n reported per test",
        "paired_test": (
            "exact two-sided sign-flip Wilcoxon signed-rank; zeros removed; "
            "average ranks for ties; all 2^m signs enumerated"
        ),
        "test_type": "DP_fdr",
        "label_mode": "strict_shared_mask",
        "primary_universe": "all_four_view_union",
        "missing_output_policy": "selected_view_noncall",
        "pseudo_label_excluded_subset_is_held_out": False,
        "note": (
            "Pseudo-label-excluded proteins did not enter classification loss, "
            "but did enter autoencoder reconstruction; call this transductive sensitivity analysis."
        ),
    }
    if qc["observed_strata"] != qc["expected_strata"]:
        raise ValueError(f"Expected 28 strata, observed {qc['observed_strata']}")
    (output_dir / "merge_qc.json").write_text(
        json.dumps(qc, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    return qc


def main() -> None:
    project = Path(__file__).resolve().parent
    default_base = project / "revision_results" / "final_required" / "fixed4label_single_view_ablation"
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--shards-root", type=Path, default=default_base / "shards")
    parser.add_argument("--output-dir", type=Path, default=default_base / "merged")
    args = parser.parse_args()
    print(json.dumps(merge_shards(args.shards_root, args.output_dir), indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
