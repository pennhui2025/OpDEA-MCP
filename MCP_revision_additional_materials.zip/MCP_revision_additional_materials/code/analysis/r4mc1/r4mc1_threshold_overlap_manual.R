# Reviewer 4 Major comment 1: final FC and statistical FDR sensitivity.
# source() ONLY defines functions. Manually run: ans <- run_r4mc1()
# 不重新训练；不改变伪标签；ROTS 原生 FDR 不再 BH 校正。
# Original full-view benchmark: 4 DIA views or 5 DDA views. All available runs,
# not a best-performing view selection. MCP's saved model threshold stays fixed.

run_r4mc1 <- function(
  inventory = "inputs/nc/common_union_audit/metrics_common_union.csv",
  helper = "code/analysis/r2c1/MCP_r2c1_ranking_threshold_manual.R",
  out = "reference/Response/r4mc1/manual_R_check",
  write_files = TRUE
) {
  h <- new.env(parent=globalenv()); sys.source(helper, envir=h); h$r2c1_selftest()
  original <- read.csv(inventory, check.names=FALSE, stringsAsFactors=FALSE)
  full <- original$model == "MVIDIA" & original$in_original_fig2 == "True" &
    ((original$acquisition == "DIA" & original$n_views == 4) |
     (original$acquisition == "DDA" & original$n_views == 5))
  m <- original[full & original$method == "MCP", , drop=FALSE]
  stopifnot(nrow(m)==71L, length(unique(m$dataset))==18L,
            !anyDuplicated(m[c("dataset","platform","dea")]))
  fc_grid <- c(1,1.2,1.5) # 1 = no FINAL magnitude exclusion, not |log2FC| >= 1
  q_grid <- c(.01,.05,.10) # Native statistical q/FDR; NOT MCP classifier scores
  per <- list(); overlap <- list(); manifest <- list()
  metric <- function(call,y) {
    tp<-as.double(sum(call & y==1)); fp<-as.double(sum(call & y==0))
    tn<-as.double(sum(!call & y==0)); fn<-as.double(sum(!call & y==1))
    den<-sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn)) # doubles prevent integer overflow
    # Zero-discovery convention matches the corrected Fig2 collector.
    c(precision=if(tp+fp>0)tp/(tp+fp) else 0,recall=tp/(tp+fn),
      MCC=if(den>0)(tp*tn-fp*fn)/den else 0,
      F1=if(2*tp+fp+fn>0)2*tp/(2*tp+fp+fn) else NA_real_,
      empirical_FDP=fp/max(tp+fp,1),
      TP=tp,FP=fp,TN=tn,FN=fn,n_called=tp+fp,n_union=length(y))
  }
  safe_div <- function(a,b) if(b>0)a/b else NA_real_
  lfc_num <- function(x) {
    z<-suppressWarnings(as.numeric(x)); if(anyNA(z))stop("Missing/non-numeric log2FC")
    # Archived log-ratios can be +/-Inf (zero group abundance). Preserve the
    # original rule: abs(Inf) passes a finite cutoff. Do not replace Inf by zero.
    z
  }
  for(i in seq_len(nrow(m))) {
    d <- read.csv(m$source_file[i],check.names=TRUE,stringsAsFactors=FALSE)
    ids <- d$Protein; h$r2c1_unique(ids,"baseline protein union")
    y <- h$r2c1_num(d$True_lab,"ground truth"); stopifnot(all(y %in% 0:1))
    raw<-d[!is.na(d$Protein.4) & nzchar(d$Protein.4),c("Protein.4","Probability.3","ori_logFC.3")]
    h$r2c1_unique(raw$Protein.4,"MCP proteins"); stopifnot(all(raw$Protein.4 %in% ids))
    b<-data.frame(score=rep(0,length(ids)),lfc=0,observed=FALSE)
    idx<-match(raw$Protein.4,ids); b$score[idx]<-h$r2c1_num(raw$Probability.3,"MCP scores")
    b$lfc[idx]<-lfc_num(raw$ori_logFC.3); b$observed[idx]<-TRUE
    threshold <- h$r2c1_threshold(d$threshold.3[!is.na(d$Protein.4) & nzchar(d$Protein.4)],"MCP threshold")
    blocks <- list(MCP=b)
    views <- strsplit(m$view_names[i],"+",fixed=TRUE)[[1]]
    for(v in c(views,"_hurdle")) {
      name <- if(v=="_hurdle")"Hurdle" else v
      blocks[[name]] <- data.frame(score=h$r2c1_num(d[[paste0("score_DP",v)]],v),
        lfc=lfc_num(d[[paste0("logFC_DP",v)]]),observed=TRUE)
    }
    ranks <- lapply(blocks,function(z)h$r2c1_roc(z$score,y))
    info <- m[i,c("dataset","acquisition","platform","dea","combination"),drop=FALSE]
    for(fc in fc_grid) {
      mcp_call <- b$observed & b$score>=threshold & abs(b$lfc)>=log2(fc)
      for(q in q_grid) {
        for(method in names(blocks)) {
          z <- blocks[[method]]
          call <- if(method=="MCP") mcp_call else
            z$observed & (1-z$score)<=q & abs(z$lfc)>=log2(fc)
          per[[length(per)+1L]] <- cbind(info,method=method,fc_ratio=fc,
            statistical_FDR_cutoff=q,MCP_score_threshold=threshold,
            as.data.frame(as.list(c(metric(call,y),ranks[[method]]))))
          if(method!="MCP") {
            both <- mcp_call & call; only_m <- mcp_call & !call
            only_b <- !mcp_call & call; either <- mcp_call | call
            vals <- c(MCP_calls=sum(mcp_call),baseline_calls=sum(call),
              overlap=sum(both),MCP_only=sum(only_m),baseline_only=sum(only_b),
              call_union=sum(either),Jaccard=safe_div(sum(both),sum(either)),
              fraction_MCP_shared=safe_div(sum(both),sum(mcp_call)),
              fraction_baseline_shared=safe_div(sum(both),sum(call)),
              MCP_only_TP=sum(only_m & y==1),MCP_only_FP=sum(only_m & y==0),
              MCP_only_precision=safe_div(sum(only_m & y==1),sum(only_m)),
              baseline_only_TP=sum(only_b & y==1),baseline_only_FP=sum(only_b & y==0),
              baseline_only_precision=safe_div(sum(only_b & y==1),sum(only_b)),
              overlap_TP=sum(both & y==1),overlap_FP=sum(both & y==0))
            overlap[[length(overlap)+1L]]<-cbind(info,baseline=method,fc_ratio=fc,
              statistical_FDR_cutoff=q,as.data.frame(as.list(vals)))
          }
        }
      }
    }
    # Verify original FC1.5/FDR.05 confusion counts against corrected Fig2 audit.
    check <- do.call(rbind,tail(per,length(blocks)))
    # Last grid point uses q=.10, so explicitly reconstruct the original criterion.
    for(method in names(blocks)) {
      z<-blocks[[method]]; call<-z$observed & abs(z$lfc)>=log2(1.5) &
        (if(method=="MCP") z$score>=threshold else (1-z$score)<=.05)
      saved<-original[full & original$source_file==m$source_file[i] &
        original$method==if(method=="Hurdle")"hurdle" else method,,drop=FALSE]
      stopifnot(nrow(saved)==1L)
      now<-metric(call,y)
      stopifnot(all(now[c("TP","FP","TN","FN")]==unlist(saved[c("tp","fp","tn","fn")],use.names=FALSE)))
      stopifnot(max(abs(now[c("precision","recall","MCC","F1")]-unlist(saved[c("Prec","Rec","Mcc","F1")],use.names=FALSE)))<1e-10)
    }
    manifest[[i]] <- cbind(info,view_names=m$view_names[i],
      source_file=m$source_file[i],file_md5=unname(tools::md5sum(m$source_file[i])),
      n_union=length(y),n_positive=sum(y==1),MCP_score_threshold=threshold)
    if(i%%10L==0L)message("Read ",i,"/",nrow(m)," raw benchmark files")
  }
  per<-do.call(rbind,per); overlap<-do.call(rbind,overlap)
  median_summary <- function(d,keys,values) {
    groups<-split(seq_len(nrow(d)),interaction(d[keys],drop=TRUE,lex.order=TRUE))
    do.call(rbind,lapply(groups,function(idx){
      z<-d[idx,,drop=FALSE]
      med<-vapply(z[values],function(x)if(all(is.na(x)))NA_real_ else median(x,na.rm=TRUE),numeric(1))
      counts<-vapply(z[values],function(x)sum(!is.na(x)),integer(1))
      names(counts)<-paste0("n_defined_",names(counts))
      cbind(z[1,keys,drop=FALSE],n_records=nrow(z),as.data.frame(as.list(med)),as.data.frame(as.list(counts)))
    }))
  }
  pkeys<-c("platform","method","fc_ratio","statistical_FDR_cutoff")
  okeys<-c("platform","baseline","fc_ratio","statistical_FDR_cutoff")
  pvals<-c("precision","recall","MCC","F1","empirical_FDP","TP","FP","TN","FN","n_called","n_union",names(ranks[[1]]))
  ovals<-setdiff(names(overlap),c(names(info),"baseline","fc_ratio","statistical_FDR_cutoff"))
  ans<-list(per_run=per,overlap_per_run=overlap,
    platform_medians=median_summary(per,pkeys,pvals),
    DEA_medians=median_summary(per,c("dea",pkeys),pvals),
    overlap_medians=median_summary(overlap,okeys,ovals),
    overlap_DEA_medians=median_summary(overlap,c("dea",okeys),ovals),
    source_manifest=do.call(rbind,manifest))
  if(write_files){dir.create(out,recursive=TRUE,showWarnings=FALSE)
    for(n in names(ans))write.csv(ans[[n]],file.path(out,paste0(n,".csv")),row.names=FALSE,na="")}
  message("Validated original confusion counts for all 71 full-view runs. ",
          nrow(per)," method-grid rows; ",nrow(overlap)," overlap-grid rows.")
  invisible(ans)
}

# Manual plotting after ans <- run_r4mc1(). ggplot2 only needed here.
plot_r4mc1 <- function(ans, out=NULL) {
  if(!requireNamespace("ggplot2",quietly=TRUE))stop("Please install ggplot2 to draw plots")
  d<-ans$overlap_medians
  d<-d[d$baseline %in% c("dlfq","Hurdle"),,drop=FALSE]
  d$final_FC<-factor(d$fc_ratio,levels=c(1,1.2,1.5),labels=c("None","1.2-fold","1.5-fold"))
  p<-ggplot2::ggplot(d,ggplot2::aes(x=final_FC,y=Jaccard,
    colour=factor(statistical_FDR_cutoff),group=factor(statistical_FDR_cutoff)))+
    ggplot2::geom_line()+ggplot2::geom_point(size=2)+
    ggplot2::facet_grid(platform~baseline)+ggplot2::theme_bw(base_size=11)+
    ggplot2::labs(x="Final fold-change filter",y="Median DEP Jaccard overlap with MCP",colour="Statistical FDR cutoff")+
    ggplot2::scale_colour_manual(values=c("#0072B2","#009E73","#D55E00"))
  print(p)
  if(!is.null(out))ggplot2::ggsave(out,p,width=7.5,height=8)
  invisible(p)
}

# Independently inspect nominal spike-in ratios using ARCHIVED sample designs.
# IMPORTANT: metadata test_contrs contains unused candidates. Do not use it to
# infer the tested contrast. Each saved benchmark run has exactly two conditions.
# Counts here are design entries (contrast x spiked species), NOT proteins.
# Use after ans <- run_r4mc1(): nominal <- read_r4mc1_nominal(ans$source_manifest)
read_r4mc1_nominal <- function(manifest,
  design_root="inputs/n/codes/DEA/data/dataset_info") {
  all_rows<-list()
  for(acq in c("DIA","DDA")) {
    file<-if(acq=="DIA")"DIA_DIANN.txt" else "DDA_Frag.txt"
    peer<-if(acq=="DIA")"DIA_spt.txt" else "DDA_mq.txt"
    a<-read.delim(file.path(design_root,file),check.names=FALSE,stringsAsFactors=FALSE)
    b<-read.delim(file.path(design_root,peer),check.names=FALSE,stringsAsFactors=FALSE)
    a<-a[a$dataset %in% manifest$dataset,,drop=FALSE]
    for(i in seq_len(nrow(a))) {
      row<-a[i,,drop=FALSE]; p<-b[b$dataset==row$dataset,,drop=FALSE]
      stopifnot(nrow(p)==1,identical(row$trueDE,p$trueDE))
      f<-basename(gsub("\\\\","/",row$true_lgfc))
      mix<-read.delim(file.path(design_root,f),check.names=FALSE,stringsAsFactors=FALSE)
      runs<-manifest[manifest$dataset==row$dataset,,drop=FALSE]
      pairs<-character(nrow(runs))
      for(j in seq_len(nrow(runs))) {
        design_dir<-file.path(dirname(dirname(runs$source_file[j])),"dt")
        saved_design<-list.files(design_dir,full.names=TRUE,
          pattern=paste0("^",row$dataset,"_.*_design[.]tsv$"))
        stopifnot(length(saved_design)==1L) # Spectronaut uses the archived alias spt.
        des<-read.delim(saved_design,stringsAsFactors=FALSE)
        cond<-sort(unique(des$condition),decreasing=TRUE)
        stopifnot(length(cond)==2L)
        pairs[j]<-paste(cond,collapse="-")
      }
      stopifnot(length(unique(pairs))==1L)
      contrast<-pairs[1]; cond<-strsplit(contrast,"-",fixed=TRUE)[[1]]
        for(species in strsplit(row$trueDE,";",fixed=TRUE)[[1]]) {
          numerator<-mix[mix$condition==cond[1],species]
          denominator<-mix[mix$condition==cond[2],species]
          stopifnot(length(numerator)==1,length(denominator)==1,numerator>0,denominator>0)
          ratio<-numerator/denominator; magnitude<-max(ratio,1/ratio)
          all_rows[[length(all_rows)+1L]]<-data.frame(acquisition=acq,dataset=row$dataset,
            source_accession=row$ID,contrast=contrast,species=species,
            numerator_amount=numerator,denominator_amount=denominator,
            directional_ratio=ratio,nominal_abs_fc=magnitude,
            below_1_5=magnitude<1.5-1e-12,mixture_source=f)
        }
    }
  }
  result<-do.call(rbind,all_rows)
  stopifnot(nrow(result)==24L,length(unique(result$dataset))==18L,
            !any(result$below_1_5),min(result$nominal_abs_fc)==1.5,max(result$nominal_abs_fc)==20)
  result
}
