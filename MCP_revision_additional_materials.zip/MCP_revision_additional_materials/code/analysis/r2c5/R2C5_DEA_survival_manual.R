# R2C5: standard limma ranking versus MCP candidate selection.
# RStudio: edit package_dir if necessary, then run section by section.
# Only base R and survival are required. No packages are installed automatically.
# Selection uses CRC plasma DEA only, NEVER the CPTAC survival outcome.
package_dir <- 'reference/Response/r2c5'
args <- commandArgs(trailingOnly=TRUE)
# Package runner selects paths; CLI args are not interpreted here.
src <- file.path(package_dir, 'source_tables')
out <- 'reproduced/survival'
dir.create(out, recursive=TRUE, showWarnings=FALSE)
stopifnot(requireNamespace('survival', quietly=TRUE), dir.exists(src))
fc_cut <- log2(1.5)
views <- c('dlfq','maxlfq','top3','top1')
read_input <- function(f) read.csv(file.path(src,f), check.names=FALSE)
save_csv <- function(d,f) write.csv(d,file.path(out,f),row.names=FALSE,na='')

# 1. Reproduce the published candidate lists before examining survival.
a <- read_input('CRC_MCP_three_views.csv')
b <- read_input('CRC_four_view_DEA.csv')
# The archived file repeats MCP score headers. Match Fig4.R's read.table
# convention: .2 is the third, final MCP output, not a different algorithm.
names(a)<-make.names(names(a),unique=TRUE)
names(b)<-make.names(names(b),unique=TRUE)
stopifnot(identical(a$Protein,b$Protein),nrow(a)==1044,!anyDuplicated(a$Protein))
mapping <- read_input('CRC_UniProt_gene_mapping.csv')
stopifnot(identical(a$Protein,mapping$UNIPROT),!anyNA(mapping$SYMBOL))
calls <- data.frame(Protein=a$Protein)
rankings <- list()
for(v in views) {
  q <- b[[paste0(v,'_qval')]]; fc <- b[[paste0(v,'_logFC')]]
  calls[[v]] <- q<=.05 & abs(fc)>=fc_cut
  z <- data.frame(method=v,Protein=a$Protein,q=q,logFC=fc)
  # q ascending; ties resolved by accession, not by survival.
  z$rank_all <- order(order(z$q,z$Protein))
  z$rank_fc <- NA_integer_
  eligible <- which(is.finite(fc) & abs(fc)>=fc_cut & is.finite(q))
  ix <- eligible[order(q[eligible],a$Protein[eligible])]
  z$rank_fc[ix] <- seq_along(ix)
  rankings[[v]] <- z
}
calls$hurdle <- a$hurdle_qval<=.05 & abs(a$hurdle_logFC)>=fc_cut
calls$MCP <- a$MVcontrast_score.2>=max(a$MVcontrast_threshold.2) & abs(a$MVcontrast_logFC.2)>=fc_cut
calls$MCP_unique <- calls$MCP & rowSums(calls[views])==0
stopifnot(sum(calls$MCP)==69,sum(calls$MCP_unique)==19)
old_calls <- read.csv(file.path(src,'archived_CRC_calls.csv'),row.names=1,check.names=FALSE)
ix <- match(old_calls$protein,calls$Protein)
stopifnot(!anyNA(ix),all(as.matrix(calls[ix,c(views,'MCP')])==as.matrix(old_calls[c(views,'MCP')])))

# Primary contrast: all 69 original MCP calls vs top 69 in each single view.
# Top-ranked lists retain the FC rule but impose NO q-value cutoff.
# Top 19 matches the historical MCP-unique search budget as a sensitivity check.
# Native calls and matched-view hurdle are contextual controls, not equal-size lists.
sets <- list(MCP_native69=calls$Protein[calls$MCP],
             MCP_unique19=calls$Protein[calls$MCP_unique])
for(v in views) {
  z <- rankings[[v]]
  for(k in c(69,19)) sets[[paste0(v,'_top',k)]] <- z$Protein[!is.na(z$rank_fc) & z$rank_fc<=k]
  sets[[paste0(v,'_native')]] <- calls$Protein[calls[[v]]]
}
sets$hurdle_native <- calls$Protein[calls$hurdle]
stopifnot(all(lengths(sets[grepl('_top69',names(sets))])==69),
          all(lengths(sets[grepl('_top19',names(sets))])==19))
membership <- do.call(rbind,lapply(names(sets),function(nm)
  data.frame(candidate_set=nm,Protein=sets[[nm]],stringsAsFactors=FALSE)))
membership$SYMBOL <- mapping$SYMBOL[match(membership$Protein,mapping$UNIPROT)]
save_csv(membership,'candidate_sets_frozen.csv')
save_csv(do.call(rbind,rankings),'all_single_view_rankings.csv')
save_csv(calls,'native_calls.csv')
vsig <- do.call(rbind,lapply(rankings,function(z)z[z$Protein=='Q9Y279',]))
vsig$called_DEP <- vapply(views,function(v) calls[[v]][calls$Protein=='Q9Y279'],logical(1))
vsig$in_top19 <- vsig$rank_fc<=19;vsig$in_top69 <- vsig$rank_fc<=69
save_csv(vsig,'VSIG4_DEA_ranks.csv')

# 2. Keep original clinical event indicators, including the last observed death.
clinical <- read_input('CPTAC_clinical_original.csv')
clinical <- clinical[complete.cases(clinical) & clinical$OS_time>0,]
stopifnot(!anyDuplicated(clinical$Sample_ID),all(clinical$OS_status %in% 0:1))
abundance <- read_input('CPTAC_native_gene_columns.csv')
names(abundance)[1] <- 'Sample_ID'
stopifnot(!anyDuplicated(abundance$Sample_ID))
clinical <- clinical[clinical$Sample_ID %in% abundance$Sample_ID,]
abundance <- abundance[match(clinical$Sample_ID,abundance$Sample_ID),,drop=FALSE]
stopifnot(nrow(clinical)==97,sum(clinical$OS_status)==7)
save_csv(clinical,'clinical_original_status_used.csv')

# Exact gene symbols only. If CPTAC has several protein columns for a gene,
# take the per-patient median of native values. Do not select the best column.
# Missing cohort measurements do not trigger replacement by the next DEA rank.
genes <- sort(unique(membership$SYMBOL))
fit_one <- function(gene) {
  j <- which(names(abundance)==gene)
  z <- data.frame(SYMBOL=gene,CPTAC_columns=length(j),N=NA_integer_,Events=NA_integer_,
    HR=NA_real_,CI_lower=NA_real_,CI_upper=NA_real_,Cox_Wald_p=NA_real_,
    Cox_PH_p=NA_real_,N_low=NA_integer_,N_high=NA_integer_,Events_low=NA_integer_,
    Events_high=NA_integer_,Log_rank_p=NA_real_,Status='Absent from CPTAC',Warning='')
  if(!length(j)) return(z)
  x <- as.matrix(abundance[,j,drop=FALSE]); storage.mode(x) <- 'double'
  x <- apply(x,1,function(v)if(all(!is.finite(v))) NA_real_ else median(v[is.finite(v)]))
  dd <- cbind(clinical,expression=x);dd <- dd[is.finite(dd$expression),]
  z$N<-nrow(dd);z$Events<-sum(dd$OS_status)
  if(nrow(dd)<10) {z$Status<-'Fewer than 10 complete cases';return(z)}
  if(length(unique(dd$expression))<2) {z$Status<-'Constant abundance';return(z)}
  dd$group<-factor(ifelse(dd$expression>median(dd$expression),'High','Low'),levels=c('Low','High'))
  z$N_low<-sum(dd$group=='Low');z$N_high<-sum(dd$group=='High')
  z$Events_low<-sum(dd$OS_status[dd$group=='Low']);z$Events_high<-sum(dd$OS_status[dd$group=='High'])
  if(z$Events==0) {z$Status<-'No observed events';return(z)}
  warns<-character()
  model<-tryCatch(withCallingHandlers(
    survival::coxph(survival::Surv(OS_time,OS_status)~expression,data=dd,ties='efron'),
    warning=function(w){warns<<-c(warns,conditionMessage(w));invokeRestart('muffleWarning')}),error=function(e)e)
  if(!inherits(model,'error')) {
    ss<-summary(model)
    z$HR<-ss$conf.int[1,'exp(coef)'];z$CI_lower<-ss$conf.int[1,'lower .95'];z$CI_upper<-ss$conf.int[1,'upper .95']
    z$Cox_Wald_p<-ss$coefficients[1,'Pr(>|z|)'];z$Status<-'Cox estimated'
    z$Cox_PH_p<-tryCatch(survival::cox.zph(model)$table[1,'p'],error=function(e)NA_real_)
  } else {z$Status<-'Cox failed';warns<-c(warns,conditionMessage(model))}
  if(any(grepl('did not converge|infinite|iterations',warns,ignore.case=TRUE)) ||
     !is.finite(z$Cox_Wald_p) || !is.finite(z$CI_upper)) {
    z$Status<-'Cox nonconvergent or non-estimable'
    z[c('HR','CI_lower','CI_upper','Cox_Wald_p','Cox_PH_p')]<-NA_real_
  }
  if(z$N_low>0 && z$N_high>0) {
    lr<-tryCatch(survival::survdiff(survival::Surv(OS_time,OS_status)~group,data=dd),error=function(e)NULL)
    if(!is.null(lr) && is.finite(lr$chisq)) z$Log_rank_p<-pchisq(lr$chisq,1,lower.tail=FALSE)
  }
  z$Warning<-paste(warns,collapse='; ')
  z
}
survival_results<-do.call(rbind,lapply(genes,fit_one))

# 3. Cox and log-rank are separate correction families, not two chances to win.
# Primary: Cox. Log-rank is secondary, using a fixed median split.
# Untestable candidates remain missing; planned tests still count in n.
adjust_n<-function(p,n) {v<-rep(NA_real_,length(p));ok<-is.finite(p);v[ok]<-p.adjust(p[ok],'BH',n=n);v}
# Cross-list family = 148 distinct genes across ALL reported sets, including
# native-call and hurdle sets; not just the primary five 69-protein panels.
survival_results$Cox_BH_q_global<-adjust_n(survival_results$Cox_Wald_p,length(genes))
survival_results$Log_rank_BH_q_global<-adjust_n(survival_results$Log_rank_p,length(genes))
save_csv(survival_results,'all_candidate_gene_survival.csv')
details<-list();summary_rows<-list()
for(nm in names(sets)) {
  m<-membership[membership$candidate_set==nm,]
  # Deduplicate genes for fitting/counting; keep protein budget for correction.
  m<-m[!duplicated(m$SYMBOL),]
  r<-survival_results[match(m$SYMBOL,survival_results$SYMBOL),]
  n_planned<-length(sets[[nm]])
  r$Cox_BH_q_family<-adjust_n(r$Cox_Wald_p,n_planned)
  r$Log_rank_BH_q_family<-adjust_n(r$Log_rank_p,n_planned)
  details[[nm]]<-cbind(candidate_set=nm,Protein=m$Protein,r)
  summary_rows[[nm]]<-data.frame(candidate_set=nm,Planned_proteins=n_planned,Unique_genes=nrow(r),
    CPTAC_available=sum(r$CPTAC_columns>0),Cox_estimable=sum(is.finite(r$Cox_Wald_p)),
    Cox_nominal_p_lt_005=sum(r$Cox_Wald_p<.05,na.rm=TRUE),Cox_BH_q_lt_005=sum(r$Cox_BH_q_family<.05,na.rm=TRUE),
    Cox_global_BH_q_lt_005=sum(r$Cox_BH_q_global<.05,na.rm=TRUE),
    Logrank_estimable=sum(is.finite(r$Log_rank_p)),Logrank_nominal_p_lt_005=sum(r$Log_rank_p<.05,na.rm=TRUE),
    Logrank_BH_q_lt_005=sum(r$Log_rank_BH_q_family<.05,na.rm=TRUE),
    Logrank_global_BH_q_lt_005=sum(r$Log_rank_BH_q_global<.05,na.rm=TRUE),VSIG4_included='VSIG4' %in% r$SYMBOL)
}
detail<-do.call(rbind,details);summary_table<-do.call(rbind,summary_rows)
save_csv(detail,'survival_by_candidate_set.csv');save_csv(summary_table,'candidate_set_summary.csv')

# 4. Existing R1C10 results must be reproduced, not silently changed.
reference<-read_input('R1C10_survival_reference.csv')
rr<-detail[detail$candidate_set=='MCP_unique19',]
ref<-reference[match(rr$SYMBOL,reference$SYMBOL),]
for(col in c('N','Events','HR','CI_lower','CI_upper','Cox_Wald_p','Log_rank_p')) {
  stopifnot(identical(is.na(rr[[col]]),is.na(ref[[col]])))
  ok<-is.finite(rr[[col]]) & is.finite(ref[[col]])
  stopifnot(max(c(0,abs(rr[[col]][ok]-ref[[col]][ok])))<1e-7)
}
stopifnot(sum(is.finite(rr$Cox_Wald_p))==11,sum(is.finite(rr$Log_rank_p))==12)
capture.output(sessionInfo(),file=file.path(out,'R_sessionInfo.txt'))
cat('\nCandidate selection summaries (counts are descriptive, not a method superiority test)\n')
print(summary_table,row.names=FALSE)
cat('\nVSIG4 ordinary DEA rankings after the common FC filter\n');print(vsig,row.names=FALSE)
cat('\nFinished. R1C10 survival estimates were reproduced.\n')
