# R1C8 | 推荐模型：手动检查原始 nested-CV 结果及训练记录组成。
# source() 只定义函数，不自动分析、不训练模型、不写文件。仅需 base R。
# 输入是原始程序保存的 36 个完整精度 Spearman rho，不是手工抄写图中数值。
# 没有逐候选组合的 outer-fold 预测，因此本脚本不重新计算 rho、不计算 regret，
# 不构成新增/外部验证。pAUC 属于蛋白分类任务，不能替代推荐模型的 Spearman。

read_original_correlations <- function(csv_file) {
  d <- read.csv(csv_file, stringsAsFactors = FALSE, check.names = FALSE)
  stopifnot(all(c("dataset", "Spearman") %in% names(d)), nrow(d) == 36)
  stopifnot(!anyDuplicated(d$dataset), !anyNA(d$Spearman), all(abs(d$Spearman) <= 1))
  platform <- sub("_[0-9]+$", "", d$dataset)
  platform[platform == "DIANN"] <- "DIA-NN"
  platform[platform == "Maxquant"] <- "MaxQuant"
  out <- data.frame(platform = platform, dataset_id = d$dataset,
                    spearman_rho = as.numeric(d$Spearman), stringsAsFactors = FALSE)
  platforms <- c("DIA-NN", "Spectronaut", "FragPipe", "MaxQuant")
  stopifnot(all(out$platform %in% platforms))
  out[order(match(out$platform, platforms), as.integer(sub("^.*_", "", out$dataset_id))), ]
}

summarize_correlations <- function(d) {
  platforms <- c("DIA-NN", "Spectronaut", "FragPipe", "MaxQuant")
  expected_n <- c(7L, 7L, 11L, 11L)
  out <- lapply(seq_along(platforms), function(i) {
    x <- d$spearman_rho[d$platform == platforms[i]]
    stopifnot(length(x) == expected_n[i], !anyNA(x))
    data.frame(platform = platforms[i], acquisition = if (i <= 2) "DIA" else "DDA",
      n_datasets = length(x), median_rho = median(x),
      # R type=7 与 Python/pandas 及 Excel QUARTILE.INC 一致。
      q1_rho = unname(quantile(x, .25, type = 7)),
      q3_rho = unname(quantile(x, .75, type = 7)),
      minimum_rho = min(x), maximum_rho = max(x),
      n_positive_rho = sum(x > 0), n_zero_rho = sum(x == 0),
      n_negative_rho = sum(x < 0), stringsAsFactors = FALSE)
  })
  do.call(rbind, out)
}

check_training_composition <- function(training_csv) {
  x <- read.csv(training_csv, stringsAsFactors = FALSE, check.names = FALSE)
  keys <- c("acq", "platform", "data_idx", "dea", "view_name")
  stopifnot(all(c(keys, "dt_perfom") %in% names(x)), nrow(x) == 1421)
  stopifnot(!anyDuplicated(x[keys]), all(x$dea %in% c("limma", "ROTS")))
  out <- do.call(rbind, lapply(c("DIA", "DDA"), function(acquisition) {
    z <- x[x$acq == acquisition, ]
    data.frame(acquisition = acquisition, n_training_rows = nrow(z),
      n_biological_datasets = length(unique(z$data_idx)),
      fraction_training_rows = nrow(z)/nrow(x))
  }))
  # 验证每个 DIA 平台 × 数据集有 22 行：11 视图组合 × limma/ROTS。
  dia <- x[x$acq == "DIA", ]
  stopifnot(all(table(dia$platform, dia$data_idx) == 22),
            all(table(dia$platform, dia$data_idx, dia$dea) == 11))
  out
}

# -------- 以下示例请在 RStudio 中手动逐行运行（去掉行首 #） --------
# source("code/analysis/r1c8/MCP_r1c8_recommendation_manual_check.R")
#
# # 首选：直接读取项目中的原始结果文件。
# original_dir <- "inputs/n/Supplementary_codes"
# corr_file <- file.path(original_dir, "res/combination_selection/res_all_exp_MCC_new_all08_MCC__nest_cv_all_res_shap3.csv")
# train_file <- file.path(original_dir, "train_feature.csv")
#
# # 如果移动了项目，可改用本包附带的原始文件副本（数值未改动）。
# work_dir <- "reference/Response/r1c8"
# corr_file <- file.path(work_dir, "data_inputs/original_nested_cv_correlations.csv")
# train_file <- file.path(work_dir, "data_inputs/original_train_feature.csv")
#
# d <- read_original_correlations(corr_file)
# print(d, row.names = FALSE, digits = 7)  # 全部 36 个 rho
# summary_table <- summarize_correlations(d)
# print(summary_table, row.names = FALSE, digits = 7)
# composition <- check_training_composition(train_file)
# print(composition, row.names = FALSE, digits = 7)
#
# # 与已附汇总数据核对；原 Supplementary Table 2 只报告三位小数。
# supplied <- read.csv(file.path(work_dir, "r1c8_reported_dataset_correlations.csv"))
# idx <- match(d$dataset_id, supplied$dataset_id_as_reported)
# stopifnot(!anyNA(idx), all(abs(d$spearman_rho - supplied$spearman_rho[idx]) < 1e-12),
#   all(round(d$spearman_rho, 3) == supplied$spearman_rho_reported[idx]))
#
# # 自行决定是否保存，绝不覆盖原始 CSV/论文。
# write.csv(summary_table, file.path(work_dir, "my_checked_r1c8_summary.csv"), row.names = FALSE)
# write.csv(composition, file.path(work_dir, "my_checked_training_composition.csv"), row.names = FALSE)
