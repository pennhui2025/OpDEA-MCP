# Open in RStudio and run the final example manually. source() only defines functions.
# 与 Fig1 原口径一致：每个蛋白在两个视图的样本 profile 间算相关，
# 要求共同观测样本数 >80%（严格大于），再平均绝对相关系数。
# Pearson 和 Spearman 使用同一蛋白、同一对有效观测，不进行缺失值插补。
package_dir <- 'reference/Response/r4minor8'

run_correlations <- function(package_dir, max_groups=Inf, write_files=TRUE) {
  manifest <- read.csv(file.path(package_dir,'data/input_manifest.csv'),check.names=FALSE)
  key <- interaction(manifest$acquisition,manifest$platform,manifest$dataset,drop=TRUE)
  sets <- split(manifest,key)
  answer <- list()
  for (g in head(sets,max_groups)) {
    g <- g[match(c('dlfq','maxlfq','top0','top3','top1','count'),g$view,nomatch=0),]
    g <- g[nzchar(g$view),]
    x <- lapply(g$path,function(p) {
      m <- as.matrix(read.csv(p,header=FALSE,na.strings=c('nan','NA'),check.names=FALSE))
      storage.mode(m)<-'double';m[!is.finite(m)|m==0]<-NA_real_;m
    })
    stopifnot(length(unique(vapply(x,nrow,1L)))==1,length(unique(vapply(x,ncol,1L)))==1)
    pairs <- combn(seq_along(x),2,simplify=FALSE)
    calculated <- lapply(pairs,function(ij) {
      a<-x[[ij[1]]];b<-x[[ij[2]]]
      z<-t(vapply(seq_len(nrow(a)),function(k) {
        ok<-is.finite(a[k,])&is.finite(b[k,]);nn<-sum(ok)
        if(nn<=ncol(a)*.8 || sd(a[k,ok])==0 || sd(b[k,ok])==0)
          return(c(n=nn,Pearson=NA_real_,Spearman=NA_real_))
        c(n=nn,Pearson=cor(a[k,ok],b[k,ok],method='pearson'),
          Spearman=cor(a[k,ok],b[k,ok],method='spearman'))
      },c(n=0,Pearson=0,Spearman=0)))
      list(ij=ij,z=z,valid=is.finite(z[,'Pearson'])&is.finite(z[,'Spearman']))
    })
    common<-Reduce('&',lapply(calculated,`[[`,'valid'))
    for(q in calculated) {
      z<-q$z;ok<-q$valid;ij<-q$ij
      answer[[length(answer)+1]]<-data.frame(acquisition=g$acquisition[1],platform=g$platform[1],
        dataset=g$dataset[1],pair=paste(g$view[ij],collapse='_'),n_union=nrow(x[[1]]),n_samples=ncol(x[[1]]),
        min_paired_samples=floor(.8*ncol(x[[1]]))+1,n_coverage_eligible=sum(z[,'n']>.8*ncol(x[[1]])),
        n_proteins=sum(ok),n_common_all_pairs=sum(common),
        mean_abs_Pearson=mean(abs(z[ok,'Pearson'])),mean_abs_Spearman=mean(abs(z[ok,'Spearman'])),
        mean_signed_Pearson=mean(z[ok,'Pearson']),mean_signed_Spearman=mean(z[ok,'Spearman']),
        n_negative_Pearson=sum(z[ok,'Pearson']<0),
        mean_abs_Pearson_common=mean(abs(z[common,'Pearson'])),mean_abs_Spearman_common=mean(abs(z[common,'Spearman'])))
    }
    message(g$platform[1],': ',g$dataset[1])
  }
  d<-do.call(rbind,answer)
  # Check independently computed values against the delivered Python calculation.
  reference<-read.csv(file.path(package_dir,'data/correlations_by_dataset_pair.csv'))
  compare<-merge(d,reference,by=c('acquisition','platform','dataset','pair'),suffixes=c('_R','_reference'))
  stopifnot(nrow(compare)==nrow(d),all(compare$n_proteins_R==compare$n_proteins_reference),
    max(abs(compare$mean_abs_Pearson_R-compare$mean_abs_Pearson_reference))<1e-8,
    max(abs(compare$mean_abs_Spearman_R-compare$mean_abs_Spearman_reference))<1e-8)
  if(write_files) {
    out<-file.path(package_dir,'manual_check_results');dir.create(out,showWarnings=FALSE)
    write.csv(d,file.path(out,'correlations_by_dataset_pair_R.csv'),row.names=FALSE)
  }
  d
}

plot_correlations <- function(package_dir) {
  stopifnot(requireNamespace('ggplot2',quietly=TRUE))
  d<-read.csv(file.path(package_dir,'data/correlation_summary_by_platform_pair.csv'))
  long<-rbind(data.frame(d[c('platform','pair')],metric='Pearson',value=d$mean_abs_Pearson),
              data.frame(d[c('platform','pair')],metric='Spearman',value=d$mean_abs_Spearman))
  p<-ggplot2::ggplot(long,ggplot2::aes(pair,value,colour=metric,group=metric))+
    ggplot2::geom_point(position=ggplot2::position_dodge(.3),size=2)+
    ggplot2::facet_wrap(~platform,scales='free_x')+
    ggplot2::scale_colour_manual(values=c(Pearson='#0072B2',Spearman='#D55E00'))+
    ggplot2::labs(x=NULL,y='Mean absolute protein-profile correlation',colour=NULL)+
    ggplot2::theme_classic()+ggplot2::theme(axis.text.x=ggplot2::element_text(angle=45,hjust=1))
  print(p);p
}
# 手动运行示例：
# check <- run_correlations(package_dir)  # all 304 dataset-pair records
# p <- plot_correlations(package_dir)
