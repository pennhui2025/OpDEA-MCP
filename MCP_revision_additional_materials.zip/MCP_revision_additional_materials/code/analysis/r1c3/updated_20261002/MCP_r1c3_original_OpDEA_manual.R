# R1C3 original OpDEA comparison, verified 2026-10-02.
# Same validated calculations as R1C6; only the default output folder is changed.
# source() defines functions only. No training or package installation. Requires readxl.
# Read original protein-level OpDEA outputs, not the matched-view hurdle proxy.
# RStudio: x <- run_original_opdea(delivery="reference/Response/r1c6")
# Same protein union within each dataset/platform; absent predictions=score 0/non-DEP.
# Keep MCP-limma and MCP-ROTS separate. Original OpDEA is not duplicated by DEA.
# Each primary metric is a median across the same six matched datasets.
# Two-stage DEA/dataset medians are a separate sensitivity analysis only.

opdea_metrics <- function(y, score, called) {
  stopifnot(length(y)==length(score), length(y)==length(called),
            all(y %in% 0:1), all(is.finite(score)), !anyNA(called))
  tn<-as.double(sum(y==0 & !called)); fp<-as.double(sum(y==0 & called))
  fn<-as.double(sum(y==1 & !called)); tp<-as.double(sum(y==1 & called))
  den<-sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn))
  stopifnot(sum(y)>0, sum(1-y)>0)
  o<-order(-score); yy<-y[o]; ss<-score[o]
  last<-c(which(diff(ss)!=0),length(ss)); t<-cumsum(yy)[last]; f<-last-t
  tpr<-c(0,t/sum(y)); fpr<-c(0,f/sum(1-y))
  trap<-function(x,z) sum(diff(x)*(head(z,-1)+tail(z,-1))/2)
  pauc<-function(a) {
    i<-max(which(fpr<=a)); xx<-fpr[seq_len(i)]; zz<-tpr[seq_len(i)]
    if(tail(xx,1)<a) {
      zz<-c(zz,tpr[i]+(a-fpr[i])*(tpr[i+1]-tpr[i])/(fpr[i+1]-fpr[i])); xx<-c(xx,a)
    }
    .5*(1+(trap(xx,zz)-.5*a^2)/(a-.5*a^2))
  }
  c(n=length(y),tn=tn,fp=fp,fn=fn,tp=tp,
    precision=if(tp+fp==0) 0 else tp/(tp+fp),recall=tp/(tp+fn),
    mcc=if(den==0) 0 else (tp*tn-fp*fn)/den,
    f1=if(2*tp+fp+fn==0) 0 else 2*tp/(2*tp+fp+fn),
    pauc001=pauc(.01),pauc005=pauc(.05),pauc01=pauc(.1))
}

run_original_opdea <- function(
  delivery="reference/Response/r1c6",
  raw_root=file.path(delivery,"original_opdea_raw"),
  out="reference/Response/r1c3/updated_20261002/manual_recheck",
  rank_book="inputs/p/Supplementary Data 7.xlsx",
  write_files=TRUE) {
  stopifnot(requireNamespace("readxl",quietly=TRUE))
  metrics<-c("precision","recall","mcc","f1","pauc001","pauc005","pauc01")
  fc_cut<-log2(1.5)
  contrasts<-c(HYEtims735_DIA="conditionB-conditionA",MYtims709_DIA="conditionC-conditionA",
    HEof_n600_DIA="conditionE-conditionB",HEof_w600_DIA="conditionE-conditionB",
    HYtims134_DIA="conditionD-conditionB",HEqe777_DIA="conditionC-conditionA",
    HEqe408_DIA="conditionB-conditionA")
  read_checked<-function(p) {
    p<-normalizePath(p,winslash="/",mustWork=TRUE)
    if(.Platform$OS.type=="windows") p<-paste0("\\\\?\\",gsub("/","\\\\",p))
    read.csv(p,check.names=TRUE,stringsAsFactors=FALSE)
  }
  mf<-read_checked(file.path(delivery,"task1_input_manifest.csv"))
  mf<-mf[mf$method=="MCP_full_DP_fdr",]
  stopifnot(nrow(mf)==28,!anyDuplicated(mf[c("dataset","platform","dea")]))
  # Verify the historical ranking; do not select the best recalculated result.
  ranks<-list()
  for(platform in c("DIANN","Spectronaut")) {
    sheet<-if(platform=="DIANN") "rank_DIANN_DIA" else "rank_spt_DIA"
    d<-as.data.frame(readxl::read_excel(rank_book,sheet=sheet,skip=1))
    d$source_sheet_row<-seq_len(nrow(d))+2L
    d<-d[!is.na(d$workflow)&grepl("^ensemble_",d$workflow),]
    d$avg_rank_mean<-as.numeric(d$avg_rank_mean)
    stopifnot(all(is.finite(d$avg_rank_mean)))
    selected<-d[d$avg_rank_mean==min(d$avg_rank_mean),]
    stopifnot(nrow(selected)==1,selected$workflow=="ensemble_hurdle||LFQ|dlfq|top3")
    ranks[[platform]]<-data.frame(platform=platform,sheet=sheet,
      source_sheet_row=selected$source_sheet_row,workflow=selected$workflow,
      avg_rank_mean=selected$avg_rank_mean,
      selection="Historical same-benchmark global ensemble rank minimum; not independent validation")
  }
  rank_audit<-do.call(rbind,ranks)
  records<-coverage<-availability<-list()
  for(platform in c("DIANN","Spectronaut")) for(dataset in names(contrasts)) {
    rr<-mf[mf$platform==platform & mf$dataset==dataset,]
    stopifnot(nrow(rr)==2,setequal(rr$dea,c("limma","ROTS")))
    files<-list.files(file.path(raw_root,platform,dataset),full.names=TRUE)
    op<-list()
    for(choice in c("OpDEA_original_same4","OpDEA_original_historical_rank1")) {
      suffix<-if(choice=="OpDEA_original_same4") "_hurdle_LFQ-dlfq-top1-top3.csv" else "_hurdle_LFQ-dlfq-top3.csv"
      p<-files[endsWith(files,suffix)]; stopifnot(length(p)==1)
      z<-read_checked(p)
      stopifnot(all(c("protein","contrast","label","adj.pvalue","logFC") %in% names(z)))
      selected<-z[z$contrast==contrasts[[dataset]],]
      availability[[length(availability)+1L]]<-data.frame(dataset,platform,method=choice,
        target_contrast=contrasts[[dataset]],available_contrasts=paste(sort(unique(z$contrast)),collapse=";"),
        n_selected=nrow(selected),included=nrow(selected)>0,file=basename(p))
      op[[choice]]<-selected
    }
    # Do not substitute another contrast for the missing HEof_w600 E-B contrast.
    if(any(vapply(op,nrow,integer(1))==0)) next
    pred<-truths<-list()
    for(i in seq_len(nrow(rr))) {
      z<-read_checked(rr$prediction_file[i])
      u<-z[!is.na(z$Protein)&nzchar(z$Protein),c("Protein","True_lab")]
      stopifnot(!anyDuplicated(u$Protein),all(u$True_lab %in% 0:1))
      truths[[paste0("MCP_",rr$dea[i])]]<-u
      b<-z[!is.na(z$Protein.4)&nzchar(z$Protein.4),c("Protein.4","Probability.3","ori_logFC.3","threshold.3")]
      names(b)<-c("Protein","score","fc","threshold")
      stopifnot(!anyDuplicated(b$Protein),all(b$Protein %in% u$Protein),
                all(is.finite(as.matrix(b[c("score","fc","threshold")]))))
      b$called<-b$score>=b$threshold & abs(b$fc)>=fc_cut
      pred[[paste0("MCP_",rr$dea[i])]]<-b[c("Protein","score","called")]
    }
    mcp_equal<-setequal(truths[[1]]$Protein,truths[[2]]$Protein)
    for(choice in names(op)) {
      z<-op[[choice]]
      stopifnot(!anyDuplicated(z$protein),all(z$label %in% 0:1),
                all(is.finite(z$adj.pvalue)),all(z$adj.pvalue>=0 & z$adj.pvalue<=1),
                all(is.finite(z$logFC)))
      truths[[choice]]<-data.frame(Protein=z$protein,True_lab=as.integer(z$label))
      pred[[choice]]<-data.frame(Protein=z$protein,score=1-z$adj.pvalue,
        called=z$adj.pvalue<=.05 & abs(z$logFC)>=fc_cut)
    }
    # True outer union: retain OpDEA-only proteins and reevaluate MCP on that union.
    truth<-do.call(rbind,truths)
    labels<-split(truth$True_lab,truth$Protein)
    stopifnot(all(vapply(labels,function(x) length(unique(x))==1,logical(1))))
    truth<-truth[!duplicated(truth$Protein),]; rownames(truth)<-NULL
    mcp_ids<-union(truths[[1]]$Protein,truths[[2]]$Protein)
    for(method in names(pred)) {
      b<-pred[[method]]; ix<-match(truth$Protein,b$Protein); present<-!is.na(ix)
      score<-numeric(nrow(truth)); called<-rep(FALSE,nrow(truth))
      score[present]<-b$score[ix[present]]; called[present]<-b$called[ix[present]]
      val<-opdea_metrics(truth$True_lab,score,called)
      records[[length(records)+1L]]<-data.frame(dataset,platform,contrast=contrasts[[dataset]],
        method,as.list(val),check.names=FALSE)
      coverage[[length(coverage)+1L]]<-data.frame(dataset,platform,method,n_union=nrow(truth),
        n_method_output=nrow(b),n_missing=sum(!present),
        n_opdea_only_vs_mcp=sum(!truth$Protein %in% mcp_ids),
        mcp_candidate_sets_equal=mcp_equal,truth_mismatches=0)
    }
  }
  strata<-do.call(rbind,records); audit<-do.call(rbind,coverage); avail<-do.call(rbind,availability)
  stopifnot(nrow(strata)==48,length(unique(strata$dataset))==6)
  # Median each metric separately; never derive MCC from median TN/FP/FN/TP.
  tmp<-strata; tmp$method[grepl("^MCP_",tmp$method)]<-"MCP_DEA_median"
  dataset_values<-aggregate(tmp[metrics],tmp[c("dataset","platform","method")],median)
  counts<-aggregate(tmp$method,tmp[c("dataset","platform","method")],length)
  names(counts)[4]<-"n_source_runs"
  dataset_values<-merge(dataset_values,counts,by=c("dataset","platform","method"))
  summary<-aggregate(dataset_values[metrics],dataset_values[c("platform","method")],median)
  summary$n_datasets<-6L
  # Report limma and ROTS separately so their differences are not hidden.
  dea_summary<-aggregate(strata[metrics],strata[c("platform","method")],median)
  dea_summary$n_datasets<-6L
  baseline<-dataset_values[dataset_values$method=="MCP_DEA_median",]
  paired<-do.call(rbind,lapply(c("OpDEA_original_same4","OpDEA_original_historical_rank1"),function(cmp) {
    b<-dataset_values[dataset_values$method==cmp,]
    j<-merge(baseline,b,by=c("dataset","platform"),suffixes=c("_MCP","_OpDEA"))
    do.call(rbind,lapply(metrics,function(metric) data.frame(dataset=j$dataset,platform=j$platform,
      comparator=cmp,metric,MCP=j[[paste0(metric,"_MCP")]],OpDEA=j[[paste0(metric,"_OpDEA")]],
      difference=j[[paste0(metric,"_MCP")]]-j[[paste0(metric,"_OpDEA")]])))
  }))
  paired_summary<-do.call(rbind,lapply(split(paired,interaction(paired$platform,paired$comparator,paired$metric)),function(d) {
    data.frame(platform=d$platform[1],comparator=d$comparator[1],metric=d$metric[1],
      n_datasets=nrow(d),median_paired_difference=median(d$difference),
      MCP_higher=sum(d$difference>1e-12),tied=sum(abs(d$difference)<=1e-12),MCP_lower=sum(d$difference< -1e-12))
  }))
  primary_pairs<-do.call(rbind,lapply(c("MCP_limma","MCP_ROTS"),function(mcp_name) {
    do.call(rbind,lapply(c("OpDEA_original_same4","OpDEA_original_historical_rank1"),function(cmp) {
      j<-merge(strata[strata$method==mcp_name,],strata[strata$method==cmp,],
               by=c("dataset","platform","contrast"),suffixes=c("_MCP","_OpDEA"))
      do.call(rbind,lapply(metrics,function(metric) data.frame(dataset=j$dataset,platform=j$platform,
        MCP_variant=mcp_name,comparator=cmp,metric,MCP=j[[paste0(metric,"_MCP")]],
        OpDEA=j[[paste0(metric,"_OpDEA")]],difference=j[[paste0(metric,"_MCP")]]-j[[paste0(metric,"_OpDEA")]])))
    }))
  }))
  result<-list(original_opdea_platform_medians=dea_summary,original_opdea_dataset_values=dataset_values,
    original_opdea_strata=strata,original_opdea_two_stage_sensitivity=summary,
    original_opdea_primary_paired_values=primary_pairs,
    original_opdea_paired_values=paired,original_opdea_paired_summary=paired_summary,
    original_opdea_coverage=audit,original_opdea_contrast_audit=avail,original_opdea_rank_audit=rank_audit)
  if(write_files) {
    dir.create(out,recursive=TRUE,showWarnings=FALSE)
    for(n in names(result)) write.csv(result[[n]],file.path(out,paste0(n,".csv")),row.names=FALSE)
  }
  result
}

# Manual execution:
# If readxl is in the private project library, uncomment the following line:
# .libPaths(c("inputs/p/MCP_r1_R_reanalysis/R_libs", .libPaths()))
# x <- run_original_opdea()
# x$original_opdea_platform_medians
# x$original_opdea_strata
# x$original_opdea_contrast_audit
# Six-dataset medians, with all dataset-level values in x$original_opdea_strata.
# Absent outputs are non-DEP with ranking score zero on the common outer union.
# pAUC(0.01/0.05/0.1) uses maximum FPR limits, not DEP calling thresholds.
# Historical rank1 comes from the old workbook, not this recalculation.
# MCP_full_DP_fdr is a stored manifest identifier for the manuscript MCP result.
