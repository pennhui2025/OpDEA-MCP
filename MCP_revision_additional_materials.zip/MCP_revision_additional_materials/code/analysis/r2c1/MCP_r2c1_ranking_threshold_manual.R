# Manual re-analysis for reviewer R2C1.  This file only defines functions: call
# run_r2c1() explicitly after sourcing it.  Raw controls are diagnostics, not a
# replacement for the canonical final MCP result / 原始控制仅用于诊断，并不替代规范MCP结果。

r2c1_default_manifest <- function() {
  "reference/Response/r2c1/data/task1_input_manifest.csv"
}

r2c1_need <- function(x, n, where) {
  if (!all(n %in% names(x))) stop(where, " lacks required columns: ", paste(setdiff(n, names(x)), collapse=", "))
}
r2c1_num <- function(x, where) {
  z <- suppressWarnings(as.numeric(x)); if (any(!is.finite(z))) stop("Non-finite numeric values in ", where); z
}
r2c1_threshold <- function(x, where) {
  z <- r2c1_num(x, where)
  if (length(unique(z)) != 1L) stop("Threshold is not unique within ", where)
  if (z[1] < 0 || z[1] > 1) stop("Threshold is outside [0,1] in ", where)
  z[1]
}
r2c1_unique <- function(ids, where) {
  if (anyNA(ids) || any(!nzchar(ids)) || anyDuplicated(ids)) stop("Missing or duplicate protein IDs in ", where)
}

# ROC is calculated group-wise at ties, so its result does not depend on arbitrary
# ordering within a tied score. pAUC maxFPR is an ROC boundary, not a p-value cutoff
# / pAUC的maxFPR是ROC边界，非p值阈值。
r2c1_roc <- function(score, truth, max_fpr=c(.01,.05,.1)) {
  if (length(score) != length(truth) || any(!is.finite(score))) stop("Invalid ROC inputs")
  truth <- as.integer(truth); pos <- sum(truth == 1); neg <- sum(truth == 0)
  ans <- c(AUROC=NA_real_, pAUC_0.01=NA_real_, pAUC_0.05=NA_real_, pAUC_0.1=NA_real_)
  if (!pos || !neg || any(!truth %in% 0:1)) return(ans)
  o <- order(score, decreasing=TRUE); s <- score[o]; y <- truth[o]
  end <- c(which(c(s[-1] != s[-length(s)], TRUE)))
  tp <- cumsum(y)[end]; fp <- cumsum(1-y)[end]
  tpr <- c(0, tp/pos); fpr <- c(0, fp/neg)
  ans["AUROC"] <- sum(diff(fpr) * (head(tpr,-1) + tail(tpr,-1))/2)
  for (m in max_fpr) {
    j <- max(which(fpr <= m));
    if (fpr[j] < m && j < length(fpr)) {
      frac <- (m-fpr[j])/(fpr[j+1]-fpr[j]); tx <- tpr[j] + frac*(tpr[j+1]-tpr[j])
      fx <- c(fpr[seq_len(j)], m); ty <- c(tpr[seq_len(j)], tx)
    } else { fx <- fpr[seq_len(j)]; ty <- tpr[seq_len(j)] }
    raw <- sum(diff(fx) * (head(ty,-1)+tail(ty,-1))/2)
    # McClish standardized partial AUC as implemented by common ROC software:
    # random=0.5 and perfect=1 (rather than reporting the unstandardized area).
    ans[paste0("pAUC_", m)] <- .5 * (1 + (raw - .5*m^2)/(m - .5*m^2))
  }
  ans
}

r2c1_metrics <- function(score, lfc, truth, threshold=.05, mcp=FALSE, observed=rep(TRUE,length(score))) {
  if (length(score) != length(lfc) || length(score) != length(truth)) stop("Metric vector length mismatch")
  # Preserve the native R1C6 q-boundary expression.  Although algebraically close
  # to score >= .95, reconstructing q from stored double precision can differ at
  # exact boundaries / 保留原始q边界表达式以避免精度边界差异。
  call <- if (mcp) score >= threshold else (1-score) <= threshold
  call <- call & observed & abs(lfc) >= log2(1.5); truth <- as.integer(truth)
  tp <- as.double(sum(call & truth == 1)); fp <- as.double(sum(call & truth == 0))
  fn <- as.double(sum(!call & truth == 1)); tn <- as.double(sum(!call & truth == 0))
  den <- sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn))
  c(precision=if ((tp+fp)>0) tp/(tp+fp) else NA_real_, recall=if ((tp+fn)>0) tp/(tp+fn) else NA_real_,
    MCC=if (den>0) (tp*tn-fp*fn)/den else NA_real_, F1=if ((2*tp+fp+fn)>0) 2*tp/(2*tp+fp+fn) else NA_real_,
    r2c1_roc(score, truth), TP=tp, FP=fp, TN=tn, FN=fn, n_union=as.double(length(truth)),
    coverage=as.double(sum(observed)))
}

r2c1_block <- function(d, idcol, pcol, lcol, ids, label) {
  r2c1_need(d, c(idcol,pcol,lcol), label); b <- d[,c(idcol,pcol,lcol),drop=FALSE]; names(b) <- c("id","prob","lfc")
  b <- b[!is.na(b$id) & nzchar(b$id),,drop=FALSE]; r2c1_unique(b$id, label)
  if (any(!b$id %in% ids)) stop(label, " contains protein IDs outside the baseline universe")
  out <- data.frame(id=ids, score=0, lfc=0, observed=FALSE, stringsAsFactors=FALSE); k <- match(b$id, ids)
  # Probability is the stored model DEP score. It is NOT a calibrated q-value.
  # 此处直接读取模型分数，不将 1-Probability 解释为统计学 q-value。
  out$score[k] <- r2c1_num(b$prob, paste(label,"Probability")); out$lfc[k] <- r2c1_num(b$lfc, paste(label,"ori_logFC")); out$observed[k] <- TRUE
  if (any(out$score < 0 | out$score > 1)) stop(label, " probabilities are outside [0,1]")
  out
}

r2c1_one_run <- function(row) {
  d <- read.csv(row[["prediction_file"]], check.names=TRUE, stringsAsFactors=FALSE)
  r2c1_need(d, c("Protein","True_lab"), row[["run_id"]]); r2c1_unique(d$Protein, paste(row[["run_id"]],"baseline"))
  ids <- d$Protein; truth <- r2c1_num(d$True_lab, paste(row[["run_id"]],"True_lab"))
  if (any(!truth %in% 0:1)) stop(row[["run_id"]], ": True_lab must be binary")
  r2c1_need(d, c(paste0("score_DP",c("dlfq","maxlfq","top3","top1")), paste0("logFC_DP",c("dlfq","maxlfq","top3","top1")), "score_DP_hurdle","logFC_DP_hurdle", "threshold", "threshold.1", "threshold.3"), row[["run_id"]])
  methods <- list()
  for (v in c("dlfq","maxlfq","top3","top1")) {
    methods[[paste0("DEA_",v)]] <- data.frame(score=r2c1_num(d[[paste0("score_DP",v)]],v), lfc=r2c1_num(d[[paste0("logFC_DP",v)]],v))
  }
  methods[["Hurdle"]] <- data.frame(score=r2c1_num(d$score_DP_hurdle,"hurdle"), lfc=r2c1_num(d$logFC_DP_hurdle,"hurdle"))
  # make.unique() names identify saved repeated output blocks deterministically.
  raw <- r2c1_block(d,"Protein.1","Probability","ori_logFC",ids,"raw fitted")
  raw05 <- r2c1_block(d,"Protein.2","Probability.1","ori_logFC.1",ids,"raw fixed 0.5")
  final <- r2c1_block(d,"Protein.4","Probability.3","ori_logFC.3",ids,"final MCP")
  raw_thr <- r2c1_threshold(d$threshold, "raw threshold"); raw05_thr <- r2c1_threshold(d$threshold.1, "raw fixed-0.5 threshold")
  final_thr <- r2c1_threshold(d$threshold.3, "final threshold")
  if (!isTRUE(all.equal(raw$score, raw05$score, tolerance=1e-12, check.attributes=FALSE))) stop(row[["run_id"]], ": raw continuous scores do not match fixed-0.5 block")
  methods[["MCP"]] <- final; methods[["MCP_raw_fitted"]] <- raw; methods[["MCP_raw_0.5"]] <- raw05
  method_threshold <- c(MCP=final_thr, MCP_raw_fitted=raw_thr, MCP_raw_0.5=raw05_thr, DEA_dlfq=.05, DEA_maxlfq=.05, DEA_top3=.05, DEA_top1=.05, Hurdle=.05)
  rows <- lapply(names(methods), function(m) { observed <- if ("observed" %in% names(methods[[m]])) methods[[m]]$observed else rep(TRUE,length(ids)); c(dataset=row$dataset,platform=row$platform,dea=row$dea,run_id=row$run_id,method=m,r2c1_metrics(methods[[m]]$score,methods[[m]]$lfc,truth,method_threshold[[m]],m %in% c("MCP","MCP_raw_fitted","MCP_raw_0.5"),observed)) })
  per <- as.data.frame(do.call(rbind, rows), stringsAsFactors=FALSE)
  num <- setdiff(names(per),c("dataset","platform","dea","run_id","method")); for (z in num) per[[z]] <- as.numeric(per[[z]])
  audit <- data.frame(dataset=row$dataset,platform=row$platform,dea=row$dea,run_id=row$run_id,
    n_score_changed=as.double(sum(abs(raw$score-final$score)>1e-12)),
    n_call_changed=as.double(sum((raw$score>=raw_thr & abs(raw$lfc)>=log2(1.5)) != (final$score>=final_thr & abs(final$lfc)>=log2(1.5)))),
    raw_threshold=raw_thr, final_threshold=final_thr)
  list(per_run=per, audit=audit)
}

run_r2c1 <- function(manifest=r2c1_default_manifest(), out="reference/Response/r2c1/manual_R_check", write_files=TRUE) {
  m <- read.csv(manifest, stringsAsFactors=FALSE, check.names=FALSE); r2c1_need(m,c("dataset","platform","dea","method","run_id","prediction_file"),"manifest")
  m <- m[m$method == "MCP_full_DP_fdr",,drop=FALSE]
  if (nrow(m)!=28L || length(unique(m$dataset))!=7L || length(unique(m$platform))!=2L || length(unique(m$dea))!=2L) stop("Expected exactly 28 MCP_full_DP_fdr files across 7 datasets, 2 platforms, and 2 DEA methods")
  if (anyDuplicated(m[,c("dataset","platform","dea")])) stop("Manifest has duplicate dataset/platform/DEA runs")
  ans <- lapply(seq_len(nrow(m)), function(i) r2c1_one_run(m[i,,drop=FALSE])); per <- do.call(rbind,lapply(ans,`[[`,"per_run")); audit <- do.call(rbind,lapply(ans,`[[`,"audit"))
  value_cols <- setdiff(names(per),c("dataset","platform","dea","run_id","method"))
  med <- aggregate(per[value_cols], per[c("platform","method")], function(x) median(x,na.rm=TRUE)); names(med)[-(1:2)] <- paste0("median_",names(med)[-(1:2)])
  raw <- per[per$method=="MCP_raw_fitted",,drop=FALSE]; fin <- per[per$method=="MCP",,drop=FALSE]
  key <- c("dataset","platform","dea","run_id"); paired <- merge(fin,raw,by=key,suffixes=c("_final","_raw"),all=FALSE)
  paired <- paired[,c(key, paste0(value_cols,"_final"),paste0(value_cols,"_raw")),drop=FALSE]
  for (z in value_cols) paired[[paste0("delta_",z)]] <- paired[[paste0(z,"_final")]]-paired[[paste0(z,"_raw")]]
  res <- list(per_run=per,platform_medians=med,score_audit=audit,paired_differences=paired)
  if (write_files) { dir.create(out,recursive=TRUE,showWarnings=FALSE); for (n in names(res)) write.csv(res[[n]],file.path(out,paste0(n,".csv")),row.names=FALSE) }
  res
}

# Tiny tie test / 并列分数自检：the two tied orderings must give identical ROC.
r2c1_selftest <- function() { a<-r2c1_roc(c(.9,.9,.1,.1),c(1,0,1,0)); b<-r2c1_roc(c(.9,.9,.1,.1),c(0,1,0,1)); stopifnot(isTRUE(all.equal(a,b))); invisible(TRUE) }
