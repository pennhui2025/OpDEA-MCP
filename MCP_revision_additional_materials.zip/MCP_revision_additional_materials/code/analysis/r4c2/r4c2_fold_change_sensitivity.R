# Reviewer 4 Comment 2: sensitivity to the FINAL fold-change filter.
# source() only defines the function. To run manually: result <- run_r4c2()
# No model training, no new pseudo-labels, and no p-value re-adjustment.
# It reuses the already delivered R2C1 protein alignment / ROC helper functions.
# 中文：只去掉或改变最终FC过滤；原训练标签、模型分数和阈值均保持不变。

run_r4c2 <- function(
  helper = "code/analysis/r2c1/MCP_r2c1_ranking_threshold_manual.R",
  manifest = "reference/Response/r2c1/data/task1_input_manifest.csv",
  original_metrics = "reference/Response/r2c1/data/per_run.csv",
  out = "reference/Response/r4c2/manual_R_check",
  write_files = TRUE
) {
  h <- new.env(parent = baseenv())
  # Helpers use stats functions through the usual global search path.
  parent.env(h) <- globalenv()
  sys.source(helper, envir = h)
  h$r2c1_selftest()
  m <- read.csv(manifest, check.names = FALSE, stringsAsFactors = FALSE)
  m <- m[m$method == "MCP_full_DP_fdr", , drop = FALSE]
  stopifnot(nrow(m) == 28L, !anyDuplicated(m[c("dataset", "platform", "dea")]))
  stopifnot(length(unique(m$dataset)) == 7L, length(unique(m$platform)) == 2L)
  rows <- list(); effects <- list(); k <- 0L
  # Ratio 1 means no magnitude exclusion, NOT |log2FC| >= 1.
  # No significance threshold tuning is performed; all ratios are reported.
  for (i in seq_len(nrow(m))) {
    d <- read.csv(m$prediction_file[i], check.names = TRUE, stringsAsFactors = FALSE)
    ids <- d$Protein; truth <- h$r2c1_num(d$True_lab, "True_lab")
    h$r2c1_unique(ids, "baseline protein universe")
    stopifnot(all(truth %in% 0:1))
    final <- h$r2c1_block(d, "Protein.4", "Probability.3", "ori_logFC.3", ids, "MCP")
    threshold <- h$r2c1_threshold(d$threshold.3, "MCP saved threshold")
    blocks <- list(MCP = final)
    for (v in c("dlfq", "maxlfq", "top3", "top1")) {
      blocks[[paste0("DEA_", v)]] <- data.frame(
        score = h$r2c1_num(d[[paste0("score_DP", v)]], v),
        lfc = h$r2c1_num(d[[paste0("logFC_DP", v)]], v), observed = TRUE)
    }
    blocks$Hurdle <- data.frame(score = h$r2c1_num(d$score_DP_hurdle, "hurdle"),
                              lfc = h$r2c1_num(d$logFC_DP_hurdle, "hurdle"), observed = TRUE)
    for (method in names(blocks)) {
      b <- blocks[[method]]
      # Statistical scores store 1-q (native ROTS FDR or limma BH adjusted P).
      # MCP Probability is a classifier score, not a statistical q-value.
      pass <- if (method == "MCP") b$score >= threshold else (1 - b$score) <= .05
      pass <- pass & b$observed
      rank_metrics <- h$r2c1_roc(b$score, truth)
      for (ratio in c(1, 1.2, 1.5)) {
        call <- pass & abs(b$lfc) >= log2(ratio)
        # Double prevents R integer overflow in the MCC denominator.
        tp <- as.double(sum(call & truth == 1)); fp <- as.double(sum(call & truth == 0))
        tn <- as.double(sum(!call & truth == 0)); fn <- as.double(sum(!call & truth == 1))
        den <- sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn))
        values <- c(precision = if (tp+fp > 0) tp/(tp+fp) else NA_real_,
                    recall = if (tp+fn > 0) tp/(tp+fn) else NA_real_,
                    MCC = if (den > 0) (tp*tn-fp*fn)/den else NA_real_,
                    F1 = if (2*tp+fp+fn > 0) 2*tp/(2*tp+fp+fn) else NA_real_,
                    rank_metrics, TP=tp, FP=fp, TN=tn, FN=fn,
                    n_union=length(ids), coverage=sum(b$observed))
        k <- k + 1L
        rows[[k]] <- cbind(m[i, c("dataset", "platform", "dea", "run_id"), drop=FALSE],
                          method=method, fc_ratio=ratio, log2fc_cutoff=log2(ratio),
                          score_threshold=if (method == "MCP") threshold else .05,
                          as.data.frame(as.list(values)), stringsAsFactors=FALSE)
      }
      # Number of known positives recovered when the final FC gate is removed.
      # This refers to measured effect sizes, not designed spike-in ratios.
      effects[[length(effects)+1L]] <- cbind(m[i,c("dataset","platform","dea"),drop=FALSE],
        method=method, true_positive_below_fc15=sum(pass & abs(b$lfc)<log2(1.5) & truth==1),
        false_positive_below_fc15=sum(pass & abs(b$lfc)<log2(1.5) & truth==0))
    }
  }
  per <- do.call(rbind, rows); rownames(per) <- NULL
  # Independent original-output comparison before trusting the new FC sensitivity.
  old <- read.csv(original_metrics, stringsAsFactors=FALSE, check.names=FALSE)
  old <- old[old$method %in% unique(per$method), ,drop=FALSE]
  now <- per[per$fc_ratio == 1.5, ,drop=FALSE]
  key <- c("dataset","platform","dea","method")
  cmp <- merge(now, old, by=key, suffixes=c("_new","_old"))
  stopifnot(nrow(cmp) == 168L)
  mapping <- c(precision="precision",recall="recall",MCC="mcc",F1="f1",
               AUROC="auroc",pAUC_0.01="pauc001",pAUC_0.05="pauc005",pAUC_0.1="pauc01")
  for (a in names(mapping)) {
    anew <- if (paste0(a,"_new") %in% names(cmp)) paste0(a,"_new") else a
    b <- mapping[[a]]; bold <- if (paste0(b,"_old") %in% names(cmp)) paste0(b,"_old") else b
    stopifnot(isTRUE(all.equal(cmp[[anew]], cmp[[bold]], tolerance=1e-10, check.attributes=FALSE)))
  }
  cols <- c("precision","recall","MCC","F1","AUROC","pAUC_0.01","pAUC_0.05","pAUC_0.1","TP","FP","TN","FN")
  medfun <- function(x) if (all(is.na(x))) NA_real_ else median(x, na.rm=TRUE)
  med <- aggregate(per[cols], per[c("platform","method","fc_ratio")], medfun)
  # Separate limma and ROTS summaries: seven datasets in each row.
  split_med <- aggregate(per[cols], per[c("platform","dea","method","fc_ratio")], medfun)
  eff <- do.call(rbind,effects)
  result <- list(per_run=per, platform_medians=med, DEA_specific_medians=split_med,
                 final_gate_excluded_calls=eff)
  if (write_files) {
    dir.create(out, recursive=TRUE, showWarnings=FALSE)
    for (n in names(result)) write.csv(result[[n]],file.path(out,paste0(n,".csv")),row.names=FALSE)
  }
  message("Validated 168 original records; calculated 504 method-run-FC records.")
  print(med[med$method %in% c("MCP","DEA_dlfq","Hurdle") & med$fc_ratio %in% c(1,1.5),
            c("platform","method","fc_ratio","precision","recall","MCC","pAUC_0.05")],row.names=FALSE)
  invisible(result)
}
