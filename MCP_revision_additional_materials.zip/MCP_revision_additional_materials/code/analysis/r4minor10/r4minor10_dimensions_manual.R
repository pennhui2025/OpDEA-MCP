# source() defines the function only. No normalization or embedding is rerun.
check_fig4b_dimensions <- function(response_dir='reference/Response') {
  plan<-read.csv(file.path(response_dir,'r4minor11/data/fig4b_corrected_clustering_metrics.csv'))
  out<-do.call(rbind,lapply(seq_len(nrow(plan)),function(i){
    x<-read.csv(plan$source_file[i],row.names=1)
    # First CSV column was the exported row index; last data column is diagnosis.
    features<-x[,-ncol(x),drop=FALSE];label<-x[[ncol(x)]]
    stopifnot(nrow(features)==579,ncol(features)==plan$n_features[i],
              sum(label==0)==385,sum(label==1)==194)
    data.frame(method=plan$method[i],patients=nrow(features),features=ncol(features))
  }))
  print(out);invisible(out)
}
# result <- check_fig4b_dimensions()
