# Source defines the function only. RStudio: run the final example manually.
# Uses existing corrected original-status patient records; no end-of-follow-up recoding.
package_dir <- 'reference/Response/r4minor13'
plot_survival <- function(package_dir) {
  stopifnot(requireNamespace('survival',quietly=TRUE))
  d<-read.csv(file.path(package_dir,'data/VSIG4_patients_original_status.csv'))
  stopifnot(nrow(d)==97,sum(d$OS_status)==7,max(d$OS_time)==531,all(d$OS_status %in% c(0,1)))
  d$group<-factor(ifelse(d$VSIG4>median(d$VSIG4),'High','Low'),levels=c('Low','High'))
  fit<-survival::survfit(survival::Surv(OS_time,OS_status)~group,data=d,conf.int=.95,conf.type='log')
  lr<-survival::survdiff(survival::Surv(OS_time,OS_status)~group,data=d)
  pval<-pchisq(lr$chisq,df=1,lower.tail=FALSE)
  ss<-summary(fit,censored=TRUE)
  curves<-data.frame(time=ss$time,survival=ss$surv,lower=ss$lower,upper=ss$upper,
    n_risk=ss$n.risk,n_event=ss$n.event,n_censor=ss$n.censor,group=sub('group=','',ss$strata))
  ticks<-c(0,100,200,300,400,500,531)
  risk<-do.call(rbind,lapply(levels(d$group),function(g) data.frame(group=g,time=ticks,
    n_risk=vapply(ticks,function(t)sum(d$group==g & d$OS_time>=t),1L))))
  figdir<-file.path(package_dir,'figures');dir.create(figdir,showWarnings=FALSE)
  write.csv(curves,file.path(package_dir,'data/VSIG4_KM_with_CI.csv'),row.names=FALSE)
  write.csv(risk,file.path(package_dir,'data/VSIG4_at_risk.csv'),row.names=FALSE)
  draw<-function() {
    layout(matrix(c(1,2),2,1),heights=c(4,1));par(mar=c(4,4,2.8,1),family='sans',las=1)
    cols<-c('#0072B2','#D55E00')
    plot(fit,col=cols,lwd=2,xlim=c(0,550),ylim=c(0,1),conf.int=TRUE,mark.time=TRUE,
      xlab='Overall survival (days)',ylab='Survival probability',main='VSIG4 in CPTAC-COAD')
    legend('bottomleft',c('Low abundance (n=49, deaths=1)','High abundance (n=48, deaths=6)'),
      col=cols,lwd=2,bty='n',cex=.84)
    mtext(sprintf('Log-rank p=%.4f; BH q=0.268; dashed lines: 95%% pointwise CI',pval),side=3,line=.25,cex=.72)
    par(mar=c(2,4,1,1));plot.new();plot.window(xlim=c(0,550),ylim=c(.5,2.5),xaxs='r')
    title('Number at risk',adj=0,line=-.2,cex.main=.8)
    for(i in 1:2) {g<-levels(d$group)[i];rr<-risk[risk$group==g,];text(rr$time,3-i,rr$n_risk,col=cols[i],cex=.78);mtext(g,side=2,at=3-i,las=1,line=1,cex=.75)}
    axis(1,at=c(0,100,200,300,400,500),cex.axis=.75)
    text(531,.55,'531',cex=.65,xpd=NA)
  }
  pdf(file.path(figdir,'VSIG4_KM_full_followup_CI.pdf'),width=6.6,height=5.5);draw();dev.off()
  png(file.path(figdir,'VSIG4_KM_full_followup_CI.png'),width=1980,height=1650,res=300);draw();dev.off()
  print(data.frame(n=nrow(d),deaths=sum(d$OS_status),min_days=min(d$OS_time),max_days=max(d$OS_time),
    n_beyond_500=sum(d$OS_time>500),logrank_p=pval))
  invisible(list(fit=fit,curves=curves,at_risk=risk))
}
# result <- plot_survival(package_dir)
