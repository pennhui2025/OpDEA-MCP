# Source defines the function only. Rechecks the existing corrected survival table.
# Full Cox refit code is retained at Response/r1c10/R1C10_manual_check.R.
package_dir <- 'reference/Response/r4minor12'
check_survival_table <- function(package_dir) {
  d<-read.csv(file.path(package_dir,'data/CRC_all19_survival.csv'))
  adjust<-function(p,n) {z<-rep(NA_real_,length(p));ok<-is.finite(p);z[ok]<-p.adjust(p[ok],method='BH',n=n);z}
  stopifnot(nrow(d)==19,sum(is.finite(d$Cox_Wald_p))==11,sum(is.finite(d$Log_rank_p))==12)
  stopifnot(isTRUE(all.equal(d$Cox_BH_q_19,adjust(d$Cox_Wald_p,19),tolerance=1e-10)),
    isTRUE(all.equal(d$Log_rank_BH_q_19,adjust(d$Log_rank_p,19),tolerance=1e-10)))
  print(d[c('UNIPROT','SYMBOL','N','Events','HR','CI_lower','CI_upper','Cox_Wald_p','Cox_BH_q_19','Log_rank_p','Log_rank_BH_q_19','Status')],row.names=FALSE)
  message('BH-significant Cox: ',sum(d$Cox_BH_q_19<.05,na.rm=TRUE),'; log-rank: ',sum(d$Log_rank_BH_q_19<.05,na.rm=TRUE))
  invisible(d)
}
# d <- check_survival_table(package_dir)
