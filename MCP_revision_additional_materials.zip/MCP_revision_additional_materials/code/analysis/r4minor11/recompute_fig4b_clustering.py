"""Read-only audit of the five archived Fig. 4b clustering matrices.

This script does not rerun DEA, UMAP, or model training.  It loads the exact
zero-filled, constant-filtered patient matrices consumed by Fig4.R, repeats
the historical KMeans protocol with the legacy n_init=10 made explicit, and
reports corrected feature-space silhouette coefficients.
"""

from __future__ import annotations

import platform
from pathlib import Path

import numpy as np
import pandas as pd
import sklearn
from sklearn.cluster import KMeans
from sklearn.metrics import (
    adjusted_rand_score,
    normalized_mutual_info_score,
    silhouette_score,
)
from sklearn.metrics.cluster import contingency_matrix


INPUT_DIR = Path(
    r"inputs/n\Figures\data\clustering_20260320"
)
OUTPUT = Path(__file__).with_name("fig4b_corrected_clustering_metrics.csv")

METHODS = {
    "dlfq": "TPD_disdlfq.csv",
    "maxlfq": "TPD_dismaxlfq.csv",
    "top3": "TPD_distop3.csv",
    "top1": "TPD_distop1.csv",
    "MCP": "TPD_disDIA_dlfq_maxlfq_top3mvdea.csv",
}

HISTORICAL = {
    "dlfq": {"ARI": 0.4559, "ASW_invalid": 0.5535, "NMI": 0.3262, "PS": 0.8411},
    "maxlfq": {"ARI": 0.4092, "ASW_invalid": 0.5095, "NMI": 0.2844, "PS": 0.8238},
    "top3": {"ARI": 0.1224, "ASW_invalid": 0.1991, "NMI": 0.1883, "PS": 0.6788},
    "top1": {"ARI": 0.1417, "ASW_invalid": 0.2244, "NMI": 0.1921, "PS": 0.6908},
    "MCP": {"ARI": 0.4753, "ASW_invalid": 0.5714, "NMI": 0.3439, "PS": 0.8480},
}


def purity(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    cm = contingency_matrix(y_true, y_pred)
    return float(np.amax(cm, axis=0).sum() / cm.sum())


def load_archived_matrix(path: Path) -> tuple[np.ndarray, np.ndarray]:
    frame = pd.read_csv(path)
    if not str(frame.columns[0]).startswith("Unnamed"):
        raise ValueError(f"Expected pandas index column in {path}")
    values = frame.iloc[:, 1:].to_numpy(dtype=float)
    data, labels = values[:, :-1], values[:, -1].astype(int)
    if data.shape[0] != labels.size or data.shape[1] == 0:
        raise ValueError(f"Invalid samples/features layout in {path}")
    if not np.isfinite(data).all():
        raise ValueError(f"Non-finite value in archived matrix {path}")
    if np.unique(labels).tolist() != [0, 1]:
        raise ValueError(f"Unexpected clinical labels in {path}")
    return data, labels


def main() -> None:
    rows: list[dict[str, object]] = []
    reference_labels: np.ndarray | None = None
    for method, filename in METHODS.items():
        path = INPUT_DIR / filename
        data, clinical_labels = load_archived_matrix(path)
        if reference_labels is None:
            reference_labels = clinical_labels.copy()
        elif not np.array_equal(reference_labels, clinical_labels):
            raise ValueError(f"Clinical-label order differs for {method}")

        fitted = KMeans(
            n_clusters=2,
            random_state=2024,
            n_init=10,
            init="k-means++",
            max_iter=300,
            tol=1e-4,
            algorithm="lloyd",
        ).fit_predict(data)
        ari = float(adjusted_rand_score(clinical_labels, fitted))
        nmi = float(normalized_mutual_info_score(clinical_labels, fitted))
        ps = purity(clinical_labels, fitted)
        corrected_asw = float(silhouette_score(data, fitted, metric="euclidean"))
        clinical_label_asw = float(
            silhouette_score(data, clinical_labels, metric="euclidean")
        )
        invalid_old_asw = float(
            silhouette_score(clinical_labels.reshape(-1, 1), fitted)
        )
        expected = HISTORICAL[method]
        rows.append(
            {
                "method": method,
                "source_file": str(path),
                "n_samples": data.shape[0],
                "n_features": data.shape[1],
                "n_benign": int((clinical_labels == 0).sum()),
                "n_malignant": int((clinical_labels == 1).sum()),
                "ARI_recomputed": ari,
                "NMI_recomputed": nmi,
                "purity_recomputed": ps,
                "ASW_feature_space_kmeans": corrected_asw,
                "ASW_feature_space_clinical_labels": clinical_label_asw,
                "ASW_invalid_old_formula": invalid_old_asw,
                "historical_ARI": expected["ARI"],
                "historical_NMI": expected["NMI"],
                "historical_purity": expected["PS"],
                "historical_ASW_invalid": expected["ASW_invalid"],
                "ARI_round4_match": round(ari, 4) == expected["ARI"],
                "NMI_round4_match": round(nmi, 4) == expected["NMI"],
                "purity_round4_match": round(ps, 4) == expected["PS"],
                "invalid_ASW_round4_match": round(invalid_old_asw, 4)
                == expected["ASW_invalid"],
                "python_version": platform.python_version(),
                "sklearn_version": sklearn.__version__,
            }
        )

    output = pd.DataFrame(rows)
    output.to_csv(OUTPUT, index=False)
    print(output.to_string(index=False))
    print(f"\nWrote {OUTPUT}")


if __name__ == "__main__":
    main()
