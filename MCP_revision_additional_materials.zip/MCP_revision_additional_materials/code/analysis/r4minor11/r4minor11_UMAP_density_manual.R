# Run source() to define the function; execute the last commented line manually.
# No UMAP fitting, no parameter optimization, no patient-label changes.
library(svglite)
package_dir <- 'reference/Response/r4minor11'
plot_saved_umap <- function(package_dir) {
  stopifnot(requireNamespace('MASS',quietly=TRUE))
  manifest <- read.csv(file.path(package_dir,'data/UMAP_source_manifest.csv'))
  frames <- lapply(manifest$file,function(f) read.csv(file.path(package_dir,'data',f),row.names=1))
  names(frames) <- manifest$method
  colors <- c(benign='#0072B2',malignant='#D55E00')
  # Estimate each clinical group's density with the SAME pooled bandwidth within
  # a representation. Each density integrates to one; it is not scaled by class size.
  # The contours enclose approximately 50% (solid) and 80% (dashed) of density mass.
  mass_level <- function(k, mass) {
    z <- sort(as.vector(k$z),decreasing=TRUE)
    z[which(cumsum(z)/sum(z)>=mass)[1]]
  }
  draw <- function() {
    par(mfrow=c(2,3),mar=c(3.6,3.6,2.2,.8),mgp=c(2.1,.6,0),family='sans',las=1)
    for(nm in names(frames)) {
      d <- frames[[nm]]
      stopifnot(nrow(d)==579,sum(d$cluster=='benign')==385,sum(d$cluster=='malignant')==194)
      xlim <- range(d$UMAP1); ylim <- range(d$UMAP2)
      h <- c(MASS::bandwidth.nrd(d$UMAP1),MASS::bandwidth.nrd(d$UMAP2))
      # MASS uses bandwidth / 4 internally; extend the grid sufficiently for tails.
      lims <- c(xlim+c(-1,1)*h[1],ylim+c(-1,1)*h[2])
      plot(d$UMAP1,d$UMAP2,pch=16,cex=.45,col=adjustcolor(colors[d$cluster],alpha.f=.25),
           xlab='UMAP 1',ylab='UMAP 2',main=nm,xlim=lims[1:2],ylim=lims[3:4])
      for(g in names(colors)) {
        dd <- d[d$cluster==g,]
        k <- MASS::kde2d(dd$UMAP1,dd$UMAP2,h=h,n=180,lims=lims)
        contour(k,levels=mass_level(k,.8),add=TRUE,drawlabels=FALSE,col=colors[g],lwd=1.3,lty=2)
        contour(k,levels=mass_level(k,.5),add=TRUE,drawlabels=FALSE,col=colors[g],lwd=1.5,lty=1)
      }
    }
    plot.new()
    legend('center',c('Benign (n=385)','Malignant (n=194)','50% density region','80% density region'),
      col=c(colors,'grey30','grey30'),lty=c(1,1,1,2),lwd=1.5,bty='n',cex=1)
    mtext('Original saved UMAP coordinates\nDescriptive densities, not clustering accuracy',side=1,line=-2,cex=.8)
  }
  out <- file.path(package_dir,'figures');dir.create(out,showWarnings=FALSE)
  pdf(file.path(out,'Fig4b_original_UMAP_density.pdf'),width=10.5,height=6.7);draw();dev.off()
  png(file.path(out,'Fig4b_original_UMAP_density.png'),width=3150,height=2010,res=300);draw();dev.off()
  svglite(file.path(out, 'Fig4b_original_UMAP_density.svg'), width = 10.5, height = 6.7);draw();dev.off()
  
  
  #svg(file.path(out,'Fig4b_original_UMAP_density.svg'),width=3150,height=2010,res=300);draw();dev.off()
  #out
  invisible(frames)
}
 result <- plot_saved_umap(package_dir)
