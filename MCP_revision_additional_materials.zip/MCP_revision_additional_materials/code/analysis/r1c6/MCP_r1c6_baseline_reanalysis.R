# Model and fusion baselines.
# Source this file, then call run_r1c6_baselines().
# MCP uses the final saved score block.

run_r1c6_baselines <- function(
  project = "code/training",
  delivery = "reference/Response/r1c6",
  out = file.path(delivery,"manual_R_baseline_results"),
  write_files = TRUE, make_plots = TRUE,
  linear_file = file.path(project,"revision_results/final_required/linear_fusion_baselines/linear_fusion_predictions.csv.gz")) {
  fc_cut <- log2(1.5)
  views <- c("dlfq","maxlfq","top3","top1")
  original_project <- "inputs/p"
  local_path <- function(p) {
    p <- gsub("\\\\","/",p)
    if(startsWith(p,paste0(original_project,"/"))) p <- paste0(project,substring(p,nchar(original_project)+1))
    p <- normalizePath(p,winslash="/",mustWork=TRUE)
    if(.Platform$OS.type=="windows") paste0("\\\\?\\",gsub("/","\\\\",p)) else p
  }
  read_table <- function(p) {
    # R write.csv 的部分原始文件含行名，read.csv 会正确处理额外首列。
    p <- local_path(p)
    z <- if(grepl("[.]gz$",p)) read.csv(gzfile(p),check.names=FALSE) else read.csv(p,check.names=FALSE)
    names(z) <- make.unique(names(z)); z
  }
  get_metrics <- function(y,score,called) {
    stopifnot(length(y)==length(score),length(y)==length(called),
              all(y %in% 0:1),all(is.finite(score)),!anyNA(called))
    # 必须先转 double，防止 MCC 分母整数乘法溢出。
    tn<-as.double(sum(y==0 & !called)); fp<-as.double(sum(y==0 & called))
    fn<-as.double(sum(y==1 & !called)); tp<-as.double(sum(y==1 & called))
    den<-sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn))
    if(!sum(y==1) || !sum(y==0)) return(c(n=length(y),tn=tn,fp=fp,fn=fn,tp=tp,
      precision=if(tp+fp==0) 0 else tp/(tp+fp),recall=if(tp+fn==0) NA_real_ else tp/(tp+fn),
      mcc=NA_real_,f1=if(2*tp+fp+fn==0) 0 else 2*tp/(2*tp+fp+fn),
      auroc=NA_real_,ap=NA_real_,pauc001=NA_real_,pauc005=NA_real_,pauc01=NA_real_))
    o<-order(-score); ys<-y[o]; ss<-score[o]
    last<-c(which(diff(ss)!=0),length(ss)) # 并列分数作为一个阈值
    t<-cumsum(ys)[last]; f<-last-t
    tpr<-c(0,t/sum(y)); fpr<-c(0,f/sum(1-y))
    trap<-function(x,z) sum(diff(x)*(head(z,-1)+tail(z,-1))/2)
    auroc<-trap(fpr,tpr)
    ap<-sum(diff(c(0,t/sum(y)))*t/last) # average precision，不是梯形 PR 面积
    # Tie groups define the ROC vertices; interpolate only the requested FPR boundary.
    # This is sklearn's McClish-standardized partial AUC, not raw partial area.
    pauc_one<-function(a) {
      i<-max(which(fpr<=a)); xx<-fpr[seq_len(i)]; zz<-tpr[seq_len(i)]
      if(tail(xx,1)<a) {
        zz<-c(zz,tpr[i]+(a-fpr[i])*(tpr[i+1]-tpr[i])/(fpr[i+1]-fpr[i])); xx<-c(xx,a)
      }
      .5*(1+(trap(xx,zz)-.5*a^2)/(a-.5*a^2))
    }
    c(n=length(y),tn=tn,fp=fp,fn=fn,tp=tp,
      precision=if(tp+fp==0) 0 else tp/(tp+fp),recall=tp/(tp+fn),
      mcc=if(den==0) 0 else (tp*tn-fp*fn)/den,f1=if(2*tp+fp+fn==0) 0 else 2*tp/(2*tp+fp+fn),
      auroc=auroc,ap=ap,pauc001=pauc_one(.01),pauc005=pauc_one(.05),pauc01=pauc_one(.1))
  }
  get_model <- function(d) {
    cols<-c("Protein.4","Probability.3","ori_logFC.3","threshold.3")
    stopifnot(all(c(cols,"Protein","True_lab") %in% names(d)))
    b<-d[!is.na(d$Protein.4)&nzchar(d$Protein.4),cols]
    names(b)<-c("Protein","score","fc","threshold")
    b$truth<-d$True_lab[match(b$Protein,d$Protein)]
    stopifnot(!anyDuplicated(b$Protein),all(is.finite(as.matrix(b[c("score","fc","threshold")]))),!anyNA(b$truth))
    b$called<-b$score>=b$threshold & abs(b$fc)>=fc_cut
    b
  }
  mf<-read_table(file.path(delivery,"task1_input_manifest.csv"))
  stopifnot(nrow(mf)==224L,!anyDuplicated(mf[c("dataset","platform","dea","method")]))
  srcmf<-read_table(file.path(delivery,"p_combination_source_manifest.csv"))
  lin<-read_table(linear_file)
  records<-list(); audit<-list(); native<-list(); protein_p<-list()
  # 同一数据集、平台和 DEA 的全四视图候选蛋白为固定 union。
  # 任何方法缺少的蛋白强制 non-DEP/score=0；真值不随方法改变。
  full_rows<-which(mf$method=="MCP_full_DP_fdr")
  for(ri in full_rows) {
    ref<-mf[ri,]; key<-ref[c("dataset","platform","dea")]
    full<-read_table(ref$prediction_file)
    u<-full[!is.na(full$Protein)&nzchar(full$Protein),c("Protein","True_lab")]
    stopifnot(!anyDuplicated(u$Protein),all(u$True_lab %in% 0:1))
    add<-function(method,b) {
      stopifnot(!anyDuplicated(b$Protein),all(b$Protein %in% u$Protein),
                identical(as.integer(b$truth),as.integer(u$True_lab[match(b$Protein,u$Protein)])),
                all(is.finite(b$score)),!anyNA(b$called))
      ix<-match(u$Protein,b$Protein); present<-!is.na(ix)
      sc<-numeric(nrow(u)); ca<-rep(FALSE,nrow(u))
      sc[present]<-b$score[ix[present]]; ca[present]<-b$called[ix[present]]
      z<-get_metrics(u$True_lab,sc,ca)
      records[[length(records)+1L]]<<-cbind(key,method=method,coverage=nrow(b),as.data.frame(as.list(z)))
      audit[[length(audit)+1L]]<<-cbind(key,method=method,n_union=nrow(u),n_observed=nrow(b),missing_predictions=sum(!present),truth_mismatch=0)
    }
    rows<-which(mf$dataset==ref$dataset & mf$platform==ref$platform & mf$dea==ref$dea)
    for(i in rows) {
      r<-mf[i,]; d<-read_table(r$prediction_file)
      if(r$method=="Mean_rank") {
        b<-data.frame(Protein=d$Protein,truth=d$True_lab,score=d$score_rank_or_pvalue_fusion,
                      fc=d$logFC_rank_or_pvalue_fusion)
        b$called<-b$score>=.95 & abs(b$fc)>=fc_cut
        typ<-"rank_or_pvalue_fusion"
      } else { b<-get_model(d); typ<-"DP_fdr" }
      add(r$method,b)
      # 原生集合指标必须与对应保存的 metrics 行吻合，再进行 union 比较。
      z<-get_metrics(b$truth,b$score,b$called)
      old<-read_table(r$metrics_file); old<-old[old$test_type==typ,]
      map<-c(precision="Prec",recall="Rec",mcc="Mcc",f1="F1",pauc001="pauc001",tn="tn",fp="fp",fn="fn",tp="tp")
      stopifnot(nrow(old)==1L)
      err<-max(abs(z[names(map)]-as.numeric(old[1,unname(map)])))
      stopifnot(err<1e-10)
      native[[length(native)+1L]]<-cbind(key,method=r$method,native_max_difference=err)
    }
    aligned<-full[match(u$Protein,full$Protein),]
    calls<-scores<-matrix(NA_real_,nrow(u),4)
    for(j in seq_along(c(views,"_hurdle"))) {
      v<-c(views,"_hurdle")[j]
      s<-aligned[[paste0("score_DP",v)]]; f<-aligned[[paste0("logFC_DP",v)]]
      s[is.na(s)]<-0; f[is.na(f)]<-0
      ca<-(1-s)<=.05 & abs(f)>=fc_cut
      method<-if(v=="_hurdle") "Hurdle_operator" else paste0("DEA_",v)
      add(method,data.frame(Protein=u$Protein,truth=u$True_lab,score=s,called=ca))
      if(j<=4) {scores[,j]<-s; calls[,j]<-ca}
    }
    add("Statistical_union",data.frame(Protein=u$Protein,truth=u$True_lab,score=apply(scores,1,max),called=rowSums(calls)>0))
    add("Statistical_intersection",data.frame(Protein=u$Protein,truth=u$True_lab,score=apply(scores,1,min),called=rowSums(calls)==4))
    ln<-lin[lin$dataset==ref$dataset & lin$platform==ref$platform & lin$dea_method==ref$dea,]
    stopifnot(!anyDuplicated(ln$Protein),setequal(ln$Protein,u$Protein))
    ln<-ln[match(u$Protein,ln$Protein),]; stopifnot(identical(ln$True_lab,u$True_lab))
    for(kind in c("early","late")) {
      s<-ln[[paste0("ridge_",kind,"_probability")]]
      add(paste0("Ridge_",kind,"_fusion"),data.frame(Protein=u$Protein,truth=u$True_lab,score=s,called=s>=.5 & abs(ln$ori_logFC)>=fc_cut))
    }
    # 新增离线 P 合并：用 raw P，不把 FDR/q 值当 P 值再合并。
    # 四视图相关，采用 Bonferroni-minP。BH 主表，BY 为依赖敏感性。
    ps<-matrix(1,nrow(u),4); fs<-matrix(0,nrow(u),4)
    sr<-srcmf[srcmf$dataset==ref$dataset & srcmf$platform==ref$platform & srcmf$dea==ref$dea,]
    for(j in seq_along(views)) {
      path<-sr$source_file[sr$view==views[j]]; stopifnot(length(path)==1L)
      d<-read_table(path)
      stopifnot(!anyDuplicated(d$protein),all(d$protein %in% u$Protein),
                all(is.finite(d$pvalue)),all(d$pvalue>=0 & d$pvalue<=1),all(is.finite(d$logFC)))
      ix<-match(d$protein,u$Protein); ps[ix,j]<-d$pvalue; fs[ix,j]<-d$logFC
    }
    # P 值及 FC 来自同一个视图；相同最小 P 按 views 固定顺序打破平局。
    arg<-max.col(-ps,ties.method="first")
    comb<-pmin(1,4*ps[cbind(seq_len(nrow(u)),arg)])
    f<-fs[cbind(seq_len(nrow(u)),arg)]
    sc<--log10(pmax(comb,.Machine$double.xmin)) # 连续排序分数，不是概率
    pp<-cbind(key[rep(1,nrow(u)),],Protein=u$Protein,truth=u$True_lab,combined_p=comb,logFC_argmin_p=f,selected_view=views[arg])
    for(corr in c("BH","BY")) {
      q<-p.adjust(comb,method=corr)
      method<-paste0("Bonferroni_minP_",corr)
      add(method,data.frame(Protein=u$Protein,truth=u$True_lab,score=sc,called=q<=.05 & abs(f)>=fc_cut))
      pp[[paste0(method,"_q")]]<-q
    }
    protein_p[[length(protein_p)+1L]]<-pp
  }
  per<-do.call(rbind,records)
  numeric_cols<-c("precision","recall","mcc","f1","auroc","ap","pauc001","pauc005","pauc01","n","tp","fp","fn","tn","coverage")
  # Dataset diagnostics retain the explicit median over its two DEA strata.
  # Primary summaries are platform-specific medians across the 7 dataset x 2 DEA strata.
  stopifnot(all(table(paste(per$dataset,per$method))==4L))
  ds<-aggregate(per[numeric_cols],per[c("dataset","platform","method")],median,na.rm=TRUE)
  names(ds)[names(ds)=="n"]<-"median_N_over_2_DEA"
  platform<-aggregate(per[numeric_cols],per[c("platform","method")],median,na.rm=TRUE)
  platform$n_dataset_x_DEA_strata<-14L
  platform$n_datasets<-7L
  # Legacy seven-dataset mean summaries/tests remain explicitly segregated and are not
  # inferential evidence for the new median estimand.
  legacy_ds<-aggregate(per[numeric_cols],per[c("dataset","method")],mean)
  legacy_sm<-aggregate(legacy_ds[numeric_cols],legacy_ds["method"],mean); legacy_sm$n_datasets<-7L
  ref<-legacy_ds[legacy_ds$method=="MCP_full_DP_fdr",]
  tests<-lapply(setdiff(unique(legacy_ds$method),"MCP_full_DP_fdr"),function(m) {
    z<-legacy_ds[legacy_ds$method==m,]; z<-z[match(ref$dataset,z$dataset),]
    delta<-ref$mcc-z$mcc
    signs<-as.matrix(expand.grid(rep(list(c(-1,1)),length(delta))))
    null<-rowMeans(sweep(signs,2,delta,"*"))
    data.frame(method=m,n_datasets=7L,mean_MCC_difference=mean(delta),
               MCP_higher=sum(delta>1e-12),MCP_lower=sum(delta< -1e-12),MCP_tied=sum(abs(delta)<=1e-12),
               exact_signflip_p=mean(abs(null)>=abs(mean(delta))-1e-12))
  })
  tests<-do.call(rbind,tests); tests$holm_p_all_MCC_comparisons<-p.adjust(tests$exact_signflip_p,"holm")
  names(tests)[names(tests)=="mean_MCC_difference"]<-"legacy_mean_MCC_difference"
  # Paired changes are calculated first within each dataset x platform x DEA stratum.
  # Difference-of-platform-medians is deliberately not labelled as a paired median change.
  metric_primary<-c("precision","recall","mcc","f1","auroc","ap","pauc001","pauc005","pauc01")
  refp<-per[per$method=="MCP_full_DP_fdr",c("dataset","platform","dea",metric_primary)]
  paired_long<-do.call(rbind,lapply(setdiff(unique(per$method),"MCP_full_DP_fdr"),function(m) {
    z<-per[per$method==m,c("dataset","platform","dea",metric_primary)]
    z<-z[match(do.call(paste,c(refp[c("dataset","platform","dea")])),do.call(paste,c(z[c("dataset","platform","dea")]))),]
    do.call(rbind,lapply(metric_primary,function(q) data.frame(dataset=refp$dataset,platform=refp$platform,dea=refp$dea,method=m,metric=q,MCP_minus_comparator=refp[[q]]-z[[q]])))
  }))
  platform_paired<-do.call(rbind,lapply(split(paired_long,interaction(paired_long$platform,paired_long$method,paired_long$metric,drop=TRUE)),function(z)
    data.frame(platform=z$platform[1],method=z$method[1],metric=z$metric[1],n_paired_strata=sum(is.finite(z$MCP_minus_comparator)),median_paired_MCP_minus_comparator=median(z$MCP_minus_comparator,na.rm=TRUE),MCP_wins=sum(z$MCP_minus_comparator>0,na.rm=TRUE),ties=sum(z$MCP_minus_comparator==0,na.rm=TRUE),comparator_wins=sum(z$MCP_minus_comparator<0,na.rm=TRUE))))
  ans<-list(per_stratum=per,per_dataset_platform_median_2DEA=ds,platform_primary_median_14strata=platform,legacy_seven_dataset_mean_summary=legacy_sm,legacy_MCC_paired_tests=tests,paired_within_stratum_all_metrics=paired_long,platform_median_paired_differences=platform_paired,
            universe_audit=do.call(rbind,audit),native_audit=do.call(rbind,native),p_combination=do.call(rbind,protein_p))
  if(write_files) {
    dir.create(out,recursive=TRUE,showWarnings=FALSE)
    for(nm in setdiff(names(ans),"p_combination")) write.csv(ans[[nm]],file.path(out,paste0(nm,".csv")),row.names=FALSE)
    con<-gzfile(file.path(out,"p_combination_protein_values.csv.gz"),"wt")
    write.csv(ans$p_combination,con,row.names=FALSE); close(con)
  }
  print(platform[c("platform","method","n_datasets","n_dataset_x_DEA_strata","precision","recall","mcc","f1","pauc001","pauc005","pauc01","auroc","ap")],row.names=FALSE)
  if(make_plots) {
    if(!requireNamespace("ggplot2",quietly=TRUE)) stop("数值分析已完成；绘图需要 ggplot2。可先 make_plots=FALSE。")
    ans$plots<-plot_r1c6_baselines(per,platform,out,save=write_files)
  }
  invisible(ans)
}

plot_r1c6_baselines <- function(per,platform_summary,out,save=TRUE) {
  facet_labels<-c(precision="Precision",recall="Recall",mcc="MCC",f1="F1",pauc001="pAUC(0.01)",pauc005="pAUC(0.05)",pauc01="pAUC(0.1)")
  labels<-c(MCP_full_DP_fdr="MCP (four-view)",Neural_early_fusion="Neural latent concatenation",
    Neural_late_fusion="Neural mean logits",Ridge_early_fusion="Ridge early fusion",
    Ridge_late_fusion="Ridge late fusion",Hurdle_operator="Matched-view hurdle operator",
    Statistical_union="Statistical union",Statistical_intersection="Statistical intersection",
    Mean_rank="Mean-rank aggregation",Bonferroni_minP_BH="Bonferroni-minP + BH",Bonferroni_minP_BY="Bonferroni-minP + BY")
  one<-function(metrics,methods,title) {
    d<-per[per$method %in% methods,]
    l<-do.call(rbind,lapply(metrics,function(m) data.frame(d[c("dataset","platform","dea","method")],metric=m,value=d[[m]])))
    l$method<-factor(l$method,levels=rev(methods)); l$metric<-factor(l$metric,levels=metrics,labels=unname(facet_labels[metrics]))
    l$platform<-factor(l$platform,levels=c("DIANN","Spectronaut"),labels=c("DIA-NN","Spectronaut"))
    avg<-platform_summary[platform_summary$method %in% methods,c("platform","method",metrics)]
    avg<-do.call(rbind,lapply(metrics,function(m) data.frame(platform=avg$platform,method=avg$method,metric=m,value=avg[[m]])))
    avg$metric<-factor(avg$metric,levels=metrics,labels=unname(facet_labels[metrics]))
    avg$platform<-factor(avg$platform,levels=c("DIANN","Spectronaut"),labels=c("DIA-NN","Spectronaut"))
    ggplot2::ggplot(l,ggplot2::aes(value,method))+
      ggplot2::geom_point(colour="grey65",size=1.35,alpha=.7,position=ggplot2::position_jitter(height=.12,width=0))+
      ggplot2::geom_point(data=avg,colour="#D55E00",size=2.8,shape=18)+
      ggplot2::facet_grid(platform~metric,scales="free_x")+ggplot2::scale_y_discrete(labels=labels)+
      ggplot2::labs(x="Dataset x DEA performance",y=NULL,title=title,
                    subtitle="Grey: 14 dataset x DEA strata/platform; orange: platform-specific median. Common four-view protein union.")+
      ggplot2::theme_classic(base_size=11)+ggplot2::theme(panel.spacing.x=grid::unit(.35,"cm"))
  }
  native<-setdiff(names(labels),c("Mean_rank","Bonferroni_minP_BY"))
  p1<-one(c("precision","recall","mcc","f1"),native,"Performance under method-specific calling rules")
  p2<-one(c("pauc001","pauc005","pauc01"),setdiff(names(labels),"Bonferroni_minP_BY"),"Standardized partial ROC AUC from saved scores")
  if(save) for(x in list(list(p=p1,n="r1c6_baseline_native_rules"),list(p=p2,n="r1c6_baseline_ranking"))) {
    ggplot2::ggsave(file.path(out,paste0(x$n,".pdf")),x$p,width=12.5,height=8.5)
    ggplot2::ggsave(file.path(out,paste0(x$n,".png")),x$p,width=12.5,height=8.5,dpi=300)
  }
  list(native=p1,ranking=p2)
}
