# Recompute fixed-view evidence from prediction CSVs.  Source() only defines
# recompute_fixedview_evidence(); it never reads files or writes output on load.
# Metrics use the union of proteins in compared runs. Missing predictions are
# deliberately scored as 0 and called non-DEP, rather than dropping proteins.

fixedview_auc <- function(y, score) {
  y <- as.integer(y); score <- as.numeric(score)
  n1 <- sum(y == 1L); n0 <- sum(y == 0L)
  if (!n1 || !n0) return(NA_real_)
  (sum(rank(score, ties.method = "average")[y == 1L]) - n1 * (n1 + 1) / 2) / (n1 * n0)
}

fixedview_ap <- function(y, score) {
  y <- as.integer(y); score <- as.numeric(score); n1 <- sum(y == 1L)
  if (!n1 || !sum(y == 0L)) return(NA_real_)
  o <- order(-score); y <- y[o]; score <- score[o]
  ends <- c(which(diff(score) != 0), length(score)); tp <- cumsum(y == 1L)[ends]
  recall <- tp / n1; precision <- tp / ends
  sum((recall - c(0, head(recall, -1))) * precision)
}

fixedview_pauc <- function(y, score, max_fpr) {
  # Tie-group ROC with boundary interpolation and McClish standardization.
  y <- as.integer(y); score <- as.numeric(score)
  n1 <- sum(y == 1L); n0 <- sum(y == 0L)
  if (!n1 || !n0) return(NA_real_)
  o <- order(-score); ys <- y[o]; ss <- score[o]
  ends <- c(which(diff(ss) != 0), length(ss)); tp <- cumsum(ys == 1L)[ends]; fp <- ends - tp
  tpr <- c(0, tp / n1); fpr <- c(0, fp / n0)
  i <- max(which(fpr <= max_fpr)); x <- fpr[seq_len(i)]; z <- tpr[seq_len(i)]
  if (tail(x, 1) < max_fpr) {
    z <- c(z, tpr[i] + (max_fpr - fpr[i]) * (tpr[i + 1L] - tpr[i]) / (fpr[i + 1L] - fpr[i]))
    x <- c(x, max_fpr)
  }
  area <- sum(diff(x) * (head(z, -1) + tail(z, -1)) / 2)
  .5 * (1 + (area - .5 * max_fpr^2) / (max_fpr - .5 * max_fpr^2))
}

fixedview_metrics <- function(y, score, called) {
  called <- as.logical(called); score <- as.numeric(score); y <- as.integer(y)
  tp <- sum(y == 1L & called); tn <- sum(y == 0L & !called)
  fp <- sum(y == 0L & called); fn <- sum(y == 1L & !called)
  precision <- if (tp + fp) tp / (tp + fp) else 0
  recall <- if (tp + fn) tp / (tp + fn) else 0
  f1 <- if (precision + recall) 2 * precision * recall / (precision + recall) else 0
  den <- sqrt(as.double(tp + fp) * as.double(tp + fn) * as.double(tn + fp) * as.double(tn + fn))
  data.frame(N_evaluated = length(y), N_true_DEP = sum(y == 1L), N_true_nonDEP = sum(y == 0L),
    tn = tn, fp = fp, fn = fn, tp = tp, precision = precision, recall = recall,
    MCC = if (den) (tp * tn - fp * fn) / den else 0, F1 = f1,
    AUROC = fixedview_auc(y, score), AP = fixedview_ap(y, score),
    pauc001 = fixedview_pauc(y, score, .01), pauc005 = fixedview_pauc(y, score, .05), pauc01 = fixedview_pauc(y, score, .1), check.names = FALSE)
}

fixedview_exact_signflip_p <- function(delta) {
  # Exact paired sign-flip test of mean MCC difference, matching the baseline R.
  x <- as.numeric(delta); stopifnot(length(x)==7L, all(is.finite(x)))
  signs <- as.matrix(expand.grid(rep(list(c(-1,1)), length(x))))
  null <- rowMeans(sweep(signs, 2, x, "*"))
  mean(abs(null) >= abs(mean(x)) - 1e-12)
}

fixedview_read <- function(path, method, run) {
  x <- read.csv(path, check.names = FALSE, stringsAsFactors = FALSE)
  need <- c("Protein", "True_lab", "DP_fdr_probability", "called_DP_fdr", "shared_full_log2fc", "DP_fdr_threshold")
  if (!all(need %in% names(x)) || anyDuplicated(x$Protein)) stop("Malformed prediction file: ", path)
  if (any(!is.finite(as.numeric(x$DP_fdr_probability))) ||
      any(!is.finite(as.numeric(x$shared_full_log2fc))) ||
      any(!is.finite(as.numeric(x$DP_fdr_threshold))) || anyNA(x$called_DP_fdr)) {
    stop("Present prediction has non-finite score/FC/threshold or missing call: ", path)
  }
  x <- x[, unique(c(need, intersect("fixed_pro_lab", names(x))))]
  names(x)[match("True_lab", names(x))] <- "truth"
  names(x)[match("DP_fdr_probability", names(x))] <- "score"
  names(x)[match("called_DP_fdr", names(x))] <- "called"
  x$truth <- as.integer(x$truth); x$score <- as.numeric(x$score); x$called <- as.logical(x$called)
  if (anyNA(x$truth) || any(!x$truth %in% c(0L, 1L))) stop("Invalid truth: ", path)
  x$method <- method; x$run <- run; x
}

fixedview_one_comparison <- function(runs, compare_id, label_audit = FALSE) {
  # runs: named list of data frames. Build the protein union then enforce one truth.
  ids <- sort(unique(unlist(lapply(runs, `[[`, "Protein"))))
  truth_rows <- do.call(rbind, lapply(runs, function(x) x[, c("Protein", "truth")]))
  truth_by_id <- split(truth_rows$truth, truth_rows$Protein)
  bad_truth <- vapply(truth_by_id, function(z) length(unique(z)) != 1L, logical(1))
  if (any(bad_truth)) stop("Truth disagreement in ", compare_id)
  truth <- as.integer(vapply(ids, function(id) truth_by_id[[id]][1], integer(1)))
  out <- do.call(rbind, lapply(names(runs), function(method) {
    x <- runs[[method]]; m <- match(ids, x$Protein)
    # Required policy applies only to proteins absent from a method's file.  A malformed
    # present row is rejected by fixedview_read(), never silently converted to non-DEP.
    score <- rep(0, length(ids)); called <- rep(FALSE, length(ids)); keep <- !is.na(m)
    score[keep] <- x$score[m[keep]]
    called[keep] <- x$called[m[keep]]
    z <- fixedview_metrics(truth, score, called); z$comparison_id <- compare_id; z$method <- method; z
  }))
  list(metrics = out, n_union = length(ids), label = if (label_audit) runs else NULL)
}

recompute_fixedview_evidence <- function(project_dir = "code/training", output_dir = "reference/Response/r1c6/manual_R_fixedview_results") {
  root <- file.path(project_dir, "revision_results")
  f4 <- file.path(root, "fixed4label_single_view_ablation")
  f3 <- file.path(root, "fixed3view_confirmatory")
  m4 <- read.csv(file.path(f4, "merged", "merged_prediction_manifest.csv"), stringsAsFactors = FALSE)
  m3 <- read.csv(file.path(f3, "merged", "comparison_prediction_manifest.csv"), stringsAsFactors = FALSE)
  l4 <- read.csv(file.path(f4, "merged", "merged_core_run_ledger.csv"), stringsAsFactors = FALSE)
  l3 <- read.csv(file.path(f3, "merged", "merged_new_core_run_ledger.csv"), stringsAsFactors = FALSE)
  dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)
  resolve4 <- function(rel) file.path(f4, rel)
  resolve3 <- function(manifest_path) {
    run <- basename(dirname(manifest_path))
    shard <- l3$shard_id[match(run, l3$run_id)]
    if (is.na(shard)) stop("No fixed3 ledger row for ", run)
    file.path(f3, "shards", paste0("shard_", shard), "runs", run, "fixed3view_DP_fdr_predictions.csv")
  }
  # Fixed4: full plus each fixed-label single view.  There are 7x2x2x5 = 140 runs.
  key4 <- interaction(m4$data_index, m4$platform, m4$dea_method, drop = TRUE)
  r4 <- list(); details <- list()
  for (key in unique(key4)) {
    a <- m4[key4 == key, ]; if (nrow(a) != 5L || !setequal(a$model_input_views, c("all4", "dlfq", "maxlfq", "top3", "top1"))) stop("Unexpected fixed4 set: ", key)
    rr <- setNames(lapply(seq_len(nrow(a)), function(i) fixedview_read(resolve4(a$prediction_file_relative[i]), a$model_input_views[i], a$run_id[i])), a$model_input_views)
    ans <- fixedview_one_comparison(rr, paste(a$data_index[1], a$platform[1], a$dea_method[1], sep = "|")); r4[[key]] <- ans$metrics
    details[[key]] <- data.frame(comparison_id = ans$metrics$comparison_id[1], data_index = a$data_index[1], dataset = a$dataset[1], platform = a$platform[1], dea_method = a$dea_method[1], N_union = ans$n_union)
  }
  raw4 <- do.call(rbind, r4); detail4 <- do.call(rbind, details)
  # Fixed3 manifest comparison: dlfq+maxlfq+top3 versus corresponding fixed4 all4 control.
  three <- "three_view_mcp_dlfq_maxlfq_top3"; raw3 <- list(); label_audit <- list(); i <- 0L
  for (key in unique(interaction(m3$data_index, m3$platform, m3$dea_method, drop = TRUE))) {
    a <- m3[interaction(m3$data_index, m3$platform, m3$dea_method, drop = TRUE) == key, ]
    if (nrow(a) != 2L || !setequal(a$method, c(three, "four_view_mcp"))) stop("Unexpected fixed3 pair: ", key)
    xs <- list(); for (method in names(xs <- setNames(vector("list", 2), a$method))) {
      row <- a[a$method == method, ]; path <- if (method == three) resolve3(row$prediction_file[1]) else resolve4(sub(".*fixed4label_single_view_ablation/(.*)$", "\\1", row$prediction_file[1]))
      xs[[method]] <- fixedview_read(path, method, if (method == three) basename(dirname(path)) else row$prediction_file[1])
    }
    ans <- fixedview_one_comparison(xs, paste(a$data_index[1], a$platform[1], a$dea_method[1], sep = "|")); i <- i + 1L; raw3[[i]] <- ans$metrics
    common <- merge(xs[[three]][, intersect(c("Protein", "fixed_pro_lab"), names(xs[[three]]))], xs[["four_view_mcp"]][, intersect(c("Protein", "fixed_pro_lab"), names(xs[["four_view_mcp"]]))], by = "Protein", suffixes = c("_three", "_four"))
    same <- if (all(c("fixed_pro_lab_three", "fixed_pro_lab_four") %in% names(common))) sum(common$fixed_pro_lab_three == common$fixed_pro_lab_four, na.rm = TRUE) else NA_integer_
    label_audit[[i]] <- data.frame(comparison_id = ans$metrics$comparison_id[1], data_index = a$data_index[1], dataset = a$dataset[1], platform = a$platform[1], dea_method = a$dea_method[1], three_view = "dlfq+maxlfq+top3", four_view = "dlfq+maxlfq+top3+top1", N_common_proteins = nrow(common), N_same_fixed_pro_lab = same, fixed_pro_lab_identical = if (is.na(same)) NA else same == nrow(common), three_manifest_path = a$prediction_file[a$method == three][1], four_manifest_path = a$prediction_file[a$method == "four_view_mcp"][1])
  }
  raw3 <- do.call(rbind, raw3); labels <- do.call(rbind, label_audit)
  # Ledger fingerprints are a second, run-level label identity check (raw fixed_pro_lab
  # identity above is the protein-level check).  The fixed4 control is declared by run ID.
  label_fp <- l3[, c("run_id", "fixed4_control_run_id", "label_fingerprint", "training_label_fingerprint")]
  names(label_fp)[c(1, 3, 4)] <- c("three_run_id", "three_label_fingerprint", "three_training_label_fingerprint")
  control_fp <- l4[, c("run_id", "label_fingerprint", "training_label_fingerprint")]
  names(control_fp) <- c("fixed4_control_run_id", "four_label_fingerprint", "four_training_label_fingerprint")
  label_fp <- merge(label_fp, control_fp, by = "fixed4_control_run_id", all.x = TRUE)
  label_fp$fingerprint_identical <- label_fp$three_label_fingerprint == label_fp$four_label_fingerprint
  label_fp$training_fingerprint_identical <- label_fp$three_training_label_fingerprint == label_fp$four_training_label_fingerprint
  labels$three_run_id <- basename(dirname(labels$three_manifest_path))
  labels <- merge(labels, label_fp, by = "three_run_id", all.x = TRUE)
  fixed4_label_audit <- aggregate(label_fingerprint ~ data_index + dataset + platform + dea_method,
    data = m4, FUN = function(x) length(unique(x)))
  names(fixed4_label_audit)[5] <- "N_distinct_label_fingerprints_among_all4_and_4_singles"
  add_dataset_and_summary <- function(raw, detail) {
    raw <- merge(raw, detail[, c("comparison_id", "data_index", "dataset", "platform", "dea_method")], by = "comparison_id", all.x = TRUE)
    metric_cols <- c("precision", "recall", "MCC", "F1", "AUROC", "AP", "pauc001", "pauc005", "pauc01")
    # Diagnostic level: explicit median of the two DEA values in each dataset/platform.
    ds <- aggregate(raw[metric_cols], raw[c("data_index", "dataset", "platform", "method")], median, na.rm = TRUE)
    ds$N_DEA_strata <- 2L
    # Primary estimand: platform-specific median of 7 dataset x 2 DEA strata.
    platform <- aggregate(raw[metric_cols], raw[c("platform", "method")], median, na.rm = TRUE)
    platform$N_dataset_x_DEA_strata <- 14L
    platform$N_datasets <- 7L
    # These legacy mean quantities are retained only as labelled diagnostics; do not use
    # their p-values as inference for the platform-median estimand.
    legacy_ds <- aggregate(raw[metric_cols], raw[c("data_index", "dataset", "method")], mean, na.rm = TRUE)
    legacy_sm <- aggregate(legacy_ds[metric_cols], legacy_ds["method"], mean, na.rm = TRUE); legacy_sm$N_datasets <- 7L
    list(raw = raw, dataset = ds, platform = platform, legacy_dataset = legacy_ds, legacy_summary = legacy_sm, metrics = metric_cols)
  }
  z4 <- add_dataset_and_summary(raw4, detail4)
  detail3 <- unique(labels[c("comparison_id", "data_index", "dataset", "platform", "dea_method")]); z3 <- add_dataset_and_summary(raw3, detail3)
  write.csv(z4$raw, file.path(output_dir, "fixed4_raw_config_metrics_common_union.csv"), row.names = FALSE)
  write.csv(z4$dataset, file.path(output_dir, "fixed4_per_dataset_platform_median_2DEA.csv"), row.names = FALSE)
  write.csv(z4$platform, file.path(output_dir, "fixed4_platform_primary_median_14strata.csv"), row.names = FALSE)
  write.csv(z4$legacy_summary, file.path(output_dir, "legacy_fixed4_equal_seven_dataset_mean_summary.csv"), row.names = FALSE)
  write.csv(z3$raw, file.path(output_dir, "fixed3_vs_fixed4_raw_config_metrics_common_union.csv"), row.names = FALSE)
  write.csv(z3$dataset, file.path(output_dir, "fixed3_vs_fixed4_per_dataset_platform_median_2DEA.csv"), row.names = FALSE)
  write.csv(z3$platform, file.path(output_dir, "fixed3_vs_fixed4_platform_primary_median_14strata.csv"), row.names = FALSE)
  write.csv(z3$legacy_summary, file.path(output_dir, "legacy_fixed3_vs_fixed4_equal_seven_dataset_mean_summary.csv"), row.names = FALSE)
  write.csv(labels, file.path(output_dir, "fixed3_vs_fixed4_label_identity_audit.csv"), row.names = FALSE)
  write.csv(fixed4_label_audit, file.path(output_dir, "fixed4_within_configuration_label_fingerprint_audit.csv"), row.names = FALSE)
  # Legacy n=7 mean-based MCC contrasts are segregated from the new median analysis.
  mcc4 <- z4$legacy_dataset[z4$legacy_dataset$method == "all4", c("data_index", "dataset", "MCC")]
  names(mcc4)[3] <- "MCC_all4"
  candidates <- rbind(
    transform(z4$legacy_dataset[z4$legacy_dataset$method != "all4", c("data_index", "dataset", "method", "MCC")], contrast = paste0("all4_minus_", method)),
    transform(z3$legacy_dataset[z3$legacy_dataset$method == three, c("data_index", "dataset", "method", "MCC")], contrast = "all4_minus_three_view_dlfq_maxlfq_top3")
  )
  paired_mcc <- merge(candidates, mcc4, by = c("data_index", "dataset"), all.x = TRUE)
  paired_mcc$delta_MCC_all4_minus_comparator <- paired_mcc$MCC_all4 - paired_mcc$MCC
  paired_summary <- do.call(rbind, lapply(split(paired_mcc, paired_mcc$contrast), function(d) {
    x <- d$delta_MCC_all4_minus_comparator
    data.frame(contrast = d$contrast[1], N_paired_datasets = sum(is.finite(x)),
      mean_delta_MCC_all4_minus_comparator = mean(x, na.rm = TRUE), median_delta_MCC_all4_minus_comparator = median(x, na.rm = TRUE),
      N_all4_better = sum(x > 0, na.rm = TRUE), N_ties = sum(x == 0, na.rm = TRUE), N_comparator_better = sum(x < 0, na.rm = TRUE),
      exact_signflip_p = fixedview_exact_signflip_p(x))
  }))
  paired_summary$holm_p_across_5_input_contrasts <- p.adjust(paired_summary$exact_signflip_p, method = "holm")
  write.csv(paired_mcc, file.path(output_dir, "legacy_exploratory_paired_dataset_mean_MCC_all4_minus_comparator.csv"), row.names = FALSE)
  write.csv(paired_summary, file.path(output_dir, "legacy_exploratory_paired_mean_MCC_all4_minus_comparator_summary.csv"), row.names = FALSE)
  # Primary paired comparisons stay at the dataset x platform x DEA stratum (14/platform).
  # The reported median is the median of paired deltas, not a difference of medians.
  ref_raw <- z4$raw[z4$raw$method == "all4", c("data_index", "dataset", "platform", "dea_method", z4$metrics)]
  comparators <- rbind(
    transform(z4$raw[z4$raw$method != "all4", c("data_index", "dataset", "platform", "dea_method", "method", z4$metrics)], contrast_method = method),
    transform(z3$raw[z3$raw$method == three, c("data_index", "dataset", "platform", "dea_method", "method", z3$metrics)], contrast_method = method)
  )
  paired_all <- do.call(rbind, lapply(split(comparators, comparators$contrast_method), function(d) {
    rr <- ref_raw[match(do.call(paste, d[c("data_index", "platform", "dea_method")]), do.call(paste, ref_raw[c("data_index", "platform", "dea_method")])), ]
    do.call(rbind, lapply(z4$metrics, function(metric) data.frame(data_index=d$data_index, dataset=d$dataset, platform=d$platform, dea_method=d$dea_method, comparator=d$contrast_method, metric=metric, all4_minus_comparator=rr[[metric]]-d[[metric]])))
  }))
  paired_platform <- do.call(rbind, lapply(split(paired_all, interaction(paired_all$platform, paired_all$comparator, paired_all$metric, drop=TRUE)), function(d)
    data.frame(platform=d$platform[1], comparator=d$comparator[1], metric=d$metric[1], n_paired_strata=sum(is.finite(d$all4_minus_comparator)), median_paired_all4_minus_comparator=median(d$all4_minus_comparator, na.rm=TRUE), all4_wins=sum(d$all4_minus_comparator>0,na.rm=TRUE), ties=sum(d$all4_minus_comparator==0,na.rm=TRUE), comparator_wins=sum(d$all4_minus_comparator<0,na.rm=TRUE))))
  write.csv(paired_all, file.path(output_dir, "paired_within_stratum_all_metrics_all4_minus_comparator.csv"), row.names = FALSE)
  write.csv(paired_platform, file.path(output_dir, "platform_median_paired_differences_win_loss_counts.csv"), row.names = FALSE)
  run_audit <- data.frame(experiment = c("fixed4label_single_view_ablation", "fixed3view_confirmatory"), manifest_runs = c(nrow(m4), sum(l3$status %in% c("completed", "skipped_existing"))), expected_runs = c(140L, 28L), unique_run_ids = c(length(unique(m4$run_id)), length(unique(l3$run_id))), test_type = c(paste(unique(m4$test_type), collapse = ";"), paste(unique(l3$test_type), collapse = ";")), label_modes = c(paste(unique(m4$label_mode), collapse = ";"), paste(unique(l3$label_mode), collapse = ";")))
  write.csv(run_audit, file.path(output_dir, "design_and_run_audit.csv"), row.names = FALSE)
  invisible(list(fixed4 = z4, fixed3 = z3, labels = labels, run_audit = run_audit))
}

# Optional ggplot2 figure; call after x <- recompute_fixedview_evidence().
plot_fixedview_evidence <- function(x, output_dir, save=TRUE) {
  stopifnot(requireNamespace("ggplot2", quietly=TRUE))
  d <- x$fixed4$raw
  metrics <- c("pauc001","pauc005","pauc01")
  long <- do.call(rbind,lapply(metrics,function(m)
    data.frame(dataset=d$dataset,platform=d$platform,dea_method=d$dea_method,method=d$method,metric=m,value=d[[m]])))
  long$method <- factor(long$method,levels=c("all4","dlfq","maxlfq","top3","top1"))
  long$metric <- factor(long$metric,levels=metrics,labels=c(pauc001="pAUC(0.01)",pauc005="pAUC(0.05)",pauc01="pAUC(0.1)"))
  long$platform <- factor(long$platform,levels=c("DIANN","Spectronaut"),labels=c("DIA-NN","Spectronaut"))
  avg <- x$fixed4$platform[,c("platform","method",metrics)]
  avg <- do.call(rbind,lapply(metrics,function(m) data.frame(platform=avg$platform,method=avg$method,metric=m,value=avg[[m]])))
  avg$metric <- factor(avg$metric,levels=metrics,labels=c(pauc001="pAUC(0.01)",pauc005="pAUC(0.05)",pauc01="pAUC(0.1)"))
  avg$platform <- factor(avg$platform,levels=c("DIANN","Spectronaut"),labels=c("DIA-NN","Spectronaut"))
  p <- ggplot2::ggplot(long,ggplot2::aes(method,value,group=interaction(dataset,dea_method)))+
    ggplot2::geom_line(colour="grey75",linewidth=.35)+
    ggplot2::geom_point(colour="grey55",size=1.3)+
    ggplot2::geom_point(data=avg,ggplot2::aes(group=NULL),colour="#D55E00",shape=18,size=3)+
    ggplot2::facet_grid(platform~metric)+
    ggplot2::scale_x_discrete(labels=c(all4="MCP (four-view)",dlfq="MCP dlfq",maxlfq="MCP maxLFQ",top3="MCP top3",top1="MCP top1"))+
    ggplot2::labs(x="MCP input views",y="Dataset x DEA performance",
      title="Fixed four-view supervision: input-view ablation",
      subtitle="Grey: 14 dataset x DEA strata/platform; orange: platform median. Labels and fold-change reference held fixed.")+
    ggplot2::theme_classic(base_size=10)+ggplot2::theme(panel.spacing.x=grid::unit(.35,"cm"))+
    ggplot2::theme(axis.text.x=ggplot2::element_text(angle=45,hjust=1))
  if(save) {
    dir.create(output_dir,recursive=TRUE,showWarnings=FALSE)
    for(ext in c("pdf","png")) ggplot2::ggsave(file.path(output_dir,paste0("r1c6_fixed_label_inputs_pauc.",ext)),p,width=11,height=8,dpi=300)
  }
  p
}
