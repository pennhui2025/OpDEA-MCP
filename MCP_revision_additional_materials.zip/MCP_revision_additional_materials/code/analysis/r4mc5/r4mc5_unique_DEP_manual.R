# R4 Major comment 5: characterize MCP-unique DEPs from saved original results.
# source() only defines functions. Run run_r4mc5() manually in RStudio.
# No model training, new DEA fitting, package installation, or source-file changes.
# MCP = final DP_fdr block; never use DP_direct / a universal 0.5 threshold.

run_r4mc5 <- function(
  source_manifest = "reference/Response/r4mc5/source_inputs.csv",
  out = "reference/Response/r4mc5/manual_R_check",
  write_files = TRUE
) {
  views <- c("dlfq", "maxlfq", "top3", "top1")
  algorithms <- c("limma", "ROTS", "SAM")
  cutoff <- log2(1.5)
  mf <- read.csv(source_manifest, stringsAsFactors = FALSE)
  stopifnot(nrow(mf) == 84L)
  if(write_files) dir.create(out, recursive = TRUE, showWarnings = FALSE)
  med <- function(x) {x <- x[is.finite(x)]; if(length(x)) median(x) else NA_real_}
  pct <- function(x) {rank(x, ties.method = "average", na.last = "keep") / sum(is.finite(x))}
  id_check <- function(x) stopifnot(!anyNA(x), all(nzchar(x)), !anyDuplicated(x))
  one_file <- function(pattern) {p <- Sys.glob(pattern); stopifnot(length(p) == 1L); p}
  sources <- list()
  record <- function(path, dataset, platform, kind) {
    sources[[length(sources)+1L]] <<- data.frame(dataset, platform, kind,
      path = normalizePath(path, winslash = "/", mustWork = TRUE), md5 = unname(tools::md5sum(path)))
  }
  read_csv <- function(path, dataset, platform, kind, ...) {
    record(path, dataset, platform, kind)
    read.csv(path, stringsAsFactors = FALSE, check.names = TRUE, ...)
  }
  read_tsv <- function(path, dataset, platform, kind) {
    record(path, dataset, platform, kind)
    read.delim(path, stringsAsFactors = FALSE, check.names = FALSE)
  }
  features <- stat_summary <- group_counts <- protein_rows <- audit <- stat_audit <- list()
  groups <- c("MCP_unique_all12", "MCP_shared_all3_algorithms", "MCP_shared_all12",
              "MCP_unique_matched4", "MCP_shared_matched4", "MCP_overlap_any12")
  feature_names <- c("mean_abundance_percentile", "mean_variance_percentile", "mean_missing_fraction",
                     "fraction_views_without_observed_abundance", "mcp_abs_log2FC")
  # Primary: unique vs none of 12 baselines; shared = MCP + all THREE DEA algorithms,
  # each algorithm may detect the protein in >=1 of the four views.
  # Stricter shared-all12 and matched-initialization-DEA definitions are sensitivities.
  for(platform in c("DIANN", "Spectronaut")) for(dataset in sort(unique(mf$dataset))) {
    message("Reading ", platform, " / ", dataset)
    mm <- mf[mf$platform == platform & mf$dataset == dataset, ]
    stopifnot(nrow(mm) == 6L)
    model <- stats <- matrices <- list(); truth_parts <- list()
    bases <- list()
    for(dea in c("limma", "ROTS")) {
      path <- mm$source_file[mm$method == paste0("MCP_", dea)]
      stopifnot(length(path) == 1L)
      bases[[dea]] <- dirname(dirname(path))
      d <- read_csv(path, dataset, platform, paste0("MCP_", dea))
      id_check(d$Protein); stopifnot(all(d$True_lab %in% 0:1))
      truth_parts[[length(truth_parts)+1L]] <- data.frame(id=d$Protein, truth=d$True_lab)
      b <- d[!is.na(d$Protein.4) & nzchar(d$Protein.4),
             c("Protein.4", "Probability.3", "ori_logFC.3", "threshold.3")]
      names(b) <- c("id", "score", "fc", "threshold")
      id_check(b$id); stopifnot(all(b$id %in% d$Protein), all(is.finite(b$score)), !anyNA(b$fc),
                               length(unique(b$threshold))==1L, all(is.finite(b$threshold)))
      b$call <- b$score >= b$threshold & abs(b$fc) >= cutoff
      model[[dea]] <- b
    }
    # Read all 12 native DEA outputs; p-values remain p-values, not q/FDR values.
    for(algorithm in algorithms) for(view in views) {
      if(algorithm == "SAM") {
        path <- mm$source_file[mm$method == paste0("SAM_", view)]
      } else {
        path <- one_file(file.path(bases[[algorithm]], "DEA_res", paste0(dataset, "union"),
                  paste0(dataset, "union_", algorithm, "_*_", view, "__.csv")))
      }
      d <- read_csv(path, dataset, platform, paste0(algorithm, "_", view), row.names=1)
      id_check(d$protein)
      stopifnot(all(d$label %in% 0:1), all(is.finite(d$pvalue)), !anyNA(d$logFC))
      invalid_p <- d$pvalue < 0 | d$pvalue > 1
      # Some archived SAM permutation estimates slightly exceed 1.
      # Preserve the saved values and audit them; exclude invalid values from p summaries.
      # Native SAM calls are unchanged and do not depend on this descriptive field.
      if(algorithm != "SAM")stopifnot(!any(invalid_p))
      stat_audit[[length(stat_audit)+1L]] <- data.frame(dataset,platform,algorithm,view,
        n_rows=nrow(d),n_p_out_of_range=sum(invalid_p),max_saved_p=max(d$pvalue),
        invalid_p_proteins=paste(d$protein[invalid_p],collapse=";"))
      p_for_summary<-d$pvalue;p_for_summary[invalid_p]<-NA_real_
      truth_parts[[length(truth_parts)+1L]] <- data.frame(id=d$protein, truth=as.integer(d$label))
      if(algorithm == "SAM") {
        native <- tolower(as.character(d$SAM.significant)) %in% c("true", "t", "1")
        stopifnot(all(d$SAM.delta.FDR[native] <= .05 + 1e-12))
        q <- rep(NA_real_, nrow(d)) # SAM delta-level FDR is NOT a protein-specific q value.
      } else {
        q <- as.numeric(d$adj.pvalue)
        stopifnot(all(is.finite(q)), all(q >= 0 & q <= 1))
        native <- q <= .05
      }
      stats[[paste(algorithm, view, sep="_")]] <- data.frame(id=d$protein, p=p_for_summary,p_saved=d$pvalue,
        q=q, fc=d$logFC, call=native & abs(d$logFC) >= cutoff,
        statistic=if(algorithm=="SAM") d$SAM.score else NA_real_,
        delta_fdr=if(algorithm=="SAM") d$SAM.delta.FDR else NA_real_)
    }
    # Pre-imputation quantitative properties. Zeros ARE missing in this pipeline.
    # Restore the raw missingness mask even if a normalized file contains imputed values.
    base <- bases$limma
    design_path <- one_file(file.path(base, "dt", paste0(dataset, "_*_design.tsv")))
    design <- read_tsv(design_path, dataset, platform, "design")
    # Comparison uses the exact two conditions in the archived limma contrast.
    contrast_file <- one_file(file.path(base, "DEA_res", paste0(dataset,"union"),
                                         paste0(dataset,"union_limma_*_dlfq__.csv")))
    contrast <- unique(read.csv(contrast_file, stringsAsFactors=FALSE)$contrast)
    stopifnot(length(contrast)==1L)
    contrast_groups <- sub("^condition", "", strsplit(contrast, "-", fixed=TRUE)[[1]])
    stopifnot(length(contrast_groups)==2L)
    idx <- lapply(contrast_groups, function(g) which(as.character(design$condition)==g))
    stopifnot(all(lengths(idx)>=2L))
    union_order <- NULL
    for(i in seq_along(views)) {
      view <- views[i]
      upath <- one_file(file.path(base, sprintf("real_normed_v%d_union_%s_*_%s.tsv", i-1, dataset, view)))
      raw_path <- file.path(base, sprintf("%s_raw_view%d_union.csv", dataset, i-1))
      norm_path <- file.path(base, sprintf("%s_normed_view%d_union.csv", dataset, i-1))
      u <- read_tsv(upath, dataset, platform, paste0("protein_order_",view)); id_check(u$Protein)
      if(is.null(union_order)) union_order <- u$Protein
      stopifnot(identical(u$Protein,union_order))
      raw <- as.matrix(read_csv(raw_path, dataset, platform, paste0("raw_",view), header=FALSE))
      norm <- as.matrix(read_csv(norm_path, dataset, platform, paste0("normed_",view), header=FALSE))
      stopifnot(nrow(raw)==nrow(u), identical(dim(raw),dim(norm)), ncol(raw)==nrow(design))
      # The limma/ROTS branches should share the same saved quantitative input.
      raw2_path <- file.path(bases$ROTS, basename(raw_path))
      raw2 <- as.matrix(read_csv(raw2_path, dataset, platform, paste0("ROTS_raw_check_",view),header=FALSE))
      stopifnot(isTRUE(all.equal(raw,raw2,tolerance=1e-12,check.attributes=FALSE)))
      norm2_path <- file.path(bases$ROTS, basename(norm_path))
      norm2 <- as.matrix(read_csv(norm2_path,dataset,platform,paste0("ROTS_norm_check_",view),header=FALSE))
      stopifnot(isTRUE(all.equal(norm,norm2,tolerance=1e-12,check.attributes=FALSE)))
      use <- c(idx[[1]],idx[[2]])
      miss <- !is.finite(raw) | raw==0
      norm[miss] <- NA_real_
      # Variance is within condition, not variance across differing group means.
      n1 <- rowSums(is.finite(norm[,idx[[1]],drop=FALSE]))
      n2 <- rowSums(is.finite(norm[,idx[[2]],drop=FALSE]))
      variance <- function(x) if(sum(is.finite(x))>=2) var(x[is.finite(x)]) else NA_real_
      v1 <- apply(norm[,idx[[1]],drop=FALSE],1,variance)
      v2 <- apply(norm[,idx[[2]],drop=FALSE],1,variance)
      vv <- ((n1-1)*v1+(n2-1)*v2)/(n1+n2-2)
      vv[n1<2 | n2<2] <- NA_real_ # Do not infer low variance from one observation.
      abundance <- apply(norm[,use,drop=FALSE],1,med)
      matrices[[view]] <- data.frame(id=u$Protein,
        abundance_log2=abundance, abundance_pct=pct(abundance), variance=vv, variance_pct=pct(vv),
        missing=rowMeans(miss[,use,drop=FALSE]), n_group1=n1,n_group2=n2)
      # Use organism annotations only to extend gold-standard truth to saved union rows.
      known <- unique(do.call(rbind,truth_parts)); id_check(known$id)
      known_y <- known$truth[match(u$Protein,known$id)]
      org <- unique(data.frame(org=u$Organism,y=known_y)); org <- org[!is.na(org$y),]
      id_check(org$org)
      uy <- org$y[match(u$Organism,org$org)]; stopifnot(!anyNA(uy))
      truth_parts[[length(truth_parts)+1L]] <- data.frame(id=u$Protein,truth=uy)
      audit[[length(audit)+1L]] <- data.frame(dataset,platform,view,n_proteins=nrow(u),
        n_samples=length(use),n_raw_zeros=sum(raw[,use,drop=FALSE]==0,na.rm=TRUE),
        n_raw_nonfinite=sum(!is.finite(raw[,use,drop=FALSE])),
        n_proteins_variance_unavailable=sum(!is.finite(vv)),
        n_proteins_abundance_unavailable=sum(!is.finite(abundance)))
    }
    truth <- unique(do.call(rbind,truth_parts));id_check(truth$id)
    ids <- truth$id; n <- length(ids)
    aligned <- function(b,field) b[[field]][match(ids,b$id)]
    stat_call <- sapply(stats, function(b) {z<-aligned(b,"call");z[is.na(z)]<-FALSE;z})
    any_by_algorithm <- sapply(algorithms,function(a)rowSums(stat_call[,paste(a,views,sep="_"),drop=FALSE])>0)
    qmat <- lapply(c("abundance_pct","variance_pct","missing"),function(k)
      sapply(matrices, aligned, field=k))
    average <- function(m) {v<-rowMeans(m,na.rm=TRUE);v[!is.finite(v)]<-NA_real_;v}
    quality <- data.frame(id=ids,truth=truth$truth,mean_abundance_percentile=average(qmat[[1]]),
      mean_variance_percentile=average(qmat[[2]]),mean_missing_fraction=average(qmat[[3]]),
      fraction_views_without_observed_abundance=rowMeans(!is.finite(qmat[[1]])),
      n_variance_views=rowSums(is.finite(qmat[[2]])),n_abundance_views=rowSums(is.finite(qmat[[1]])))
    # New group definitions are set before inspecting the results.
    for(init in c("limma","ROTS")) {
      b <- model[[init]]; mcp <- aligned(b,"call");mcp[is.na(mcp)]<-FALSE
      fc <- aligned(b,"fc");quality$mcp_abs_log2FC<-abs(fc)
      k <- rowSums(stat_call[,paste(init,views,sep="_"),drop=FALSE])
      masks <- list(MCP_unique_all12=mcp & rowSums(stat_call)==0,
        MCP_shared_all3_algorithms=mcp & rowSums(any_by_algorithm)==3,
        MCP_shared_all12=mcp & rowSums(stat_call)==12,
        MCP_unique_matched4=mcp & k==0, MCP_shared_matched4=mcp & k==4,
        MCP_overlap_any12=mcp & rowSums(stat_call)>0)
      for(group in groups) {
        take <- masks[[group]]
        group_counts[[length(group_counts)+1L]] <- data.frame(dataset,platform,initialization=init,group,
          n_union=n,n_mcp=sum(mcp),n_group=sum(take),n_true=sum(truth$truth[take]),
          truth_fraction=if(sum(take))mean(truth$truth[take]) else NA_real_)
        for(metric in feature_names) {
          v <- quality[[metric]][take]; finite <- is.finite(v)
          features[[length(features)+1L]] <- data.frame(dataset,platform,initialization=init,group,metric,
            n_group=sum(take),n_valid=sum(finite),median=med(v),
            q25=if(any(finite))quantile(v[finite],.25,names=FALSE) else NA_real_,
            q75=if(any(finite))quantile(v[finite],.75,names=FALSE) else NA_real_)
        }
        for(algorithm in algorithms) for(view in views) {
          s <- stats[[paste(algorithm,view,sep="_")]]
          for(field in c("p","q","fc")) {
            if(algorithm=="SAM" && field=="q") next
            v <- aligned(s,field)[take];if(field=="fc")v<-abs(v)
            ok<-is.finite(v)
            stat_summary[[length(stat_summary)+1L]] <- data.frame(dataset,platform,initialization=init,group,
              algorithm,view,metric=c(p="raw_pvalue",q="native_adjusted_value",fc="abs_log2FC")[[field]],
              n_group=sum(take),n_available=sum(ok),n_infinite=sum(is.infinite(v)),
              median=med(v),q25=if(any(ok))quantile(v[ok],.25,names=FALSE) else NA_real_,
              q75=if(any(ok))quantile(v[ok],.75,names=FALSE) else NA_real_)
          }
        }
      }
      # Complete protein table, including membership flags and unmodified continuous evidence.
      pr <- data.frame(dataset,platform,initialization=init,quality,mcp_call=mcp,
        mcp_log2FC=fc,mcp_score=aligned(b,"score"),mcp_threshold=aligned(b,"threshold"),masks,check.names=FALSE)
      for(view in views)for(field in c("abundance_log2","variance","missing","n_group1","n_group2"))
        pr[[paste(view,field,sep="_")]]<-aligned(matrices[[view]],field)
      for(name in names(stats))for(field in c("p","p_saved","q","fc","call","statistic","delta_fdr")) {
        if(!startsWith(name,"SAM_") && field %in% c("statistic","delta_fdr"))next
        if(startsWith(name,"SAM_") && field=="q")next
        z<-aligned(stats[[name]],field);if(field=="call")z[is.na(z)]<-FALSE
        pr[[paste(name,field,sep="_")]]<-z
      }
      # Limit the protein supplement to called MCP proteins; group comparison concerns these proteins.
      protein_rows[[length(protein_rows)+1L]] <- pr[mcp,,drop=FALSE]
    }
  }
  counts <- do.call(rbind,group_counts);feats <- do.call(rbind,features);ss <- do.call(rbind,stat_summary)
  # Every empty group remains in the tables. No sparse stratum is silently dropped.
  stopifnot(nrow(counts)==28L*length(groups),nrow(feats)==28L*length(groups)*length(feature_names))
  summarize <- function(d,keys,value="median") {
    blocks <- split(d,interaction(d[keys],drop=TRUE,lex.order=TRUE))
    do.call(rbind,lapply(blocks,function(z) {
      v<-z[[value]];ok<-is.finite(v)
      data.frame(z[1,keys,drop=FALSE],n_records=nrow(z),n_available=sum(ok),
        median=med(v),q25=if(any(ok))quantile(v[ok],.25,names=FALSE) else NA_real_,
        q75=if(any(ok))quantile(v[ok],.75,names=FALSE) else NA_real_)
    }))
  }
  # Primary descriptive table: medians across 14 dataset x initialization records per platform.
  # Also export seven-dataset summaries and paired differences; no protein-level tests.
  fp <- summarize(feats,c("platform","group","metric"))
  sp <- summarize(ss,c("platform","group","algorithm","view","metric"))
  cp <- do.call(rbind,lapply(c("n_group","truth_fraction"),function(m) {
    z<-summarize(counts,c("platform","group"),m);z$metric<-m;z
  }))
  fd <- summarize(feats,c("dataset","platform","group","metric"))
  pair_keys <- c("dataset","platform","initialization","metric")
  unique_group <- feats[feats$group=="MCP_unique_all12",c(pair_keys,"median")]
  common <- feats[feats$group=="MCP_shared_all3_algorithms",c(pair_keys,"median")]
  pair_strata <- merge(unique_group,common,by=pair_keys,suffixes=c("_unique","_shared"))
  pair_strata$difference<-pair_strata$median_unique-pair_strata$median_shared
  pair <- summarize(pair_strata,c("dataset","platform","metric"),"difference")
  names(pair)[names(pair)=="median"] <- "median_paired_difference"
  names(pair)[names(pair)=="n_available"] <- "n_complete_pairs"
  # A separate 7-dataset table also collapses platforms; do not treat platforms/DEAs as replicates.
  fd7 <- summarize(fd,c("dataset","group","metric"))
  pair7 <- summarize(pair,c("dataset","metric"),"median_paired_difference")
  names(pair7)[names(pair7)=="median"] <- "median_paired_difference"
  names(pair7)[names(pair7)=="n_available"] <- "n_available_platforms"
  complete_pairs <- aggregate(n_complete_pairs ~ dataset+metric,pair,sum)
  pair7 <- merge(pair7,complete_pairs,by=c("dataset","metric"))
  result <- list(group_counts=counts,quality_by_stratum=feats,quality_platform_medians=fp,
    statistics_by_stratum=ss,statistics_platform_medians=sp,count_platform_medians=cp,
    quality_by_dataset_platform=fd,paired_stratum_differences=pair_strata,paired_dataset_platform_differences=pair,
    quality_by_seven_datasets=fd7,paired_seven_dataset_differences=pair7,input_audit=do.call(rbind,audit),
    statistics_input_audit=do.call(rbind,stat_audit),
    source_manifest=unique(do.call(rbind,sources)))
  if(write_files) {
    for(name in names(result))write.csv(result[[name]],file.path(out,paste0(name,".csv")),row.names=FALSE,na="")
    con<-gzfile(file.path(out,"MCP_called_protein_evidence.csv.gz"),"wt")
    write.csv(do.call(rbind,protein_rows),con,row.names=FALSE,na="");close(con)
  }
  print(fp[fp$group %in% groups[1:2],],row.names=FALSE)
  invisible(result)
}

# Manual use:
# source("code/analysis/r4mc5/r4mc5_unique_DEP_manual.R")
# result <- run_r4mc5()
