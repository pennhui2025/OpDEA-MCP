# Pseudo-label sensitivity analysis.
# Source this file, then call run_r1c5().
# Repeats are averaged within a condition; platform summaries use medians.

r1c5_pauc <- function(y, score, max_fpr) {
  stopifnot(length(y)==length(score), length(y)>0, !anyNA(y),
            all(y %in% c(0,1)), all(is.finite(score)),
            length(max_fpr)==1, max_fpr>0, max_fpr<=1)
  npos <- sum(y==1); nneg <- sum(y==0)
  if(npos==0 || nneg==0) return(NA_real_) # undefined ROC, not zero
  ord <- order(score, decreasing=TRUE)
  ys <- y[ord]; ss <- score[ord]
  # Include all proteins with the same score together (tie-safe ROC).
  ends <- c(which(diff(ss)!=0), length(ss))
  tp <- cumsum(ys)[ends]; fp <- ends-tp
  tpr <- c(0,tp/npos); fpr <- c(0,fp/nneg)
  # Keep the last ROC point at/below alpha and linearly interpolate the boundary.
  # findInterval with duplicate FPRs retains vertical ROC segments, as sklearn does.
  k <- max(which(fpr<=max_fpr))
  if(k<length(fpr)) {
    boundary <- tpr[k]+(tpr[k+1]-tpr[k])*(max_fpr-fpr[k])/(fpr[k+1]-fpr[k])
    xx <- c(fpr[seq_len(k)],max_fpr); yy <- c(tpr[seq_len(k)],boundary)
  } else { xx<-fpr; yy<-tpr }
  area <- sum(diff(xx)*(head(yy,-1)+tail(yy,-1))/2)
  if(max_fpr==1) return(area)
  chance <- max_fpr^2/2
  0.5*(1+(area-chance)/(max_fpr-chance))
}

run_r1c5 <- function(project = "code/training",
                      out = "reference/Response/r1c5/manual_R_Task3_results",
                      inventory = "reference/Response/r1c5/task3_raw_path_inventory.csv",
                      make_plots = TRUE) {
  rawroot <- file.path(project, "revision_results/remaining_tasks_shards")
  dir.create(out, recursive=TRUE, showWarnings=FALSE)
  longpath <- function(x) if (.Platform$OS.type=="windows") paste0("\\\\?\\", gsub("/", "\\\\", normalizePath(x, winslash="/", mustWork=FALSE))) else x
  rcsv <- function(x, ...) read.csv(longpath(x), check.names=TRUE, stringsAsFactors=FALSE, ...)
  fc <- log2(1.5)
  # No probability/q cutoff is applied when calculating pAUC: continuous scores
  # define the ROC; max_fpr truncates the false-positive-rate axis only.
  met <- function(y,s,call) { # missing model score is explicit score=0/non-DEP
    stopifnot(length(y)==length(s),length(y)==length(call),!anyNA(y),all(y %in% c(0,1)),all(is.finite(s)),all(call %in% c(0,1)))
    y<-as.integer(y); call<-as.integer(call)
    tp<-as.double(sum(y==1&call==1)); fp<-as.double(sum(y==0&call==1)); fn<-as.double(sum(y==1&call==0)); tn<-as.double(sum(y==0&call==0))
    den<-sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn));
    c(n=length(y),prevalence=mean(y),precision=ifelse(tp+fp, tp/(tp+fp),0),
      recall=ifelse(tp+fn,tp/(tp+fn),NA),mcc=ifelse(den,(tp*tn-fp*fn)/den,0),
      f1=ifelse(2*tp+fp+fn,2*tp/(2*tp+fp+fn),0),
      pauc001=r1c5_pauc(y,s,.01),pauc005=r1c5_pauc(y,s,.05),
      pauc01=r1c5_pauc(y,s,.1),tp=tp,fp=fp,fn=fn,tn=tn) }
  safe <- function(z) suppressWarnings(as.numeric(z))
  # Fourth repeated result block is DP_fdr: R makes duplicated names .1--.4
  # (Probability.3 / ori_logFC.3 / threshold.3).  Refuse a different layout.
  block <- function(d) {
    need <- c("Protein.4","Probability.3","ori_logFC.3","qvalue.3","threshold.3")
    if(!all(need %in% names(d))) stop("DP_fdr fourth block missing; refusing inferred column mapping")
    data.frame(protein=as.character(d[["Protein.4"]]),
      score=safe(d[["Probability.3"]]), lfc=safe(d[["ori_logFC.3"]]),
      q=safe(d[["qvalue.3"]]), threshold=safe(d[["threshold.3"]]), stringsAsFactors=FALSE)
  }
  if(!file.exists(inventory)) stop("Missing task3_raw_path_inventory.csv; generate it from the original raw tree before running R.")
  files <- read.csv(inventory, stringsAsFactors=FALSE)[[1]]
  if(length(files)!=672L) stop("Expected exactly 672 Task 3 DP_fdr raw files, found ",length(files))
  universes <- new.env(parent=emptyenv())
  one <- function(f, meta=NULL) {
    q <- gsub("\\\\","/",f); p <- strsplit(q,"/")[[1]]; i <- match("task3_pseudo_label",p)
    platform<-p[i+1]; dea<-p[i+2]; strategy<-sub(".*__pseudo__([^/]+?)/temp.*","\\1",q)
    dat<-sub("_DP_res_all.csv$","",basename(f)); d<-rcsv(f)
    if(!is.null(meta)) {platform<-meta$platform;dea<-meta$dea;strategy<-"original_initialization";dat<-meta$dataset}
    b<-block(d); b<-b[!is.na(b$protein) & nzchar(b$protein),,drop=FALSE]; if(anyDuplicated(b$protein)) stop("Duplicate DP_fdr Protein IDs: ",f)
    # all-candidate union is leading Protein/True_lab.  Predictions absent from
    # DP_fdr are retained as 0 score/non-DEP; extra IDs or conflicting truth fail.
    u<-data.frame(protein=as.character(d$Protein),truth=safe(d$True_lab),stringsAsFactors=FALSE)
    stopifnot(!anyNA(u),all(u$truth %in% c(0,1)))
    if(anyDuplicated(u$protein)) stop("Duplicate baseline Protein IDs: ",f)
    key<-paste(dat,platform,dea,sep="|"); signature<-paste(u$protein,u$truth,sep="\t");signature<-sort(signature)
    if(exists(key,envir=universes,inherits=FALSE)) stopifnot(identical(signature,get(key,envir=universes))) else assign(key,signature,envir=universes)
    extra<-setdiff(b$protein,u$protein); if(length(extra)) stop("DP_fdr contains extra Protein IDs: ",f)
    m<-match(u$protein,b$protein); hit<-!is.na(m)
    score<-rep(0,nrow(u)); lfc<-rep(0,nrow(u)); qq<-rep(1,nrow(u)); th<-rep(NA_real_,nrow(u))
    score[hit]<-b$score[m[hit]]; lfc[hit]<-b$lfc[m[hit]]; qq[hit]<-b$q[m[hit]]; th[hit]<-b$threshold[m[hit]]
    if(any(!is.finite(th[hit]))) stop("Missing saved DP_fdr threshold: ",f)
    stopifnot(all(is.finite(score)),!anyNA(lfc))
    call<-as.integer(hit & score>=th & abs(lfc)>=fc) # canonical saved DP_fdr threshold
    z<-met(u$truth,score,call)
    data.frame(dataset=dat,platform=platform,dea=dea,strategy=strategy,file=f,
      coverage=sum(hit),n_union=nrow(u),threshold_min=min(th[hit]),threshold_max=max(th[hit]),t(z),check.names=FALSE)
  }
  runs <- do.call(rbind,lapply(files,one))
  if(nrow(runs)!=672L || length(unique(paste(runs$dataset,runs$platform,runs$dea,runs$strategy)))!=672L) stop("Nonunique Task3 run key")
  write.csv(runs,file.path(out,"task3_dp_fdr_per_run_union_metrics.csv"),row.names=FALSE)
  # Reduce noise repeats to ONE record per dataset/platform/DEA/strategy.
  runs$group<-sub("_rep[1-5]$","",runs$strategy)
  runs$initialization_definition <- ifelse(runs$group == "reference_hurdle_agreement",
    "controlled_agreement_external_pseudolabels_not_original_initialization", "Task3_external_pseudolabel_strategy")
  nums<-names(runs)[vapply(runs,is.numeric,logical(1))]
  a<-aggregate(runs[nums],runs[c("dataset","platform","dea","group")],mean,na.rm=TRUE)
  stopifnot(all(table(a$dataset,a$group)==4L))
  ds<-aggregate(a[nums],a[c("dataset","platform","group")],median); ds$n_dea<-2L
  # Match Fig.2: median over the 14 dataset x DEA records within each platform.
  # Do NOT take a median of dataset medians (a different estimand).
  sm<-aggregate(a[nums],a[c("platform","group")],median); sm$n_datasets<-7L;sm$n_records<-14L
  write.csv(a,file.path(out,"task3_condition_metrics.csv"),row.names=FALSE)
  write.csv(ds,file.path(out,"task3_dp_fdr_per_dataset_metrics.csv"),row.names=FALSE)
  write.csv(sm,file.path(out,"task3_platform_medians.csv"),row.names=FALSE)
  # Separate original-initialization reference: 28 prior full-four-view runs.
  ledger<-rcsv(file.path(project,"revision_results/revision_results/revision_results/task1_2_core_merged_limma_ROTS/core_run_ledger.csv"))
  original<-ledger[ledger$variant=="full_mcp",]
  stopifnot(nrow(original)==28L,all(original$views=="dlfq+maxlfq+top3+top1"))
  originals<-do.call(rbind,lapply(seq_len(nrow(original)),function(i) {
    r<-original[i,]; tail<-sub("^.*?/revision_results/","",r$prediction_file)
    path<-file.path(project,"revision_results/revision_results/revision_results",tail)
    one(path,list(dataset=r$dataset,platform=r$platform,dea=strsplit(r$dea_methods,"+",fixed=TRUE)[[1]][1]))
  }))
  originals$group<-"original_initialization"
  ods<-aggregate(originals[nums],originals[c("dataset","platform","group")],median);ods$n_dea<-2L
  os<-aggregate(originals[nums],originals[c("platform","group")],median);os$n_datasets<-7L;os$n_records<-14L
  write.csv(originals,file.path(out,"original_initialization_28_per_run.csv"),row.names=FALSE)
  write.csv(ods,file.path(out,"original_initialization_28_per_dataset.csv"),row.names=FALSE)
  sm<-rbind(os,sm)
  write.csv(sm,file.path(out,"task3_plus_original_summary.csv"),row.names=FALSE)
  # Controlled-agreement audit: neural pseudo-labels and actual run summary.
  refs<-runs[runs$strategy=="reference_hurdle_agreement",]
  audit<-lapply(seq_len(nrow(refs)),function(i) {
    r<-refs[i,]; d<-rcsv(r$file); b<-block(d); b<-b[!is.na(b$protein) & nzchar(b$protein),,drop=FALSE]
    pp<-strsplit(gsub("\\\\","/",r$file),"/")[[1]]; ti<-match("task3_pseudo_label",pp)
    if(is.na(ti)) stop("Cannot locate Task 3 root in path: ",r$file)
    root<-paste(pp[seq_len(ti+2)],collapse="/"); lab<-rcsv(file.path(root,"generated_pseudo_labels.csv"))
    lab<-lab[lab$dataset==r$dataset,c("protein","true_label","reference_hurdle_agreement")]; names(lab)[1]<-"protein"
    actual<-rcsv(file.path(dirname(r$file),"pseudo_label_run_summary.csv"))
    actual<-actual[actual$dataset==r$dataset & actual$strategy==r$strategy,,drop=FALSE]
    if(nrow(actual)!=1L) stop("Expected one pseudo_label_run_summary row: ",r$file)
    u<-data.frame(protein=as.character(d$Protein),truth=safe(d$True_lab)); m<-match(u$protein,b$protein); hit<-!is.na(m)
    score<-rep(0,nrow(u)); threshold<-rep(Inf,nrow(u)); lfc<-rep(0,nrow(u)); score[hit]<-b$score[m[hit]]; threshold[hit]<-b$threshold[m[hit]]; lfc[hit]<-b$lfc[m[hit]]; mcall<-as.integer(hit & score>=threshold & abs(lfc)>=fc)
    lm<-match(u$protein,lab$protein); if(anyNA(lm)) stop("Labels do not cover baseline union")
    stopifnot(!anyDuplicated(lab$protein),identical(as.numeric(u$truth),as.numeric(lab$true_label[lm])))
    pseudo<-safe(lab$reference_hurdle_agreement[lm]); unl<-pseudo==-1
    stopifnot(sum(unl)==actual$n_unlabeled,sum(!unl)==actual$n_labeled,sum(pseudo==1)==actual$n_positive,sum(pseudo==0)==actual$n_negative)
    # exact source calls specified by reviewer: 1-score <= .05, plus absFC cutoff.
    dlfq<-as.integer(!is.na(safe(d$score_DPdlfq)) & 1-safe(d$score_DPdlfq)<=.05 & abs(safe(d$logFC_DPdlfq))>=fc)
    hur<-as.integer(!is.na(safe(d$score_DP_hurdle)) & 1-safe(d$score_DP_hurdle)<=.05 & abs(safe(d$logFC_DP_hurdle))>=fc)
    ss<-function(name,sc,ca) { z<-met(u$truth[unl],sc[unl],ca[unl]); data.frame(dataset=r$dataset,platform=r$platform,dea=r$dea,method=name,n_unlabeled=sum(unl),t(z)) }
    known<-!unl; data.frame(r[1:4],n_union=nrow(u),n_unlabeled=sum(unl),n_labeled=sum(!unl),
      actual_n_unlabeled=actual$n_unlabeled,actual_n_labeled=actual$n_labeled,
      actual_vs_reconstructed_label_mismatch=as.integer(sum(unl)!=actual$n_unlabeled || sum(!unl)!=actual$n_labeled),
      known_pseudolabel_error_rate=mean(pseudo[known]!=u$truth[known]),
      known_dp_fdr_error_rate=mean(mcall[known]!=u$truth[known]),
      known_call_agreement_with_pseudolabel=mean(mcall[known]==pseudo[known]),
      mcp_vs_dlfq_true_rescues=sum(unl&mcall==1&dlfq==0&u$truth==1),mcp_vs_dlfq_harmful_falsepositives=sum(unl&mcall==1&dlfq==0&u$truth==0),
      mcp_vs_hurdle_true_rescues=sum(unl&mcall==1&hur==0&u$truth==1),mcp_vs_hurdle_harmful_falsepositives=sum(unl&mcall==1&hur==0&u$truth==0),stringsAsFactors=FALSE) -> h
    list(h, rbind(ss("DP_fdr",score,mcall),ss("direct_dlfq",safe(d$score_DPdlfq),dlfq),ss("hurdle",safe(d$score_DP_hurdle),hur))) })
  ah<-do.call(rbind,lapply(audit,`[[`,1)); ac<-do.call(rbind,lapply(audit,`[[`,2))
  write.csv(ah,file.path(out,"reference_hurdle_initialization_membership_audit.csv"),row.names=FALSE)
  kh<-aggregate(ah[c("known_pseudolabel_error_rate","known_dp_fdr_error_rate","known_call_agreement_with_pseudolabel")],ah["dataset"],mean,na.rm=TRUE)
  delta<-kh$known_pseudolabel_error_rate-kh$known_dp_fdr_error_rate
  # Exact two-sided sign-flip test across the seven biological datasets.
  signs<-as.matrix(expand.grid(rep(list(c(-1,1)),nrow(kh)))); null<-rowMeans(sweep(signs,2,delta,"*"))
  kp<-mean(abs(null)>=abs(mean(delta))-1e-12)
  write.csv(data.frame(n_datasets=nrow(kh),mean_pseudolabel_error=mean(kh$known_pseudolabel_error_rate),mean_dp_fdr_error=mean(kh$known_dp_fdr_error_rate),mean_net_error_reduction=mean(delta),exact_signflip_p=kp),file.path(out,"reference_hurdle_known_label_net_correction_test.csv"),row.names=FALSE)
  write.csv(ac,file.path(out,"reference_hurdle_actual_unlabeled_method_comparison.csv"),row.names=FALSE)
  ucols<-names(ac)[vapply(ac,is.numeric,logical(1))]
  ud<-aggregate(ac[ucols],ac[c("dataset","platform","method")],median); ud$n_dea<-2L
  us<-aggregate(ac[ucols],ac[c("platform","method")],median); us$n_datasets<-7L;us$n_records<-14L
  write.csv(ud,file.path(out,"task3_unlabeled_per_dataset.csv"),row.names=FALSE)
  write.csv(us,file.path(out,"task3_unlabeled_summary.csv"),row.names=FALSE)
  write.csv(kh,file.path(out,"known_label_errors_per_dataset.csv"),row.names=FALSE)
  write.csv(data.frame(dp_fdr_file=files),file.path(out,"task3_raw_path_manifest.csv"),row.names=FALSE)
  if(make_plots && requireNamespace("ggplot2", quietly=TRUE)) {
    # Each point = dataset/platform median across the two DEAs.
    ud$Method<-factor(ud$method,levels=c("direct_dlfq","hurdle","DP_fdr"),labels=c("dLFQ DEA","Hurdle","MCP"))
    g<-ggplot2::ggplot(ud,ggplot2::aes(Method,mcc,group=dataset))+
      ggplot2::geom_hline(yintercept=0,colour="grey70")+
      ggplot2::geom_line(colour="grey70",linewidth=.4)+
      ggplot2::geom_point(ggplot2::aes(colour=Method),size=2.8)+
      ggplot2::scale_colour_manual(values=c("#0072B2","#E69F00","#D55E00"))+
      ggplot2::facet_wrap(~platform)+
      ggplot2::labs(x=NULL,y="Median MCC across limma and ROTS",title="Initially unlabelled proteins",subtitle="Controlled dLFQ-hurdle agreement; seven DIA datasets")+
      ggplot2::theme_classic(base_size=12)+ggplot2::theme(legend.position="none")
    ggplot2::ggsave(file.path(out,"r1c5_unlabeled_MCC.pdf"),g,width=6.8,height=4.2)
    ggplot2::ggsave(file.path(out,"r1c5_unlabeled_MCC.png"),g,width=6.8,height=4.2,dpi=300)
    nd<-a[grepl("agreement_noise",a$group)|a$group=="reference_hurdle_agreement",]
    nd$noise<-0; noisy<-nd$group!="reference_hurdle_agreement"
    nd$noise[noisy]<-as.numeric(sub("agreement_noise_","",nd$group[noisy]))
    nl<-do.call(rbind,lapply(c("precision","recall","mcc","pauc001","pauc005","pauc01"),function(m) data.frame(nd[c("dataset","platform","dea","noise")],metric=m,value=nd[[m]])))
    medians<-aggregate(value~noise+metric+platform,nl,median)
    g<-ggplot2::ggplot(nl,ggplot2::aes(noise*100,value,group=interaction(dataset,dea)))+
      ggplot2::geom_line(colour="grey75",linewidth=.35)+ggplot2::geom_point(colour="grey65",size=1.4)+
      ggplot2::geom_line(data=medians,ggplot2::aes(group=1),colour="#D55E00",linewidth=1)+
      ggplot2::geom_point(data=medians,ggplot2::aes(group=1),colour="#D55E00",size=2.4)+
      ggplot2::facet_grid(platform~metric)+ggplot2::scale_x_continuous(breaks=c(0,5,10,20))+
      ggplot2::labs(x="Assigned labels flipped (%)",y="Metric",subtitle="Grey: dataset x DEA conditions; red: median of 14 conditions. Five noise repetitions averaged first.")+
      ggplot2::theme_classic(base_size=11)
    ggplot2::ggsave(file.path(out,"r1c5_noise_sensitivity.pdf"),g,width=13,height=5.5)
    ggplot2::ggsave(file.path(out,"r1c5_noise_sensitivity.png"),g,width=13,height=5.5,dpi=300)
  }
  invisible(list(per_run=runs,per_dataset=ds,summary=sm,membership_audit=ah,unlabeled_comparison=ac))
}
