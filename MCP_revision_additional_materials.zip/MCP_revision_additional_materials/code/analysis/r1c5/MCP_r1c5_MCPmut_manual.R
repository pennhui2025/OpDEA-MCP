# R1C5: original MCP_mut experiment, kept SEPARATE from controlled Task 3.
# Source only defines functions. Run the example at the bottom manually.
# MCP means the DP_fdr row, NEVER DP_KNN, DP_direct, or DP_05.
# IMPORTANT: historical MCP_mut files lack neural per-protein DP_fdr outputs.
# These are SAVED native-universe metrics, NOT a common-union reanalysis.

run_mcp_mut <- function(
    ncs = "inputs/n",
    out = "reference/Response/r1c5/mcp_mut_data") {
  # Windows long paths. Input files are never modified.
  lp <- function(x) {
    if (.Platform$OS.type != "windows") return(x)
    paste0("\\\\?\\", gsub("/", "\\\\", normalizePath(x, winslash="/", mustWork=FALSE)))
  }
  rd <- function(f) read.csv(lp(f), stringsAsFactors=FALSE, check.names=FALSE)
  dir.create(out, recursive=TRUE, showWarnings=FALSE)
  metric_names <- c("Acc","Prec","Rec","F1","F1w","Mcc","nMcc",
                    "geomean","tn","fp","fn","tp","pauc001","pauc005","pauc01")
  files <- list.files(file.path(ncs,"MCP_mut"), pattern="__metrics_all_s\\.csv$",
                      recursive=TRUE, full.names=TRUE)
  if (!length(files)) stop("No MCP_mut metrics found under ", ncs)

  get_row <- function(f) {
    d <- rd(f)
    if (!all(c("test_type",metric_names) %in% names(d))) stop("Wrong schema: ", f)
    z <- d[d$test_type == "DP_fdr", metric_names, drop=FALSE]
    if (nrow(z)!=1L) stop("Expected exactly one DP_fdr row: ", f)
    z[] <- lapply(z, as.numeric)
    if (anyNA(z)) stop("Missing saved metric: ", f)
    z$n_native <- with(z, tn+fp+fn+tp)
    # Source methods are evaluated on the leading all-candidate union.
    # Same total N DOES NOT prove equality of protein IDs or truth mapping.
    b <- d[grepl("^DP",d$test_type) & !d$test_type %in%
           c("DP_direct","DP_vote","DP_fdr","DP_05"), ,drop=FALSE]
    if (!nrow(b)) stop("Missing source-method rows: ", f)
    nn <- rowSums(b[c("tn","fp","fn","tp")])
    if (length(unique(nn))!=1L) stop("Source methods have different N: ",f)
    z$n_source_union <- nn[1]
    z$n_native_minus_source_union <- z$n_native-z$n_source_union
    # Check saved confusion metrics independently; doubles prevent integer overflow.
    tp<-as.double(z$tp); fp<-as.double(z$fp); fn<-as.double(z$fn); tn<-as.double(z$tn)
    den<-sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn))
    mm<-if(den==0) 0 else (tp*tn-fp*fn)/den
    if(abs(mm-z$Mcc)>1e-10) stop("Saved MCC inconsistent with counts: ", f)
    z
  }
  rows <- vector("list", length(files)); missing <- list()
  for (i in seq_along(files)) {
    f <- gsub("\\\\","/",files[i]); parts <- strsplit(f,"/")[[1]]
    j <- match("all_exp_012",parts)
    if(is.na(j)) stop("Unexpected path: ",f)
    combo <- parts[j+1]; tmp <- parts[j+2]; dataset <- parts[j+3]
    nv <- length(strsplit(sub("^(DIA|DDA)_","",combo),"_")[[1]])
    dea <- sub("^temp[0-9]+_(limma|ROTS)_.*$","\\1",tmp)
    platform <- sub("^temp[0-9]+_(limma|ROTS)_(.+)_view[0-9]+$","\\2",tmp)
    if(!dea %in% c("limma","ROTS")) stop("Unrecognised DEA: ",tmp)
    meta<-data.frame(platform=platform, acquisition=sub("_.*","",combo),
      views=sub("^(DIA|DDA)_","",combo), n_views=nv, dea=dea, dataset=dataset,
      temp=tmp, stringsAsFactors=FALSE)
    standard <- file.path(ncs,paste0(nv,"v"),"all_exp_mcc_new","all_exp_mcc_new",
                          combo,tmp,dataset,basename(f))
    a <- cbind(meta,method="MCP_mut",get_row(f),file=f)
    if(file.exists(lp(standard))) {
      b<-cbind(meta,method="MCP",get_row(standard),file=standard)
      rows[[i]]<-rbind(a,b)
    } else {
      rows[[i]]<-a
      missing[[length(missing)+1L]]<-cbind(meta,missing_MCP_file=standard)
    }
  }
  raw <- do.call(rbind,rows)
  key <- c("platform","views","dea","dataset")
  id <- function(d) do.call(paste,c(d[key],sep="|"))
  if(anyDuplicated(paste(id(raw),raw$method))) stop("Duplicate run keys; do not average silently")
  paired_keys <- intersect(id(raw[raw$method=="MCP",]),id(raw[raw$method=="MCP_mut",]))
  paired <- raw[id(raw) %in% paired_keys,]
  paired$evidence_type <- "historical_saved_DP_fdr_not_union_recomputed"
  raw$evidence_type <- "historical_saved_DP_fdr_not_union_recomputed"
  # Paired available records only. Within each platform x combination x method,
  # take the median over dataset x limma/ROTS records, as in the original heatmap.
  group <- c("platform","acquisition","views","n_views","method")
  setting <- aggregate(paired[metric_names],paired[group],median)
  sizes <- aggregate(paired["dataset"],paired[group],length); names(sizes)[6]<-"n_records"
  setting <- merge(setting,sizes,by=group,sort=TRUE)
  setting$n_expected <- ifelse(setting$acquisition=="DIA",14L,22L)
  setting$evidence_type <- "historical_saved_DP_fdr_not_union_recomputed"
  a<-setting[setting$method=="MCP",]; b<-setting[setting$method=="MCP_mut",]
  delta <- merge(a,b,by=c("platform","acquisition","views","n_views"),
                 suffixes=c("_MCP","_MCP_mut"),sort=TRUE)
  for(m in metric_names) delta[[paste0("delta_",m)]]<-delta[[paste0(m,"_MCP")]]-delta[[paste0(m,"_MCP_mut")]]
  platform_summary<-do.call(rbind,lapply(split(delta,delta$platform),function(d)
    data.frame(platform=d$platform[1],n_settings=nrow(d),
      MCP_higher_MCC=sum(d$delta_Mcc>1e-12),equal_MCC=sum(abs(d$delta_Mcc)<=1e-12),
      MCP_lower_MCC=sum(d$delta_Mcc< -1e-12),median_delta_MCC=median(d$delta_Mcc))))
  full <- delta[delta$n_views==ifelse(delta$acquisition=="DIA",4,5),]
  # Coverage: expected datasets are inferred from the observed dataset inventory
  # within each platform. Do not treat an absent file as a failed/zero result.
  mut<-raw[raw$method=="MCP_mut",]
  expected <- do.call(rbind,lapply(split(mut,mut$platform),function(d) {
    e<-expand.grid(views=unique(d$views),dea=c("limma","ROTS"),
                   dataset=unique(d$dataset),stringsAsFactors=FALSE)
    e$platform<-d$platform[1]; e
  }))
  missing_mut <- expected[!id(expected) %in% id(mut),]
  pa<-paired[paired$method=="MCP",];pb<-paired[paired$method=="MCP_mut",]
  pb<-pb[match(id(pa),id(pb)),]
  audit <- data.frame(metric=c("MCP_mut_run_files","paired_run_records","setting_count",
    "missing_mut_runs_in_observed_design","mut_without_standard_comparator",
    "paired_native_N_different","paired_native_positive_count_different",
    "mut_native_N_differs_from_source_union","MCP_native_N_differs_from_source_union"),
    value=c(nrow(mut),nrow(pa),nrow(delta),nrow(missing_mut),length(missing),
      sum(pa$n_native!=pb$n_native),sum(pa$tp+pa$fn!=pb$tp+pb$fn),
      sum(mut$n_native_minus_source_union!=0),sum(pa$n_native_minus_source_union!=0)))
  wc<-function(x,name) write.csv(x,file.path(out,paste0(name,".csv")),row.names=FALSE,na="")
  wc(raw,"MCPmut_all_saved_records");wc(paired,"MCPmut_paired_records")
  wc(setting,"MCPmut_setting_medians");wc(delta,"MCPmut_setting_differences")
  wc(platform_summary,"MCPmut_platform_summary");wc(full,"MCPmut_full_view_settings")
  wc(audit,"MCPmut_coverage_audit");wc(missing_mut,"MCPmut_missing_mut_runs")
  if(length(missing)) wc(do.call(rbind,missing),"MCPmut_missing_standard_runs")
  print(audit);print(platform_summary)
  message("Legacy metrics only: equal N is not an ID-level common-union validation.")
  invisible(list(raw=raw,paired=paired,settings=setting,differences=delta,
                 platform_summary=platform_summary,full_views=full,audit=audit))
}

# MANUALLY RUN in RStudio, after checking the paths above:
# source("code/analysis/r1c5/MCP_r1c5_MCPmut_manual.R")
# mut <- run_mcp_mut()
# View(mut$settings)      # 148 rows: 74 settings x 2 methods
# View(mut$differences)  # 74 paired setting-level differences, all saved metrics
# View(mut$audit)        # coverage and native-universe count limitations
#
# Task 3 remains a separate calculation. Existing script source defines functions:
# source("code/analysis/r1c5/r1c5_task3_dp_fdr_reanalysis.R")
# task3 <- run_r1c5()
# Do NOT rbind mut$settings and Task 3 summaries to compute an overall mean.
