# r1c5: SAM replaces the initialization DEA inside MCP, not MCP itself.
# Source this file in RStudio, then manually run:
# sam <- run_sam_r1c5()
# No model is retrained and no original file is modified.
DELIVERY_DIR <- "reference/Response/r1c5"

sam_metrics <- function(y, call, score) {
  stopifnot(length(y)==length(call), length(y)==length(score),
            all(y %in% c(0,1)), all(is.finite(score)))
  # Convert counts to double BEFORE multiplying, to avoid R integer overflow.
  tn <- as.double(sum(y==0 & !call)); fp <- as.double(sum(y==0 & call))
  fn <- as.double(sum(y==1 & !call)); tp <- as.double(sum(y==1 & call))
  den <- sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn))
  precision <- if (tp+fp==0) 0 else tp/(tp+fp)
  recall <- if (tp+fn==0) NA_real_ else tp/(tp+fn)
  mcc <- if (den==0) 0 else (tp*tn-fp*fn)/den
  f1 <- if (2*tp+fp+fn==0) 0 else 2*tp/(2*tp+fp+fn)
  c(tn=tn,fp=fp,fn=fn,tp=tp,Prec=precision,Rec=recall,Mcc=mcc,F1=f1,
    pauc001=r1c5_pauc(y,score,.01),pauc005=r1c5_pauc(y,score,.05),
    pauc01=r1c5_pauc(y,score,.1))
}

run_sam_r1c5 <- function(delivery_dir=DELIVERY_DIR, write_files=TRUE,
                        out_dir=file.path(delivery_dir,"manual_R_SAM_results"),
                        metrics_script=file.path(delivery_dir,"r1c5_task3_dp_fdr_reanalysis.R")) {
  # Sourcing defines the shared standardized pAUC function; it runs no Task 3 analysis.
  source(metrics_script)
  manifest <- read.csv(file.path(delivery_dir,"sam_input_manifest.csv"),check.names=FALSE)
  key <- paste(manifest$dataset,manifest$platform,sep="|")
  out <- list(); k <- 0L
  for (indices in split(seq_len(nrow(manifest)),key)) {
    g <- manifest[indices,]
    stopifnot(nrow(g)==3, setequal(g$label_source,c("SAM","limma","ROTS")))
    # Read original protein predictions, not the old summarized metrics.
    paths<-g$source_file
    if(.Platform$OS.type=="windows") paths<-paste0("\\\\?\\",gsub("/","\\\\",normalizePath(paths,winslash="/",mustWork=TRUE)))
    d <- lapply(paths,read.csv,check.names=TRUE)
    u <- unique(do.call(rbind,lapply(d,function(x) x[!is.na(x$Protein),c("Protein","True_lab")])))
    stopifnot(!anyDuplicated(u$Protein),all(u$True_lab %in% c(0,1)))
    for (j in seq_along(d)) {
      x <- d[[j]]
      # Physical fourth model block is DP_fdr. Never use the unsuffixed Probability.
      b <- x[!is.na(x$Protein.4),c("Protein.4","Probability.3","ori_logFC.3","threshold.3")]
      stopifnot(!anyDuplicated(b$Protein.4),all(b$Protein.4 %in% u$Protein))
      m <- match(u$Protein,b$Protein.4); present <- !is.na(m)
      score <- fc <- rep(0,nrow(u)); call <- rep(FALSE,nrow(u))
      score[present] <- b$Probability.3[m[present]]
      fc[present] <- b$ori_logFC.3[m[present]]
      call[present] <- score[present]>=b$threshold.3[m[present]] & abs(fc[present])>=log2(1.5)
      z <- sam_metrics(u$True_lab,call,score)
      k <- k+1L
      out[[k]] <- cbind(g[j,c("dataset","platform","label_source")],n_union=nrow(u),
                        n_model=nrow(b),as.data.frame(as.list(z)))
    }
  }
  raw <- do.call(rbind,out)
  metrics <- c("Prec","Rec","Mcc","F1","pauc001","pauc005","pauc01")
  summary <- aggregate(raw[metrics],raw[c("platform","label_source")],median)
  summary$n_datasets <- vapply(summary$platform,function(p) length(unique(raw$dataset[raw$platform==p])),integer(1))
  print(summary)
  # DIANN has 7 matched datasets, Spectronaut only 4. Do not pool them as 11 independent datasets.
  if (write_files) {
    dir.create(out_dir,recursive=TRUE,showWarnings=FALSE)
    write.csv(raw,file.path(out_dir,"sam_union_per_dataset_R.csv"),row.names=FALSE)
    write.csv(summary,file.path(out_dir,"sam_union_summary_R.csv"),row.names=FALSE)
  }
  invisible(list(per_dataset=raw,summary=summary))
}
