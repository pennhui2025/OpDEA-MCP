# Reviewer 4 Major comment 2: native ROTS FDR, without a second BH adjustment.
# source() only defines this function. Run ans <- run_r4mc2() manually.
# 只重新读取已保存的蛋白级结果，不重新训练，不重新运行ROTS，不安装包。
# 用R4MC1已核实的原始全视图清单，避免把不同组合重复当作独立数据集。

run_r4mc2 <- function(
  source_dir = "reference/Response/r4mc1/data",
  helper = "code/analysis/r2c1/MCP_r2c1_ranking_threshold_manual.R",
  out = "reference/Response/r4mc2/manual_R_check",
  write_files = TRUE
) {
  h <- new.env(parent=globalenv())
  sys.source(helper, envir=h) # Only reuse validated, tie-aware ROC/pAUC functions.
  h$r2c1_selftest()
  manifest <- read.csv(file.path(source_dir,"source_manifest.csv"), stringsAsFactors=FALSE)
  manifest <- manifest[manifest$dea=="ROTS",,drop=FALSE]
  stopifnot(nrow(manifest)==35L, length(unique(manifest$dataset))==18L,
            !anyDuplicated(manifest[c("dataset","platform","dea")]))

  metric <- function(call,y) {
    tp<-as.double(sum(call & y==1)); fp<-as.double(sum(call & y==0))
    tn<-as.double(sum(!call & y==0)); fn<-as.double(sum(!call & y==1))
    den<-sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn))
    c(precision=if(tp+fp>0)tp/(tp+fp) else 0, recall=tp/(tp+fn),
      MCC=if(den>0)(tp*tn-fp*fn)/den else 0,
      F1=2*tp/(2*tp+fp+fn), empirical_FDP=fp/max(tp+fp,1),
      TP=tp,FP=fp,TN=tn,FN=fn,n_called=tp+fp,n_union=length(y))
  }
  lfc_num <- function(x) {
    x<-suppressWarnings(as.numeric(x)); stopifnot(!anyNA(x)); x
    # Preserve archived +/-Inf logFC, as in the original threshold predicate.
  }
  rows<-list()
  for(i in seq_len(nrow(manifest))) {
    d<-read.csv(manifest$source_file[i], check.names=TRUE, stringsAsFactors=FALSE)
    ids<-d$Protein; h$r2c1_unique(ids,"baseline union")
    y<-h$r2c1_num(d$True_lab,"truth"); stopifnot(all(y %in% 0:1))

    # 最终MCP分数块，而非原始/直接0.5分类块；按protein ID对齐。
    present<-!is.na(d$Protein.4) & nzchar(d$Protein.4)
    raw<-d[present,c("Protein.4","Probability.3","ori_logFC.3")]
    h$r2c1_unique(raw$Protein.4,"MCP IDs"); stopifnot(all(raw$Protein.4 %in% ids))
    b<-data.frame(score=rep(0,length(ids)),lfc=0,observed=FALSE)
    idx<-match(raw$Protein.4,ids)
    b$score[idx]<-h$r2c1_num(raw$Probability.3,"MCP score")
    b$lfc[idx]<-lfc_num(raw$ori_logFC.3); b$observed[idx]<-TRUE
    # Read full precision from RAW CSV, not rounded summary/workbook thresholds.
    threshold<-h$r2c1_threshold(d$threshold.3[present],"MCP threshold")
    blocks<-list(MCP=b)
    views<-setdiff(strsplit(manifest$view_names[i],"+",fixed=TRUE)[[1]],"count")
    # 原代码对spectral count强制用edgeR，不能将它当成ROTS单视图。
    # DDA的完整MCP仍使用5视图；本处仅排除单独的count基线。
    stopifnot(length(views)==4L)
    for(v in views) {
      blocks[[v]]<-data.frame(score=h$r2c1_num(d[[paste0("score_DP",v)]],v),
        lfc=lfc_num(d[[paste0("logFC_DP",v)]]),observed=TRUE)
    }
    # Hurdle is not a native single-view ROTS test, so it is not included here.
    for(method in names(blocks)) {
      z<-blocks[[method]]
      ranking<-h$r2c1_roc(z$score,y) # No final FC/significance selection for ROC.
      for(fc in c(1,1.5)) { # 1 means no FINAL magnitude filter.
        native_fdr<-1-z$score # ROTS saved score = 1 - native FDR.
        call<-if(method=="MCP")z$observed & z$score>=threshold else native_fdr<=.05
        if(fc>1)call<-call & abs(z$lfc)>=log2(fc)
        rows[[length(rows)+1L]]<-cbind(
          manifest[i,c("dataset","acquisition","platform","dea","combination")],
          method=method,fc_ratio=fc,statistical_FDR_cutoff=.05,
          as.data.frame(as.list(c(metric(call,y),ranking))))
      }
    }
  }
  per_run<-do.call(rbind,rows); rownames(per_run)<-NULL
  stopifnot(nrow(per_run)==350L)
  keys<-c("platform","method","fc_ratio")
  values<-c("precision","recall","MCC","F1","empirical_FDP","TP","FP","TN","FN",
            "n_called","n_union","AUROC","pAUC_0.01","pAUC_0.05","pAUC_0.1")
  groups<-split(seq_len(nrow(per_run)),interaction(per_run[keys],drop=TRUE,lex.order=TRUE))
  medians<-do.call(rbind,lapply(groups,function(idx){
    z<-per_run[idx,,drop=FALSE]
    cbind(z[1,keys,drop=FALSE],n_records=nrow(z),
          as.data.frame(as.list(vapply(z[values],median,numeric(1)))))
  }))
  # Each metric is summarized separately. Do not reconstruct metrics from median counts.
  rownames(medians)<-NULL; stopifnot(nrow(medians)==40L)

  # Compare recomputed values with the independent R4MC1 grid already in Data12.
  previous<-read.csv(file.path(source_dir,"per_run.csv"),check.names=FALSE)
  previous<-previous[previous$dea=="ROTS" & !previous$method %in% c("Hurdle","count") &
    previous$fc_ratio %in% c(1,1.5) & previous$statistical_FDR_cutoff==.05,,drop=FALSE]
  join_keys<-c("dataset","platform","dea","method","fc_ratio")
  check<-merge(per_run,previous,by=join_keys,suffixes=c("_new","_previous"))
  stopifnot(nrow(check)==350L)
  max_error<-max(vapply(values,function(v)
    max(abs(check[[paste0(v,"_new")]]-check[[paste0(v,"_previous")]])),numeric(1)))
  stopifnot(max_error<1e-12)
  response_table<-medians[medians$fc_ratio==1 & medians$method %in% c("MCP","dlfq"),
    c("platform","method","n_records","n_called","precision","recall")]
  ans<-list(response_table=response_table,all_view_medians=medians,
            per_run=per_run,source_manifest=manifest)
  if(write_files) {
    dir.create(out,recursive=TRUE,showWarnings=FALSE)
    for(n in names(ans))write.csv(ans[[n]],file.path(out,paste0(n,".csv")),row.names=FALSE,na="")
  }
  print(response_table,row.names=FALSE)
  message("35 original ROTS-based runs; 350 rows. Maximum difference from R4MC1: ",max_error)
  invisible(ans)
}
