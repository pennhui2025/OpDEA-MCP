# -*- coding: utf-8 -*-
# R1 integration (2026-09-23): original XGBoost methods are retained.
# RankSpacingVote is self-contained below; no other MCP_r1_*.py file is needed.
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.model_selection import cross_val_score, ShuffleSplit, StratifiedShuffleSplit, StratifiedKFold
from xgboost import XGBClassifier, XGBClassifier
from sklearn.metrics import roc_auc_score
# from cca_zoo.linear import GCCA
from sklearn import preprocessing
import optuna
import random
import os
from sklearn.metrics import accuracy_score as acc, recall_score as recall, precision_score as precision, f1_score as f1, matthews_corrcoef as mcc
import matplotlib.pyplot as plt
from sklearn.metrics import RocCurveDisplay, roc_curve
from sklearn.metrics import auc as Auc
from sklearn.neighbors import KNeighborsClassifier as KNN
import pickle
from sklearn.svm import SVC
#from TPD_classification6 import preprocess_multi_view as preprocess_multi_view_bc

def average_replicate(mat, design):

    uni_pat = np.unique(design['Patient_ID'].values)

    idx_avg = []
    avg_intens = np.zeros((len(mat.values[:, 0]), 0))
    for i in range(len(uni_pat)):
        pat = uni_pat[i]

        idx = np.where((design['Patient_ID'].values == pat))[0]+2
        idx_avg.append(idx[0]-2)

        mat_pat = mat.iloc[:, idx]

        inten = np.array(mat_pat.values, dtype='float')
        avg_inten = np.nanmean(inten, axis=1)
        avg_intens = np.column_stack((avg_intens, avg_inten))

    avg_mat = pd.DataFrame(np.column_stack((mat.values[:, 0:2], avg_intens)), columns=list(mat.columns.values[0:2]) + list(uni_pat))
    design_avg = design.iloc[idx_avg, :]
    return avg_mat, design_avg

def get_pro_list(matrix):
    pros = matrix['Protein'].values
    pros_id = []
    for i in range(len(pros)):
        pro = pros[i].split(';')
        pro_id = ''
        if len(pro) == 1:
            pro_id = pro[0].split('|')[1]
        elif len(pro) > 1:
            for j in range(len(pro)):
                id = pro[j].split('|')[1]
                if pro_id == '':
                    pro_id = id
                else:
                    pro_id += ';' + id

        pros_id.append(pro_id)
    return pros_id

def get_pro_inten_tr(pro_list, matrix, design, logT='F'):

    pros = matrix['Protein'].values
    pros_id = []
    for i in range(len(pros)):
        pro = pros[i].split(';')
        pro_id = ''
        if len(pro) == 1:
            pro_id = pro[0].split('|')[1]
        elif len(pro) > 1:
            for j in range(len(pro)):
                id = pro[j].split('|')[1]
                if pro_id == '':
                    pro_id = id
                else:
                    pro_id += ';' + id

        pros_id.append(pro_id)

    pros_id = np.array(pros_id)

    com, idx1, idx2 = np.intersect1d(np.array(pro_list), pros_id, return_indices= True)

    mat_all = np.array(matrix.values[:, 2:len(matrix.values[0, :])], dtype='float')
    #mat_pro = np.zeros((len(pro_list), len(mat_all[0, :])))
    #mat_pro[idx1, :] = mat_all[idx2, :]
    mat_pro = mat_all[idx2, :]
    out_mat = matrix.iloc[idx2]

    header = np.array(matrix.columns.values)[2:len(matrix.columns.values)]
    labels = []
    idxs = []
    non_find = []
    samples = []

    for i in range(len(header)):

        sample = (header[i].replace('C:\\Users\\10352\Desktop\\TPD_Discovery\\', '').replace('.mzML.dia', '')
                  .replace('.mzML', '').replace('.', '_').replace('-', '_').replace('batch', 'b').
                  replace('TPD_b', 'TPD_DIA_b').replace('(liu)','')).split('_')
        sample_name = ''
        for t in range(5):
            #print(sample)
            if sample_name == '':
                sample_name = sample[t]
            else:
                sample_name = sample_name + '_' + sample[t]
        idx = np.where((design['MS_file_name'].values == sample_name))[0]
        if len(idx) == 1:
            labels.append(design['Classificaiton_type'].values[idx[0]])
            idxs.append(idx[0])
            samples.append(design['MS_file_name'].values[idx[0]])

        else:

            non_find.append(header[i])
    #design_final = design.iloc[idxs]
    labels = np.array(labels)

    comm, idx11, idx12 = np.intersect1d(np.array(samples), design['MS_file_name'].values, return_indices=True)
    mat_pro = mat_pro[:, idx11]
    design_final = design.iloc[idx12]

    if logT == 'T':
        mat_pro[mat_pro == 0] = np.nan
        mat_pro = np.log2(mat_pro)

        out_mat_inten = np.array(out_mat.values[:, 2:len(out_mat.values[0, :])], dtype='float')
        out_mat_inten[out_mat_inten == 0] = np.nan
        out_mat_inten = np.log2(out_mat_inten)
        out_mat = pd.DataFrame(np.column_stack((out_mat.values[:, 0:2], out_mat_inten)),
                               columns=list(out_mat.columns.values))

    out_mat = out_mat.iloc[:, list([0, 1]) + list(idx11 + 2)]

    avg_mat, design_avg = average_replicate(out_mat, design_final)
    return mat_pro, out_mat, labels[idx11], design_final, avg_mat, design_avg

def get_pro_inten_te(pro_list, matrix, design, logT='F'):

    pros = matrix['Protein'].values
    pros_id = []
    for i in range(len(pros)):
        pro = pros[i].split(';')
        pro_id = ''
        if len(pro) == 1:
            pro_id = pro[0].split('|')[1]
        elif len(pro) > 1:
            for j in range(len(pro)):
                id = pro[j].split('|')[1]
                if pro_id == '':
                    pro_id = id
                else:
                    pro_id += ';' + id

        pros_id.append(pro_id)

    pros_id = np.array(pros_id)

    com, idx1, idx2 = np.intersect1d(np.array(pro_list), pros_id, return_indices= True)
    np.setdiff1d(np.array(pro_list), pros_id)
    mat_all = np.array(matrix.values[:, 2:len(matrix.values[0, :])], dtype='float')
    # mat_pro = np.zeros((len(pro_list), len(mat_all[0, :])))
    # mat_pro[idx1, :] = mat_all[idx2, :]
    mat_pro = mat_all[idx2, :]
    out_mat = matrix.iloc[idx2]

    header = np.array(matrix.columns.values)[2:len(matrix.columns.values)]
    labels = []
    idxs = []
    non_find = []
    samples = []

    for i in range(len(header)):

        sample = (header[i].replace('D:\\', '').replace('.mzML.dia', '')
                  .replace('.mzML', '').replace('.', '_').replace('-', '_'))

        idx = np.where((design['MS_file_name'].values == sample))[0]
        if len(idx) == 1:
            labels.append(design['Classificaiton_type'].values[idx[0]])
            idxs.append(idx[0])
            samples.append(design['MS_file_name'].values[idx[0]])

        else:

            non_find.append(header[i])
    #design_final = design.iloc[idxs]
    labels = np.array(labels)

    comm, idx11, idx12 = np.intersect1d(np.array(samples), design['MS_file_name'].values, return_indices=True)
    mat_pro = mat_pro[:, idx11]
    design_final = design.iloc[idx12]


    if logT == 'T':
        mat_pro[mat_pro==0] = np.nan
        mat_pro = np.log2(mat_pro)

        out_mat_inten = np.array(out_mat.values[:, 2:len(out_mat.values[0, :])], dtype='float')
        out_mat_inten[out_mat_inten==0] = np.nan
        out_mat_inten = np.log2(out_mat_inten)
        out_mat = pd.DataFrame(np.column_stack((out_mat.values[:, 0:2], out_mat_inten)), columns=list(out_mat.columns.values))

    out_mat = out_mat.iloc[:, list([0, 1]) + list(idx11 + 2)]

    avg_mat, design_avg = average_replicate(out_mat, design_final)
    return mat_pro, out_mat, labels[idx11], design_final, avg_mat, design_avg

def preprocess_multi_view(pro_list):

    folder = 'data/'

    dlfq_tr_pth = folder + 'discovery/dlfq.tsv'
    maxlfq_tr_pth = folder + 'discovery/maxlfq.tsv'
    top3_tr_pth = folder + 'discovery/top3.tsv'

    dlfq_te_pth = folder + 'retrospective/dlfq.tsv'
    maxlfq_te_pth = folder + 'retrospective/maxlfq.tsv'
    top3_te_pth = folder + 'retrospective/top3.tsv'

    dlfq_te_pth = folder + 'retrospective/dlfq.tsv'
    maxlfq_te_pth = folder + 'retrospective/maxlfq.tsv'
    top3_te_pth = folder + 'retrospective/top3.tsv'

    design_tr_pth = folder + 'TPD_diann_protMatrix_20230207_lab_dis.csv'
    design_te_pth = folder + 'TPD_diann_protMatrix_20230207_lab_ret.csv'

    maxlfq_tr = pd.read_csv(maxlfq_tr_pth, sep='\t', header=0)
    dlfq_tr = pd.read_csv(dlfq_tr_pth, sep='\t', header=0)
    top3_tr = pd.read_csv(top3_tr_pth, sep='\t', header=0)

    maxlfq_te = pd.read_csv(maxlfq_te_pth, sep='\t', header=0)
    dlfq_te = pd.read_csv(dlfq_te_pth, sep='\t', header=0)
    top3_te = pd.read_csv(top3_te_pth, sep='\t', header=0)

    design_tr = pd.read_csv(design_tr_pth, sep=',', header=0)
    design_te = pd.read_csv(design_te_pth, sep=',', header=0)

    # pros_tr_maxlfq = get_pro_list(maxlfq_tr)
    # pros_tr_dlfq = get_pro_list(dlfq_tr)
    # pros_tr_top3 = get_pro_list(top3_tr)
    #
    # pros_te_maxlfq = get_pro_list(maxlfq_te)
    # pros_te_dlfq = get_pro_list(dlfq_te)
    # pros_te_top3 = get_pro_list(top3_te)

    pro_maxlfq_tr, mat_maxlfq_tr, labels_maxlfq_tr, design_maxlfq_tr, avg_mat_maxlfq_tr, avg_design_maxlfq_tr = get_pro_inten_tr(pro_list, maxlfq_tr, design_tr)
    # avg_mat_maxlfq_tr.to_csv(folder + 'avg_maxlfq_dis.csv')
    # avg_design_maxlfq_tr.to_csv(folder + 'avg_design_dis.csv')
    pro_dlfq_tr, mat_dlfq_tr, labels_dlfq_tr, design_dlfq_tr, avg_mat_dlfq_tr, avg_design_dlfq_tr = get_pro_inten_tr(pro_list, dlfq_tr, design_tr, logT='T')
    # avg_mat_dlfq_tr.to_csv(folder + 'avg_dlfq_dis.csv')
    pro_top3_tr, mat_top3_tr, labels_top3_tr, design_top3_tr, avg_mat_top3_tr, avg_design_top3_tr = get_pro_inten_tr(pro_list, top3_tr, design_tr)
    # avg_mat_top3_tr.to_csv(folder + 'avg_top3_dis.csv')

    pro_maxlfq_te, mat_maxlfq_te, labels_maxlfq_te, design_maxlfq_te, avg_mat_maxlfq_te, avg_design_maxlfq_te = get_pro_inten_te(pro_list, maxlfq_te, design_te)
    # avg_mat_maxlfq_te.to_csv(folder + 'avg_maxlfq_ret.csv')
    # avg_design_maxlfq_te.to_csv(folder + 'avg_design_te.csv')
    pro_dlfq_te, mat_dlfq_te, labels_dlfq_te, design_dlfq_te, avg_mat_dlfq_te, avg_design_dlfq_te = get_pro_inten_te(pro_list, dlfq_te, design_te, logT='T')
    # avg_mat_dlfq_te.to_csv(folder + 'avg_dlfq_ret.csv')
    pro_top3_te, mat_top3_te, labels_top3_te, design_top3_te, avg_mat_top3_te, avg_design_top3_te = get_pro_inten_te(pro_list, top3_te, design_te)
    # avg_mat_top3_te.to_csv(folder + 'avg_top3_ret.csv')

    tr_data = {'dlfq':{'data':avg_mat_dlfq_tr, 'design':avg_design_dlfq_tr},
                'maxlfq':{'data': avg_mat_maxlfq_tr, 'design':avg_design_maxlfq_tr},
                'top3':{'data': avg_mat_top3_tr, 'design':avg_design_top3_tr}}

    te_data = {'dlfq': {'data': avg_mat_dlfq_te, 'design': avg_design_dlfq_te},
                'maxlfq': {'data': avg_mat_maxlfq_te, 'design': avg_design_maxlfq_te},
                'top3': {'data': avg_mat_top3_te, 'design': avg_design_top3_te}}

    return tr_data, te_data

def xg_test_new(train_fea, test_fea, train_lab, test_lab, mean_fpr, ty='single'):
    if ty == 'mv':
        seed_torch(2024)

        kmcca = GCCA(latent_dimensions=30, random_state=2024)
        lat_out = kmcca.fit_transform(train_fea)
        lats_out = lat_out[0]
        for i in range(1, len(lat_out)):
            lats_out = np.column_stack((lats_out, lat_out[i]))

        lat_test = kmcca.transform(test_fea)
        lats_out_test = lat_test[0]
        for i in range(1, len(lat_test)):
            lats_out_test = np.column_stack((lats_out_test, lat_test[i]))

        train_fea = lats_out
        test_fea = lats_out_test

    #bst = XGBClassifier(objective='binary:logistic', scale_pos_weight=len(np.where((train_lab==0))[0]) / len(np.where((train_lab==1))[0]))
    bst = XGBClassifier(objective='binary:logistic', device='cuda', num_round=100)
    #bst = KNN()
    bst.fit(train_fea, train_lab)
    preds = bst.predict_proba(test_fea)
    pred_lab = bst.predict(test_fea)
    auc = roc_auc_score(test_lab[:, 0], preds[:, 1])


    fpr, tpr, thresholds = roc_curve(test_lab[:, 0], preds[:, 1], pos_label=1)

    interp_tpr = np.interp(mean_fpr, fpr, tpr)
    interp_tpr[0] = 0.0

    Acc = acc(test_lab[:, 0], pred_lab)
    Prec = precision(test_lab[:, 0], pred_lab)
    Rec = recall(test_lab[:, 0], pred_lab)
    F1 = f1(test_lab[:, 0], pred_lab)
    Mcc = mcc(test_lab[:, 0], pred_lab)

    return [auc, Acc, Prec, Rec, F1, Mcc], interp_tpr, auc, preds[:, 1], pred_lab

def xg_test_extend(train_fea, test_fea, train_lab, test_lab, mean_fpr, extend_true_lab, extend_score, extend_lab):

    bst = XGBClassifier(objective='binary:logistic')
    #bst = KNN()
    bst.fit(train_fea, train_lab)
    preds = bst.predict_proba(test_fea)
    pred_lab = bst.predict(test_fea)

    pred_prob = np.array(list(extend_score) + list(preds[:, 1]))
    pred_lab = np.array(list(extend_lab) + list(pred_lab))
    auc = roc_auc_score(np.array(list(extend_true_lab[:, 0]) + list(test_lab[:, 0])), pred_prob)

    fpr, tpr, thresholds = roc_curve(np.array(list(extend_true_lab[:, 0]) + list(test_lab[:, 0])), pred_prob, pos_label=1)

    interp_tpr = np.interp(mean_fpr, fpr, tpr)
    interp_tpr[0] = 0.0

    Acc = acc(np.array(list(extend_true_lab[:, 0]) + list(test_lab[:, 0])), pred_lab)
    Prec = precision(np.array(list(extend_true_lab[:, 0]) + list(test_lab[:, 0])), pred_lab)
    Rec = recall(np.array(list(extend_true_lab[:, 0]) + list(test_lab[:, 0])), pred_lab)
    F1 = f1(np.array(list(extend_true_lab[:, 0]) + list(test_lab[:, 0])), pred_lab)
    Mcc = mcc(np.array(list(extend_true_lab[:, 0]) + list(test_lab[:, 0])), pred_lab)

    return [auc, Acc, Prec, Rec, F1, Mcc], interp_tpr, auc, pred_prob, pred_lab

def xg_test_ens(train_fea, test_fea, train_lab, test_lab, mean_fpr):

    preds = []
    pred_labs = []
    for i in range(len(train_fea)):
        bst = XGBClassifier(objective='binary:logistic', device='cuda', num_round=100)
        #bst = KNN()
        bst.fit(train_fea[i], train_lab)
        pred = bst.predict_proba(test_fea[i])
        pred_lab = bst.predict(test_fea[i])
        preds.append(pred[:, 1])
        pred_labs.append(pred_lab)

    preds = np.mean(np.array(preds),axis=0)
    pred_labs = np.array(pred_labs).T

    pred_lab1 = np.array([1 if preds[j]>0.5 else 0 for j in range(len(preds))])
    pred_lab2 = np.array([1 if sum(pred_labs[j, :])>1 else 0 for j in range(len(pred_labs))])

    auc = roc_auc_score(test_lab[:, 0], preds)
    #mean_fpr = np.linspace(0, 1, 100)
    fpr, tpr, thresholds = roc_curve(test_lab[:, 0], preds, pos_label=1)

    interp_tpr = np.interp(mean_fpr, fpr, tpr)
    interp_tpr[0] = 0.0

    Acc1 = acc(test_lab[:, 0], pred_lab1)
    Prec1 = precision(test_lab[:, 0], pred_lab1)
    Rec1 = recall(test_lab[:, 0], pred_lab1)
    F11 = f1(test_lab[:, 0], pred_lab1)
    Mcc1 = mcc(test_lab[:, 0], pred_lab1)

    Acc2 = acc(test_lab[:, 0], pred_lab2)
    Prec2 = precision(test_lab[:, 0], pred_lab2)
    Rec2 = recall(test_lab[:, 0], pred_lab2)
    F12 = f1(test_lab[:, 0], pred_lab2)
    Mcc2 = mcc(test_lab[:, 0], pred_lab2)

    return [auc, Acc1, Prec1, Rec1, F11, Mcc1, auc, Acc2, Prec2, Rec2, F12, Mcc2], interp_tpr, auc

def get_data_lab(dict, view):

    data_dis_dlfq = np.array(dict[view]['data'].values[:, 2:len(dict[view]['data'].values[0, :])].T, dtype='float')
    lab_dis_dlfq = np.zeros((len(data_dis_dlfq[:, 0]), 1))
    lab_dis_dlfq[np.where((dict[view]['design']['Classificaiton_type'].values == 'B'))[0]] = 1
    lab_dis_dlfq = lab_dis_dlfq
    return data_dis_dlfq, lab_dis_dlfq

def Fill_nan(data, fill_value):

    data[np.isnan(data)] = fill_value
    return data

def cv_model(train_feas, train_lab, seed, param, model='XGB'):
    seed_torch(seed)
    rs = StratifiedKFold(n_splits=5, shuffle=True,  random_state=2024)
    aucs = []
    Mccs = []
    f1s = []
    accs = []
    bsts = []
    for i, (train_index, test_index) in enumerate(rs.split(train_feas, train_lab)):
        train = train_feas[train_index, :]
        test = train_feas[test_index, :]

        train_y = train_lab[train_index]
        test_y = train_lab[test_index]

        if model == 'XGB':
            bst = XGBClassifier(n_estimators=param['num'], max_depth=param['d'], learning_rate=param['lr'], objective='binary:logistic')
        elif model == 'svm':
            bst = SVC(C=param['C'], gamma=param['g'], probability=True)
        # fit model
        bst.fit(train, train_y)
        # make predictions
        preds = bst.predict_proba(test)
        pred_lab = bst.predict(test)
        Mcc = mcc(test_y[:, 0], pred_lab)
        auc = roc_auc_score(test_y[:, 0], preds[:, 1])
        Mccs.append(Mcc)
        aucs.append(auc)
        f1_ = f1(test_y[:, 0], pred_lab)
        f1s.append(f1_)
        ac = acc(test_y[:, 0], pred_lab)
        accs.append(ac)
        bsts.append(bst)
    return np.mean(aucs), np.mean(Mccs), np.mean(f1s), np.mean(accs)


def cv_model_mv(train_feas, train_lab, test_feas, test_lab, seed, param, model='XGB'):
    seed_torch(seed)

    kmcca = GCCA(latent_dimensions=param['N'], c=param['c'], random_state=2024)

    all_data = [np.row_stack((train_feas[i], test_feas[i])) for i in range(len(train_feas))]

    lat_out = kmcca.fit_transform(all_data)
    lats_out_mvidia_all = np.concatenate(lat_out, axis=1)
    lats_out_mvidia = lats_out_mvidia_all[0:len(train_lab), :]

    rs = StratifiedKFold(n_splits=5, shuffle=True,  random_state=2024)
    aucs = []
    Mccs = []
    f1s = []
    accs = []
    for i, (train_index, test_index) in enumerate(rs.split(train_feas[0], train_lab)):
        train = lats_out_mvidia[train_index, :]
        test = lats_out_mvidia[test_index, :]
        cat_train = np.concatenate(train_feas, axis=1)[train_index, :]
        cat_test = np.concatenate(train_feas, axis=1)[test_index, :]

        train_y = train_lab[train_index]
        test_y = train_lab[test_index]
        if model == 'mv-concat':
            bst = XGBClassifier(n_estimators=param['num'], max_depth=param['d'], learning_rate=param['lr'],
                                objective='binary:logistic')
            bst_concat = XGBClassifier(n_estimators=param['num_cat'], max_depth=param['d_cat'], learning_rate=param['lr_cat'],
                                objective='binary:logistic')
            bst_concat.fit(cat_train, train_y)
            bst.fit(train, train_y)
            # make predictions
            pred_mv = bst.predict_proba(test)
            pred_cat = bst_concat.predict_proba(cat_test)
            preds = (pred_mv + pred_cat)/2 #pred_mv * param['alpha'] + pred_cat * (1-param['alpha'])
            auc = roc_auc_score(test_y[:, 0], preds[:, 1])
            pred_lab = np.array([0] * len(preds))
            pred_lab[np.where((preds[:, 1] >= 0.5))[0]] = 1
            Mcc = mcc(test_y[:, 0], pred_lab)
            Mccs.append(Mcc)
            aucs.append(auc)
            f1_ = f1(test_y[:, 0], pred_lab)
            f1s.append(f1_)
            ac = acc(test_y[:, 0], pred_lab)
            accs.append(ac)
        elif model == 'mv+concat':
            bst = XGBClassifier(n_estimators=param['num'], max_depth=param['d'], learning_rate=param['lr'],
                                objective='binary:logistic')

            bst.fit(np.concatenate([train, cat_train],axis=1), train_y)
            preds = bst.predict_proba(np.concatenate([test, cat_test],axis=1))
            pred_lab = bst.predict(np.concatenate([test, cat_test],axis=1))
            Mcc = mcc(test_y[:, 0], pred_lab)
            auc = roc_auc_score(test_y[:, 0], preds[:, 1])
            Mccs.append(Mcc)
            aucs.append(auc)
            f1_ = f1(test_y[:, 0], pred_lab)
            f1s.append(f1_)
            ac = acc(test_y[:, 0], pred_lab)
            accs.append(ac)
        else:
            if model == 'XGB':
                bst = XGBClassifier(n_estimators=param['num'], max_depth=param['d'], learning_rate=param['lr'],
                                    objective='binary:logistic')

            elif model == 'svm':
                bst = SVC(C=param['C'], gamma=param['g'], probability=True)
            # fit model
            bst.fit(train, train_y)
            # make predictions
            preds = bst.predict_proba(test)

            pred_lab = bst.predict(test)
            Mcc = mcc(test_y[:, 0], pred_lab)
            auc = roc_auc_score(test_y[:, 0], preds[:, 1])
            Mccs.append(Mcc)
            aucs.append(auc)
            f1_ = f1(test_y[:, 0], pred_lab)
            f1s.append(f1_)
            ac = acc(test_y[:, 0], pred_lab)
            accs.append(ac)

    return np.mean(aucs), np.mean(Mccs), np.mean(f1s), np.mean(accs)

def cv_model_semi(train_feas, train_lab, test_feas, test_lab, seed, param, model='XGB'):
    seed_torch(seed)

    rs = StratifiedKFold(n_splits=5, shuffle=True,  random_state=2024)
    aucs = []
    Mccs = []
    f1s = []
    accs = []

    test_pesudo = np.array([[0] * len(test_lab)]).T
    test_data = [np.row_stack((train_feas[j], test_feas[j])) for j in range(len(train_feas))]
    test_label = np.row_stack((train_lab, test_pesudo))

    kmcca = GCCA(latent_dimensions=param['N'], c=param['c'], random_state=2024)
    lat_out = kmcca.fit_transform(test_data)
    lats_out_tr = lat_out[0]
    for i in range(1, len(lat_out)):
        lats_out_tr = np.column_stack((lats_out_tr, lat_out[i]))

    for i, (train_index, test_index) in enumerate(rs.split(lats_out_tr, test_label)):
        train = lats_out_tr[train_index, :]
        test = lats_out_tr[test_index, :]

        train_y = test_label[train_index]
        test_y = test_label[test_index]

        if model == 'XGB':
            bst = XGBClassifier(n_estimators=param['num'], max_depth=param['d'], learning_rate=param['lr'],
                                objective='binary:logistic')
        elif model == 'svm':
            bst = SVC(C=param['C'], gamma=param['g'], probability=True)
        # fit model
        bst.fit(train, train_y)
        # make predictions
        preds = bst.predict_proba(test)

        pred_lab = bst.predict(test)
        Mcc = mcc(test_y[:, 0], pred_lab)
        auc = roc_auc_score(test_y[:, 0], preds[:, 1])
        Mccs.append(Mcc)
        aucs.append(auc)
        f1_ = f1(test_y[:, 0], pred_lab)
        f1s.append(f1_)
        ac = acc(test_y[:, 0], pred_lab)
        accs.append(ac)

    return np.mean(aucs), np.mean(Mccs), np.mean(f1s), np.mean(accs)

def cv_model_mvidia(test_fea_single, train_fea_single, train_feas, train_lab, test_feas, test_lab, seed, param, bsts, model='XGB'):
    seed_torch(seed)

    preds = []
    pred_labs = []

    for i in range(len(train_feas)):

        pred = bsts[i].predict_proba(np.row_stack((train_fea_single[i], test_fea_single[i])))
        pred_lab = bsts[i].predict(np.row_stack((train_fea_single[i], test_fea_single[i])))
        preds.append(pred[:, 1])
        pred_labs.append(pred_lab)

    sum_lab = np.sum(pred_labs, axis=0)
    ind_reliable = np.where(((sum_lab == 0) | (sum_lab == len(train_feas))))[0]

    train_fea_reliable = [np.row_stack((train_feas[j], test_feas[j]))[ind_reliable, :] for j in range(len(train_feas))]
    train_lab_reliable = np.array([pred_labs[0][ind_reliable]]).T
    acc0 = acc(np.row_stack((train_lab, test_lab))[ind_reliable, 0], pred_labs[0][ind_reliable])
    if (model == 'mvidia') | (model == 'mv-concat') | (model == 'mv+concat'):
        kmcca = GCCA(latent_dimensions=param['N'], c=param['c'], random_state=2024)
        # fea_all = [np.row_stack((train_fea_single[i], test_fea_single[i])) for i in range(len(train_fea_single))]
        fea_all = [np.row_stack((train_feas[i], test_feas[i])) for i in range(len(train_feas))]
        lat_out = kmcca.fit_transform(fea_all)
        lats_out_all = np.concatenate(lat_out, axis=1)
        lats_out_tr = lats_out_all[ind_reliable, :]

    elif model == 'concat':
        lats_out_tr = np.concatenate(train_fea_reliable, axis=1)
    elif model == 'ens':
        lats_out_tr = train_fea_reliable

    Mccs = []
    aucs = []
    f1s = []
    accs = []
    rs = StratifiedKFold(n_splits=5, shuffle=True, random_state=2024)
    if model != 'ens':
        for i, (train_index, test_index) in enumerate(rs.split(lats_out_tr, train_lab_reliable)):
            train = lats_out_tr[train_index, :]
            test = lats_out_tr[test_index, :]

            cat_train = np.concatenate(train_fea_reliable, axis=1)[train_index, :]
            cat_test = np.concatenate(train_fea_reliable, axis=1)[test_index, :]

            train_y = train_lab_reliable[train_index]
            test_y = train_lab_reliable[test_index]

            if model == 'mv-concat':
                bst = XGBClassifier(n_estimators=param['num'], max_depth=param['d'], learning_rate=param['lr'],
                                    objective='binary:logistic')
                bst.fit(train, train_y)
                preds_mv = bst.predict_proba(test)

                bst_cat = XGBClassifier(n_estimators=param['num_cat'], max_depth=param['d_cat'], learning_rate=param['lr_cat'],
                                    objective='binary:logistic')
                bst_cat.fit(cat_train, train_y)
                preds_cat = bst_cat.predict_proba(cat_test)

                preds = (preds_mv + preds_cat)/2#preds_mv * param['alpha'] + preds_cat * (1-param['alpha'])
                pred_lab = np.array([0] * len(preds))
                pred_lab[np.where((preds[:, 1] >= 0.5))[0]] = 1
            elif model == 'mv+concat':
                bst = XGBClassifier(n_estimators=param['num'], max_depth=param['d'], learning_rate=param['lr'],
                                    objective='binary:logistic')
                bst.fit(np.concatenate([train, cat_train], axis=1), train_y)
                preds = bst.predict_proba(np.concatenate([test, cat_test], axis=1))
                pred_lab = bst.predict(np.concatenate([test, cat_test], axis=1))

            else:
                bst = XGBClassifier(n_estimators=param['num'], max_depth=param['d'], learning_rate=param['lr'],
                                    objective='binary:logistic')

                bst.fit(train, train_y)
                # make predictions
                preds = bst.predict_proba(test)
                pred_lab = bst.predict(test)
            Mcc = mcc(test_y[:, 0], pred_lab)
            auc = roc_auc_score(test_y[:, 0], preds[:, 1])
            Mccs.append(Mcc)
            aucs.append(auc)
            f1_ = f1(test_y[:, 0], pred_lab)
            f1s.append(f1_)
            ac = acc(test_y[:, 0], pred_lab)
            accs.append(ac)

    else:
        for i, (train_index, test_index) in enumerate(rs.split(lats_out_tr[0], train_lab_reliable)):
            train = [lats_out_tr[v][train_index, :] for v in range(len(lats_out_tr))]
            test = [lats_out_tr[v][test_index, :] for v in range(len(lats_out_tr))]

            train_y = train_lab_reliable[train_index]
            test_y = train_lab_reliable[test_index]

            bst = [XGBClassifier(n_estimators=param['num'+str(v)], max_depth=param['d'+str(v)], learning_rate=param['lr'+str(v)],
                                objective='binary:logistic') for v in range(len(bsts))]

            preds = []
            for v in range(len(bsts)):
                bst[v].fit(train[v], train_y)
                pred = bst[v].predict_proba(test[v])

                preds.append(pred[:, 1])
            preds = np.mean(preds, axis=0)

            pred_lab = np.array([0] * len(preds))
            pred_lab[np.where((preds >= 0.5))[0]] = 1

            Mcc = mcc(test_y[:, 0], pred_lab)
            auc = roc_auc_score(test_y[:, 0], preds)
            Mccs.append(Mcc)
            aucs.append(auc)
            f1_ = f1(test_y[:, 0], pred_lab)
            f1s.append(f1_)
            ac = acc(test_y[:, 0], pred_lab)
            accs.append(ac)

    return np.mean(aucs), np.mean(Mccs), np.mean(f1s), np.mean(accs)


def test_model(train_feas, train_lab, seed, test_feas, test_lab, param, model='XGB'):
    seed_torch(seed)

    if model == 'XGB':
        bst = XGBClassifier(n_estimators=param['num'], max_depth=param['d'], learning_rate=param['lr'],
                            objective='binary:logistic')
    elif model == 'svm':
        bst = SVC(C=2**param['C'], gamma=2**param['g'], probability=True)
    bst.fit(train_feas, train_lab)
    # make predictions
    preds = bst.predict_proba(test_feas)
    auc = roc_auc_score(test_lab[:, 0], preds[:, 1])

    pred_lab = bst.predict(test_feas)

    Acc = acc(test_lab[:, 0], pred_lab)
    Prec = precision(test_lab[:, 0], pred_lab)
    Rec = recall(test_lab[:, 0], pred_lab)
    F1 = f1(test_lab[:, 0], pred_lab)
    Mcc = mcc(test_lab[:, 0], pred_lab)

    return preds[:, 1], [auc, Acc, Prec, Rec, F1, Mcc], bst


def test_model_mv(train_feas, train_lab, seed, test_feas, test_lab, param, model='XGB'):
    seed_torch(seed)

    kmcca = GCCA(latent_dimensions=param['N'], c=param['c'], random_state=2024)
    all_data = [np.row_stack((train_feas[v], test_feas[v])) for v in range(len(train_feas))]
    lat_out = kmcca.fit_transform(all_data)
    lats_out_mvidia = np.concatenate(lat_out, axis=1)

    lats_out_mvidia_test = lats_out_mvidia[len(train_lab):len(lats_out_mvidia[:, 0]), :]
    lats_out_mvidia = lats_out_mvidia[0:len(train_lab), :]

    if model == 'mv-concat':
        bst = XGBClassifier(n_estimators=param['num'], max_depth=param['d'], learning_rate=param['lr'],
                            objective='binary:logistic')
        bst_concat = XGBClassifier(n_estimators=param['num_cat'], max_depth=param['d_cat'], learning_rate=param['lr_cat'],
                            objective='binary:logistic')

        bst.fit(lats_out_mvidia, train_lab)
        preds_mv = bst.predict_proba(lats_out_mvidia_test)

        bst_concat.fit(np.concatenate(train_feas, axis=1), train_lab)
        preds_cat = bst_concat.predict_proba(np.concatenate(test_feas, axis=1))

        preds = (preds_mv + preds_cat)/2#preds_mv * param['alpha'] + preds_cat * (1 - param['alpha'])
        pred_lab = np.array([0] * len(preds))
        pred_lab[np.where((preds[:, 1] >= 0.5))[0]] = 1

        bst = [bst, bst_concat]
    elif model == 'mv+concat':
        bst = XGBClassifier(n_estimators=param['num'], max_depth=param['d'], learning_rate=param['lr'],
                            objective='binary:logistic')
        bst.fit(np.concatenate([lats_out_mvidia, np.concatenate(train_feas, axis=1)], axis=1), train_lab)
        preds = bst.predict_proba(np.concatenate([lats_out_mvidia_test, np.concatenate(test_feas, axis=1)], axis=1))
        pred_lab = bst.predict(np.concatenate([lats_out_mvidia_test, np.concatenate(test_feas, axis=1)], axis=1))
    else:
        if model == 'XGB':
            bst = XGBClassifier(n_estimators=param['num'], max_depth=param['d'], learning_rate=param['lr'],
                                objective='binary:logistic')
        elif model == 'svm':
            bst = SVC(C=2**param['C'], gamma=2**param['g'], probability=True)
        bst.fit(lats_out_mvidia, train_lab)
        preds = bst.predict_proba(lats_out_mvidia_test)
        pred_lab = bst.predict(lats_out_mvidia_test)

    auc = roc_auc_score(test_lab[:, 0], preds[:, 1])
    Acc = acc(test_lab[:, 0], pred_lab)
    Prec = precision(test_lab[:, 0], pred_lab)
    Rec = recall(test_lab[:, 0], pred_lab)
    F1 = f1(test_lab[:, 0], pred_lab)
    Mcc = mcc(test_lab[:, 0], pred_lab)

    return preds[:, 1], [auc, Acc, Prec, Rec, F1, Mcc], lats_out_mvidia_test, bst

def test_model_semi(train_feas, train_lab, seed, test_feas, test_lab, param, model='XGB'):
    seed_torch(seed)
    seed_torch(seed)

    rs = StratifiedKFold(n_splits=5, shuffle=True, random_state=2024)
    # aucs = []
    # Mccs = []

    test_pesudo = np.array([[0] * len(test_lab)]).T
    test_data = [np.row_stack((train_feas[j], test_feas[j])) for j in range(len(train_feas))]
    test_label = np.row_stack((train_lab, test_pesudo))

    kmcca = GCCA(latent_dimensions=param['N'], c=param['c'], random_state=2024)
    lat_out = kmcca.fit_transform(test_data)
    lats_out_tr = lat_out[0]
    for i in range(1, len(lat_out)):
        lats_out_tr = np.column_stack((lats_out_tr, lat_out[i]))

    preds = []
    for i, (train_index, test_index) in enumerate(rs.split(lats_out_tr, test_label)):
        train = lats_out_tr[train_index, :]
        test = lats_out_tr[test_index, :]

        train_y = test_label[train_index]
        test_y = test_label[test_index]

        if model == 'XGB':
            bst = XGBClassifier(n_estimators=param['num'], max_depth=param['d'], learning_rate=param['lr'],
                                objective='binary:logistic')
        elif model == 'svm':
            bst = SVC(C=param['C'], gamma=param['g'], probability=True)
        # fit model
        bst.fit(train, train_y)

        # make predictions
        pred = bst.predict_proba(test[len(train_lab):len(test_label), :])
        preds.append(pred)

    preds = np.mean(preds, axis=0)
    auc = roc_auc_score(test_lab[:, 0], preds)

    pred_lab = np.array([0] * len(preds))
    pred_lab[np.where((preds >= 0.5))[0]] = 1

    Acc = acc(test_lab[:, 0], pred_lab)
    Prec = precision(test_lab[:, 0], pred_lab)
    Rec = recall(test_lab[:, 0], pred_lab)
    F1 = f1(test_lab[:, 0], pred_lab)
    Mcc = mcc(test_lab[:, 0], pred_lab)

    return preds, [auc, Acc, Prec, Rec, F1, Mcc], '', ''

def test_model_mvidia(test_fea_single, train_fea_single, train_feas, train_lab, seed, test_feas, test_lab, bsts, param, model='XGB'):
    seed_torch(seed)

    preds = []
    pred_labs = []

    for i in range(len(bsts)):

        pred = bsts[i].predict_proba(np.row_stack((train_fea_single[i], test_fea_single[i])))
        pred_lab = bsts[i].predict(np.row_stack((train_fea_single[i], test_fea_single[i])))
        preds.append(pred)
        pred_labs.append(pred_lab)

    sum_lab = np.sum(pred_labs, axis=0)
    ind_reliable = np.where(((sum_lab == 0) | (sum_lab == len(bsts))))[0]

    acc0 = acc(np.row_stack((train_lab, test_lab))[ind_reliable, 0], pred_labs[0][ind_reliable])

    train_fea_reliable = [np.row_stack((train_feas[j], test_feas[j]))[ind_reliable, :] for j in range(len(bsts))]
    train_lab_reliable = np.array([pred_labs[0]]).T[ind_reliable]

    if (model == 'mvidia') | (model == 'mv-concat') | (model == 'mv+concat'):

        all_data = [np.row_stack((train_fea_reliable[v], test_feas[v])) for v in range(len(bsts))]

        kmcca = GCCA(latent_dimensions=param['N'], c=param['c'], random_state=2024)

        lat_out = kmcca.fit_transform(all_data)
        lats_out_all = np.concatenate(lat_out, axis=1)

        lats_out_te = lats_out_all[len(train_lab_reliable):len(all_data[0][:, 0]), :]
        lats_out_tr = lats_out_all[0:len(train_lab_reliable), :]

        # all_data = [np.row_stack((train_feas[v], test_feas[v])) for v in range(len(bsts))]
        # kmcca = GCCA(latent_dimensions=param['N'], c=param['c'], random_state=2024)
        #
        # lat_out = kmcca.fit_transform(all_data)
        # lats_out_all = np.concatenate(lat_out, axis=1)
        #
        # lats_out_te = lats_out_all[len(train_lab):len(lats_out_all[:, 0]), :]
        # lats_out_tr = lats_out_all[ind_reliable, :]

    elif model == 'concat':
        lats_out_tr = np.concatenate(train_fea_reliable, axis=1)
        lats_out_te = np.concatenate(test_feas, axis=1)
    elif model == 'ens':
        lats_out_tr = train_fea_reliable
        lats_out_te = test_feas

    if model != 'ens':
        if model == 'mv-concat':
            bst = XGBClassifier(n_estimators=param['num'], max_depth=param['d'], learning_rate=param['lr'],
                                objective='binary:logistic')

            bst.fit(lats_out_tr, train_lab_reliable)
            preds_mv = bst.predict_proba(lats_out_te)

            bst_cat = XGBClassifier(n_estimators=param['num_cat'], max_depth=param['d_cat'], learning_rate=param['lr_cat'],
                                objective='binary:logistic')

            bst_cat.fit(np.concatenate(train_fea_reliable, axis=1), train_lab_reliable)
            preds_cat = bst_cat.predict_proba(np.concatenate(test_feas, axis=1))

            preds = (preds_mv + preds_cat)/2#preds_mv * param['alpha'] + preds_cat * (1 - param['alpha'])
            pred_lab = np.array([0] * len(preds))
            pred_lab[np.where((preds[:, 1] >= 0.5))[0]] = 1

            bst = [bst, bst_cat]

        elif model == 'mv+concat':
            bst = XGBClassifier(n_estimators=param['num'], max_depth=param['d'], learning_rate=param['lr'],
                                objective='binary:logistic')
            bst.fit(np.concatenate([lats_out_tr, np.concatenate(train_fea_reliable, axis=1)], axis=1), train_lab_reliable)
            preds = bst.predict_proba(np.concatenate([lats_out_te, np.concatenate(test_feas, axis=1)], axis=1))
            pred_lab = bst.predict(np.concatenate([lats_out_te, np.concatenate(test_feas, axis=1)], axis=1))

        else:
            bst = XGBClassifier(n_estimators=param['num'], max_depth=param['d'], learning_rate=param['lr'],
                                    objective='binary:logistic')

            bst.fit(lats_out_tr, train_lab_reliable)
            preds = bst.predict_proba(lats_out_te)
            pred_lab = bst.predict(lats_out_te)

        auc = roc_auc_score(test_lab[:, 0], preds[:, 1])
        Acc = acc(test_lab[:, 0], pred_lab)
        Prec = precision(test_lab[:, 0], pred_lab)
        Rec = recall(test_lab[:, 0], pred_lab)
        F1 = f1(test_lab[:, 0], pred_lab)
        Mcc = mcc(test_lab[:, 0], pred_lab)

        preds = preds[:, 1]

    else:

        bst = [XGBClassifier(n_estimators=param['num' + str(v)], max_depth=param['d' + str(v)],
                             learning_rate=param['lr' + str(v)],
                             objective='binary:logistic') for v in range(len(bsts))]

        preds = []
        for v in range(len(bsts)):
            bst[v].fit(lats_out_tr[v], train_lab_reliable)
            pred = bst[v].predict_proba(lats_out_te[v])

            preds.append(pred[:, 1])

        preds = np.mean(preds, axis=0)
        auc = roc_auc_score(test_lab[:, 0], preds)

        pred_lab = np.array([0] * len(preds))
        pred_lab[np.where((preds >= 0.5))[0]] = 1

        Acc = acc(test_lab[:, 0], pred_lab)
        Prec = precision(test_lab[:, 0], pred_lab)
        Rec = recall(test_lab[:, 0], pred_lab)
        F1 = f1(test_lab[:, 0], pred_lab)
        Mcc = mcc(test_lab[:, 0], pred_lab)

    return preds, [auc, Acc, Prec, Rec, F1, Mcc], lats_out_te, bst

def test_model_ens(bsts, params, seed, train_feas, test_feas, test_lab, ty):
    seed_torch(seed)


    preds = []
    for i in range(0,len(train_feas)):

        pred = bsts[i].predict_proba(test_feas[i])
        preds.append(pred[:, 1])

    if 'c' in ty: #fusion ens and cat
        idx = ty.index('c')
        preds.append(bsts[idx].predict_proba(np.concatenate(test_feas, axis=1))[:, 1])

    if 'g' in ty: # fusion ens, cat and gcca

        idx = ty.index('g')

        kmcca = GCCA(latent_dimensions=params[idx]['N'], c=params[idx]['c'], random_state=2024)
        all_data = [np.row_stack((train_feas[v], test_feas[v])) for v in range(len(train_feas))]
        lat_out = kmcca.fit_transform(all_data)
        lats_out_mvidia = np.concatenate(lat_out, axis=1)

        test_lat = lats_out_mvidia[len(train_feas[0][:, 0]):len(lats_out_mvidia[:, 0]), :]

        preds.append(bsts[idx].predict_proba(test_lat)[:, 1])


    preds = np.mean(preds, axis=0)
    auc = roc_auc_score(test_lab[:, 0], preds)

    pred_lab = np.array([0] * len(preds))
    pred_lab[np.where((preds>=0.5))[0]] = 1

    Acc = acc(test_lab[:, 0], pred_lab)
    Prec = precision(test_lab[:, 0], pred_lab)
    Rec = recall(test_lab[:, 0], pred_lab)
    F1 = f1(test_lab[:, 0], pred_lab)
    Mcc = mcc(test_lab[:, 0], pred_lab)

    return preds, [auc, Acc, Prec, Rec, F1, Mcc]

def test_model_ens_all(preds, test_lab):

    preds = np.mean(preds, axis=0)
    auc = roc_auc_score(test_lab[:, 0], preds)

    pred_lab = np.array([0] * len(preds))
    pred_lab[np.where((preds>=0.5))[0]] = 1

    Acc = acc(test_lab[:, 0], pred_lab)
    Prec = precision(test_lab[:, 0], pred_lab)
    Rec = recall(test_lab[:, 0], pred_lab)
    F1 = f1(test_lab[:, 0], pred_lab)
    Mcc = mcc(test_lab[:, 0], pred_lab)

    return preds, [auc, Acc, Prec, Rec, F1, Mcc]

def seed_torch(seed=1029):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)


def objective(trail, train_feas, train_lab, test_feas, test_lab, seed, model_type):
    seed_torch(seed)

    if model_type == 'single':
        num = trail.suggest_int('num', 2, 100, step=5)  # n_estimators
        d = trail.suggest_int('d', 1, 10, step=1)  # max depth
        lr = trail.suggest_float('lr', 0.0001, 1)  # max depth
        param = {'num': num, 'd': d, 'lr':lr}
        auc, mcc, f1, acc = cv_model(train_feas, train_lab, seed, param)

    elif (model_type == 'mv') | (model_type == 'mv+concat'):
        max_N = min([len(train_feas[0][0, :]), len(train_feas[0][:, 0])])
        N = trail.suggest_int('N', 2, max_N, step=1) # n_estimators
        num = trail.suggest_int('num', 2, 100, step=5)  # n_estimators
        d = trail.suggest_int('d', 1, 15, step=1)  # max depth
        c = trail.suggest_float('c', 0.0001, 1)  # max depth
        lr = trail.suggest_float('lr', 0.0001, 1)  # max depth
        # alpha = trail.suggest_float('alpha', 0, 1)
        param = {'N': N, 'num': num, 'd': d, 'lr':lr, 'c':c}
        if model_type == 'mv+cat':
            auc, mcc, f1, acc = cv_model_mv(train_feas, train_lab, test_feas, test_lab, seed, param, model='mv+concat')
        else:
            auc, mcc, f1, acc = cv_model_mv(train_feas, train_lab, test_feas, test_lab, seed, param)

    elif model_type == 'mv-concat':
        max_N = min([len(train_feas[0][0, :]), len(train_feas[0][:, 0])])
        N = trail.suggest_int('N', 2, max_N, step=1) # n_estimators
        num = trail.suggest_int('num', 2, 100, step=5)  # n_estimators
        d = trail.suggest_int('d', 1, 10, step=1)  # max depth
        c = trail.suggest_float('c', 0.0001, 1)  # max depth
        lr = trail.suggest_float('lr', 0.0001, 1)  # max depth

        num_cat = trail.suggest_int('num_cat', 2, 100, step=5)  # n_estimators
        d_cat = trail.suggest_int('d_cat', 1, 10, step=1)  # max depth
        lr_cat = trail.suggest_float('lr_cat', 0.0001, 1)  # max depth
        # alpha = trail.suggest_float('alpha', 0.0, 1)  # max depth
        param = {'N': N, 'num': num, 'd': d, 'lr':lr, 'c':c, 'num_cat':num_cat, 'd_cat':d_cat, 'lr_cat':lr_cat}#, 'alpha':alpha}

        auc, mcc, f1, acc = cv_model_mv(train_feas, train_lab, test_feas, test_lab, seed, param, model='mv-concat')

    elif model_type == 'single_svm':
        C = trail.suggest_int('C', -10, 10, step=1) # n_estimators
        g = trail.suggest_int('g', -10, 10, step=1) # max depth
        #lr = trail.suggest_float('lr', 0.0001, 1) # max depth
        param = {'C': 2**C, 'g': 2**g}
        auc, mcc, f1, acc = cv_model(train_feas, train_lab, seed, param, model='svm')

    elif model_type == 'mv_svm':

        max_N = min([len(train_feas[0][0, :]), len(train_feas[0][:, 0])])
        N = trail.suggest_int('N', 2, max_N, step=1)  # n_estimators
        C = trail.suggest_int('C', -10, 10, step=1)  # n_estimators
        g = trail.suggest_int('g', -10, 10, step=1)  # max depth
        param = {'N': N,'C': 2**C, 'g': 2**g}

        auc, mcc, f1, acc = cv_model_mv(train_feas, train_lab, seed, param, model='svm')


    return 1 - auc#mcc#auc#acc#f1

def objective_semi(trail, train_feas, train_lab, test_feas, test_lab, seed, model_type):
    seed_torch(seed)

    if model_type == 'single':
        num = trail.suggest_int('num', 2, 100, step=5) # n_estimators
        d = trail.suggest_int('d', 1, 10, step=1)  # max depth
        lr = trail.suggest_float('lr', 0.0001, 0.1)  # max depth
        param = {'num': num, 'd': d, 'lr': lr}
        auc, mcc, f1, acc = cv_model_semi(train_feas, train_lab, test_feas, test_lab, seed, param)

    elif model_type == 'semi':

        max_N = min([len(train_feas[0][0, :]), len(train_feas[0][:, 0])])
        N = trail.suggest_int('N', 2, max_N, step=1)  # n_estimators
        num = trail.suggest_int('num', 2, 100, step=5) # n_estimators
        d = trail.suggest_int('d', 1, 10, step=1)  # max depth
        lr = trail.suggest_float('lr', 0.0001, 1)  # max depth
        c = trail.suggest_float('c', 0.0001, 1)  # max depth
        param = {'N': N, 'num': num, 'd': d, 'lr': lr, 'c':c}

        auc, mcc, f1, acc = cv_model_semi(train_feas, train_lab, test_feas, test_lab, seed, param)

    return 1 - auc#acc#f1

def objective_mvidia(trail, test_fea_single, train_fea_single, train_feas, train_lab, test_feas, test_lab, seed, model_type, bst):
    seed_torch(seed)

    if (model_type == 'concat'):
        num = trail.suggest_int('num', 2, 100, step=5) # n_estimators
        d = trail.suggest_int('d', 1, 10, step=1)  # max depth
        lr = trail.suggest_float('lr', 0.0001, 1)  # max depth
        param = {'num': num, 'd': d, 'lr': lr}
        auc, mcc, f1, acc = cv_model_mvidia(test_fea_single, train_fea_single, train_feas, train_lab, test_feas, test_lab, seed, param, bst, model_type)

    elif model_type == 'mv-concat':
        max_N = min([len(train_feas[0][0, :]), len(train_feas[0][:, 0])])
        N = trail.suggest_int('N', 2, max_N, step=1) # n_estimators
        num = trail.suggest_int('num', 2, 100, step=5)  # n_estimators
        d = trail.suggest_int('d', 1, 10, step=1)  # max depth
        c = trail.suggest_float('c', 0.0001, 1)  # max depth
        lr = trail.suggest_float('lr', 0.0001, 1)  # max depth

        num_cat = trail.suggest_int('num_cat', 2, 100, step=5)  # n_estimators
        d_cat = trail.suggest_int('d_cat', 1, 10, step=1)  # max depth
        lr_cat = trail.suggest_float('lr_cat', 0.0001, 1)  # max depth
        # alpha = trail.suggest_float('alpha', 0.0, 1)  # max depth
        param = {'N': N, 'num': num, 'd': d, 'lr':lr, 'c':c, 'num_cat':num_cat, 'd_cat':d_cat, 'lr_cat':lr_cat}#, 'alpha':alpha}

        auc, mcc, f1, acc = cv_model_mvidia(test_fea_single, train_fea_single, train_feas, train_lab, test_feas, test_lab, seed,
                                   param, bst, model_type)

    elif (model_type == 'mvidia') | (model_type == 'mv+concat') | (model_type == 'mv+concat+ens'):

        max_N = min([len(train_feas[0][0, :]), len(train_feas[0][:, 0])])
        N = trail.suggest_int('N', 2, max_N, step=1)  # n_estimators
        c = trail.suggest_float('c', 0.0001, 1)
        num = trail.suggest_int('num', 2, 100, step=5) # n_estimators
        d = trail.suggest_int('d', 1, 10, step=1)  # max depth
        lr = trail.suggest_float('lr', 0.0001, 1)  # max depth
        param = {'N': N, 'num': num, 'd': d, 'lr': lr, 'c':c}

        auc, mcc, f1, acc = cv_model_mvidia(test_fea_single, train_fea_single, train_feas, train_lab, test_feas, test_lab, seed, param, bst, model_type)

    elif model_type == 'ens':
        param = {}
        for v in range(len(bst)):
            num = trail.suggest_int('num'+str(v), 2, 100, step=5)  # n_estimators
            d = trail.suggest_int('d'+str(v), 1, 10, step=1)  # max depth
            lr = trail.suggest_float('lr'+str(v), 0.0001, 1)  # max depth
            param.update({'num'+str(v): num, 'd'+str(v): d, 'lr'+str(v): lr})

        auc, mcc, f1, acc = cv_model_mvidia(test_fea_single, train_fea_single, train_feas, train_lab, test_feas, test_lab, seed, param, bst, model_type)

    return 1 - auc#acc#f1

def optuna_optimize(train_feas, train_lab, seed, model_type, test_feas, test_lab, trial_num):
    seed_torch(seed)
    study = optuna.create_study(study_name='test', direction='minimize', sampler=optuna.samplers.TPESampler(seed=seed),
                                pruner=optuna.pruners.HyperbandPruner())

    if model_type != 'semi':
        func = lambda trial: objective(trial, train_feas, train_lab, test_feas, test_lab, seed, model_type)
    else:
        func = lambda trial: objective_semi(trial, train_feas, train_lab, test_feas, test_lab, seed, model_type)
    study.optimize(func, n_trials=trial_num)
    print(study.best_params)
    print(study.best_trial)
    print(study.best_trial.value)
    print(model_type)
    if (model_type == 'single') | (model_type == 'single_svm'):
        if model_type == 'single_svm':
            model = 'svm'
            #study.best_params.update({'C': 2 ** study.best_params['C'], 'g': 2 ** study.best_params['g']})
        else:
            model = 'XGB'

        pred, auc, bst = test_model(train_feas, train_lab, seed, test_feas, test_lab, study.best_params, model)
        lat = '_'
    elif model_type == 'mv-concat':
        model = model_type
        pred, auc, lat, bst = test_model_mv(train_feas, train_lab, seed, test_feas, test_lab, study.best_params, model)
    elif (model_type == 'mv') | (model_type == 'mv_svm') | (model_type == 'semi') | (model_type == 'mv+concat'):
        if model_type == 'mv_svm':
            model = 'svm'
            #study.best_params.update({'C': 2 ** study.best_params['C'], 'g': 2 ** study.best_params['g']})
        else:
            model = 'XGB'
        pred, auc, lat, bst = test_model_mv(train_feas, train_lab, seed, test_feas, test_lab, study.best_params, model)
    elif model_type == 'semi':
        pred, auc, lat, bst = test_model_semi(train_feas, train_lab, seed, test_feas, test_lab, study.best_params, model)
    return pred, auc, study.best_params, lat, bst

def optuna_optimize_mvidia(test_fea_single, train_fea_single, train_feas, train_lab, seed, model_type, test_feas, test_lab, bst, trial_num):
    seed_torch(seed)
    study = optuna.create_study(study_name='test', direction='minimize', sampler=optuna.samplers.TPESampler(seed=seed),
                                pruner=optuna.pruners.HyperbandPruner())

    func = lambda trial: objective_mvidia(trial, test_fea_single, train_fea_single, train_feas, train_lab, test_feas, test_lab, seed, model_type, bst)
    study.optimize(func, n_trials=trial_num)
    print(study.best_params)
    print(study.best_trial)
    print(study.best_trial.value)
    print(model_type)

    pred, auc, lat, bst = test_model_mvidia(test_fea_single, train_fea_single, train_feas, train_lab, seed, test_feas, test_lab, bst, study.best_params, model_type)
    return pred, auc, study.best_params, lat, bst

def log2Transfer(dt):

    out_mat_inten = np.array(dt.values[:, 2:], dtype='float')
    out_mat_inten[out_mat_inten == 0] = np.nan
    out_mat_inten = np.log2(out_mat_inten)
    out_mat = pd.DataFrame(np.column_stack((dt.values[:, 0:2], out_mat_inten)),
                               columns=list(dt.columns.values))

    return out_mat

def processing_type(data, scale):
    if scale >= 0:
        if scale == 0:
            mm = preprocessing.MinMaxScaler(feature_range=(0, 1))
        elif scale == 1:
            mm = preprocessing.MinMaxScaler(feature_range=(-1, 1))
        elif scale == 2:
            mm = preprocessing.StandardScaler()
        data = mm.fit_transform(data)
    elif scale < 0:
        mm = 0
        data = data
    return data, mm

def align_sample(df, design, g1, g2, scale):

    design = design[(design['condition'] == g1) | (design['condition'] == g2)]

    sample_name_df = df.columns.values[2:]
    sample_name_design = design['sample_name'].values

    mat_df = df.values[:, 2:]
    mat_df[mat_df == 0] = np.nan
    df_info = df.iloc[:, :2]

    idxs = [np.where((sample_name_df == sample_name_design[i]))[0] for i in range(len(sample_name_design))]
    mat_align = mat_df[:, np.array(idxs, dtype=int)[:, 0]]
    mat_align, mm = processing_type(mat_align, scale)  # scale to [0, 1]
    df_mat = pd.DataFrame(mat_align, columns=sample_name_design)
    #mat_min = min(mat_align)

    df_align = pd.concat([df_info, df_mat], axis=1)

    return df_align, design

def get_DEPs(root_fold, sub_fold, all_fold, best_fold, method, logthre, qthre):

    DEA_res_all = pd.read_csv(root_fold + sub_fold + '/' + all_fold + '/DEA_res.csv', sep=',', header=0)
    DEA_best = pd.read_csv(root_fold + sub_fold + '/' + best_fold + '/DEA_res.csv', sep=',', header=0)

    dlfq_deg = DEA_res_all['Protein'].values[
        np.where(((DEA_res_all['dlfq_qval'].values <= qthre) & (abs(DEA_res_all['dlfq_logFC'].values) >= logthre)))]
    maxlfq_deg = DEA_res_all['Protein'].values[
        np.where(((DEA_res_all['maxlfq_qval'].values <= qthre) & (abs(DEA_res_all['maxlfq_logFC'].values) >= logthre)))]
    top3_deg = DEA_res_all['Protein'].values[
        np.where(((DEA_res_all['top3_qval'].values <= qthre) & (abs(DEA_res_all['top3_logFC'].values) >= logthre)))]
    top1_deg = DEA_res_all['Protein'].values[
        np.where(((DEA_res_all['top1_qval'].values <= qthre) & (abs(DEA_res_all['top1_logFC'].values) >= logthre)))]
    hurdle_deg = DEA_best['Protein'].values[
        np.where(((DEA_best['hurdle_qval'].values <= qthre) & (abs(DEA_best['hurdle_logFC'].values) >= logthre)))]

    if method == 'DL_pred':
        DL_deg = DEA_best['Protein'].values[np.where(((DEA_best['MVcontrast_score'].values >= max(
            DEA_best['MVcontrast_threshold'].values)) & (abs(DEA_best['MVcontrast_logFC'].values) >= logthre)))]
    elif method == 'DP_fdr':
        DL_deg = DEA_best['Protein'].values[np.where(((DEA_best['MVcontrast_score.2'].values >= max(
            DEA_best['MVcontrast_threshold.2'].values)) & (abs(DEA_best['MVcontrast_logFC.2'].values) >= logthre)))]

    return dlfq_deg, maxlfq_deg, top3_deg, top1_deg, hurdle_deg, DL_deg

def get_single_view(pro_list, raw_fold_dis, raw_fold_ret, view_type, g1, g2):

    dlfq_logT = 'F'
    post = '.csv'

    design_dis = pd.read_csv(raw_fold_dis + 'design' + post, sep='\t', header=0)
    design_ret = pd.read_csv(raw_fold_ret + 'design' + post, sep='\t', header=0)


    view_dis = pd.read_csv(raw_fold_dis + view_type + post, sep='\t', header=0)
    view_ret = pd.read_csv(raw_fold_ret + view_type + post, sep='\t', header=0)

    if dlfq_logT == 'T':
        view_dis = log2Transfer(view_dis)
        view_ret = log2Transfer(view_ret)

    view_dis, _ = align_sample(view_dis, design_dis, g1, g2, -1)
    view_ret, _ = align_sample(view_ret, design_ret, g1, g2, -1)

    # com1, idx11, idx21 = np.intersect1d(view_dis['Protein'].values, pro_list, return_indices=True)
    # com2, idx21, idx22 = np.intersect1d(view_ret['Protein'].values, com1, return_indices=True)
    view_dis.index = view_dis['Protein'].values
    view_ret.index = view_ret['Protein'].values
    view_dis = view_dis.reindex(pro_list)#, fill_value=0)
    view_ret = view_ret.reindex(pro_list)#, fill_value=0)

    label_dis = design_dis['condition'].values
    label_dis_bin = (label_dis == g2).astype(int)
    label_dis_bin = np.array([label_dis_bin]).T

    label_ret = design_ret['condition'].values
    label_ret_bin = (label_ret == g2).astype(int)
    label_ret_bin = np.array([label_ret_bin]).T

    return view_dis, view_ret, label_dis_bin, label_ret_bin


def get_views(pro_list, raw_fold_dis, raw_fold_ret, view_type, g1, g2, view_comb):

    if view_type not in ['hurdle', 'DL']:

        view_dis, view_ret, label_dis_bin, label_ret_bin = get_single_view(pro_list, raw_fold_dis, raw_fold_ret, view_type, g1, g2)
        return view_dis, view_ret, label_dis_bin, label_ret_bin

    else:

        views_dis = []
        views_ret = []

        for v in view_comb:
            view_dis, view_ret, label_dis_bin, label_ret_bin = get_single_view(pro_list, raw_fold_dis, raw_fold_ret,
                                                                               v, g1, g2)
            views_dis.append(view_dis)
            views_ret.append(view_ret)

        return views_dis, views_ret, label_dis_bin, label_ret_bin


# ---------------------------------------------------------------------------
# New method: fixed mean of RQ and RZ probabilities (standalone implementation).
# RQ: raw abundance + linear within-patient ranks.
# RZ: raw abundance + normal-score within-patient ranks.
# IMPORTANT: use RAW, unfilled matrices here, not the legacy XGB feature matrix.
# All imputation/scaling/rank eligibility is fitted on the current TRAINING fold.
# This method was selected after repeated exploration of the 288-patient cohort;
# these results are exploratory, not new independent clinical validation.
# ---------------------------------------------------------------------------
from pathlib import Path
from datetime import datetime
import hashlib
import json
import warnings
import sys
import scipy
import sklearn
import xgboost
from scipy.stats import rankdata
from scipy.special import ndtri
from sklearn.linear_model import LogisticRegression
from threadpoolctl import threadpool_limits

R1_VIEWS = ('dlfq', 'maxlfq', 'top3')
R1_CS = (0.01, 0.1, 1.0, 10.0, 100.0)
R1_KINDS = ('dlfq', 'concat', 'RQ', 'RZ')
R1_METHODS = ('LR_dlfq', 'LR_concat', 'RQ_fixed', 'RZ_fixed', 'RankSpacingVote_fixed')
R1_METRICS = ['auc', 'Acc', 'Prec', 'Rec', 'F1', 'Mcc']


def r1_panel_name(source, proteins):
    """Name the DEP source and actual list size, not the diagnostic input view."""
    return '{}{}protein'.format(source, len(proteins))


def r1_method_name(panel, views, classifier):
    # Example: MCP54protein_dlfq_maxlfq_top3_xgboost.
    return '{}_{}_{}'.format(panel, '_'.join(views), classifier)


def r1_method_details(panel, method_id):
    views = ('dlfq',) if method_id == 'LR_dlfq' else R1_VIEWS
    classifier = 'logisticregression' if method_id in ('LR_dlfq', 'LR_concat') else method_id
    return r1_method_name(panel, views, classifier), views, classifier


def r1_result_row(panel, n_proteins, views, classifier, values6, method_id=None):
    return dict(Method=r1_method_name(panel, views, classifier), FeatureSet='DEPs',
                **dict(zip(R1_METRICS, values6)), ProteinPanel=panel, nProteins=n_proteins,
                InputViews='_'.join(views), Classifier=classifier,
                method_id=classifier if method_id is None else method_id)


def r1_require(condition, message):
    if not condition:
        raise ValueError(message)


class R1RawFeatures:
    """Training-column median imputation and per-view population SD scaling."""
    def fit(self, x):
        self.stats = {}
        for view in R1_VIEWS:
            a = np.asarray(x[view], float)
            with warnings.catch_warnings():
                warnings.simplefilter('ignore', RuntimeWarning)
                med = np.nanmedian(a, axis=0)
            available = np.isfinite(med)
            med = np.where(available, med, 0.)
            filled = np.where(np.isfinite(a) & available, a, med)
            mean, scale = filled.mean(0), filled.std(0)
            scale[scale < 1e-8] = 1.
            self.stats[view] = (med, mean, scale, available)
        return self

    def transform(self, x):
        result = {}
        for view in R1_VIEWS:
            med, mean, scale, available = self.stats[view]
            a = np.asarray(x[view], float)
            r1_require(a.shape[1] == len(med), 'Protein order/width changed')
            result[view] = (np.where(np.isfinite(a) & available, a, med) - mean) / scale
        result['concat'] = np.concatenate([result[v] for v in R1_VIEWS], axis=1)
        return result


class R1RankFeatures:
    """Linear Q or normal-score Z; no statistics from test patients are fitted."""
    def __init__(self, normal=False):
        self.normal = normal

    def rank_matrix(self, a, eligible):
        a = np.asarray(a, float)
        r1_require(a.ndim == 2 and a.shape[1] == len(eligible), 'Wrong rank shape')
        result = np.full(a.shape, np.nan)
        for i, row in enumerate(a):
            ok = np.isfinite(row) & eligible
            n = int(ok.sum())
            if n >= 2:
                ranks = rankdata(row[ok], method='average')
                if self.normal:
                    u = (ranks - 0.5) / n
                    r1_require(((u > 0) & (u < 1)).all(), 'Invalid normal-score quantiles')
                    result[i, ok] = ndtri(u)
                else:
                    result[i, ok] = 2 * (ranks - 1) / (n - 1) - 1
        return result

    def fit(self, x):
        self.stats = {}
        for view in R1_VIEWS:
            a = np.asarray(x[view], float)
            eligible = np.isfinite(a).any(0)
            q = self.rank_matrix(a, eligible)
            finite = np.isfinite(q)
            count = finite.sum(0)
            mean = np.where(finite, q, 0).sum(0) / np.maximum(count, 1)
            scale = np.sqrt((np.where(finite, q - mean, 0) ** 2).sum(0) / np.maximum(count, 1))
            scale[scale < 1e-6] = 1.
            self.stats[view] = dict(eligible=eligible, mean=mean, scale=scale, available=count > 0)
        return self

    def transform(self, x):
        result = []
        for view in R1_VIEWS:
            s = self.stats[view]
            q = self.rank_matrix(x[view], s['eligible'])
            ok = np.isfinite(q) & s['available']
            result.append(np.where(ok, (q - s['mean']) / s['scale'], 0.))
        return np.concatenate(result, axis=1)


def r1_fit_preprocessors(x):
    return (R1RawFeatures().fit(x), R1RankFeatures(False).fit(x), R1RankFeatures(True).fit(x))


def r1_transform(pre, x):
    raw, q, z = pre
    r = raw.transform(x)
    return dict(dlfq=r['dlfq'], concat=r['concat'],
                RQ=np.concatenate((np.sqrt(.5) * r['concat'], np.sqrt(.5) * q.transform(x)), axis=1),
                RZ=np.concatenate((np.sqrt(.5) * r['concat'], np.sqrt(.5) * z.transform(x)), axis=1))


def r1_fit_rankspacing(x, y, inner_seed=6123):
    """Fit using training labels ONLY. Test features/labels are not arguments.

    Each of the four representations independently selects C by mean 3-fold
    AUROC; exact ties use smaller C. The .5/.5 vote and p>.5 rule are fixed.
    For full seed2024 fitting, 6123 = 2024 + 4000 + 99, exactly as R19.
    """
    y = np.asarray(y, int).ravel()
    r1_require(np.array_equal(np.unique(y), [0, 1]), 'Both training classes required')
    r1_require(all(x[v].shape == x[R1_VIEWS[0]].shape for v in R1_VIEWS), 'Views must align')
    r1_require(len(y) == x[R1_VIEWS[0]].shape[0], 'Training label length mismatch')
    records = [dict(kind=k, C=c, aucs=[]) for k in R1_KINDS for c in R1_CS]
    splits = list(StratifiedKFold(3, shuffle=True, random_state=inner_seed).split(np.zeros(len(y)), y))
    for train, valid in splits:
        xa = {v: x[v][train] for v in R1_VIEWS}
        xb = {v: x[v][valid] for v in R1_VIEWS}
        pre = r1_fit_preprocessors(xa)
        a, b = r1_transform(pre, xa), r1_transform(pre, xb)
        for row in records:
            model = LogisticRegression(C=row['C'], max_iter=2000, tol=1e-7)
            model.fit(a[row['kind']], y[train])
            r1_require(int(model.n_iter_.max()) < model.max_iter, 'LR did not converge')
            p = model.predict_proba(b[row['kind']])[:, 1]
            row['aucs'].append(float(roc_auc_score(y[valid], p)))
    for row in records:
        row['mean_auc'] = float(np.mean(row['aucs']))
    selected = {k: max((r for r in records if r['kind'] == k), key=lambda r: (r['mean_auc'], -r['C']))
                for k in R1_KINDS}
    pre = r1_fit_preprocessors(x)
    full = r1_transform(pre, x)
    models = {}
    for kind, choice in selected.items():
        models[kind] = LogisticRegression(C=choice['C'], max_iter=2000, tol=1e-7).fit(full[kind], y)
        r1_require(int(models[kind].n_iter_.max()) < 2000, 'Full LR did not converge')
    # R19 passed this logical seed to a factory; deterministic lbfgs ignores it.
    return dict(pre=pre, models=models, selected=selected, records=records,
                inner_seed=inner_seed, logical_model_seed=inner_seed + 1000)


def r1_predict_rankspacing(bundle, x):
    """Frozen inference; no labels, fit, target calibration or target scaling."""
    a = r1_transform(bundle['pre'], x)
    p = {k: model.predict_proba(a[k])[:, 1] for k, model in bundle['models'].items()}
    result = dict(LR_dlfq=p['dlfq'], LR_concat=p['concat'], RQ_fixed=p['RQ'], RZ_fixed=p['RZ'],
                  RankSpacingVote_fixed=.5 * p['RQ'] + .5 * p['RZ'])
    r1_require(all(np.isfinite(v).all() and ((v >= 0) & (v <= 1)).all() for v in result.values()),
               'Invalid probability')
    return result


def r1_metrics(y, p):
    y, p = np.asarray(y).ravel(), np.asarray(p).ravel()
    calls = (p > .5).astype(int)  # NOT >=.5, not rounded probabilities
    return [roc_auc_score(y, p), acc(y, calls), precision(y, calls, zero_division=0),
            recall(y, calls, zero_division=0), f1(y, calls, zero_division=0), mcc(y, calls)]


def r1_load_raw_views(folder, proteins, g1='B', g2='M'):
    """Same files/panels as original script; explicit patient/protein alignment."""
    folder = Path(folder)
    design = pd.read_csv(folder / 'design.csv', sep='\t', dtype=str)
    r1_require(design.condition.isin([g1, g2]).all(), 'Unexpected condition in design.csv')
    r1_require(not design.sample_name.isna().any() and not design.sample_name.duplicated().any(), 'Invalid sample names')
    r1_require('Patient_ID' in design, 'Patient_ID required for patient-overlap checks')
    r1_require(not design.Patient_ID.isna().any() and not design.Patient_ID.duplicated().any(), 'Invalid patient IDs')
    proteins = np.asarray(proteins, str)
    r1_require(len(proteins) == len(set(proteins)), 'Duplicate panel protein')
    views = {}
    for view in R1_VIEWS:
        table = pd.read_csv(folder / (view + '.csv'), sep='\t')
        r1_require(not table.Protein.isna().any() and not table.Protein.duplicated().any(), 'Duplicate/missing protein ID')
        r1_require(set(design.sample_name).issubset(table.columns), 'Sample absent in ' + view)
        a = table.set_index('Protein').loc[:, design.sample_name].reindex(proteins).to_numpy(dtype=float).T
        r1_require(not np.isinf(a).any(), 'Infinite abundance in ' + view)
        a[a == 0] = np.nan  # Inputs already log-transformed; do NOT log again.
        views[view] = a
    return views, (design.condition.to_numpy() == g2).astype(int), design


def r1_prediction_rows(panel, seed, method, y, p, design, fold=-1):
    name, _, _ = r1_method_details(panel, method)
    return pd.DataFrame(dict(panel=panel, seed=seed, method=name, method_id=method, row=np.arange(len(y)) + 1,
        sample_name=design.sample_name.to_numpy(), label=y, probability=p,
        threshold=.5, prediction=(p > .5).astype(int), fold=fold))


def r1_run_new_method(raw_fold_dis, raw_fold_ret, panels, output_dir, discovery_cv=False,
                      seed=2024, g1='B', g2='M'):
    """Run fixed fusion and matched LR controls on every supplied protein panel.

    Default follows the original script: full 579 training -> all 288 test.
    Optional discovery_cv=True additionally reruns 3 seeds x 5 outer folds with
    3-fold INNER C selection. It is NOT training-set performance.
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    scores, predictions, choices, candidates = [], [], [], []
    cv_scores, cv_predictions, cv_choices = [], [], []
    frozen = {}
    source_design = None
    # Train/freeze ALL supplied panels before loading retrospective data.
    with threadpool_limits(limits=1):
        for panel, proteins in panels.items():
            print('[RankSpacingVote] fitting {} ({} proteins)'.format(panel, len(proteins)), flush=True)
            x, y, design = r1_load_raw_views(raw_fold_dis, proteins, g1, g2)
            r1_require(len(y) == 579 and int(y.sum()) == 194, 'Expected current discovery labels: B385/M194')
            source_design = design
            pd.DataFrame({'Protein': proteins}).to_csv(output_dir / (panel + '_proteins.csv'), index=False)
            bundle = r1_fit_rankspacing(x, y, seed + 4099)
            frozen[panel] = bundle
            for kind, row in bundle['selected'].items():
                choices.append(dict(panel=panel, seed=seed, inner_seed=seed + 4099, kind=kind,
                                    C=row['C'], mean_inner_auc=row['mean_auc']))
            for row in bundle['records']:
                candidates.append(dict(panel=panel, seed=seed, kind=row['kind'], C=row['C'],
                                       mean_inner_auc=row['mean_auc'],
                                       fold1=row['aucs'][0], fold2=row['aucs'][1], fold3=row['aucs'][2]))
            if discovery_cv:
                for cv_seed in (2024, 2025, 2026):
                    oof = {k: np.full(len(y), np.nan) for k in R1_METHODS}
                    fold_ids = np.full(len(y), -1, int)
                    splitter = StratifiedKFold(5, shuffle=True, random_state=cv_seed)
                    for fold, (train, valid) in enumerate(splitter.split(np.zeros(len(y)), y)):
                        print('[RankSpacingVote] {} discovery seed {} fold {}/5'.format(panel, cv_seed, fold + 1), flush=True)
                        fitted = r1_fit_rankspacing({v: x[v][train] for v in R1_VIEWS}, y[train], cv_seed + 4000 + fold)
                        values = r1_predict_rankspacing(fitted, {v: x[v][valid] for v in R1_VIEWS})
                        fold_ids[valid] = fold
                        for kind, row in fitted['selected'].items():
                            cv_choices.append(dict(panel=panel, seed=cv_seed, fold=fold, kind=kind,
                                                   C=row['C'], mean_inner_auc=row['mean_auc']))
                        for method, p in values.items():
                            oof[method][valid] = p
                    for method, p in oof.items():
                        r1_require(np.isfinite(p).all(), 'Incomplete OOF predictions')
                        name, _, _ = r1_method_details(panel, method)
                        cv_scores.append(dict(panel=panel, seed=cv_seed, method=name, method_id=method,
                                              **dict(zip(R1_METRICS, r1_metrics(y, p)))))
                        cv_predictions.append(r1_prediction_rows(panel, cv_seed, method, y, p, design, fold_ids))
        # freeze checkpoint: no test information has entered fitting above
        pd.DataFrame(choices).to_csv(output_dir / 'RankSpacingVote_selected_C.csv', index=False)
        pd.DataFrame(candidates).to_csv(output_dir / 'RankSpacingVote_inner_candidates.csv', index=False)
        (output_dir / 'training_complete_before_ret.json').write_text(json.dumps(dict(
            seed=seed, panels=list(panels), n_frozen=len(frozen), trained_before_loading_ret=True), indent=2), encoding='utf-8')
        for panel, proteins in panels.items():
            x, y, design = r1_load_raw_views(raw_fold_ret, proteins, g1, g2)
            r1_require(len(y) == 288 and int(y.sum()) == 144, 'Expected retrospective B144/M144')
            r1_require(not set(design.sample_name) & set(source_design.sample_name), 'Train/test sample overlap')
            r1_require(not set(design.Patient_ID) & set(source_design.Patient_ID), 'Train/test patient overlap')
            values = r1_predict_rankspacing(frozen[panel], x)
            for method, p in values.items():
                values6 = r1_metrics(y, p)
                _, views, classifier = r1_method_details(panel, method)
                scores.append(r1_result_row(panel, len(proteins), views, classifier, values6, method_id=method))
                predictions.append(r1_prediction_rows(panel, seed, method, y, p, design))
    matched = pd.DataFrame(scores).set_index('Method')
    matched.to_csv(output_dir / 'RankSpacingVote_matched_controls_288.csv')
    pd.concat(predictions, ignore_index=True).to_csv(output_dir / 'RankSpacingVote_predictions_288.csv', index=False)
    if discovery_cv:
        per_seed = pd.DataFrame(cv_scores)
        per_seed.to_csv(output_dir / 'RankSpacingVote_discovery579_each_seed.csv', index=False)
        per_seed.groupby(['panel', 'method', 'method_id'])[R1_METRICS].median().reset_index().to_csv(
            output_dir / 'RankSpacingVote_discovery579_median.csv', index=False)
        pd.concat(cv_predictions, ignore_index=True).to_csv(output_dir / 'RankSpacingVote_predictions_discovery579.csv', index=False)
        pd.DataFrame(cv_choices).to_csv(output_dir / 'RankSpacingVote_discovery579_selected_C.csv', index=False)
    files = [Path(__file__)]
    for folder in (Path(raw_fold_dis), Path(raw_fold_ret)):
        files.extend(folder / name for name in ['design.csv'] + [v + '.csv' for v in R1_VIEWS])
    protocol = dict(method='RankSpacingVote_fixed = .5*p_RQ + .5*p_RZ', seed=seed, inner_seed=seed + 4099,
        logical_model_seed=seed + 5099, solver='lbfgs (deterministic, random_state unused)',
        C_grid=R1_CS, threshold='p > 0.5', discovery_cv=discovery_cv,
        panels={k: list(map(str, v)) for k, v in panels.items()},
        python=sys.version, executable=sys.executable,
        packages=dict(numpy=np.__version__, pandas=pd.__version__, sklearn=sklearn.__version__, scipy=scipy.__version__, xgboost=xgboost.__version__),
        sha256={str(p.resolve()): hashlib.sha256(p.read_bytes()).hexdigest() for p in files},
        limitation='Exploratory after repeated ret288 use. Legacy XGB and new LR fusion have different training protocols. Fixed panels selected on all579 labels.')
    (output_dir / 'RankSpacingVote_protocol.json').write_text(json.dumps(protocol, indent=2), encoding='utf-8')
    print('\nMatched controls on ALL 288 patients (new-method protocol):\n', matched)
    # Include dLFQ-only LR and simple concatenation in the FINAL table as well.
    return matched


def r1_prepare_legacy_xgb(proteins, views, raw_fold_dis, raw_fold_ret, g1, g2):
    """Apply the original 1218 XGB preprocessing to a requested panel/input.

    Single input: train minimum fill; training-fitted scaler.
    Three inputs: each cohort/view uses its own minimum fill; one scaler fitted
    on the first discovery view is applied to all views, exactly as legacy MCP.
    This deliberately reproduces that protocol for matched XGB comparisons.
    """
    train_blocks, test_blocks = [], []
    labels_train, labels_test = None, None
    for view in views:
        a, b, ya, yb = get_single_view(proteins, raw_fold_dis, raw_fold_ret, view, g1, g2)
        a = np.array(a.values[:, 2:].T, dtype=float)
        b = np.array(b.values[:, 2:].T, dtype=float)
        r1_require(np.isfinite(a).any() and np.isfinite(b).any(), 'No finite values in ' + view)
        if labels_train is not None:
            r1_require(np.array_equal(ya, labels_train) and np.array_equal(yb, labels_test), 'View label mismatch')
        labels_train, labels_test = ya, yb
        a = Fill_nan(a, min(a[~np.isnan(a)]))
        b = Fill_nan(b, min(a[~np.isnan(a)]) if len(views) == 1 else min(b[~np.isnan(b)]))
        train_blocks.append(a)
        test_blocks.append(b)
    scaler = StandardScaler().fit(train_blocks[0])
    xa = np.concatenate([scaler.transform(a) for a in train_blocks], axis=1)
    xb = np.concatenate([scaler.transform(b) for b in test_blocks], axis=1)
    return xa, xb, labels_train, labels_test


def r1_run_additional_xgb(panels, raw_fold_dis, raw_fold_ret, output_dir, trial_num=30, g1='B', g2='M'):
    """Add MCP54/dLFQ-only and all four single-view-derived panels/three views.

    Same XGB/Optuna function and trial budget as the original six methods.
    No protein selection or view-combination optimization is performed here.
    """
    output_dir = Path(output_dir)
    jobs = [('MCP', ('dlfq',))] + [(v, R1_VIEWS) for v in ('dlfq', 'maxlfq', 'top3', 'top1')]
    rows, predictions, choices = [], [], []
    for source, views in jobs:
        proteins = panels[source]
        panel = r1_panel_name(source, proteins)
        name = r1_method_name(panel, views, 'xgboost')
        print('\n[Additional XGB] ' + name, flush=True)
        a, b, ya, yb = r1_prepare_legacy_xgb(proteins, views, raw_fold_dis, raw_fold_ret, g1, g2)
        r1_require(a.shape == (579, len(proteins) * len(views)) and b.shape == (288, a.shape[1]), 'Unexpected XGB dimensions')
        p, values6, params, _, fitted = optuna_optimize(a, ya, 2024, 'single', b, yb, trial_num)
        rows.append(r1_result_row(panel, len(proteins), views, 'xgboost', values6))
        # Actual XGB calls, rather than a newly chosen classification threshold.
        calls = fitted.predict(b)
        design = pd.read_csv(Path(raw_fold_ret) / 'design.csv', sep='\t', dtype=str)
        predictions.append(pd.DataFrame(dict(Method=name, method_id='xgboost', sample_name=design.sample_name,
            label=yb[:, 0], probability=p, prediction=calls)))
        choices.append(dict(Method=name, seed=2024, n_trials=trial_num, best_params=params))
        pd.DataFrame(rows).set_index('Method').to_csv(output_dir / 'additional_xgboost_288.csv')
    pd.concat(predictions, ignore_index=True).to_csv(output_dir / 'additional_xgboost_predictions_288.csv', index=False)
    (output_dir / 'additional_xgboost_parameters.json').write_text(json.dumps(choices, indent=2), encoding='utf-8')
    return pd.DataFrame(rows).set_index('Method')


def TPD_classificaion(raw_fold_dis, raw_fold_ret, root_fold, sub_fold, best_fold, all_fold, trial_num, DEA_method, logthre, qthre, g1, g2, view_comb, res_name, output_file=None):

    dlfq_deg, maxlfq_deg, top3_deg, top1_deg, hurdle_deg, DL_deg = get_DEPs(root_fold, sub_fold, all_fold, best_fold, DEA_method, logthre, qthre)

    views_dis_dlfq, views_ret_dlfq, lab_dis_dlfq, lab_ret_dlfq = get_views(dlfq_deg, raw_fold_dis,
                                                                                       raw_fold_ret, 'dlfq', g1, g2,
                                                                                       view_comb)
    data_dis_dlfq = np.array(views_dis_dlfq.values[:, 2:].T, dtype='float')
    data_ret_dlfq = np.array(views_ret_dlfq.values[:, 2:].T, dtype='float')

    views_dis_maxlfq, views_ret_maxlfq, lab_dis_maxlfq, lab_ret_maxlfq = get_views(maxlfq_deg, raw_fold_dis,
                                                                                       raw_fold_ret, 'maxlfq', g1, g2,
                                                                                       view_comb)
    data_dis_maxlfq = np.array(views_dis_maxlfq.values[:, 2:].T, dtype='float')
    data_ret_maxlfq = np.array(views_ret_maxlfq.values[:, 2:].T, dtype='float')

    views_dis_top3, views_ret_top3, lab_dis_top3, lab_ret_top3 = get_views(top3_deg, raw_fold_dis,
                                                                                       raw_fold_ret, 'top3', g1, g2,
                                                                                       view_comb)
    data_dis_top3 = np.array(views_dis_top3.values[:, 2:].T, dtype='float')
    data_ret_top3 = np.array(views_ret_top3.values[:, 2:].T, dtype='float')

    views_dis_top1, views_ret_top1, lab_dis_top1, lab_ret_top1 = get_views(top1_deg, raw_fold_dis,
                                                                                       raw_fold_ret, 'top1', g1, g2,
                                                                                       view_comb)
    data_dis_top1 = np.array(views_dis_top1.values[:, 2:].T, dtype='float')
    data_ret_top1 = np.array(views_ret_top1.values[:, 2:].T, dtype='float')

    """
    dlfq based
    """

    data_dis_dlfq = Fill_nan(data_dis_dlfq, min(data_dis_dlfq[~np.isnan(data_dis_dlfq)]))
    data_ret_dlfq = Fill_nan(data_ret_dlfq, min(data_dis_dlfq[~np.isnan(data_dis_dlfq)]))

    # scale the data
    scaler = StandardScaler()
    # scaler = MinMaxScaler()
    scaler.fit(data_dis_dlfq)

    data_dis_dlfq = scaler.transform(data_dis_dlfq)
    data_ret_dlfq = scaler.transform(data_ret_dlfq)

    seed = 2024
    # dlfq
    pred1, auc1, best_params1, lat, bst1 = optuna_optimize(data_dis_dlfq, lab_dis_dlfq, seed, 'single', data_ret_dlfq,
                                                           lab_ret_dlfq, trial_num)

    # """
    #     maxlfq based
    # """
    data_dis_maxlfq = Fill_nan(data_dis_maxlfq, min(data_dis_maxlfq[~np.isnan(data_dis_maxlfq)]))
    # data_dis_maxlfq = Fill_nan(data_dis_maxlfq, 0)
    data_ret_maxlfq = Fill_nan(data_ret_maxlfq, min(data_dis_maxlfq[~np.isnan(data_dis_maxlfq)]))
    # data_ret_maxlfq = Fill_nan(data_ret_maxlfq, 0)

    # scale the data
    scaler = StandardScaler()
    # scaler = MinMaxScaler()
    scaler.fit(data_dis_maxlfq)

    data_dis_maxlfq = scaler.transform(data_dis_maxlfq)
    data_ret_maxlfq = scaler.transform(data_ret_maxlfq)

    seed = 2024
    # maxlfq
    pred2, auc2, best_params2, lat, bst2 = optuna_optimize(data_dis_maxlfq, lab_dis_maxlfq, seed, 'single',
                                                           data_ret_maxlfq,
                                                           lab_ret_maxlfq, trial_num)

    """
            top3 based
        """

    data_dis_top3 = Fill_nan(data_dis_top3, min(data_dis_top3[~np.isnan(data_dis_top3)]))
    # data_dis_top3 = Fill_nan(data_dis_top3, 0)
    data_ret_top3 = Fill_nan(data_ret_top3, min(data_dis_top3[~np.isnan(data_dis_top3)]))
    # data_ret_top3 = Fill_nan(data_ret_top3, 0)

    # scale the data
    scaler = StandardScaler()
    # scaler = MinMaxScaler()
    scaler.fit(data_dis_top3)

    data_dis_top3 = scaler.transform(data_dis_top3)
    data_ret_top3 = scaler.transform(data_ret_top3)

    # top3
    pred3, auc3, best_params3, lat, bst3 = optuna_optimize(data_dis_top3, lab_dis_top3, seed, 'single',
                                                           data_ret_top3,
                                                           lab_ret_top3, trial_num)

    """
                top1 based
            """
    data_dis_top1 = Fill_nan(data_dis_top1, min(data_dis_top1[~np.isnan(data_dis_top1)]))
    # data_dis_top3 = Fill_nan(data_dis_top3, 0)
    data_ret_top1 = Fill_nan(data_ret_top1, min(data_dis_top1[~np.isnan(data_dis_top1)]))
    # data_ret_top3 = Fill_nan(data_ret_top3, 0)

    # scale the data
    scaler = StandardScaler()
    # scaler = MinMaxScaler()
    scaler.fit(data_dis_top1)

    data_dis_top1 = scaler.transform(data_dis_top1)
    data_ret_top1 = scaler.transform(data_ret_top1)

    # top1
    pred4, auc4, best_params4, lat4, bst4 = optuna_optimize(data_dis_top1, lab_dis_top1, seed, 'single',
                                                           data_ret_top1,
                                                           lab_ret_top1, trial_num)

    """
                    hurdle based
                """

    views_diss, views_rets, lab_dis, lab_ret = get_views(hurdle_deg, raw_fold_dis,
                                                                                   raw_fold_ret, 'hurdle', g1, g2,
                                                                                   view_comb)
    data_diss = []
    data_rets = []

    all_zero_col = []
    for v in range(len(view_comb)):
        data_dis = np.array(views_diss[v].values[:, 2:].T, dtype='float')
        data_dis = Fill_nan(data_dis, min(data_dis[~np.isnan(data_dis)]))
        data_ret = np.array(views_rets[v].values[:, 2:].T, dtype='float')
        data_ret = Fill_nan(data_ret, min(data_ret[~np.isnan(data_ret)]))

        zero_col_dis = np.where((data_dis == 0).all(axis=0))[0]
        zero_col_ret = np.where((data_ret == 0).all(axis=0))[0]

        all_zero_col.extend(zero_col_dis)
        all_zero_col.extend(zero_col_ret)

        data_diss.append(data_dis)
        data_rets.append(data_ret)

    # scale the data
    scaler = StandardScaler()
    # scaler = MinMaxScaler()
    scaler.fit(data_diss[0])

    for v in range(len(view_comb)):
        data_diss[v] = scaler.transform(data_diss[v])
        data_rets[v] = scaler.transform(data_rets[v])

    data_dis_hurdle = np.concatenate(data_diss, axis=1)
    data_ret_hurdle = np.concatenate(data_rets, axis=1)
    seed = 2024
    # hurdle
    pred5, auc5, best_params5, lat5, bst5 = optuna_optimize(data_dis_hurdle, lab_dis, seed, 'single',
                                                            data_ret_hurdle,
                                                            lab_ret, trial_num)

    """
                        DL based
                    """
    views_diss, views_rets, lab_dis, lab_ret = get_views(DL_deg, raw_fold_dis,
                                                         raw_fold_ret, 'DL', g1, g2,
                                                         view_comb)
    data_diss = []
    data_rets = []

    all_zero_col = []
    for v in range(len(view_comb)):
        data_dis = np.array(views_diss[v].values[:, 2:].T, dtype='float')
        data_dis = Fill_nan(data_dis, min(data_dis[~np.isnan(data_dis)]))
        data_ret = np.array(views_rets[v].values[:, 2:].T, dtype='float')
        data_ret = Fill_nan(data_ret, min(data_ret[~np.isnan(data_ret)]))

        zero_col_dis = np.where((data_dis == 0).all(axis=0))[0]
        zero_col_ret = np.where((data_ret == 0).all(axis=0))[0]

        all_zero_col.extend(zero_col_dis)
        all_zero_col.extend(zero_col_ret)

        data_diss.append(data_dis)
        data_rets.append(data_ret)

    # scale the data
    scaler = StandardScaler()
    # scaler = MinMaxScaler()
    scaler.fit(data_diss[0])

    for v in range(len(view_comb)):
        data_diss[v] = scaler.transform(data_diss[v])
        data_rets[v] = scaler.transform(data_rets[v])

    data_dis_DL = np.concatenate(data_diss, axis=1)
    data_ret_DL = np.concatenate(data_rets, axis=1)
    seed = 2024
    # DL
    pred6, auc6, best_params6, lat6, bst6 = optuna_optimize(data_dis_DL, lab_dis, seed, 'single',
                                                            data_ret_DL,
                                                            lab_ret, trial_num)


    res_all = np.array([auc1, auc2, auc3, auc4, auc5, auc6])
    # res_name = 'DEPs'
    df = pd.DataFrame(np.column_stack((np.array([len(res_all) * [res_name]]).T, res_all)), columns=['FeatureSet', 'auc', 'Acc', 'Prec', 'Rec', 'F1', 'Mcc'],
                 index=['dlfq', 'maxlfq', 'top3', 'top1', 'hurdle', 'MCP'])
    # Rename the original six rows; the fitted models/metrics above are unchanged.
    descriptors = [('dlfq', dlfq_deg, ('dlfq',)), ('maxlfq', maxlfq_deg, ('maxlfq',)),
                   ('top3', top3_deg, ('top3',)), ('top1', top1_deg, ('top1',)),
                   ('hurdle', hurdle_deg, tuple(view_comb)), ('MCP', DL_deg, tuple(view_comb))]
    df.index = [r1_method_name(r1_panel_name(s, p), v, 'xgboost') for s, p, v in descriptors]
    df.index.name = 'Method'
    df['ProteinPanel'] = [r1_panel_name(s, p) for s, p, v in descriptors]
    df['nProteins'] = [len(p) for s, p, v in descriptors]
    df['InputViews'] = ['_'.join(v) for s, p, v in descriptors]
    df['Classifier'] = 'xgboost'
    df['method_id'] = 'xgboost'
    print(df)
    df.to_csv(output_file if output_file is not None else root_fold + res_name +'_XGB_perform.csv')
    return df


if __name__ == "__main__":
    # PyCharm: run this file directly. No command-line arguments/helper scripts.
    RUN_ORIGINAL_METHODS = True     # original six XGB methods (30 Optuna trials)
    RUN_ADDITIONAL_XGBOOST = True   # five additional panel/input tests, same XGB
    RUN_NEW_METHOD = True           # fixed RankSpacingVote + LR controls on FIVE panels
    RUN_NEW_DISCOVERY_CV = False    # True: also reproduce 579-person 3-seed nested CV
    #pro_list = ['P02765', 'P04083', 'O00339', 'P58546', 'O75347', 'P04216', 'P02751', 'P83731', 'P00568', 'P78527', 'P04792', 'P57737', 'P42224', 'P27797', 'Q9HAT2', 'P30086', 'O14964', 'P10909', 'P17931']

    #res_name = 'author19'
    trial_num = 30 # trial number in hyperparameter selection
    best_fold = 'DIA_dlfq_maxlfq_top3'#'DIA_dlfq_maxlfq'#'DIA_dlfq_maxlfq_top3'
    all_fold = 'DIA_dlfq_maxlfq_top3_top1'
    root_fold = 'D:/Roffline/MVIDIA/case_Res/all08/'
    sub_fold = 'TPD_dis_filter_all08'#'TPD_dis_proteomics_v1'#'TPD_dis_filter_all08'#'TPD_dis_proteomics_v1_1'
    DEA_method = 'DP_fdr'
    logthre = np.log2(2)
    qthre = 0.01
    raw_fold_dis = 'D:/Roffline/MVIDIA/case_Res/TPD_views/dis/'
    raw_fold_ret = 'D:/Roffline/MVIDIA/case_Res/TPD_views/ret/'
    res_name = 'MCP_proteomics_ori_2026_1_29_dlfq_maxlfq'#'MCP_proteomics_V1_1'
    g1 = 'B'
    g2 = 'M'
    view_comb = ['dlfq', 'maxlfq', 'top3']
    # Every run gets a NEW folder, protecting old Fig.4/results from overwrite.
    output_dir = Path(__file__).resolve().parent / 'TPD_rankspacing_results' / datetime.now().strftime('run_%Y%m%d_%H%M%S_%f')
    output_dir.mkdir(parents=True, exist_ok=False)
    tables = []
    new_table = None
    dlfq_panel, maxlfq_panel, top3_panel, top1_panel, hurdle_panel, mcp_panel = get_DEPs(
        root_fold, sub_fold, all_fold, best_fold, DEA_method, logthre, qthre)
    source_panels = {'MCP': mcp_panel, 'dlfq': dlfq_panel, 'maxlfq': maxlfq_panel,
                     'top3': top3_panel, 'top1': top1_panel}
    for source, proteins in source_panels.items():
        r1_require(len(proteins) > 0 and len(proteins) == len(set(proteins)), 'Empty/duplicate panel: ' + source)
    pd.DataFrame([dict(ProteinSource=s, ProteinPanel=r1_panel_name(s, p), nProteins=len(p))
                  for s, p in source_panels.items()]).to_csv(output_dir / 'protein_panel_summary.csv', index=False)
    for source, proteins in source_panels.items():
        pd.DataFrame({'Protein': proteins}).to_csv(output_dir / (r1_panel_name(source, proteins) + '_proteins.csv'), index=False)
    # Run the source-only branch FIRST: legacy XGB itself loads ret288 early.
    if RUN_NEW_METHOD:
        r1_require(tuple(view_comb) == R1_VIEWS, 'New method is fixed to dlfq/maxlfq/top3')
        r1_require(DEA_method == 'DP_fdr' and len(mcp_panel) == 54 and len(dlfq_panel) == 83,
                   'Expected DP_fdr MCP54 and dLFQ83 panels; check the DEA files/thresholds')
        new_table = r1_run_new_method(raw_fold_dis, raw_fold_ret,
            {r1_panel_name(s, p): p for s, p in source_panels.items()}, output_dir,
            discovery_cv=RUN_NEW_DISCOVERY_CV, seed=2024, g1=g1, g2=g2)
        new_table['Protocol'] = 'Source-only preprocessing; inner3 LR; method-specific features'
    if RUN_ORIGINAL_METHODS:
        original_table = TPD_classificaion(raw_fold_dis, raw_fold_ret, root_fold, sub_fold, best_fold, all_fold,
            trial_num, DEA_method, logthre, qthre, g1, g2, view_comb, res_name,
            output_file=output_dir / (res_name + '_XGB_original_perform.csv'))
        original_table['Protocol'] = 'Legacy Fig4 XGB; original preprocessing/Optuna'
        tables.append(original_table)
    if RUN_ADDITIONAL_XGBOOST:
        extra_table = r1_run_additional_xgb(source_panels, raw_fold_dis, raw_fold_ret,
                                           output_dir, trial_num, g1, g2)
        extra_table['Protocol'] = 'Fig4-style added configuration; original preprocessing/Optuna'
        tables.append(extra_table)
    if new_table is not None:
        tables.append(new_table)
    if tables:
        combined = pd.concat(tables)
        r1_require(not combined.index.duplicated().any(), 'Duplicate final method name')
        expected_rows = 6 * int(RUN_ORIGINAL_METHODS) + 5 * int(RUN_ADDITIONAL_XGBOOST) + 5 * len(source_panels) * int(RUN_NEW_METHOD)
        r1_require(len(combined) == expected_rows, 'Incomplete final result table')
        combined.to_csv(output_dir / 'TPD_all_methods_288.csv')
        combined.to_csv(output_dir / (res_name + '_XGB_plus_RankSpacingVote_perform.csv'))
        print('\nAll requested methods on 288 patients:\n', combined.to_string())
        print('\nNOTE: matched new-method controls are in RankSpacingVote_matched_controls_288.csv.')
    print('\nAll new output files:', output_dir)
