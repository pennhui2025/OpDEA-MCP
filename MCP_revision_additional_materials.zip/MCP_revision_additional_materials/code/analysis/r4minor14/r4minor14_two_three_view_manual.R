# Source only defines this function. Run the commented final line manually.
# This reads ORIGINAL DEA_res.csv files, not merely the delivered summary tables.
package_dir <- 'reference/Response/r4minor14'
check_two_three_views <- function(package_dir, write_files=FALSE) {
  plan <- read.csv(file.path(package_dir,'data/two_three_view_dep_overlap_summary.csv'))
  get_calls <- function(path,fold_change) {
    # R's make.names creates .1 and .2 for the duplicated block names.
    x <- read.csv(path,check.names=TRUE)
    needed <- c('Protein','MVcontrast_score.2','MVcontrast_threshold.2','MVcontrast_logFC.2')
    stopifnot(all(needed %in% names(x)))
    threshold <- max(x$MVcontrast_threshold.2,na.rm=TRUE)
    keep <- is.finite(x$MVcontrast_score.2) & is.finite(x$MVcontrast_logFC.2) &
      x$MVcontrast_score.2>=threshold & abs(x$MVcontrast_logFC.2)>=log2(fold_change)
    list(proteins=unique(as.character(x$Protein[keep])),threshold=threshold)
  }
  out <- list();calls <- list()
  for(i in seq_len(nrow(plan))) {
    p <- plan[i,]
    a <- get_calls(p$two_view_source,p$fold_change_threshold)
    b <- get_calls(p$three_view_source,p$fold_change_threshold)
    common <- intersect(a$proteins,b$proteins);both <- union(a$proteins,b$proteins)
    row <- data.frame(cohort=p$cohort,n_two_view=length(a$proteins),n_three_view=length(b$proteins),
      n_shared=length(common),n_two_view_only=length(setdiff(a$proteins,b$proteins)),
      n_three_view_only=length(setdiff(b$proteins,a$proteins)),n_union=length(both),
      jaccard=length(common)/length(both),two_view_threshold=a$threshold,three_view_threshold=b$threshold)
    for(nm in c('n_two_view','n_three_view','n_shared','n_two_view_only','n_three_view_only','n_union'))
      stopifnot(row[[nm]]==p[[nm]])
    stopifnot(abs(row$jaccard-p$jaccard)<1e-12)
    out[[i]] <- row
    calls[[i]] <- data.frame(cohort=p$cohort,Protein=sort(both),
      two_view=sort(both) %in% a$proteins,three_view=sort(both) %in% b$proteins)
  }
  summary <- do.call(rbind,out);protein_calls<-do.call(rbind,calls)
  print(summary)
  if(write_files) {
    write.csv(summary,file.path(package_dir,'data/R_verified_overlap_summary.csv'),row.names=FALSE)
    write.csv(protein_calls,file.path(package_dir,'data/R_verified_protein_calls.csv'),row.names=FALSE)
  }
  invisible(list(summary=summary,calls=protein_calls))
}
# result <- check_two_three_views(package_dir,write_files=TRUE)
