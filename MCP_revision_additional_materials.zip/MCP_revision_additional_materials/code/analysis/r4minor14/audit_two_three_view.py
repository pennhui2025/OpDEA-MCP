"""Audit simpler two-view versus selected three-view TPD/CRC outputs.

Read-only inputs; writes compact CSV evidence beside this script.  This does
not train MCP or the recommendation model and does not rerun DEA or UMAP.
"""

from __future__ import annotations

import hashlib
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.metrics import (
    adjusted_rand_score,
    normalized_mutual_info_score,
    silhouette_score,
)
from sklearn.metrics.cluster import contingency_matrix


HERE = Path(__file__).resolve().parent
NCS_CASE = Path(
    r"inputs/n\Figures\data\case_study"
)
NCS_CLUSTER = Path(
    r"inputs/n\Figures\data\clustering_20260320"
)
NCS_FIG4 = Path(r"inputs/n\Figures\res\Fig4")
REPRO_VIEW = Path(
    r"inputs/nc\Result_reproducing"
    r"\Result_reproducing\View_combination_selection"
)

COHORTS = {
    "TPD": {"folder": "TPD_dis_filter_all08", "fold_change": 2.0},
    "CRC": {"folder": "CRC_filter_all08", "fold_change": 1.5},
}
COMBINATIONS = {
    "two_view": "DIA_dlfq_maxlfq",
    "three_view": "DIA_dlfq_maxlfq_top3",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def dep_set(path: Path, fold_change: float) -> tuple[set[str], float]:
    table = pd.read_csv(path)
    threshold = float(table["MVcontrast_threshold.2"].max())
    keep = (table["MVcontrast_score.2"] >= threshold) & (
        table["MVcontrast_logFC.2"].abs() >= np.log2(fold_change)
    )
    return set(table.loc[keep, "Protein"].astype(str)), threshold


def purity(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    cm = contingency_matrix(y_true, y_pred)
    return float(np.amax(cm, axis=0).sum() / cm.sum())


def cluster_metrics(path: Path) -> dict[str, float | int | str]:
    frame = pd.read_csv(path)
    values = frame.iloc[:, 1:].to_numpy(dtype=float)
    data, labels = values[:, :-1], values[:, -1].astype(int)
    clusters = KMeans(
        n_clusters=2,
        random_state=2024,
        n_init=10,
        init="k-means++",
        max_iter=300,
        tol=1e-4,
        algorithm="lloyd",
    ).fit_predict(data)
    return {
        "source_file": str(path),
        "n_samples": data.shape[0],
        "n_features": data.shape[1],
        "ARI": adjusted_rand_score(labels, clusters),
        "NMI": normalized_mutual_info_score(labels, clusters),
        "purity": purity(labels, clusters),
        "ASW_feature_space_kmeans": silhouette_score(data, clusters),
        "ASW_feature_space_clinical_labels": silhouette_score(data, labels),
        "ASW_invalid_old_formula": silhouette_score(labels.reshape(-1, 1), clusters),
    }


def reconstruct_scores(dataset: str) -> pd.DataFrame:
    """Recover intended pairings positionally; source CSV lost row alignment."""
    path = REPRO_VIEW / f"{dataset}_5fold_pred_performance.csv"
    raw = pd.read_csv(path)
    meta = raw.loc[raw["view_name"].notna()].reset_index(drop=True)
    scores = raw.loc[raw["pred_mcc"].notna(), "pred_mcc"].reset_index(drop=True)
    if len(meta) != len(scores):
        raise ValueError(f"Cannot reconstruct {path}: {len(meta)} metadata vs {len(scores)} scores")
    out = meta[["view_name", "acq", "platform", "dea", "view_num"]].copy()
    out.insert(0, "dataset", dataset)
    out.insert(1, "position_in_prediction_order", np.arange(len(out)))
    out["predicted_normalized_relative_MCC"] = scores
    out["pairing_status"] = "positional_reconstruction_from_two_row_blocks"
    out["source_file"] = str(path)
    out["source_sha256"] = sha256(path)
    return out


def main() -> None:
    presence_rows: list[dict[str, object]] = []
    summary_rows: list[dict[str, object]] = []
    manifest_paths: list[Path] = []
    saved_sets: dict[str, dict[str, set[str]]] = {}

    for cohort, config in COHORTS.items():
        sets: dict[str, set[str]] = {}
        thresholds: dict[str, float] = {}
        paths: dict[str, Path] = {}
        for label, folder in COMBINATIONS.items():
            path = NCS_CASE / str(config["folder"]) / folder / "DEA_res.csv"
            paths[label] = path
            manifest_paths.append(path)
            sets[label], thresholds[label] = dep_set(path, float(config["fold_change"]))
        saved_sets[cohort] = sets
        union = sets["two_view"] | sets["three_view"]
        intersection = sets["two_view"] & sets["three_view"]
        for protein in sorted(union):
            in_two = protein in sets["two_view"]
            in_three = protein in sets["three_view"]
            status = "shared" if in_two and in_three else ("two_view_only" if in_two else "three_view_only")
            presence_rows.append(
                {
                    "cohort": cohort,
                    "protein": protein,
                    "in_dlfq_maxlfq": in_two,
                    "in_dlfq_maxlfq_top3": in_three,
                    "membership": status,
                }
            )
        summary_rows.append(
            {
                "cohort": cohort,
                "fold_change_threshold": config["fold_change"],
                "two_view_score_threshold": thresholds["two_view"],
                "three_view_score_threshold": thresholds["three_view"],
                "n_two_view": len(sets["two_view"]),
                "n_three_view": len(sets["three_view"]),
                "n_shared": len(intersection),
                "n_two_view_only": len(sets["two_view"] - sets["three_view"]),
                "n_three_view_only": len(sets["three_view"] - sets["two_view"]),
                "n_union": len(union),
                "jaccard": len(intersection) / len(union),
                "three_view_fraction_retained_by_two_view": len(intersection)
                / len(sets["three_view"]),
                "two_view_source": str(paths["two_view"]),
                "three_view_source": str(paths["three_view"]),
            }
        )

    pd.DataFrame(presence_rows).to_csv(HERE / "two_three_view_dep_presence.csv", index=False)
    pd.DataFrame(summary_rows).to_csv(HERE / "two_three_view_dep_overlap_summary.csv", index=False)

    unique19_path = NCS_FIG4 / "MCP_unique_protein_CRC.csv"
    unique19 = pd.read_csv(unique19_path)
    manifest_paths.append(unique19_path)
    unique19["in_selected_three_view_MCP"] = unique19["UNIPROT"].isin(
        saved_sets["CRC"]["three_view"]
    )
    unique19["in_simpler_two_view_MCP"] = unique19["UNIPROT"].isin(
        saved_sets["CRC"]["two_view"]
    )
    unique19["retention_status"] = np.where(
        unique19["in_simpler_two_view_MCP"], "retained_by_two_view", "not_called_by_two_view"
    )
    unique19.to_csv(HERE / "crc_19_selected_mcp_unique_retention.csv", index=False)

    cluster_files = {
        "two_view": NCS_CLUSTER / "TPD_disDIA_dlfq_maxlfqmvdea.csv",
        "three_view": NCS_CLUSTER / "TPD_disDIA_dlfq_maxlfq_top3mvdea.csv",
    }
    cluster_rows = []
    for label, path in cluster_files.items():
        manifest_paths.append(path)
        row = {"combination": label, **cluster_metrics(path)}
        cluster_rows.append(row)
    pd.DataFrame(cluster_rows).to_csv(HERE / "tpd_two_three_view_clustering_metrics.csv", index=False)

    score_frames = [reconstruct_scores("TPD"), reconstruct_scores("CRC")]
    scores = pd.concat(score_frames, ignore_index=True)
    scores.to_csv(HERE / "recommendation_scores_positional_reconstruction.csv", index=False)
    for dataset in ("TPD", "CRC"):
        manifest_paths.extend(
            [
                REPRO_VIEW / f"{dataset}_5fold_pred_performance.csv",
                REPRO_VIEW / f"{dataset}_feature.csv",
            ]
        )
    manifest_paths.extend(
        [
            REPRO_VIEW / "combination_selection.py",
            REPRO_VIEW / "trained_model_scale_T_trial305fold.joblib",
            REPRO_VIEW / "train_feature.csv",
        ]
    )
    manifest = pd.DataFrame(
        [
            {
                "path": str(path),
                "bytes": path.stat().st_size,
                "sha256": sha256(path),
            }
            for path in dict.fromkeys(manifest_paths)
        ]
    )
    manifest.to_csv(HERE / "audit_input_sha256.csv", index=False)

    print(pd.DataFrame(summary_rows).to_string(index=False))
    print("\nCRC 19 selected-MCP-unique retention:")
    print(unique19.to_string(index=False))
    print("\nTPD two/three-view clustering:")
    print(pd.DataFrame(cluster_rows).to_string(index=False))


if __name__ == "__main__":
    main()
