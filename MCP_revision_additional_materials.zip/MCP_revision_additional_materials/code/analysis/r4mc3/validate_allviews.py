"""Independent sklearn validation of the expanded MCP initialization analysis.

Reads only the matched-source manifest and raw DP result files.  It reconstructs
the common protein union, the physical fourth neural output block (DP_fdr), both
binary operating points, and the two-stage medians without using the R metrics.
"""

from __future__ import annotations

import json
import math
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import sklearn
from sklearn.metrics import (
    confusion_matrix,
    f1_score,
    matthews_corrcoef,
    precision_score,
    recall_score,
    roc_auc_score,
)


BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
MANIFEST = DATA / "all_initialization_matched_manifest.csv"
OUT_JSON = BASE / "initialization_validation.json"

PER_PATH = DATA / "initialization_per_run.csv"
SETTING_PATH = DATA / "initialization_setting_medians.csv"
SUMMARY_PATH = DATA / "initialization_medians.csv"
SOURCES_PATH = DATA / "initialization_sources.csv"

SOURCE_KEYS = ["dataset", "platform", "acquisition", "view_count", "views"]
PER_KEYS = SOURCE_KEYS + ["method", "contains_count", "fc_ratio"]
SETTING_KEYS = [
    "acquisition",
    "platform",
    "view_count",
    "views",
    "method",
    "contains_count",
    "fc_ratio",
]
SUMMARY_KEYS = ["acquisition", "platform", "method", "fc_ratio"]
METRICS = [
    "precision",
    "recall",
    "MCC",
    "F1",
    "TP",
    "FP",
    "TN",
    "FN",
    "n_called",
    "n_union",
    "AUROC",
    "pAUC_0.01",
    "pAUC_0.05",
    "pAUC_0.1",
]
USECOLS = [
    "Protein",
    "True_lab",
    "Protein.4",
    "Probability.3",
    "ori_logFC.3",
    "threshold.3",
]


def fail(message: str) -> None:
    raise RuntimeError(message)


def normalize_bool(series: pd.Series) -> pd.Series:
    if pd.api.types.is_bool_dtype(series):
        return series.astype(bool)
    mapped = series.astype(str).str.strip().str.lower().map(
        {"true": True, "false": False, "1": True, "0": False}
    )
    if mapped.isna().any():
        fail(f"Cannot normalize boolean values: {series[mapped.isna()].unique()[:5]}")
    return mapped.astype(bool)


def binary_metrics(y: np.ndarray, call: np.ndarray) -> dict[str, float]:
    tn, fp, fn, tp = confusion_matrix(y, call.astype(int), labels=[0, 1]).ravel()
    return {
        "precision": float(precision_score(y, call, zero_division=0)),
        "recall": float(recall_score(y, call, zero_division=0)),
        "MCC": float(matthews_corrcoef(y, call)),
        "F1": float(f1_score(y, call, zero_division=0)),
        "TP": float(tp),
        "FP": float(fp),
        "TN": float(tn),
        "FN": float(fn),
        "n_called": float(call.sum()),
        "n_union": float(y.size),
    }


def ranking_metrics(y: np.ndarray, score: np.ndarray) -> dict[str, float]:
    if not np.isfinite(score).all():
        fail("Non-finite model score encountered")
    if np.unique(y).size != 2:
        fail("ROC metrics require both truth classes")
    return {
        "AUROC": float(roc_auc_score(y, score)),
        "pAUC_0.01": float(roc_auc_score(y, score, max_fpr=0.01)),
        "pAUC_0.05": float(roc_auc_score(y, score, max_fpr=0.05)),
        "pAUC_0.1": float(roc_auc_score(y, score, max_fpr=0.1)),
    }


def truth_union(frames: list[pd.DataFrame]) -> pd.DataFrame:
    pieces = []
    for frame in frames:
        part = frame.loc[frame["Protein"].notna(), ["Protein", "True_lab"]].copy()
        part = part.loc[part["Protein"].astype(str).str.strip().ne("")]
        pieces.append(part)
    all_truth = pd.concat(pieces, ignore_index=True).drop_duplicates()
    all_truth["True_lab"] = pd.to_numeric(all_truth["True_lab"], errors="raise").astype(int)
    if not set(all_truth["True_lab"].unique()).issubset({0, 1}):
        fail("Truth labels outside {0,1}")
    conflict = all_truth.groupby("Protein", sort=False)["True_lab"].nunique()
    if (conflict != 1).any():
        fail(f"Conflicting truth labels for {int((conflict != 1).sum())} proteins")
    truth = all_truth.drop_duplicates("Protein", keep="first").reset_index(drop=True)
    if truth["Protein"].duplicated().any():
        fail("Duplicate protein in common truth union")
    return truth


def read_source(path: str) -> pd.DataFrame:
    p = Path(path)
    if not p.is_file():
        fail(f"Missing source file: {p}")
    return pd.read_csv(p, usecols=USECOLS, low_memory=False)


def key_frame(frame: pd.DataFrame, keys: list[str]) -> pd.DataFrame:
    out = frame.copy()
    if "view_count" in out:
        out["view_count"] = pd.to_numeric(out["view_count"], errors="raise").astype(int)
    if "fc_ratio" in out:
        out["fc_ratio"] = pd.to_numeric(out["fc_ratio"], errors="raise").astype(float)
    if "contains_count" in out:
        out["contains_count"] = normalize_bool(out["contains_count"])
    for key in keys:
        if key not in out.columns:
            fail(f"Missing key column {key}")
    return out


def compare_table(
    name: str,
    observed: pd.DataFrame,
    expected: pd.DataFrame,
    keys: list[str],
    numeric_columns: list[str],
) -> dict:
    obs = key_frame(observed, keys)
    exp = key_frame(expected, keys)
    if obs.duplicated(keys).any() or exp.duplicated(keys).any():
        fail(f"Duplicate comparison keys in {name}")
    merged = exp.merge(obs, on=keys, how="outer", suffixes=("_py", "_r"), indicator=True)
    key_mismatch = int((merged["_merge"] != "both").sum())
    diffs: dict[str, float] = {}
    mismatch_counts: dict[str, int] = {}
    for column in numeric_columns:
        a = pd.to_numeric(merged[f"{column}_py"], errors="coerce").to_numpy(float)
        b = pd.to_numeric(merged[f"{column}_r"], errors="coerce").to_numpy(float)
        valid = np.isfinite(a) & np.isfinite(b)
        both_nan = np.isnan(a) & np.isnan(b)
        invalid_pair = ~(valid | both_nan)
        delta = np.abs(a[valid] - b[valid])
        diffs[column] = float(delta.max()) if delta.size else 0.0
        mismatch_counts[column] = int(invalid_pair.sum() + (delta > 1e-12).sum())
    return {
        "python_rows": int(len(expected)),
        "r_rows": int(len(observed)),
        "key_mismatches": key_mismatch,
        "max_abs_difference": diffs,
        "value_mismatches_gt_1e-12": mismatch_counts,
    }


def main() -> None:
    manifest = pd.read_csv(MANIFEST, low_memory=False)
    if len(manifest) != 975:
        fail(f"Expected 975 manifest rows, found {len(manifest)}")
    manifest["view_count"] = pd.to_numeric(manifest["view_count"], errors="raise").astype(int)
    if manifest.duplicated(SOURCE_KEYS + ["label_source"]).any():
        fail("Duplicate matched source key in manifest")

    expected_counts = {
        PER_PATH: 1950,
        SETTING_PATH: 252,
        SUMMARY_PATH: 24,
        SOURCES_PATH: 975,
    }
    observed_tables: dict[Path, pd.DataFrame] = {}
    for path, expected_n in expected_counts.items():
        if not path.is_file():
            fail(f"R output not ready: missing {path}")
        table = pd.read_csv(path, low_memory=False)
        if len(table) != expected_n:
            fail(f"R output not ready: {path.name} has {len(table)} rows, expected {expected_n}")
        observed_tables[path] = table

    per_rows: list[dict] = []
    source_rows: list[dict] = []
    infinite_source_files = 0
    infinite_fc_values = 0
    infinite_fc_called_no_filter = 0
    infinite_fc_called_fc15 = 0

    grouped = manifest.groupby(SOURCE_KEYS, sort=False, dropna=False)
    if grouped.ngroups != 325:
        fail(f"Expected 325 matched strata, found {grouped.ngroups}")

    for _, group in grouped:
        if len(group) != 3 or set(group["label_source"]) != {"limma", "ROTS", "SAM"}:
            fail("A matched stratum is not a limma/ROTS/SAM triplet")
        frames = [read_source(path) for path in group["source_file"]]
        truth = truth_union(frames)
        truth_ids = truth["Protein"].astype(str).to_numpy()
        y = truth["True_lab"].to_numpy(int)
        truth_index = {protein: i for i, protein in enumerate(truth_ids)}

        for (_, meta), frame in zip(group.iterrows(), frames):
            mask = frame["Protein.4"].notna() & frame["Protein.4"].astype(str).str.strip().ne("")
            block = frame.loc[mask, ["Protein.4", "Probability.3", "ori_logFC.3", "threshold.3"]].copy()
            ids = block["Protein.4"].astype(str).to_numpy()
            if len(ids) == 0 or pd.Series(ids).duplicated().any():
                fail(f"Empty or duplicate final model IDs: {meta['source_file']}")
            if any(protein not in truth_index for protein in ids):
                fail(f"Final model protein absent from truth union: {meta['source_file']}")

            probabilities = pd.to_numeric(block["Probability.3"], errors="raise").to_numpy(float)
            fold_changes = pd.to_numeric(block["ori_logFC.3"], errors="raise").to_numpy(float)
            thresholds = pd.to_numeric(block["threshold.3"], errors="raise").to_numpy(float)
            if not np.isfinite(probabilities).all():
                fail(f"Non-finite probability: {meta['source_file']}")
            if np.isnan(fold_changes).any():
                fail(f"NA fold change: {meta['source_file']}")
            finite_thresholds = np.unique(thresholds[np.isfinite(thresholds)])
            if len(finite_thresholds) != 1 or not np.isfinite(thresholds).all():
                fail(f"Non-unique/non-finite threshold: {meta['source_file']}")
            threshold = float(finite_thresholds[0])

            score = np.zeros(len(truth), dtype=float)
            lfc = np.zeros(len(truth), dtype=float)
            seen = np.zeros(len(truth), dtype=bool)
            positions = np.fromiter((truth_index[p] for p in ids), dtype=int, count=len(ids))
            score[positions] = probabilities
            lfc[positions] = fold_changes
            seen[positions] = True
            base_call = seen & (score >= threshold)
            fc15_call = base_call & (np.abs(lfc) >= math.log2(1.5))
            rank = ranking_metrics(y, score)

            inf_mask = np.isinf(fold_changes)
            n_inf = int(inf_mask.sum())
            if n_inf:
                infinite_source_files += 1
                infinite_fc_values += n_inf
                inf_positions = positions[inf_mask]
                infinite_fc_called_no_filter += int(base_call[inf_positions].sum())
                infinite_fc_called_fc15 += int(fc15_call[inf_positions].sum())

            common = {
                key: meta[key] for key in SOURCE_KEYS
            }
            common.update(
                {
                    "method": f"MCP_{meta['label_source']}",
                    "contains_count": "count" in str(meta["views"]).split("_"),
                }
            )
            for fc_ratio, call in ((1.5, fc15_call), (1.0, base_call)):
                row = dict(common)
                row["fc_ratio"] = fc_ratio
                row.update(binary_metrics(y, call))
                row.update(rank)
                per_rows.append(row)

            source_row = dict(common)
            source_row.update(
                {
                    "source_file": meta["source_file"],
                    "model_threshold": threshold,
                    "n_union": len(truth),
                    "n_available": int(seen.sum()),
                    "n_unavailable": int((~seen).sum()),
                    "n_truth_positive": int(y.sum()),
                    "n_infinite_logFC": n_inf,
                    "source_batch": meta["source_batch"],
                }
            )
            source_rows.append(source_row)

    per = pd.DataFrame(per_rows)
    sources = pd.DataFrame(source_rows)
    if len(per) != 1950 or len(sources) != 975:
        fail(f"Unexpected reconstructed rows: per={len(per)}, sources={len(sources)}")

    setting = (
        per.groupby(SETTING_KEYS, sort=False, dropna=False)
        .agg(n_datasets=("dataset", "size"), **{metric: (metric, "median") for metric in METRICS})
        .reset_index()
    )
    if len(setting) != 252:
        fail(f"Expected 252 setting rows, found {len(setting)}")

    summary = (
        setting.groupby(SUMMARY_KEYS, sort=False, dropna=False)
        .agg(
            n_settings=("views", "size"),
            n_matched_records=("n_datasets", "sum"),
            min_datasets_per_setting=("n_datasets", "min"),
            max_datasets_per_setting=("n_datasets", "max"),
            **{metric: (metric, "median") for metric in METRICS},
        )
        .reset_index()
    )
    if len(summary) != 24:
        fail(f"Expected 24 platform-summary rows, found {len(summary)}")

    per_check = compare_table(
        "per_run",
        observed_tables[PER_PATH],
        per,
        PER_KEYS,
        METRICS,
    )
    setting_check = compare_table(
        "setting_medians",
        observed_tables[SETTING_PATH],
        setting,
        SETTING_KEYS,
        ["n_datasets"] + METRICS,
    )
    summary_check = compare_table(
        "platform_medians",
        observed_tables[SUMMARY_PATH],
        summary,
        SUMMARY_KEYS,
        [
            "n_settings",
            "n_matched_records",
            "min_datasets_per_setting",
            "max_datasets_per_setting",
        ]
        + METRICS,
    )
    source_check = compare_table(
        "sources",
        observed_tables[SOURCES_PATH],
        sources,
        SOURCE_KEYS + ["method"],
        [
            "model_threshold",
            "n_union",
            "n_available",
            "n_unavailable",
            "n_truth_positive",
            "n_infinite_logFC",
        ],
    )

    checks = {
        "per_run": per_check,
        "setting_medians": setting_check,
        "platform_medians": summary_check,
        "sources": source_check,
    }
    passed = all(
        check["key_mismatches"] == 0
        and all(v == 0 for v in check["value_mismatches_gt_1e-12"].values())
        for check in checks.values()
    )

    report = {
        "status": "pass" if passed else "fail",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "python": sys.version,
        "pandas_version": pd.__version__,
        "sklearn_version": sklearn.__version__,
        "input_counts": {
            "manifest_rows": int(len(manifest)),
            "unique_source_paths": int(manifest["source_file"].nunique()),
            "matched_strata": int(grouped.ngroups),
            "recomputed_per_run_rows": int(len(per)),
            "recomputed_setting_rows": int(len(setting)),
            "recomputed_platform_rows": int(len(summary)),
        },
        "comparisons": checks,
        "infinite_fold_change_audit": {
            "source_files_with_infinite_logFC": infinite_source_files,
            "infinite_logFC_values": infinite_fc_values,
            "infinite_logFC_values_called_without_FC_filter": infinite_fc_called_no_filter,
            "infinite_logFC_values_called_with_1.5_fold_filter": infinite_fc_called_fc15,
            "na_logFC_values": 0,
            "handling": (
                "Saved +/-Inf values were preserved. If their model score met the saved threshold, "
                "they passed the absolute 1.5-fold magnitude gate; missing model rows remained "
                "score=0/non-DEP with logFC=0."
            ),
            "interpretation_caveat": (
                "An infinite saved logFC preserves the archived binary-call behavior but is not a "
                "finite effect-size estimate and should not be interpreted as measured biological magnitude."
            ),
        },
        "scientific_scope_caveats": [
            "Metrics validate available matched triplets, not missing or unmatched runs.",
            "The setting-level then platform-level medians give each available view combination equal weight; unequal complete-case coverage can still cause survivorship bias.",
            "Repeated datasets and overlapping view combinations are not independent biological replicates.",
            "Count-containing DDA settings use edgeR for the count view in every initialization branch and are SAM/edgeR, limma/edgeR, or ROTS/edgeR hybrids.",
        ],
    }
    OUT_JSON.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    if not passed:
        fail("Independent validation did not match R outputs; see initialization_validation.json")
    print(json.dumps({"status": report["status"], "input_counts": report["input_counts"]}, indent=2))


if __name__ == "__main__":
    main()

