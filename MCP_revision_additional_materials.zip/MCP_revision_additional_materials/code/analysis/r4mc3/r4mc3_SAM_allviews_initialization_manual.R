# 完整SAM初始化比较：DIA 2/3/4视图 + DDA 2视图。
# 只读取已完成的原始结果，不训练模型；source()只定义函数。
# 手动运行：ans <- run_sam_initialization_allviews()
# SAM、limma、ROTS均指MCP的初始化DEA，不是三种独立DEA基线。

run_sam_initialization_allviews <- function(
  delivery_dir="reference/Response/r4mc3",
  manifest_path=file.path(delivery_dir,"data/all_initialization_matched_manifest.csv"),
  metrics_script=file.path(delivery_dir,"r4mc3_SAM_reference_manual.R"),
  out=file.path(delivery_dir,"manual_R_allviews_initialization"),write_files=TRUE
) {
  source(metrics_script) # 仅使用已验证的binary/ROC函数；不自动运行其它分析。
  mf<-read.csv(manifest_path,stringsAsFactors=FALSE)
  keys<-c("dataset","platform","acquisition","view_count","views")
  stopifnot(nrow(mf)==975L,!anyDuplicated(mf[c(keys,"label_source")]))
  valid_ids<-function(x)stopifnot(!anyNA(x),all(nzchar(x)),!anyDuplicated(x))
  long_path<-function(path) {
    path<-normalizePath(path,winslash="/",mustWork=TRUE)
    if(.Platform$OS.type=="windows")path<-paste0("\\\\?\\",chartr("/","\\",path))
    path
  }
  strata<-split(seq_len(nrow(mf)),do.call(paste,c(mf[keys],sep="|")))
  result_rows<-source_rows<-list(); processed<-0L
  for(ii in strata) {
    g<-mf[ii,,drop=FALSE]
    stopifnot(nrow(g)==3L,setequal(g$label_source,c("limma","ROTS","SAM")))
    raw<-lapply(g$source_file,function(p)read.csv(long_path(p),check.names=TRUE))
    truth<-unique(do.call(rbind,lapply(raw,function(d)
      d[!is.na(d$Protein) & nzchar(trimws(as.character(d$Protein))),c("Protein","True_lab")])))
    valid_ids(truth$Protein);stopifnot(all(truth$True_lab %in% 0:1))
    for(j in seq_along(raw)) {
      d<-raw[[j]]
      # 每个视图数下均读取最终模型的第四输出块(DP_fdr)，不使用DP_direct。
      required<-c("Protein.4","Probability.3","ori_logFC.3","threshold.3")
      stopifnot(all(required %in% names(d)))
      # CSV blocks can be padded with either NA or empty IDs; padding is not a protein.
      b<-d[!is.na(d$Protein.4) & nzchar(trimws(as.character(d$Protein.4))),required]
      stopifnot(nrow(b)>0L)
      valid_ids(b$Protein.4);stopifnot(all(b$Protein.4 %in% truth$Protein))
      threshold<-unique(b$threshold.3)
      stopifnot(length(threshold)==1L,is.finite(threshold),
                all(is.finite(b$Probability.3)),!anyNA(b$ori_logFC.3))
      # Saved +/-Inf logFC values retain their original magnitude-filter behavior.
      # Do not convert infinity to NA or silently delete these proteins.
      ix<-match(truth$Protein,b$Protein.4);seen<-!is.na(ix)
      score<-lfc<-numeric(nrow(truth));call<-rep(FALSE,nrow(truth))
      score[seen]<-b$Probability.3[ix[seen]];lfc[seen]<-b$ori_logFC.3[ix[seen]]
      call[seen]<-score[seen]>=threshold
      # 所有方法共同union；无输出的蛋白为non-DEP、最低score=0。
      # 连续排名不进行显著性/FC过滤；pAUC的0.01/.05/.1为FPR上限。
      rank<-r4mc3_roc(score,truth$True_lab)
      method<-paste0("MCP_",g$label_source[j])
      contains_count<-"count" %in% strsplit(g$views[j],"_",fixed=TRUE)[[1]]
      for(fc in c(1.5,1)) {
        cc<-call
        if(fc>1)cc<-cc & abs(lfc)>=log2(fc)
        result_rows[[length(result_rows)+1L]]<-data.frame(g[j,keys],method,
          contains_count,fc_ratio=fc,as.list(c(r4mc3_binary(cc,truth$True_lab),rank)),check.names=FALSE)
      }
      source_rows[[length(source_rows)+1L]]<-data.frame(g[j,keys],method,
        contains_count,source_file=g$source_file[j],
        file_md5=unname(tools::md5sum(long_path(g$source_file[j]))),model_threshold=threshold,
        n_union=nrow(truth),n_available=sum(seen),n_unavailable=sum(!seen),
        n_truth_positive=sum(truth$True_lab),n_infinite_logFC=sum(is.infinite(b$ori_logFC.3)),
        source_batch=g$source_batch[j])
    }
    processed<-processed+1L
    if(processed %% 25L==0L)message("Matched dataset-platform-combinations processed: ",processed," / ",length(strata))
  }
  per<-do.call(rbind,result_rows);sources<-do.call(rbind,source_rows)
  metric_cols<-c("precision","recall","MCC","F1","TP","FP","TN","FN","n_called","n_union",
                 "AUROC","pAUC_0.01","pAUC_0.05","pAUC_0.1")
  # 第一层：每个平台×组合内，对相同且可配对的数据集逐指标取median。
  skeys<-c("acquisition","platform","view_count","views","method","contains_count","fc_ratio")
  sg<-split(seq_len(nrow(per)),do.call(paste,c(per[skeys],sep="|")))
  setting<-do.call(rbind,lapply(sg,function(ii) {
    z<-per[ii,,drop=FALSE];stopifnot(!anyDuplicated(z$dataset))
    data.frame(z[1,skeys],n_datasets=nrow(z),
      as.list(vapply(z[metric_cols],median,numeric(1))),check.names=FALSE)
  }))
  # 第二层：各平台对组合层median再取median，每个组合权重相同。
  # 不把所有dataset×组合直接混池，不把重复使用的数据集当独立重复。
  pkeys<-c("acquisition","platform","method","fc_ratio")
  pg<-split(seq_len(nrow(setting)),do.call(paste,c(setting[pkeys],sep="|")))
  summary<-do.call(rbind,lapply(pg,function(ii) {
    z<-setting[ii,,drop=FALSE]
    data.frame(z[1,pkeys],n_settings=nrow(z),n_matched_records=sum(z$n_datasets),
      min_datasets_per_setting=min(z$n_datasets),max_datasets_per_setting=max(z$n_datasets),
      as.list(vapply(z[metric_cols],median,numeric(1))),check.names=FALSE)
  }))
  rownames(per)<-rownames(setting)<-rownames(summary)<-rownames(sources)<-NULL
  stopifnot(nrow(per)==1950L,nrow(setting)==252L,nrow(summary)==24L,nrow(sources)==975L)
  ans<-list(initialization_medians=summary,initialization_per_run=per,
            initialization_setting_medians=setting,initialization_sources=sources)
  if(write_files){dir.create(out,recursive=TRUE,showWarnings=FALSE)
    for(n in names(ans))write.csv(ans[[n]],file.path(out,paste0(n,".csv")),row.names=FALSE,na="")}
  print(summary[summary$fc_ratio==1.5,c("platform","method","n_settings","n_matched_records",
    "precision","recall","MCC","pAUC_0.01","pAUC_0.05","pAUC_0.1")],row.names=FALSE)
  invisible(ans)
}
