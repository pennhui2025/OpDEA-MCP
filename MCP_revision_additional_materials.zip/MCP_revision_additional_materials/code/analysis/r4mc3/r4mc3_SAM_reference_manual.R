# Reviewer 4 Major comment 3: standalone SAM AND SAM-initialized MCP.
# RStudio: source(".../r4mc3_SAM_reference_manual.R"); ans <- run_r4mc3()
# source()只定义函数；不训练模型、不重新运行SAM、不安装R包、不修改原数据。
# SAM.significant是SAM原生delta规则的判定，不能把分段赋值的adj.pvalue用于连续排序。

r4mc3_roc <- function(score, y) {
  stopifnot(length(score)==length(y), all(is.finite(score)), all(y %in% 0:1))
  n1<-sum(y==1); n0<-sum(y==0); stopifnot(n1>0,n0>0)
  o<-order(score,decreasing=TRUE); s<-score[o]; y<-y[o]
  ends<-c(which(diff(s)!=0),length(s))
  x<-c(0,cumsum(1-y)[ends]/n0); z<-c(0,cumsum(y)[ends]/n1)
  area<-function(a,b)sum(diff(a)*(head(b,-1)+tail(b,-1))/2)
  out<-c(AUROC=area(x,z))
  for(m in c(.01,.05,.1)) {
    k<-max(which(x<=m)); xx<-x[seq_len(k)]; zz<-z[seq_len(k)]
    if(x[k]<m) {
      zz<-c(zz,z[k]+(m-x[k])/(x[k+1]-x[k])*(z[k+1]-z[k]))
      xx<-c(xx,m)
    }
    # McClish标准化partial ROC AUC:随机0.5，完美1；m是FPR上限，不是FDR。
    out[paste0("pAUC_",m)]<-.5*(1+(area(xx,zz)-.5*m*m)/(m-.5*m*m))
  }
  out
}

# MCP初始化比较已扩展为DIA+DDA所有可配对组合，见同目录：
# r4mc3_SAM_allviews_initialization_manual.R -> run_sam_initialization_allviews()
# 旧的33模型窄范围初始化函数已移除，避免混用旧结果。

r4mc3_binary <- function(call,y) {
  tp<-as.double(sum(call & y==1)); fp<-as.double(sum(call & y==0))
  tn<-as.double(sum(!call & y==0)); fn<-as.double(sum(!call & y==1))
  den<-sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn)) # double避免整数乘法溢出
  c(precision=if(tp+fp>0)tp/(tp+fp) else 0,recall=tp/(tp+fn),
    MCC=if(den>0)(tp*tn-fp*fn)/den else 0,F1=2*tp/(2*tp+fp+fn),
    TP=tp,FP=fp,TN=tn,FN=fn,n_called=tp+fp,n_union=length(y))
}

run_r4mc3 <- function(
  project="inputs/p",
  mcp_manifest="reference/Response/r4mc1/data/source_manifest.csv",
  out="reference/Response/r4mc3/manual_R_check",
  write_files=TRUE
) {
  # Tie-aware ROC自检，无需第三方包。
  stopifnot(all(abs(r4mc3_roc(rep(1,4),c(0,0,1,1))-.5)<1e-12),
            all(abs(r4mc3_roc(c(0,0,1,1),c(0,0,1,1))-1)<1e-12))
  manifest<-read.csv(mcp_manifest,stringsAsFactors=FALSE)
  manifest<-manifest[manifest$acquisition=="DIA",,drop=FALSE]
  stopifnot(nrow(manifest)==28L,!anyDuplicated(manifest[c("dataset","platform","dea")]),
            setequal(manifest$dea,c("limma","ROTS")))
  datasets<-sort(unique(manifest$dataset)); stopifnot(length(datasets)==7L)
  views<-c("dlfq","maxlfq","top3","top1")
  roots<-c(DIANN="temp0_SAMdelta_DIANN_view4",Spectronaut="temp1_SAMdelta_Spectronaut_view4")
  file_platform<-c(DIANN="DIANN",Spectronaut="spt")
  rows<-sources<-audit<-list()
  unique_ids<-function(x)stopifnot(!anyNA(x),all(nzchar(x)),!anyDuplicated(x))
  read_raw<-function(path,...) {
    stopifnot(file.exists(path)); read.csv(path,stringsAsFactors=FALSE,...)
  }
  for(platform in names(roots))for(dataset in datasets) {
    key<-manifest$platform==platform & manifest$dataset==dataset
    mm<-manifest[key,,drop=FALSE]; stopifnot(nrow(mm)==2L)
    blocks<-list(); truth_rows<-list(); universes<-list(); org_rows<-list()
    for(j in seq_len(nrow(mm))) {
      d<-read_raw(mm$source_file[j],check.names=TRUE)
      unique_ids(d$Protein); stopifnot(all(d$True_lab %in% 0:1))
      truth_rows[[length(truth_rows)+1L]]<-data.frame(id=d$Protein,y=d$True_lab)
      keep<-!is.na(d$Protein.4) & nzchar(d$Protein.4)
      b<-d[keep,c("Protein.4","Probability.3","ori_logFC.3","threshold.3")]
      unique_ids(b$Protein.4); stopifnot(all(b$Protein.4 %in% d$Protein))
      threshold<-unique(b$threshold.3); stopifnot(length(threshold)==1,is.finite(threshold))
      method<-paste0("MCP_",mm$dea[j])
      blocks[[method]]<-data.frame(id=b$Protein.4,score=b$Probability.3,
        permutation_score=b$Probability.3,lfc=b$ori_logFC.3,
        call=b$Probability.3>=threshold)
      sources[[length(sources)+1L]]<-data.frame(dataset,platform,method,
        source_file=mm$source_file[j],union_file="",file_md5=unname(tools::md5sum(mm$source_file[j])),
        model_threshold=threshold,selected_delta=NA_real_,delta_median_FDR=NA_real_)
    }
    base<-file.path(project,"4views_rev10.05_auc_blank_blank_remove_0_h","revision",
                    "DIA_dlfq_maxlfq_top3_top1",roots[[platform]])
    for(i in seq_along(views)) {
      view<-views[i]
      path<-file.path(base,"DEA_res",paste0(dataset,"union"),
        paste0(dataset,"union_SAMdelta_",file_platform[[platform]],"_",view,"__.csv"))
      upath<-file.path(base,sprintf("real_normed_v%d_union_%s_%s_%s.tsv",i-1,dataset,file_platform[[platform]],view))
      # 原R writer保留row.names，第一列是行号，不是蛋白ID。
      d<-read_raw(path,row.names=1,check.names=FALSE)
      unique_ids(d$protein)
      stopifnot(all(c("SAM.score","SAM.significant","SAM.delta.FDR","pvalue") %in% names(d)),
                all(d$label %in% 0:1),all(is.finite(d$SAM.score)),all(is.finite(d$pvalue)))
      call<-tolower(as.character(d$SAM.significant)) %in% c("true","t","1")
      stopifnot(all(is.finite(d$SAM.delta.FDR[call])),all(d$SAM.delta.FDR[call]<=.05+1e-12))
      truth_rows[[length(truth_rows)+1L]]<-data.frame(id=d$protein,y=as.integer(d$label))
      org_rows[[length(org_rows)+1L]]<-unique(data.frame(organism=d$organism,y=as.integer(d$label)))
      universe<-read.delim(upath,stringsAsFactors=FALSE,check.names=FALSE)
      unique_ids(universe$Protein); universes[[view]]<-universe[c("Protein","Organism")]
      method<-paste0("SAM_",view)
      blocks[[method]]<-data.frame(id=d$protein,score=abs(d$SAM.score),
        permutation_score=1-d$pvalue,lfc=d$logFC,call=call)
      delta<-unique(d$SAM.selected.delta); fdr<-unique(d$SAM.delta.FDR)
      stopifnot(length(delta)==1L,length(fdr)==1L)
      sources[[length(sources)+1L]]<-data.frame(dataset,platform,method,source_file=path,
        union_file=upath,file_md5=unname(tools::md5sum(path)),model_threshold=NA_real_,
        selected_delta=delta,delta_median_FDR=fdr)
    }
    # 统一为该dataset/platform的原始候选蛋白union，并检查所有来源的真值一致。
    orgmap<-unique(do.call(rbind,org_rows)); unique_ids(orgmap$organism)
    for(u in universes) {
      yy<-orgmap$y[match(u$Organism,orgmap$organism)]; stopifnot(!anyNA(yy))
      truth_rows[[length(truth_rows)+1L]]<-data.frame(id=u$Protein,y=yy)
    }
    truth<-unique(do.call(rbind,truth_rows)); unique_ids(truth$id)
    ids<-truth$id; y<-truth$y
    for(method in names(blocks)) {
      b<-blocks[[method]]; stopifnot(all(is.finite(b$score)),!anyNA(b$lfc),!anyNA(b$call))
      idx<-match(ids,b$id); seen<-!is.na(idx)
      score<-scorep<-lfc<-rep(0,length(ids)); call<-rep(FALSE,length(ids))
      score[seen]<-b$score[idx[seen]]; scorep[seen]<-b$permutation_score[idx[seen]]
      lfc[seen]<-b$lfc[idx[seen]]; call[seen]<-b$call[idx[seen]]
      ranking<-r4mc3_roc(score,y); permutation_ranking<-r4mc3_roc(scorep,y)
      # 两种SAM连续排序都保留，主分析使用|SAM statistic|，不是二值化adj.pvalue。
      names(permutation_ranking)<-paste0(names(permutation_ranking),"_permutation_p")
      for(fc in c(1.5,1)) {
        cc<-call
        if(fc>1)cc<-cc & abs(lfc)>=log2(fc)
        rows[[length(rows)+1L]]<-data.frame(dataset,platform,method,fc_ratio=fc,
          as.list(c(r4mc3_binary(cc,y),ranking,permutation_ranking)),check.names=FALSE)
      }
      audit[[length(audit)+1L]]<-data.frame(dataset,platform,method,n_union=length(ids),
        n_available=sum(seen),n_unavailable=sum(!seen),n_truth_positive=sum(y),
        n_native_calls_before_final_fc=sum(call))
    }
  }
  per_run<-do.call(rbind,rows); source_manifest<-do.call(rbind,sources)
  universe_audit<-do.call(rbind,audit); stopifnot(nrow(per_run)==168L,nrow(source_manifest)==84L)
  metrics<-setdiff(names(per_run),c("dataset","platform","method","fc_ratio"))
  groups<-split(seq_len(nrow(per_run)),interaction(per_run[c("platform","method","fc_ratio")],drop=TRUE))
  medians<-do.call(rbind,lapply(groups,function(ii){
    d<-per_run[ii,]; stopifnot(nrow(d)==7L)
    data.frame(d[1,c("platform","method","fc_ratio")],n_datasets=nrow(d),
      as.list(vapply(d[metrics],median,numeric(1))),check.names=FALSE)
  }))
  rownames(medians)<-NULL
  result<-list(platform_medians=medians,per_run=per_run,source_manifest=source_manifest,universe_audit=universe_audit)
  if(write_files) {
    dir.create(out,recursive=TRUE,showWarnings=FALSE)
    for(n in names(result))write.csv(result[[n]],file.path(out,paste0(n,".csv")),row.names=FALSE,na="")
  }
  print(medians[medians$fc_ratio==1.5,c("platform","method","n_datasets","precision","recall","MCC","pAUC_0.01","pAUC_0.05","pAUC_0.1")],row.names=FALSE)
  message("56 native SAM view results + 28 original MCP runs; 14 dataset-platform unions; 168 metric rows.")
  invisible(result)
}
