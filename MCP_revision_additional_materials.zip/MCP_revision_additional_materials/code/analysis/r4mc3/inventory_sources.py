"""Inventory supplied SAM archives and original matched MCP benchmarks, without changing sources."""
from pathlib import Path
import re,json,hashlib
import pandas as pd
root=Path(__file__).resolve().parent
project=Path('inputs/p')
original=Path('inputs/n')
records=[];unparsed=[]
rx=re.compile(r'temp\d+_(SAMdelta|limma|ROTS)_(DIANN|Spectronaut|FragPipe|Maxquant)_view([234])$')
for n in [2,3,4]:
    for batch,base in [('SAM_archive',project/f'{n}views_rev10.05_auc_blank_blank_remove_0_h'),('original_benchmark',original/f'{n}v')]:
        for p in base.rglob('*_DP_res_all.csv'):
            m=rx.fullmatch(p.parent.parent.name)
            if not m:unparsed.append(str(p));continue
            dea,platform,nv=m.groups()
            if (batch=='SAM_archive')!=(dea=='SAMdelta'):continue
            combo=p.parent.parent.parent.name
            acq,views=combo.split('_',1)
            assert len(views.split('_'))==int(nv),(p,n)
            records.append(dict(dataset=p.parent.name,platform=platform,acquisition=acq,
                view_count=int(nv),container_views=n,views=views,label_source='SAM' if dea=='SAMdelta' else dea,
                source_batch=batch,source_file=p.as_posix(),file_bytes=p.stat().st_size))
df=pd.DataFrame(records)
keys=['dataset','platform','acquisition','view_count','views']
duplicates=df[df.duplicated(keys+['label_source'],False)]
duplicates.to_csv(root/'data/duplicate_source_paths.csv',index=False)
keep=[]
for _,g in df.groupby(keys+['label_source']):
    if len(g)>1:
        # Prefer the correctly named outer container, never choose by performance.
        preferred=g[g.container_views==g.view_count]
        if len(preferred)==1:keep.append(preferred.index[0]);continue
        hashes=[hashlib.md5(Path(p).read_bytes()).hexdigest() for p in g.source_file]
        assert len(set(hashes))==1,g.to_string(index=False)
    keep.append(g.index[0])
df=df.loc[keep].copy()
df.to_csv(root/'data/all_initialization_source_inventory.csv',index=False)
cover=df.pivot(index=keys,columns='label_source',values='source_file').reset_index()
cover['has_SAM']=cover.SAM.notna()
cover['matched_triplet']=cover[['SAM','limma','ROTS']].notna().all(axis=1)
cover.to_csv(root/'data/all_initialization_coverage.csv',index=False)
target_settings=df[df.label_source=='SAM'][['platform','acquisition','view_count','views']].drop_duplicates()
target_cover=cover.merge(target_settings,on=['platform','acquisition','view_count','views'])
# Explicitly enumerate the complete benchmark grid, including strata absent from
# all three archives (otherwise an availability table silently omits them).
benchmark_datasets=df[df.source_batch.eq('original_benchmark')][['dataset','acquisition']].drop_duplicates()
expected=target_settings.merge(benchmark_datasets,on='acquisition')[keys].drop_duplicates()
target_cover=expected.merge(target_cover,on=keys,how='outer',validate='one_to_one')
target_cover['has_SAM']=target_cover.SAM.notna()
target_cover['matched_triplet']=target_cover[['SAM','limma','ROTS']].notna().all(axis=1)
target_cover['status']=target_cover.apply(lambda r: 'matched' if r.matched_triplet else
    ('no matched original controls' if r.has_SAM else
     ('all three model outputs unavailable' if pd.isna(r.limma) and pd.isna(r.ROTS)
      else 'SAM final MCP output unavailable')),axis=1)
assert len(target_cover)==375
assert int((~target_cover.has_SAM).sum())==49
target_cover.to_csv(root/'data/initialization_coverage.csv',index=False)
matched=cover[cover.matched_triplet][keys]
mf=df.merge(matched,on=keys,validate='many_to_one').sort_values(keys+['label_source'])
mf.to_csv(root/'data/all_initialization_matched_manifest.csv',index=False)
summary=df.groupby(['source_batch','acquisition','platform','view_count','label_source']).agg(n_files=('source_file','size'),n_datasets=('dataset','nunique'),n_combinations=('views','nunique')).reset_index()
summary.to_csv(root/'data/all_initialization_inventory_summary.csv',index=False)
print(summary.to_string(index=False))
print('Matched strata:',len(matched),'SAM files:',int((df.label_source=='SAM').sum()),'unparsed:',len(unparsed))
if unparsed:print('Unparsed examples:',unparsed[:8])
print(matched.groupby(['platform','view_count']).agg(n_records=('dataset','size'),n_datasets=('dataset','nunique'),n_combinations=('views','nunique')).to_string())
