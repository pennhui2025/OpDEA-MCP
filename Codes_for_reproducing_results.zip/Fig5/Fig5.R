#########################################################################
##
##case study on U2OS
##
###############################################################

#  if the package "this.path" has not been install please installed
# install.packages("this.path", repos = "https://cloud.r-project.org")
library("this.path", character.only = TRUE)
library(readxl)
library(ggplot2)
library(reshape2)
library(ggpubr)
library(cowplot)
library(openxlsx)
library(org.Hs.eg.db)
library(clusterProfiler) 
library(enrichplot)
library(DOSE)

script_path <- this.path()
script_dir <- dirname(script_path)
parent_fold<-dirname(script_dir)

root_fold<-paste0(parent_fold, '/data/')

save_fold<-paste0(script_dir, '/res/Fig5/')
if(!dir.exists(save_fold)){
  dir.create(save_fold, recursive = TRUE)
}


get_entry<-function(ty, pro_list){
  if(ty == 'uniport'){
    return(unlist(lapply(pro_list, function(x) strsplit(x, '|', fixed = T)[[1]][2])))
  }else if(ty == 'gene'){
    return(unlist(lapply(pro_list, function(x) strsplit(strsplit(x, '|', fixed = T)[[1]][3], '_', fixed=T)[[1]][1])))
  }
}

run_kegg <- function(genes_symbol, ori_ty = 'SYMBOL', species = "hsa") {
  
  OrgDb <- if (species == "hsa") org.Hs.eg.db else org.Mm.eg.db
  
  gene_df <- bitr(genes_symbol,
                  fromType = ori_ty,
                  toType = "ENTREZID",
                  OrgDb = OrgDb)
  
  ekegg <- enrichKEGG(
    gene         = gene_df$ENTREZID,
    organism     = species,
    pvalueCutoff = 0.01
  )
  
  ekegg <- setReadable(ekegg, OrgDb = OrgDb, keyType = "ENTREZID")
  
  return(ekegg)
}


root_fold_bulk<-paste0(root_fold, 'case_study_views/U2OS/bulk/')
all_INFy_proteins<-read_xlsx(paste0(root_fold_bulk, '41467_2024_52605_MOESM11_ESM.xlsx'), sheet = 'Sheet1')
uni_TNFy_protein<-unique(all_INFy_proteins$IFNy_database)

kegg_dt<-run_kegg(unique(all_INFy_proteins$IFNy_database))


dotplot(kegg_dt, showCategory = 30) +
  ggtitle("KEGG Pathway Enrichment")

kegg_dt_all<-kegg_dt@result
### best_fold is determined by the regression results by the python script
### 'Supplementary_codes/combination_selection.py'
raw_fold = root_fold_bulk

des_fold<-paste0(parent_fold, '/Case_studies/res/U2OS_bulk_DEA_res/')
best_fold<-'DDA_dlfq_top0_top3'
all_fold<-'DDA_dlfq_maxlfq_top0_top3_count'

dea_res_best<-read.table(paste0(des_fold, best_fold, '/DEA_res.csv'), sep = ',', header = T)
dea_res_svs<-read.table(paste0(des_fold, all_fold, '/DEA_res.csv'), sep = ',', header = T)

DEP_MCP_b<-get_entry('uniport', dea_res_best$Protein[which(dea_res_best$MVcontrast_label.2==1)])
val_MCP_b<-intersect(DEP_MCP_b, all_INFy_proteins$Entry)
cat('percent of validate rate of MCP:', length(val_MCP_b)/length(DEP_MCP_b))

kegg_MCP_b<-run_kegg(get_entry('gene', dea_res_best$Protein[which(dea_res_best$MVcontrast_label.2==1)]))
kegg_MCP_b_all<-kegg_MCP_b@result

length(intersect(kegg_dt_all$ID, kegg_MCP_b_all$ID))

DEP_dlfq_b<-get_entry('uniport', dea_res_svs$Protein[which(dea_res_svs$dlfq_label==1)])
val_dlfq_b<-intersect(DEP_dlfq_b, all_INFy_proteins$Entry)
cat('percent of validate rate of dlfq:', length(val_dlfq_b)/length(DEP_dlfq_b))

kegg_dlfq_b<-run_kegg(get_entry('gene', dea_res_svs$Protein[which(dea_res_svs$dlfq_label==1)]))
kegg_dlfq_b_all<-kegg_dlfq_b@result

length(intersect(kegg_dt_all$ID, kegg_dlfq_b_all$ID))

DEP_maxlfq_b<-get_entry('uniport', dea_res_svs$Protein[which(dea_res_svs$maxlfq_label==1)])
val_maxlfq_b<-intersect(DEP_maxlfq_b, all_INFy_proteins$Entry)
cat('percent of validate rate of maxlfq:', length(val_maxlfq_b)/length(DEP_maxlfq_b))

kegg_maxlfq_b<-run_kegg(get_entry('gene', dea_res_svs$Protein[which(dea_res_svs$maxlfq_label==1)]))
kegg_maxlfq_b_all<-kegg_maxlfq_b@result

length(intersect(kegg_dt_all$ID, kegg_maxlfq_b_all$ID))

DEP_top3_b<-get_entry('uniport', dea_res_svs$Protein[which(dea_res_svs$top3_label==1)])
val_top3_b<-intersect(DEP_top3_b, all_INFy_proteins$Entry)
cat('percent of validate rate of top3:', length(val_top3_b)/length(DEP_top3_b))

kegg_top3_b<-run_kegg(get_entry('gene', dea_res_svs$Protein[which(dea_res_svs$top3_label==1)]))
kegg_top3_b_all<-kegg_top3_b@result

length(intersect(kegg_dt_all$ID, kegg_top3_b_all$ID))

DEP_top0_b<-get_entry('uniport', dea_res_svs$Protein[which(dea_res_svs$top0_label==1)])
val_top0_b<-intersect(DEP_top0_b, all_INFy_proteins$Entry)
cat('percent of validate rate of top0:', length(val_top0_b)/length(DEP_top0_b))

kegg_top0_b<-run_kegg(get_entry('gene', dea_res_svs$Protein[which(dea_res_svs$top0_label==1)]))
kegg_top0_b_all<-kegg_top0_b@result

length(intersect(kegg_dt_all$ID, kegg_top0_b_all$ID))


DEP_count_b<-get_entry('uniport', dea_res_svs$Protein[which(dea_res_svs$count_label==1)])
val_count_b<-intersect(DEP_count_b, all_INFy_proteins$Entry)
cat('percent of validate rate of count:', length(val_count_b)/length(DEP_count_b))

kegg_count_b<-run_kegg(get_entry('gene', dea_res_svs$Protein[which(dea_res_svs$count_label==1)]))
kegg_count_b_all<-kegg_count_b@result

length(intersect(kegg_dt_all$ID, kegg_count_b_all$ID))



library(UpSetR)
library(dplyr)
library(tidyr)

list_DE <- list(
  MCP = DEP_MCP_b, 
  dlfq = DEP_dlfq_b, 
  maxlfq = DEP_maxlfq_b, 
  top0 = DEP_top0_b, 
  top3 = DEP_top3_b, 
  count = DEP_count_b
)
validated <- unique(all_INFy_proteins$Entry)
write.table(all_INFy_proteins, paste0(save_fold, 'Vlidated_INFy_proteins.csv'), sep = ',', col.names = T, row.names = T)

library(UpSetR)

UpSetR::upset(fromList(list_DE),
              sets = c('MCP','dlfq', 'maxlfq',
                       'top0', 'top3', 'count'
              ),
              order.by="freq", matrix.color="black", point.size=3,
              sets.bar.color=c("#b2df8a", "#33a02c", "#1f78b4", "lightblue", "#f078b4",
                               "#CD6155"
                               #'#FF1493'#,
                               #'#40E0D0'
              ),mb.ratio=c(0.6, 0.4), text.scale = 1.5,
              number.angles =0,
              keep.order = T,nintersects=20)

input_lists<-list_DE
all_items <- unique(unlist(input_lists))


binary_matrix <- matrix(
  0,
  nrow = length(all_items),
  ncol = length(input_lists),
  dimnames = list(all_items, names(input_lists)) 
)


for (i in seq_along(input_lists)) {
  current_list <- input_lists[[i]]
  binary_matrix[current_list, i] <- 1
}
print(binary_matrix)

validate_status<-c(rep('Not_in_database', length(binary_matrix[,1])))

validate_status[match(intersect(all_items, all_INFy_proteins$Entry), all_items)] = 'In_database'
write.table(data.frame(protein=all_items, Validation_Status=validate_status,binary_matrix), paste0(save_fold, 'DEPs_bulk_U2OS.csv'), col.names = T, row.names = T, sep = ',')


library(ggplot2)
library(dplyr)
library(tidyr)

list_DE <- list(MCP = DEP_MCP_b, dlfq=DEP_dlfq_b, maxlfq = DEP_maxlfq_b, 
                top0 = DEP_top0_b, top3 = DEP_top3_b, count=DEP_count_b)
validated <- unique(all_INFy_proteins$Entry)

plot_data <- lapply(names(list_DE), function(m) {
  deps <- list_DE[[m]]
  total <- length(deps)

  not_in_db_count <- total - sum(deps %in% validated)  

  in_db_count <- sum(deps %in% validated)  
  data.frame(
    Method = m,
    Type = c("not in database", "in database"),  
    Value = c(not_in_db_count, in_db_count), 
    Total = total
  )
}) %>% bind_rows() %>%
  group_by(Method) %>%
  arrange(Type) %>% 
  mutate(
    cum_value = cumsum(Value)  
  ) %>%
  ungroup()


plot_data$Type <- factor(plot_data$Type, levels = c("not in database", "in database"))

ggplot(plot_data, aes(x = Method, y = Value, fill = Type)) +
  geom_bar(stat = "identity", position = "stack", width = 0.6, color = "black") +

  geom_text(aes(label = Total, y = Total + 5), fontface = "bold", size = 4) +

  geom_text(
    aes(label = Value, y = cum_value - Value/2), 
    color = "black", fontface = "bold", size = 3.5
  ) +

  scale_fill_manual(values = c("not in database" = "grey80", "in database" = "#4575b4")) +
  theme_minimal(base_size = 14) +
  labs(y = "DEPs", x = "") +
  theme(
    legend.title = element_blank(),
    legend.position = c(0.05, 0.9), 
    legend.justification = c(0, 1),
    legend.background = element_rect(fill = "white", color = NA)
  )

write.table(plot_data, paste0(save_fold, 'DEPs_bulk_validation.csv'), sep = ',', col.names = T, row.names = T)
#### visualization of pathway enrichment on bulk
########################
library(ggplot2)
library(dplyr)
library(forcats)
library(ggtext)
library(scales)
p_threshold<-0.01

res_list<-list(MCP=kegg_MCP_b_all, dlfq=kegg_dlfq_b_all, maxlfq=kegg_maxlfq_b_all, 
               top0=kegg_top0_b_all, top3=kegg_top3_b_all, count=kegg_count_b_all)

df <- purrr::map_df(names(res_list), function(nm) {
  res_list[[nm]] %>% mutate(Group = nm)
})

if (!"ID" %in% colnames(df)) {
  stop("no 'ID' column")
}


df_filt <- df %>% filter(pvalue <= p_threshold)

if (nrow(df_filt) == 0) {
  stop("no pathway with p-value <= 0.05")
}
df_filt$Pathway = df_filt$ID 
df_filt$Validate = df_filt$Pathway %in% kegg_dt_all$ID[which(kegg_dt_all$pvalue < 0.05)]
### -----------------------------------------------
### 1. preparing the data
### -----------------------------------------------
df_plot <- df_filt %>%
  mutate(
    GeneRatio_num = purrr::map_dbl(GeneRatio, function(x){
      x <- gsub(" ", "", x)
      if(grepl("/", x)){
        v <- strsplit(x, "/")[[1]]
        return(as.numeric(v[1]) / as.numeric(v[2]))
      } else return(as.numeric(x))
    }),
    logP = -log10(pvalue)
  )

group_validate_ratio <- df_filt %>%
  group_by(Group) %>%
  summarize(
    total = n(),
    validate_count = sum(Validate),
    validate_ratio = validate_count / total
  ) %>%
  ungroup()

group_validate_ratio <- group_validate_ratio %>%
  mutate(
    label = paste0(Group, "\n(", scales::percent(validate_ratio, accuracy = 0.1), ")")
  )
new_x_labels <- group_validate_ratio$label
names(new_x_labels) <- group_validate_ratio$Group

desc_labels <- df_plot %>%
  group_by(Description) %>%
  summarise(Validate = any(Validate)) %>%
  ungroup() %>%
  mutate(
    label = ifelse(
      Validate,
      paste0("<b><span style='color:#C94F00;'>", Description, "</span></b>"),
      paste0("<span style='color:#222222;'>", Description, "</span>")
    )
  )

desc_lab <- setNames(desc_labels$label, desc_labels$Description)


df_plot <- df_plot %>%
  group_by(Description) %>%
  mutate(max_logP = max(logP)) %>%
  ungroup() %>%
  mutate(
    Description = fct_reorder(Description, max_logP, .desc = TRUE)
  )


### -----------------------------------------------
### 2. color
### -----------------------------------------------
# 
cold_color <- "#4A6FA5" 
hot_color  <- "#B02E34" 


### -----------------------------------------------
### 3. ggpubr + ggtext HTML
### -----------------------------------------------
p <- ggplot(df_plot, aes(
  x = Group,
  y = Description,
  color = logP,
  size  = GeneRatio_num
)) +
  geom_point(alpha = 0.85) +
  scale_color_gradient(
    low  = cold_color,
    high = hot_color,
    name = expression(-log[10](pvalue))
  ) +
  scale_size(
    range = c(2.5, 10),
    name = "Gene Ratio"
  ) +
  scale_x_discrete(labels = new_x_labels) +
  scale_y_discrete(labels = desc_lab) +
  guides(
    size = guide_legend(override.aes = list(alpha = 1)),
    color = guide_colorbar(barwidth = 1.2, barheight = 8)
  ) +
  labs(
    x = "",
    y = "",
    title = "Pathway Enrichment Comparison Across Quantification Methods"
  ) +
  
  ### ------------------------------
### 4. style
### ------------------------------
theme_bw(base_size = 14) +
  theme(
    plot.title      = element_text(face = "bold", hjust = 0.8, size = 13),
    panel.grid.minor = element_blank(),
    panel.grid.major = element_line(color = "grey92"),
    axis.text.x      = element_text(angle = 40, hjust = 1, vjust = 1, size = 12),
    axis.text.y      = element_markdown(size = 10, lineheight = 1.2),
    panel.border     = element_rect(color = "black", size = 0.8),
    legend.title     = element_text(size = 12, face = "bold"),
    legend.text      = element_text(size = 11),
    legend.key.width = unit(0.8, "cm"),
    plot.margin      = margin(10, 15, 10, 10)
  )

p
write.table(df_plot, paste0(save_fold, 'pathway_enrichment_bulk.csv'), sep = ',', col.names = T, row.names = T)
###############################################################################
########## 
##########single cell proteomics
##########
###############################################################################
u2os_fold<-paste0(parent_fold, '/Case_studies/res/U2OS_filtered_rb_DEA_res/')
best_fold<-'DIA_dlfq_maxlfq'
all_fold<-'DIA_dlfq_maxlfq_top3_top1'

dea_res_best<-read.table(paste0(u2os_fold, best_fold, '/DEA_res.csv'), sep = ',', header = T)
dea_res_svs<-read.table(paste0(u2os_fold, all_fold, '/DEA_res.csv'), sep = ',', header = T)

DEP_MCP_s<-dea_res_best$Protein[which(dea_res_best$MVcontrast_label.2==1)]
val_MCP_s<-intersect(DEP_MCP_s, all_INFy_proteins$Entry)
cat('percent of validate rate of MCP:', length(val_MCP_s)/length(DEP_MCP_s))

kegg_MCP_s<-run_kegg(DEP_MCP_s, ori_ty = 'UNIPROT')
kegg_MCP_s_all<-kegg_MCP_s@result

length(intersect(kegg_dt_all$ID, kegg_MCP_s_all$ID))

DEP_dlfq_s<-dea_res_svs$Protein[which(dea_res_svs$dlfq_label==1)]
val_dlfq_s<-intersect(DEP_dlfq_s, all_INFy_proteins$Entry)
cat('percent of validate rate of dlfq:', length(val_dlfq_s)/length(DEP_dlfq_s))

kegg_dlfq_s<-run_kegg(DEP_dlfq_s, ori_ty = 'UNIPROT')
kegg_dlfq_s_all<-kegg_dlfq_s@result

length(intersect(kegg_dt_all$ID, kegg_dlfq_s_all$ID))

DEP_maxlfq_s<-dea_res_svs$Protein[which(dea_res_svs$maxlfq_label==1)]
val_maxlfq_s<-intersect(DEP_maxlfq_s, all_INFy_proteins$Entry)
cat('percent of validate rate of maxlfq:', length(val_maxlfq_s)/length(DEP_maxlfq_s))

kegg_maxlfq_s<-run_kegg(DEP_maxlfq_s, ori_ty = 'UNIPROT')
kegg_maxlfq_s_all<-kegg_maxlfq_s@result

length(intersect(kegg_dt_all$ID, kegg_maxlfq_s_all$ID))

DEP_top3_s<-dea_res_svs$Protein[which(dea_res_svs$top3_label==1)]
val_top3_s<-intersect(DEP_top3_s, all_INFy_proteins$Entry)
cat('percent of validate rate of top3:', length(val_top3_s)/length(DEP_top3_s))

kegg_top3_s<-run_kegg(DEP_top3_s, ori_ty = 'UNIPROT')
kegg_top3_s_all<-kegg_top3_s@result

length(intersect(kegg_dt_all$ID, kegg_top3_s_all$ID))

DEP_top1_s<-dea_res_svs$Protein[which(dea_res_svs$top1_label==1)]
val_top1_s<-intersect(DEP_top1_s, all_INFy_proteins$Entry)
cat('percent of validate rate of top1:', length(val_top1_s)/length(DEP_top1_s))

kegg_top1_s<-run_kegg(DEP_top1_s, ori_ty = 'UNIPROT')
kegg_top1_s_all<-kegg_top1_s@result

length(intersect(kegg_dt_all$ID, kegg_top1_s_all$ID))

list_DE <- list(MCP = DEP_MCP_s, dlfq=DEP_dlfq_s, maxlfq = DEP_maxlfq_s, 
                top3 = DEP_top3_s, top1=DEP_top1_s)
validated <- unique(all_INFy_proteins$Entry)

input_lists<-list_DE
all_items <- unique(unlist(input_lists))


binary_matrix <- matrix(
  0,
  nrow = length(all_items),
  ncol = length(input_lists),
  dimnames = list(all_items, names(input_lists)) 
)


for (i in seq_along(input_lists)) {
  current_list <- input_lists[[i]]
  binary_matrix[current_list, i] <- 1
}
print(binary_matrix)

validate_status<-c(rep('Not_in_database', length(binary_matrix[,1])))

validate_status[match(intersect(all_items, all_INFy_proteins$Entry), all_items)] = 'In_database'
write.table(data.frame(protein=all_items, Validation_Status=validate_status,binary_matrix), paste0(save_fold, 'DEPs_scp_U2OS.csv'), col.names = T, row.names = T, sep = ',')


kegg_res_list <- list(
  MCP = kegg_MCP_s_all, 
  dlfq = kegg_dlfq_s_all, 
  maxlfq = kegg_maxlfq_s_all, 
  top3 = kegg_top3_s_all, 
  top1 = kegg_top1_s_all
)

if (!requireNamespace("BiocManager", quietly = TRUE)) install.packages("BiocManager")
if (!requireNamespace("biomaRt", quietly = TRUE)) BiocManager::install("biomaRt")
if (!requireNamespace("UpSetR", quietly = TRUE)) {
  suppressWarnings(install.packages("UpSetR", dependencies = TRUE))
}
if (!requireNamespace("networkD3", quietly = TRUE)) {
  suppressWarnings(install.packages("networkD3", dependencies = TRUE))
}
if (!requireNamespace("htmlwidgets", quietly = TRUE)) {
  suppressWarnings(install.packages("htmlwidgets", dependencies = TRUE))
}

if (!requireNamespace("ggtext", quietly = TRUE)) {
  suppressWarnings(install.packages("ggtext", dependencies = TRUE))
}

if (!requireNamespace("ggplot2", quietly = TRUE)) {
  suppressWarnings(install.packages("ggplot2", dependencies = TRUE))
}

library(biomaRt)
library(UpSetR)
library(networkD3)
library(htmlwidgets)
library(ggplot2)
library(ggtext)

#pvalue<=0.01）
p_threshold <- 0.01
############################################################
# UniProt ID to Gene Symbol
############################################################
uniprot_to_genesymbol <- function(uniprot_ids, taxId = 9606) {
  if (length(uniprot_ids) == 0) return(character(0))
  
  uniprot_unique <- unique(uniprot_ids)
  
  mart <- tryCatch({
    if (taxId == 9606) { 
      useMart("ensembl", dataset = "hsapiens_gene_ensembl")
    } else if (taxId == 10090) {
      useMart("ensembl", dataset = "mmusculus_gene_ensembl")
    } else if (taxId == 10116) {
      useMart("ensembl", dataset = "rnorvegicus_gene_ensembl")
    } else if (taxId == 7227) {
      useMart("ensembl", dataset = "dmelanogaster_gene_ensembl")
    } else if (taxId == 4932) {
      useMart("ensembl", dataset = "scerevisiae_gene_ensembl")
    } else {
      datasets <- listDatasets(useMart("ensembl"))
      dataset <- datasets[grep(paste0("^", taxId, "$"), datasets$taxonomy_id), "dataset"]
      if (length(dataset) == 0) stop("no Ensembl found")
      useMart("ensembl", dataset = dataset)
    }
  }, error = function(e) {

    tryCatch({
      useMart("ensembl", dataset = ifelse(taxId == 9606, "hsapiens_gene_ensembl",
                                          ifelse(taxId == 10090, "mmusculus_gene_ensembl",
                                                 "rnorvegicus_gene_ensembl")),
              host = "uswest.ensembl.org") 
    }, error = function(e2) {
      stop(paste("cannnot connect to Ensembl：", e2$message, "\n please check your network"))
    })
  })
  
  # UniProt ID (Swiss-Prot) → Gene Symbol
  # mapping：uniprotswissprot → hgnc_symbol
  symbol_attr <- if (taxId == 9606) {
    "hgnc_symbol"
  } else if (taxId == 10090) {
    "mgi_symbol"
  } else if (taxId == 10116) {
    "rgd_symbol"
  } else {
    "external_gene_name"
  }
  
  conversion <- getBM(
    attributes = c("uniprotswissprot", symbol_attr),
    filters = "uniprotswissprot",
    values = uniprot_unique, 
    mart = mart,
    useCache = FALSE
  )
  
  conversion <- conversion[conversion[[symbol_attr]] != "", ]
  conversion <- conversion[!duplicated(conversion$uniprotswissprot), ]
  
  # UniProt ID → Gene Symbol
  convert_dict <- setNames(conversion[[symbol_attr]], conversion$uniprotswissprot)
  
  gene_symbols <- ifelse(uniprot_ids %in% names(convert_dict),
                         convert_dict[uniprot_ids],
                         uniprot_ids)
  
  failed_ids <- uniprot_ids[!uniprot_ids %in% names(convert_dict)]
  if (length(failed_ids) > 0) {
    warning(paste("The following UniProt ID cannot be mapped to Gene Symbol：",
                  paste(unique(failed_ids)[1:20], collapse = ", "),
                  ifelse(length(failed_ids) > 20, paste(", total", length(failed_ids), "个"), "")))
  }
  
  return(gene_symbols)
}

############################################################
# pvalue checking
############################################################
required_objects <- c("list_DE", "validated", "kegg_res_list")
missing <- required_objects[!sapply(required_objects, exists)]

if (length(missing) > 0) {
  stop(paste("global environment lack of：", paste(missing, collapse = ", ")))
}

if (!is.list(list_DE) || !all(sapply(list_DE, is.character))) {
  stop("list_DE must be a list")
}

list_DE <- list_DE[sapply(list_DE, length) > 0]
if (length(list_DE) == 0) {
  stop("all lists are null")
}
methods <- names(list_DE)


required_kegg_cols <- c("Description", "pvalue", "p.adjust", "Count", "geneID")
if (!is.list(kegg_res_list) || !all(sapply(kegg_res_list, is.data.frame))) {
  stop("kegg_res_list must be a list")
}
kegg_valid <- sapply(kegg_res_list, function(df) {
  all(required_kegg_cols %in% colnames(df))
})
if (!all(kegg_valid)) {
  stop(paste("the KEGG results without p-values", 
             paste(names(kegg_res_list)[!kegg_valid], collapse = ", "),
             "\n required column", paste(required_kegg_cols, collapse = ", ")))
}


kegg_res_list <- lapply(kegg_res_list, function(df) {
  df[df$pvalue <= p_threshold, ]
})

kegg_res_list <- kegg_res_list[sapply(kegg_res_list, function(df) nrow(df) > 0)]
if (length(kegg_res_list) == 0) {
  warning("no KEGG pathway with pvalue ≤ 0.01 skip")
}

# validated must be string vector
if (!is.character(validated)) {
  stop("validated must be UniProt ID vector")
}
if (length(validated) == 0) {
  warning("validated is null, skip")
}

############################################################
# UniProt ID → Gene Symbol
############################################################

library(AnnotationDbi)
library(org.Hs.eg.db)

uniprot_to_genesymbol_orgdb <- function(ids) {
  res <- mapIds(
    org.Hs.eg.db,
    keys = ids,
    column = "SYMBOL",
    keytype = "UNIPROT",
    multiVals = "first"
  )
  unname(na.omit(res))
}

list_DE_genesymbol <- lapply(list_DE, uniprot_to_genesymbol_orgdb)

names(list_DE_genesymbol) <- names(list_DE)

validated_genesymbol <- uniprot_to_genesymbol_orgdb(validated)


list_DE <- list_DE_genesymbol
validated <- validated_genesymbol


############################################################


if (length(kegg_res_list) > 0) {
  ##########################################
  # 1. preparing data
  ##########################################
  all_pathways <- unique(unlist(lapply(kegg_res_list, function(df) as.character(df$Description))))
  validated_genes <- unique(validated[validated != ""])
  
  orange_pathways <- c()
  for (m in names(kegg_res_list)) {
    df <- kegg_res_list[[m]]
    for (i in seq_len(nrow(df))) {
      pw <- as.character(df$Description[i])
      pw_genes <- strsplit(as.character(df$geneID[i]), "/")[[1]]
      if (any(pw_genes %in% validated_genes)) {
        orange_pathways <- unique(c(orange_pathways, pw))
      }
    }
  }
  
  heatmap_data <- expand.grid(
    Method = methods,
    Pathway = all_pathways,
    stringsAsFactors = FALSE
  )
  heatmap_data$NegLogPadj <- 0
  heatmap_data$Genes <- ""
  
  for (m in methods) {
    if (!m %in% names(kegg_res_list)) next
    df <- kegg_res_list[[m]]
    for (i in seq_len(nrow(df))) {
      pw <- as.character(df$Description[i])
      padj <- df$p.adjust[i]
      neg_log_p <- ifelse(padj == 0, max(-log10(df$p.adjust[df$p.adjust > 0]), na.rm = TRUE), -log10(padj))
      pw_genes <- unique(strsplit(as.character(df$geneID[i]), "/")[[1]])
      
      row_idx <- which(heatmap_data$Method == m & heatmap_data$Pathway == pw)
      heatmap_data$NegLogPadj[row_idx] <- neg_log_p
      heatmap_data$Genes[row_idx] <- paste(pw_genes, collapse = "; ")
    }
  }
  
  heatmap_data$FormattedGenes <- sapply(heatmap_data$Genes, function(gene_str) {
    if (gene_str == "") return("")
    genes <- strsplit(gene_str, "; ")[[1]]
    if (length(genes) %% 2 == 0) {
      gene_groups <- split(genes, rep(1:(length(genes)/2), each = 2))
    } else {
      gene_groups <- split(genes, c(rep(1:floor(length(genes)/2), each = 2), length(genes)))
    }
    gene_lines <- sapply(gene_groups, function(g) paste(g, collapse = "; "))
    formatted_lines <- sapply(gene_lines, function(line) {
      genes_in_line <- strsplit(line, "; ")[[1]]
      formatted_genes <- sapply(genes_in_line, function(g) {
        if (g %in% validated_genes) {
          paste0("<span style='color:#6a3d9a; font-weight:bold; font-size:7pt'>", g, "</span>")
        } else {
          paste0("<span style='font-size:7pt'>", g, "</span>")
        }
      })
      paste(formatted_genes, collapse = "; ")
    })
    paste(formatted_lines, collapse = "<br>")
  })
  
  ##########################################
  # 3. Nature style
  ##########################################
  pathway_color_map <- setNames(
    ifelse(all_pathways %in% orange_pathways, "#E64B35", "#333333"),
    all_pathways
  )
  ordered_pathways <- levels(reorder(heatmap_data$Pathway, heatmap_data$NegLogPadj, FUN = max))
  pathway_colors <- pathway_color_map[ordered_pathways]
  nature_palette <- colorRampPalette(c("#F5F5F5", "#66a61e"))(100)
  
  ##########################################
  # 4. heatmap
  ##########################################
  p_nature <- ggplot(
    heatmap_data,
    aes(x = Method, y = reorder(Pathway, NegLogPadj, FUN = max))
  ) +
    geom_tile(aes(fill = NegLogPadj), color = "white", size = 0.3, width = 1) +
    scale_x_discrete(expand = c(0, 0)) + 
    scale_y_discrete(expand = c(0, 0)) + 
    scale_fill_gradientn(
      colors = nature_palette,
      name = "-log10(P-adjust)",
      limits = c(0, max(heatmap_data$NegLogPadj, na.rm = TRUE)),
      labels = scales::number_format(accuracy = 0.1)
    ) +
    geom_richtext(
      aes(label = FormattedGenes),
      fill = NA, label.color = NA,
      lineheight = 0.6,
      hjust = 0.5, vjust = 0.5,
      size = 2.0
    ) +
    labs(
      x = NULL,
      y = NULL,
      title = "KEGG pathway enrichment analysis",
      subtitle = paste0("Significance: p ≤ ", p_threshold, " | <span style='color:#E64B35'>Orange pathways</span>: Validated genes enriched | <span style='color:#6a3d9a'>Purple genes</span>: Validated genes")
    ) +
    theme_classic() +
    theme(

      plot.margin = margin(8, 10, 15, 40),
      
      axis.text.y = element_text(
        color = pathway_colors, 
        size = 10, 
        hjust = 0.95,
        family = "Arial", 
        face = ifelse(ordered_pathways %in% orange_pathways, "bold", "plain"),
        margin = margin(r = 5)
      ),
      
      axis.text.x = element_text(
        angle = 0, 
        hjust = 1, 
        size = 8,
        color = "#333333", 
        family = "Arial",
        margin = margin(t = 5)
      ),
      
      legend.title = element_text(size = 7, family = "Arial", color = "#333333"),
      legend.text = element_text(size = 6, family = "Arial", color = "#333333"),
      legend.key.height = unit(1.2, "cm"),
      legend.key.width = unit(0.3, "cm"),
      legend.position = "right",
      legend.box.spacing = unit(5, "pt"),
      
      plot.title = element_text(
        hjust = 0.5, size = 11, face = "plain",
        margin = margin(b = 8), family = "Arial"
      ),
      plot.subtitle = element_markdown(
        hjust = 0.8, size = 9, color = "#555555",
        margin = margin(b = 10), family = "Arial"
      ),
      axis.title = element_text(
        size = 9, color = "#333333", face = "plain",
        family = "Arial"
      ),
      panel.grid = element_blank(),
      axis.line = element_line(color = "#333333", linewidth = 0.3)
    )
  
  ##########################################
  # 5. save picture
  ##########################################

  plot_width <- max(8, length(methods) * 1.6) 
  Cairo::CairoPDF(
    "02_KEGG_Nature_Style_Heatmap_p0.01.pdf",
    width = plot_width,
    height = 1.0 * length(ordered_pathways),
    family = "Arial",
    dpi = 600
  )
  print(p_nature)
  dev.off()
  
  p_nature
}

write.table(heatmap_data, paste0(save_fold, 'SCP_pathway_heatmap.csv'), sep = ',', col.names = T, row.names = T)
###### visualization of clustering of single cells

library(pheatmap)
library(VennDiagram)
library(ggplot2)
library(clusterProfiler)
library(org.Hs.eg.db)
library(SuperExactTest)
library(reshape2)
library(this.path)


script_path <- this.path()
script_dir <- dirname(script_path)
parent_fold<-dirname(script_dir)

root_fold<-paste0(parent_fold, '/data/')

save_fold<-paste0(script_dir, '/res/Fig5/')
if(!dir.exists(save_fold)){
  dir.create(save_fold, recursive = TRUE)
}


dt_name = 'U2OS_filtered_rb'
  
raw_fold_scp = paste0(root_fold,'case_study_views/U2OS/single_cell/U2OS_scp/U2OS_rb/')
sub_fold = 'U2OS_filtered_rb_DEA_res'
best_fold = 'DIA_dlfq_maxlfq'
all_fold = 'DIA_dlfq_maxlfq_top3_top1'

logthre = log2(1.5)
qthre = 0.05
dlfq_logT = 'F'
post = '.csv'
g1 = 'Control'
g2 = 'IFN-γ'

dea_fold<-

res_all<-read.table(paste0(DEA_res_fold, sub_fold, '/', all_fold, '/DEA_res.csv'), header = T, sep = ',')
res_all1<-read.table(paste0(DEA_res_fold, sub_fold, '/', best_fold,'/DEA_res.csv'), header = T, sep = ',')


list_to_matrix <- function(gene_sets) {

  all_genes <- unique(unlist(gene_sets))
  
  binary_mat <- matrix(0,
                       nrow = length(all_genes),
                       ncol = length(gene_sets),
                       dimnames = list(all_genes, names(gene_sets)))
  
  for(i in seq_along(gene_sets)) {
    binary_mat[rownames(binary_mat) %in% gene_sets[[i]], i] <- 1
  }
  
  return(binary_mat)
}



dlfq_deg <- subset(res_all, dlfq_qval <= qthre & abs(dlfq_logFC) >= logthre)
maxlfq_deg <- subset(res_all, maxlfq_qval <= qthre & abs(maxlfq_logFC) >= logthre)
top3_deg <- subset(res_all, top3_qval <= qthre & abs(top3_logFC) >= logthre)
top1_deg <- subset(res_all, top1_qval <= qthre & abs(top1_logFC) >= logthre)
DL_direct_deg <- subset(res_all1, MVcontrast_score.2 >= max(res_all1$MVcontrast_threshold.2) & abs(MVcontrast_logFC.2) >= logthre)

input=list(dlfq=dlfq_deg$Protein, top3=top3_deg$Protein, maxlfq=maxlfq_deg$Protein, top1 = top1_deg$Protein,
           MCP=DL_direct_deg$Protein)


library(UpSetR)

UpSetR::upset(fromList(input),
              sets = c('dlfq', 'maxlfq',
                       'top3', 'top1',
                       'MCP'
              ),
              order.by="freq", matrix.color="black", point.size=3,
              sets.bar.color=c("#b2df8a", "#33a02c", "#1f78b4", "lightblue", "#f078b4"
              ),mb.ratio=c(0.6, 0.4), text.scale = 1.5,
              number.angles =0,
              keep.order = T,nintersects=20)

input_lists<-input
all_items <- unique(unlist(input_lists))


binary_matrix <- matrix(
  0,
  nrow = length(all_items),
  ncol = length(input_lists),
  dimnames = list(all_items, names(input_lists)) 
)


for (i in seq_along(input_lists)) {
  current_list <- input_lists[[i]]
  binary_matrix[current_list, i] <- 1
}
print(binary_matrix)

validate_status<-c(rep('Not_in_database', length(binary_matrix[,1])))

validate_status[match(intersect(all_items, all_INFy_proteins$Entry), all_items)] = 'In_database'
write.table(data.frame(protein=all_items, Validation_Status=validate_status,binary_matrix), paste0(save_fold, 'DEPs_scp_U2OS_rb.csv'), col.names = T, row.names = T, sep = ',')


input_top3=list(dlfq=dlfq_deg$Protein, maxlfq=maxlfq_deg$Protein, 
                MCP=DL_direct_deg$Protein)
library(VennDiagram)
library(ggVennDiagram)
library("readxl")
library(ggplot2)
library(reshape2)
library(ggpubr)
library(cowplot)
set.seed(123)
nature_palette <- c("#b2df8a", "#33a02c", "#f078b4")

ggVennDiagram(
  input_top3,
  label_alpha = 0,   
  label = "count", 
  set_color = nature_palette 
) +
  scale_fill_gradient(low = "#FFFFFF", high = "#E64B35") + 
  theme_void(base_size = 14) +   
  theme(
    legend.position = "none",  
    plot.title = element_text(size = 16, face = "bold", hjust = 0.5)
  ) #+

clustering_fold<-paste0(parent_fold,'/Clustering/')
dlfq<-read.table(paste0(clustering_fold, dt_name, 'dlfq.csv'), sep = ',', header = T)
dlfq_view<-dlfq[,2:(length(dlfq[1,])-1)]
dlfq_lab<-dlfq[,length(dlfq[1,])]
dlfq_lab_chr<-c(rep(g1, length(dlfq_lab)))
dlfq_lab_chr[which(dlfq_lab==1)]=g2
dlfq_full<-read.table(paste0(clustering_fold, dt_name, 'dlfq_full.csv'), sep = ',', header = T)
dlfq_view_full<-dlfq_full[,2:(length(dlfq_full[1,])-1)]
dlfq_pro<-colnames(dlfq_view_full)
dlfq_pro<-gsub('\\.', '|', dlfq_pro)

maxlfq<-read.table(paste0(clustering_fold, dt_name, 'maxlfq.csv'), sep = ',', header = T)
maxlfq_view<-maxlfq[,2:(length(maxlfq[1,])-1)]
maxlfq_lab<-maxlfq[,length(maxlfq[1,])]
maxlfq_lab_chr<-c(rep(g1, length(maxlfq_lab)))
maxlfq_lab_chr[which(maxlfq_lab==1)]=g2
maxlfq_full<-read.table(paste0(clustering_fold, dt_name, 'maxlfq_full.csv'), sep = ',', header = T)
maxlfq_view_full<-maxlfq_full[,2:(length(maxlfq_full[1,])-1)]
maxlfq_pro<-colnames(maxlfq_view_full)
maxlfq_pro<-gsub('\\.', '|', maxlfq_pro)

top3<-read.table(paste0(clustering_fold, dt_name, 'top3.csv'), sep = ',', header = T)
top3_view<-top3[,2:(length(top3[1,])-1)]
top3_lab<-top3[,length(top3[1,])]
top3_lab_chr<-c(rep(g1, length(top3_lab)))
top3_lab_chr[which(top3_lab==1)]=g2
top3_full<-read.table(paste0(clustering_fold, dt_name, 'top3_full.csv'), sep = ',', header = T)
top3_view_full<-top3_full[,2:(length(top3_full[1,])-1)]
top3_pro<-colnames(top3_view_full)
top3_pro<-gsub('\\.', '|', top3_pro)

top1<-read.table(paste0(clustering_fold, dt_name, 'top1.csv'), sep = ',', header = T)
top1_view<-top1[,2:(length(top1[1,])-1)]
top1_lab<-top1[,length(top1[1,])]
top1_lab_chr<-c(rep(g1, length(top1_lab)))
top1_lab_chr[which(top1_lab==1)]=g2
top1_full<-read.table(paste0(clustering_fold, dt_name, 'top1_full.csv'), sep = ',', header = T)
top1_view_full<-top1_full[,2:(length(top1_full[1,])-1)]
top1_pro<-colnames(top1_view_full)
top1_pro<-gsub('\\.', '|', top1_pro)

MVDEA<-read.table(paste0(clustering_fold, dt_name, best_fold, 'mvdea.csv'), sep = ',', header = T)
MVDEA_view<-MVDEA[,2:(length(MVDEA[1,])-1)]
MVDEA_lab<-MVDEA[,length(MVDEA[1,])]
MVDEA_lab_chr<-c(rep(g1, length(MVDEA_lab)))
MVDEA_lab_chr[which(MVDEA_lab==1)]=g2

hurdle<-read.table(paste0(clustering_fold, dt_name, best_fold, 'hurdle.csv'), sep = ',', header = T)
hurdle_view<-hurdle[,2:(length(hurdle[1,])-1)]
hurdle_lab<-hurdle[,length(hurdle[1,])]
hurdle_lab_chr<-c(rep(g1, length(hurdle_lab)))
hurdle_lab_chr[which(hurdle_lab==1)]=g2


library(umap)
library(ggpubr)
library("gridExtra")

extract_legend <- function(my_ggp) {
  step1 <- ggplot_gtable(ggplot_build(my_ggp))
  step2 <- which(sapply(step1$grobs, function(x) x$name) == "guide-box")
  step3 <- step1$grobs[[step2]]
  return(step3)
}

clus_perform<-read.table(paste0(clustering_fold, dt_name, '_clustering_performance_fill0_', best_fold, '.csv'), sep = ',', header = T)[,1:4]

write.table(clus_perform, paste0(save_fold, 'U20S_clustering_performance.csv'), sep = ',', col.names = T, row.names = T)
plot_umap2 <- function(umap_result_optimized, cluster_label, method_name, clus_perform, show_legend = FALSE){
  
  library(ggplot2)
  library(dplyr)
  
  umap_df <- data.frame(
    UMAP1 = umap_result_optimized$layout[, 1],
    UMAP2 = umap_result_optimized$layout[, 2],
    cluster = as.factor(cluster_label)
  )
  

  hull_df <- umap_df %>%
    group_by(cluster) %>%
    filter(n() >= 3) %>%
    do({
      idx <- chull(.$UMAP1, .$UMAP2)
      .[c(idx, idx[1]), ]
    }) %>%
    ungroup()
  
  center_df <- umap_df %>% 
    group_by(cluster) %>% 
    summarise(UMAP1 = mean(UMAP1), UMAP2 = mean(UMAP2))
  
  ann_x <- min(umap_df$UMAP1) + 0.02 * diff(range(umap_df$UMAP1))
  ann_y <- max(umap_df$UMAP2) - 0.02 * diff(range(umap_df$UMAP2))
  
  annot_df <- subset(clus_perform, X == method_name)
  
  pup <- ggplot() +
    geom_point(data = umap_df, aes(UMAP1, UMAP2, color = cluster),
               size = 3, alpha = 0.8) +
    geom_polygon(data = hull_df,
                 aes(UMAP1, UMAP2, group = cluster, color = cluster),
                 fill = NA, linewidth = 1) +
    geom_point(data = center_df,
               aes(UMAP1, UMAP2, color = cluster),
               shape = 3, size = 4, stroke = 1.2) +
    
    labs(x = "UMAP1", y = "UMAP2") +
    
    theme_minimal(base_size = 12) +
    theme(
      axis.text = element_blank(),
      axis.ticks = element_blank(),
      legend.position = 'right',
      panel.grid = element_line(color = "grey90", size = 0.2)
    ) +
    
    scale_color_manual(values = c("#15d08a","#f2ca01"))+#"#E64B35FF", "#4DBBD5FF")) +
    
    annotate("label",
             x = ann_x, y = ann_y,
             label = sprintf("ARI = %.2f\nASW = %.2f\nNMI = %.2f",
                             annot_df$ARI, annot_df$ASW, annot_df$NMI),
             hjust = 0, vjust = 1,
             size = 4,
             fill = alpha("white", 0.25),
             label.size = 0,
             label.r = unit(0.15, "lines")
    )
  
  return(list(p = pup, dt = umap_df))
}

umap_dlfq<-umap(as.matrix(dlfq_view), min_dist = 0.05, random_state=2025)

umap_maxlfq<-umap(as.matrix(maxlfq_view), min_dist = 0.05, random_state=2025)

umap_top3<-umap(as.matrix(top3_view), min_dist = 0.05, random_state=2025)

umap_top1<-umap(as.matrix(top1_view), min_dist = 0.05, random_state=2025)

umap_mvdea<-umap(as.matrix(MVDEA_view), min_dist = 0.05, random_state=2025)

umap_hurdle<-umap(as.matrix(hurdle_view), min_dist = 0.05, random_state=2025)

write.table(dlfq, paste0(save_fold, 'cell_representation_dlfq.csv'), sep = ',', col.names = T, row.names = T)
write.table(maxlfq, paste0(save_fold, 'cell_representation_maxlfq.csv'), sep = ',', col.names = T, row.names = T)
write.table(top3, paste0(save_fold, 'cell_representation_top3.csv'), sep = ',', col.names = T, row.names = T)
write.table(top1, paste0(save_fold, 'cell_representation_top1.csv'), sep = ',', col.names = T, row.names = T)
write.table(MVDEA, paste0(save_fold, 'cell_representation_MCP.csv'), sep = ',', col.names = T, row.names = T)

p_dlfq <- plot_umap2(umap_dlfq, as.character(dlfq_lab_chr), "dlfq", clus_perform)
p_maxlfq <- plot_umap2(umap_maxlfq, as.character(maxlfq_lab_chr), "maxlfq", clus_perform)
p_top3   <- plot_umap2(umap_top3,  as.character(top3_lab_chr),  "top3",  clus_perform)
p_top1   <- plot_umap2(umap_top1,  as.character(top1_lab_chr),  "top1",  clus_perform)
p_mvdea  <- plot_umap2(umap_mvdea, as.character(MVDEA_lab_chr), "MVDEA", clus_perform)
p_hurdle <- plot_umap2(umap_hurdle,as.character(hurdle_lab_chr),"hurdle",clus_perform)

write.table(p_dlfq$dt, paste0(save_fold, 'umap_dlfq.csv'), sep = ',', col.names = T, row.names = T)
write.table(p_maxlfq$dt, paste0(save_fold, 'umap_maxlfq.csv'), sep = ',', col.names = T, row.names = T)
write.table(p_top3$dt, paste0(save_fold, 'umap_top3.csv'), sep = ',', col.names = T, row.names = T)
write.table(p_top1$dt, paste0(save_fold, 'umap_top1.csv'), sep = ',', col.names = T, row.names = T)
write.table(p_mvdea$dt, paste0(save_fold, 'umap_MCP.csv'), sep = ',', col.names = T, row.names = T)

shared_legend <- extract_legend(p_dlfq$p)
pall<-grid.arrange(
  p_dlfq$p+ggtitle('dlfq')+theme(legend.position = 'none',plot.title = element_text(hjust = 0.5), axis.title.x = element_blank()),
  p_maxlfq$p+ggtitle('maxlfq')+theme(legend.position = 'none', axis.title.y = element_blank(), axis.title.x = element_blank(),plot.title = element_text(hjust = 0.5)),
  p_top3$p+ggtitle('top3')+theme(legend.position = 'none', axis.title.x = element_blank(),plot.title = element_text(hjust = 0.5)),
  p_top1$p+ggtitle('top1')+theme(legend.position = 'none', axis.title.y = element_blank(), plot.title = element_text(hjust = 0.5)),
  p_mvdea$p+ggtitle('MCP')+theme(legend.position = 'none', plot.title = element_text(hjust = 0.5)),
  shared_legend,
  ncol=2,widths=c(1, 1))
