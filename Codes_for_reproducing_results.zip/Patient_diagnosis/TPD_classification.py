import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.model_selection import cross_val_score, ShuffleSplit, StratifiedShuffleSplit, StratifiedKFold
from xgboost import XGBClassifier, XGBClassifier
from sklearn.metrics import roc_auc_score
from cca_zoo.linear import GCCA
from sklearn import preprocessing
import optuna
import random
import os
from sklearn.metrics import accuracy_score as acc, recall_score as recall, precision_score as precision, f1_score as f1, matthews_corrcoef as mcc
import matplotlib.pyplot as plt
from sklearn.metrics import RocCurveDisplay, roc_curve
from sklearn.metrics import auc as Auc
from sklearn.neighbors import KNeighborsClassifier as KNN
import pickle
from sklearn.svm import SVC

def average_replicate(mat, design):

    uni_pat = np.unique(design['Patient_ID'].values)

    idx_avg = []
    avg_intens = np.zeros((len(mat.values[:, 0]), 0))
    for i in range(len(uni_pat)):
        pat = uni_pat[i]

        idx = np.where((design['Patient_ID'].values == pat))[0]+2
        idx_avg.append(idx[0]-2)

        mat_pat = mat.iloc[:, idx]

        inten = np.array(mat_pat.values, dtype='float')
        avg_inten = np.nanmean(inten, axis=1)
        avg_intens = np.column_stack((avg_intens, avg_inten))

    avg_mat = pd.DataFrame(np.column_stack((mat.values[:, 0:2], avg_intens)), columns=list(mat.columns.values[0:2]) + list(uni_pat))
    design_avg = design.iloc[idx_avg, :]
    return avg_mat, design_avg

def get_pro_list(matrix):
    pros = matrix['Protein'].values
    pros_id = []
    for i in range(len(pros)):
        pro = pros[i].split(';')
        pro_id = ''
        if len(pro) == 1:
            pro_id = pro[0].split('|')[1]
        elif len(pro) > 1:
            for j in range(len(pro)):
                id = pro[j].split('|')[1]
                if pro_id == '':
                    pro_id = id
                else:
                    pro_id += ';' + id

        pros_id.append(pro_id)
    return pros_id

def get_pro_inten_tr(pro_list, matrix, design, logT='F'):

    pros = matrix['Protein'].values
    pros_id = []
    for i in range(len(pros)):
        pro = pros[i].split(';')
        pro_id = ''
        if len(pro) == 1:
            pro_id = pro[0].split('|')[1]
        elif len(pro) > 1:
            for j in range(len(pro)):
                id = pro[j].split('|')[1]
                if pro_id == '':
                    pro_id = id
                else:
                    pro_id += ';' + id

        pros_id.append(pro_id)

    pros_id = np.array(pros_id)

    com, idx1, idx2 = np.intersect1d(np.array(pro_list), pros_id, return_indices= True)

    mat_all = np.array(matrix.values[:, 2:len(matrix.values[0, :])], dtype='float')
    #mat_pro = np.zeros((len(pro_list), len(mat_all[0, :])))
    #mat_pro[idx1, :] = mat_all[idx2, :]
    mat_pro = mat_all[idx2, :]
    out_mat = matrix.iloc[idx2]

    header = np.array(matrix.columns.values)[2:len(matrix.columns.values)]
    labels = []
    idxs = []
    non_find = []
    samples = []

    for i in range(len(header)):

        sample = (header[i].replace('C:\\Users\\10352\Desktop\\TPD_Discovery\\', '').replace('.mzML.dia', '')
                  .replace('.mzML', '').replace('.', '_').replace('-', '_').replace('batch', 'b').
                  replace('TPD_b', 'TPD_DIA_b').replace('(liu)','')).split('_')
        sample_name = ''
        for t in range(5):
            #print(sample)
            if sample_name == '':
                sample_name = sample[t]
            else:
                sample_name = sample_name + '_' + sample[t]
        idx = np.where((design['MS_file_name'].values == sample_name))[0]
        if len(idx) == 1:
            labels.append(design['Classificaiton_type'].values[idx[0]])
            idxs.append(idx[0])
            samples.append(design['MS_file_name'].values[idx[0]])

        else:

            non_find.append(header[i])
    #design_final = design.iloc[idxs]
    labels = np.array(labels)

    comm, idx11, idx12 = np.intersect1d(np.array(samples), design['MS_file_name'].values, return_indices=True)
    mat_pro = mat_pro[:, idx11]
    design_final = design.iloc[idx12]

    if logT == 'T':
        mat_pro[mat_pro == 0] = np.nan
        mat_pro = np.log2(mat_pro)

        out_mat_inten = np.array(out_mat.values[:, 2:len(out_mat.values[0, :])], dtype='float')
        out_mat_inten[out_mat_inten == 0] = np.nan
        out_mat_inten = np.log2(out_mat_inten)
        out_mat = pd.DataFrame(np.column_stack((out_mat.values[:, 0:2], out_mat_inten)),
                               columns=list(out_mat.columns.values))

    out_mat = out_mat.iloc[:, list([0, 1]) + list(idx11 + 2)]

    avg_mat, design_avg = average_replicate(out_mat, design_final)
    return mat_pro, out_mat, labels[idx11], design_final, avg_mat, design_avg

def get_pro_inten_te(pro_list, matrix, design, logT='F'):

    pros = matrix['Protein'].values
    pros_id = []
    for i in range(len(pros)):
        pro = pros[i].split(';')
        pro_id = ''
        if len(pro) == 1:
            pro_id = pro[0].split('|')[1]
        elif len(pro) > 1:
            for j in range(len(pro)):
                id = pro[j].split('|')[1]
                if pro_id == '':
                    pro_id = id
                else:
                    pro_id += ';' + id

        pros_id.append(pro_id)

    pros_id = np.array(pros_id)

    com, idx1, idx2 = np.intersect1d(np.array(pro_list), pros_id, return_indices= True)
    np.setdiff1d(np.array(pro_list), pros_id)
    mat_all = np.array(matrix.values[:, 2:len(matrix.values[0, :])], dtype='float')
    # mat_pro = np.zeros((len(pro_list), len(mat_all[0, :])))
    # mat_pro[idx1, :] = mat_all[idx2, :]
    mat_pro = mat_all[idx2, :]
    out_mat = matrix.iloc[idx2]

    header = np.array(matrix.columns.values)[2:len(matrix.columns.values)]
    labels = []
    idxs = []
    non_find = []
    samples = []

    for i in range(len(header)):

        sample = (header[i].replace('D:\\', '').replace('.mzML.dia', '')
                  .replace('.mzML', '').replace('.', '_').replace('-', '_'))

        idx = np.where((design['MS_file_name'].values == sample))[0]
        if len(idx) == 1:
            labels.append(design['Classificaiton_type'].values[idx[0]])
            idxs.append(idx[0])
            samples.append(design['MS_file_name'].values[idx[0]])

        else:

            non_find.append(header[i])
    #design_final = design.iloc[idxs]
    labels = np.array(labels)

    comm, idx11, idx12 = np.intersect1d(np.array(samples), design['MS_file_name'].values, return_indices=True)
    mat_pro = mat_pro[:, idx11]
    design_final = design.iloc[idx12]


    if logT == 'T':
        mat_pro[mat_pro==0] = np.nan
        mat_pro = np.log2(mat_pro)

        out_mat_inten = np.array(out_mat.values[:, 2:len(out_mat.values[0, :])], dtype='float')
        out_mat_inten[out_mat_inten==0] = np.nan
        out_mat_inten = np.log2(out_mat_inten)
        out_mat = pd.DataFrame(np.column_stack((out_mat.values[:, 0:2], out_mat_inten)), columns=list(out_mat.columns.values))

    out_mat = out_mat.iloc[:, list([0, 1]) + list(idx11 + 2)]

    avg_mat, design_avg = average_replicate(out_mat, design_final)
    return mat_pro, out_mat, labels[idx11], design_final, avg_mat, design_avg

def preprocess_multi_view(pro_list):

    folder = 'data/'

    dlfq_tr_pth = folder + 'discovery/dlfq.tsv'
    maxlfq_tr_pth = folder + 'discovery/maxlfq.tsv'
    top3_tr_pth = folder + 'discovery/top3.tsv'

    dlfq_te_pth = folder + 'retrospective/dlfq.tsv'
    maxlfq_te_pth = folder + 'retrospective/maxlfq.tsv'
    top3_te_pth = folder + 'retrospective/top3.tsv'

    dlfq_te_pth = folder + 'retrospective/dlfq.tsv'
    maxlfq_te_pth = folder + 'retrospective/maxlfq.tsv'
    top3_te_pth = folder + 'retrospective/top3.tsv'

    design_tr_pth = folder + 'TPD_diann_protMatrix_20230207_lab_dis.csv'
    design_te_pth = folder + 'TPD_diann_protMatrix_20230207_lab_ret.csv'

    maxlfq_tr = pd.read_csv(maxlfq_tr_pth, sep='\t', header=0)
    dlfq_tr = pd.read_csv(dlfq_tr_pth, sep='\t', header=0)
    top3_tr = pd.read_csv(top3_tr_pth, sep='\t', header=0)

    maxlfq_te = pd.read_csv(maxlfq_te_pth, sep='\t', header=0)
    dlfq_te = pd.read_csv(dlfq_te_pth, sep='\t', header=0)
    top3_te = pd.read_csv(top3_te_pth, sep='\t', header=0)

    design_tr = pd.read_csv(design_tr_pth, sep=',', header=0)
    design_te = pd.read_csv(design_te_pth, sep=',', header=0)

    # pros_tr_maxlfq = get_pro_list(maxlfq_tr)
    # pros_tr_dlfq = get_pro_list(dlfq_tr)
    # pros_tr_top3 = get_pro_list(top3_tr)
    #
    # pros_te_maxlfq = get_pro_list(maxlfq_te)
    # pros_te_dlfq = get_pro_list(dlfq_te)
    # pros_te_top3 = get_pro_list(top3_te)

    pro_maxlfq_tr, mat_maxlfq_tr, labels_maxlfq_tr, design_maxlfq_tr, avg_mat_maxlfq_tr, avg_design_maxlfq_tr = get_pro_inten_tr(pro_list, maxlfq_tr, design_tr)
    # avg_mat_maxlfq_tr.to_csv(folder + 'avg_maxlfq_dis.csv')
    # avg_design_maxlfq_tr.to_csv(folder + 'avg_design_dis.csv')
    pro_dlfq_tr, mat_dlfq_tr, labels_dlfq_tr, design_dlfq_tr, avg_mat_dlfq_tr, avg_design_dlfq_tr = get_pro_inten_tr(pro_list, dlfq_tr, design_tr, logT='T')
    # avg_mat_dlfq_tr.to_csv(folder + 'avg_dlfq_dis.csv')
    pro_top3_tr, mat_top3_tr, labels_top3_tr, design_top3_tr, avg_mat_top3_tr, avg_design_top3_tr = get_pro_inten_tr(pro_list, top3_tr, design_tr)
    # avg_mat_top3_tr.to_csv(folder + 'avg_top3_dis.csv')

    pro_maxlfq_te, mat_maxlfq_te, labels_maxlfq_te, design_maxlfq_te, avg_mat_maxlfq_te, avg_design_maxlfq_te = get_pro_inten_te(pro_list, maxlfq_te, design_te)
    # avg_mat_maxlfq_te.to_csv(folder + 'avg_maxlfq_ret.csv')
    # avg_design_maxlfq_te.to_csv(folder + 'avg_design_te.csv')
    pro_dlfq_te, mat_dlfq_te, labels_dlfq_te, design_dlfq_te, avg_mat_dlfq_te, avg_design_dlfq_te = get_pro_inten_te(pro_list, dlfq_te, design_te, logT='T')
    # avg_mat_dlfq_te.to_csv(folder + 'avg_dlfq_ret.csv')
    pro_top3_te, mat_top3_te, labels_top3_te, design_top3_te, avg_mat_top3_te, avg_design_top3_te = get_pro_inten_te(pro_list, top3_te, design_te)
    # avg_mat_top3_te.to_csv(folder + 'avg_top3_ret.csv')

    tr_data = {'dlfq':{'data':avg_mat_dlfq_tr, 'design':avg_design_dlfq_tr},
                'maxlfq':{'data': avg_mat_maxlfq_tr, 'design':avg_design_maxlfq_tr},
                'top3':{'data': avg_mat_top3_tr, 'design':avg_design_top3_tr}}

    te_data = {'dlfq': {'data': avg_mat_dlfq_te, 'design': avg_design_dlfq_te},
                'maxlfq': {'data': avg_mat_maxlfq_te, 'design': avg_design_maxlfq_te},
                'top3': {'data': avg_mat_top3_te, 'design': avg_design_top3_te}}

    return tr_data, te_data

def xg_test_new(train_fea, test_fea, train_lab, test_lab, mean_fpr, ty='single'):
    if ty == 'mv':
        seed_torch(2024)

        kmcca = GCCA(latent_dimensions=30, random_state=2024)
        lat_out = kmcca.fit_transform(train_fea)
        lats_out = lat_out[0]
        for i in range(1, len(lat_out)):
            lats_out = np.column_stack((lats_out, lat_out[i]))

        lat_test = kmcca.transform(test_fea)
        lats_out_test = lat_test[0]
        for i in range(1, len(lat_test)):
            lats_out_test = np.column_stack((lats_out_test, lat_test[i]))

        train_fea = lats_out
        test_fea = lats_out_test

    #bst = XGBClassifier(objective='binary:logistic', scale_pos_weight=len(np.where((train_lab==0))[0]) / len(np.where((train_lab==1))[0]))
    bst = XGBClassifier(objective='binary:logistic', device='cuda', num_round=100)
    #bst = KNN()
    bst.fit(train_fea, train_lab)
    preds = bst.predict_proba(test_fea)
    pred_lab = bst.predict(test_fea)
    auc = roc_auc_score(test_lab[:, 0], preds[:, 1])


    fpr, tpr, thresholds = roc_curve(test_lab[:, 0], preds[:, 1], pos_label=1)

    interp_tpr = np.interp(mean_fpr, fpr, tpr)
    interp_tpr[0] = 0.0

    Acc = acc(test_lab[:, 0], pred_lab)
    Prec = precision(test_lab[:, 0], pred_lab)
    Rec = recall(test_lab[:, 0], pred_lab)
    F1 = f1(test_lab[:, 0], pred_lab)
    Mcc = mcc(test_lab[:, 0], pred_lab)

    return [auc, Acc, Prec, Rec, F1, Mcc], interp_tpr, auc, preds[:, 1], pred_lab

def xg_test_extend(train_fea, test_fea, train_lab, test_lab, mean_fpr, extend_true_lab, extend_score, extend_lab):

    bst = XGBClassifier(objective='binary:logistic')
    #bst = KNN()
    bst.fit(train_fea, train_lab)
    preds = bst.predict_proba(test_fea)
    pred_lab = bst.predict(test_fea)

    pred_prob = np.array(list(extend_score) + list(preds[:, 1]))
    pred_lab = np.array(list(extend_lab) + list(pred_lab))
    auc = roc_auc_score(np.array(list(extend_true_lab[:, 0]) + list(test_lab[:, 0])), pred_prob)

    fpr, tpr, thresholds = roc_curve(np.array(list(extend_true_lab[:, 0]) + list(test_lab[:, 0])), pred_prob, pos_label=1)

    interp_tpr = np.interp(mean_fpr, fpr, tpr)
    interp_tpr[0] = 0.0

    Acc = acc(np.array(list(extend_true_lab[:, 0]) + list(test_lab[:, 0])), pred_lab)
    Prec = precision(np.array(list(extend_true_lab[:, 0]) + list(test_lab[:, 0])), pred_lab)
    Rec = recall(np.array(list(extend_true_lab[:, 0]) + list(test_lab[:, 0])), pred_lab)
    F1 = f1(np.array(list(extend_true_lab[:, 0]) + list(test_lab[:, 0])), pred_lab)
    Mcc = mcc(np.array(list(extend_true_lab[:, 0]) + list(test_lab[:, 0])), pred_lab)

    return [auc, Acc, Prec, Rec, F1, Mcc], interp_tpr, auc, pred_prob, pred_lab

def xg_test_ens(train_fea, test_fea, train_lab, test_lab, mean_fpr):

    preds = []
    pred_labs = []
    for i in range(len(train_fea)):
        bst = XGBClassifier(objective='binary:logistic', device='cuda', num_round=100)
        #bst = KNN()
        bst.fit(train_fea[i], train_lab)
        pred = bst.predict_proba(test_fea[i])
        pred_lab = bst.predict(test_fea[i])
        preds.append(pred[:, 1])
        pred_labs.append(pred_lab)

    preds = np.mean(np.array(preds),axis=0)
    pred_labs = np.array(pred_labs).T

    pred_lab1 = np.array([1 if preds[j]>0.5 else 0 for j in range(len(preds))])
    pred_lab2 = np.array([1 if sum(pred_labs[j, :])>1 else 0 for j in range(len(pred_labs))])

    auc = roc_auc_score(test_lab[:, 0], preds)
    #mean_fpr = np.linspace(0, 1, 100)
    fpr, tpr, thresholds = roc_curve(test_lab[:, 0], preds, pos_label=1)

    interp_tpr = np.interp(mean_fpr, fpr, tpr)
    interp_tpr[0] = 0.0

    Acc1 = acc(test_lab[:, 0], pred_lab1)
    Prec1 = precision(test_lab[:, 0], pred_lab1)
    Rec1 = recall(test_lab[:, 0], pred_lab1)
    F11 = f1(test_lab[:, 0], pred_lab1)
    Mcc1 = mcc(test_lab[:, 0], pred_lab1)

    Acc2 = acc(test_lab[:, 0], pred_lab2)
    Prec2 = precision(test_lab[:, 0], pred_lab2)
    Rec2 = recall(test_lab[:, 0], pred_lab2)
    F12 = f1(test_lab[:, 0], pred_lab2)
    Mcc2 = mcc(test_lab[:, 0], pred_lab2)

    return [auc, Acc1, Prec1, Rec1, F11, Mcc1, auc, Acc2, Prec2, Rec2, F12, Mcc2], interp_tpr, auc

def get_data_lab(dict, view):

    data_dis_dlfq = np.array(dict[view]['data'].values[:, 2:len(dict[view]['data'].values[0, :])].T, dtype='float')
    lab_dis_dlfq = np.zeros((len(data_dis_dlfq[:, 0]), 1))
    lab_dis_dlfq[np.where((dict[view]['design']['Classificaiton_type'].values == 'B'))[0]] = 1
    lab_dis_dlfq = lab_dis_dlfq
    return data_dis_dlfq, lab_dis_dlfq

def Fill_nan(data, fill_value):

    data[np.isnan(data)] = fill_value
    return data

def cv_model(train_feas, train_lab, seed, param, model='XGB'):
    seed_torch(seed)
    rs = StratifiedKFold(n_splits=5, shuffle=True,  random_state=2024)
    aucs = []
    Mccs = []
    f1s = []
    accs = []
    bsts = []
    for i, (train_index, test_index) in enumerate(rs.split(train_feas, train_lab)):
        train = train_feas[train_index, :]
        test = train_feas[test_index, :]

        train_y = train_lab[train_index]
        test_y = train_lab[test_index]

        if model == 'XGB':
            bst = XGBClassifier(n_estimators=param['num'], max_depth=param['d'], learning_rate=param['lr'], objective='binary:logistic')
        elif model == 'svm':
            bst = SVC(C=param['C'], gamma=param['g'], probability=True)
        # fit model
        bst.fit(train, train_y)
        # make predictions
        preds = bst.predict_proba(test)
        pred_lab = bst.predict(test)
        Mcc = mcc(test_y[:, 0], pred_lab)
        auc = roc_auc_score(test_y[:, 0], preds[:, 1])
        Mccs.append(Mcc)
        aucs.append(auc)
        f1_ = f1(test_y[:, 0], pred_lab)
        f1s.append(f1_)
        ac = acc(test_y[:, 0], pred_lab)
        accs.append(ac)
        bsts.append(bst)
    return np.mean(aucs), np.mean(Mccs), np.mean(f1s), np.mean(accs)


def cv_model_mv(train_feas, train_lab, test_feas, test_lab, seed, param, model='XGB'):
    seed_torch(seed)

    kmcca = GCCA(latent_dimensions=param['N'], c=param['c'], random_state=2024)

    all_data = [np.row_stack((train_feas[i], test_feas[i])) for i in range(len(train_feas))]

    lat_out = kmcca.fit_transform(all_data)
    lats_out_mvidia_all = np.concatenate(lat_out, axis=1)
    lats_out_mvidia = lats_out_mvidia_all[0:len(train_lab), :]

    rs = StratifiedKFold(n_splits=5, shuffle=True,  random_state=2024)
    aucs = []
    Mccs = []
    f1s = []
    accs = []
    for i, (train_index, test_index) in enumerate(rs.split(train_feas[0], train_lab)):
        train = lats_out_mvidia[train_index, :]
        test = lats_out_mvidia[test_index, :]
        cat_train = np.concatenate(train_feas, axis=1)[train_index, :]
        cat_test = np.concatenate(train_feas, axis=1)[test_index, :]

        train_y = train_lab[train_index]
        test_y = train_lab[test_index]
        if model == 'mv-concat':
            bst = XGBClassifier(n_estimators=param['num'], max_depth=param['d'], learning_rate=param['lr'],
                                objective='binary:logistic')
            bst_concat = XGBClassifier(n_estimators=param['num_cat'], max_depth=param['d_cat'], learning_rate=param['lr_cat'],
                                objective='binary:logistic')
            bst_concat.fit(cat_train, train_y)
            bst.fit(train, train_y)
            # make predictions
            pred_mv = bst.predict_proba(test)
            pred_cat = bst_concat.predict_proba(cat_test)
            preds = (pred_mv + pred_cat)/2 #pred_mv * param['alpha'] + pred_cat * (1-param['alpha'])
            auc = roc_auc_score(test_y[:, 0], preds[:, 1])
            pred_lab = np.array([0] * len(preds))
            pred_lab[np.where((preds[:, 1] >= 0.5))[0]] = 1
            Mcc = mcc(test_y[:, 0], pred_lab)
            Mccs.append(Mcc)
            aucs.append(auc)
            f1_ = f1(test_y[:, 0], pred_lab)
            f1s.append(f1_)
            ac = acc(test_y[:, 0], pred_lab)
            accs.append(ac)
        elif model == 'mv+concat':
            bst = XGBClassifier(n_estimators=param['num'], max_depth=param['d'], learning_rate=param['lr'],
                                objective='binary:logistic')

            bst.fit(np.concatenate([train, cat_train],axis=1), train_y)
            preds = bst.predict_proba(np.concatenate([test, cat_test],axis=1))
            pred_lab = bst.predict(np.concatenate([test, cat_test],axis=1))
            Mcc = mcc(test_y[:, 0], pred_lab)
            auc = roc_auc_score(test_y[:, 0], preds[:, 1])
            Mccs.append(Mcc)
            aucs.append(auc)
            f1_ = f1(test_y[:, 0], pred_lab)
            f1s.append(f1_)
            ac = acc(test_y[:, 0], pred_lab)
            accs.append(ac)
        else:
            if model == 'XGB':
                bst = XGBClassifier(n_estimators=param['num'], max_depth=param['d'], learning_rate=param['lr'],
                                    objective='binary:logistic')

            elif model == 'svm':
                bst = SVC(C=param['C'], gamma=param['g'], probability=True)
            # fit model
            bst.fit(train, train_y)
            # make predictions
            preds = bst.predict_proba(test)

            pred_lab = bst.predict(test)
            Mcc = mcc(test_y[:, 0], pred_lab)
            auc = roc_auc_score(test_y[:, 0], preds[:, 1])
            Mccs.append(Mcc)
            aucs.append(auc)
            f1_ = f1(test_y[:, 0], pred_lab)
            f1s.append(f1_)
            ac = acc(test_y[:, 0], pred_lab)
            accs.append(ac)

    return np.mean(aucs), np.mean(Mccs), np.mean(f1s), np.mean(accs)

def cv_model_semi(train_feas, train_lab, test_feas, test_lab, seed, param, model='XGB'):
    seed_torch(seed)

    rs = StratifiedKFold(n_splits=5, shuffle=True,  random_state=2024)
    aucs = []
    Mccs = []
    f1s = []
    accs = []

    test_pesudo = np.array([[0] * len(test_lab)]).T
    test_data = [np.row_stack((train_feas[j], test_feas[j])) for j in range(len(train_feas))]
    test_label = np.row_stack((train_lab, test_pesudo))

    kmcca = GCCA(latent_dimensions=param['N'], c=param['c'], random_state=2024)
    lat_out = kmcca.fit_transform(test_data)
    lats_out_tr = lat_out[0]
    for i in range(1, len(lat_out)):
        lats_out_tr = np.column_stack((lats_out_tr, lat_out[i]))

    for i, (train_index, test_index) in enumerate(rs.split(lats_out_tr, test_label)):
        train = lats_out_tr[train_index, :]
        test = lats_out_tr[test_index, :]

        train_y = test_label[train_index]
        test_y = test_label[test_index]

        if model == 'XGB':
            bst = XGBClassifier(n_estimators=param['num'], max_depth=param['d'], learning_rate=param['lr'],
                                objective='binary:logistic')
        elif model == 'svm':
            bst = SVC(C=param['C'], gamma=param['g'], probability=True)
        # fit model
        bst.fit(train, train_y)
        # make predictions
        preds = bst.predict_proba(test)

        pred_lab = bst.predict(test)
        Mcc = mcc(test_y[:, 0], pred_lab)
        auc = roc_auc_score(test_y[:, 0], preds[:, 1])
        Mccs.append(Mcc)
        aucs.append(auc)
        f1_ = f1(test_y[:, 0], pred_lab)
        f1s.append(f1_)
        ac = acc(test_y[:, 0], pred_lab)
        accs.append(ac)

    return np.mean(aucs), np.mean(Mccs), np.mean(f1s), np.mean(accs)

def cv_model_mvidia(test_fea_single, train_fea_single, train_feas, train_lab, test_feas, test_lab, seed, param, bsts, model='XGB'):
    seed_torch(seed)

    preds = []
    pred_labs = []

    for i in range(len(train_feas)):

        pred = bsts[i].predict_proba(np.row_stack((train_fea_single[i], test_fea_single[i])))
        pred_lab = bsts[i].predict(np.row_stack((train_fea_single[i], test_fea_single[i])))
        preds.append(pred[:, 1])
        pred_labs.append(pred_lab)

    sum_lab = np.sum(pred_labs, axis=0)
    ind_reliable = np.where(((sum_lab == 0) | (sum_lab == len(train_feas))))[0]

    train_fea_reliable = [np.row_stack((train_feas[j], test_feas[j]))[ind_reliable, :] for j in range(len(train_feas))]
    train_lab_reliable = np.array([pred_labs[0][ind_reliable]]).T
    acc0 = acc(np.row_stack((train_lab, test_lab))[ind_reliable, 0], pred_labs[0][ind_reliable])
    if (model == 'mvidia') | (model == 'mv-concat') | (model == 'mv+concat'):
        kmcca = GCCA(latent_dimensions=param['N'], c=param['c'], random_state=2024)
        # fea_all = [np.row_stack((train_fea_single[i], test_fea_single[i])) for i in range(len(train_fea_single))]
        fea_all = [np.row_stack((train_feas[i], test_feas[i])) for i in range(len(train_feas))]
        lat_out = kmcca.fit_transform(fea_all)
        lats_out_all = np.concatenate(lat_out, axis=1)
        lats_out_tr = lats_out_all[ind_reliable, :]

    elif model == 'concat':
        lats_out_tr = np.concatenate(train_fea_reliable, axis=1)
    elif model == 'ens':
        lats_out_tr = train_fea_reliable

    Mccs = []
    aucs = []
    f1s = []
    accs = []
    rs = StratifiedKFold(n_splits=5, shuffle=True, random_state=2024)
    if model != 'ens':
        for i, (train_index, test_index) in enumerate(rs.split(lats_out_tr, train_lab_reliable)):
            train = lats_out_tr[train_index, :]
            test = lats_out_tr[test_index, :]

            cat_train = np.concatenate(train_fea_reliable, axis=1)[train_index, :]
            cat_test = np.concatenate(train_fea_reliable, axis=1)[test_index, :]

            train_y = train_lab_reliable[train_index]
            test_y = train_lab_reliable[test_index]

            if model == 'mv-concat':
                bst = XGBClassifier(n_estimators=param['num'], max_depth=param['d'], learning_rate=param['lr'],
                                    objective='binary:logistic')
                bst.fit(train, train_y)
                preds_mv = bst.predict_proba(test)

                bst_cat = XGBClassifier(n_estimators=param['num_cat'], max_depth=param['d_cat'], learning_rate=param['lr_cat'],
                                    objective='binary:logistic')
                bst_cat.fit(cat_train, train_y)
                preds_cat = bst_cat.predict_proba(cat_test)

                preds = (preds_mv + preds_cat)/2#preds_mv * param['alpha'] + preds_cat * (1-param['alpha'])
                pred_lab = np.array([0] * len(preds))
                pred_lab[np.where((preds[:, 1] >= 0.5))[0]] = 1
            elif model == 'mv+concat':
                bst = XGBClassifier(n_estimators=param['num'], max_depth=param['d'], learning_rate=param['lr'],
                                    objective='binary:logistic')
                bst.fit(np.concatenate([train, cat_train], axis=1), train_y)
                preds = bst.predict_proba(np.concatenate([test, cat_test], axis=1))
                pred_lab = bst.predict(np.concatenate([test, cat_test], axis=1))

            else:
                bst = XGBClassifier(n_estimators=param['num'], max_depth=param['d'], learning_rate=param['lr'],
                                    objective='binary:logistic')

                bst.fit(train, train_y)
                # make predictions
                preds = bst.predict_proba(test)
                pred_lab = bst.predict(test)
            Mcc = mcc(test_y[:, 0], pred_lab)
            auc = roc_auc_score(test_y[:, 0], preds[:, 1])
            Mccs.append(Mcc)
            aucs.append(auc)
            f1_ = f1(test_y[:, 0], pred_lab)
            f1s.append(f1_)
            ac = acc(test_y[:, 0], pred_lab)
            accs.append(ac)

    else:
        for i, (train_index, test_index) in enumerate(rs.split(lats_out_tr[0], train_lab_reliable)):
            train = [lats_out_tr[v][train_index, :] for v in range(len(lats_out_tr))]
            test = [lats_out_tr[v][test_index, :] for v in range(len(lats_out_tr))]

            train_y = train_lab_reliable[train_index]
            test_y = train_lab_reliable[test_index]

            bst = [XGBClassifier(n_estimators=param['num'+str(v)], max_depth=param['d'+str(v)], learning_rate=param['lr'+str(v)],
                                objective='binary:logistic') for v in range(len(bsts))]

            preds = []
            for v in range(len(bsts)):
                bst[v].fit(train[v], train_y)
                pred = bst[v].predict_proba(test[v])

                preds.append(pred[:, 1])
            preds = np.mean(preds, axis=0)

            pred_lab = np.array([0] * len(preds))
            pred_lab[np.where((preds >= 0.5))[0]] = 1

            Mcc = mcc(test_y[:, 0], pred_lab)
            auc = roc_auc_score(test_y[:, 0], preds)
            Mccs.append(Mcc)
            aucs.append(auc)
            f1_ = f1(test_y[:, 0], pred_lab)
            f1s.append(f1_)
            ac = acc(test_y[:, 0], pred_lab)
            accs.append(ac)

    return np.mean(aucs), np.mean(Mccs), np.mean(f1s), np.mean(accs)


def test_model(train_feas, train_lab, seed, test_feas, test_lab, param, model='XGB'):
    seed_torch(seed)

    if model == 'XGB':
        bst = XGBClassifier(n_estimators=param['num'], max_depth=param['d'], learning_rate=param['lr'],
                            objective='binary:logistic')
    elif model == 'svm':
        bst = SVC(C=2**param['C'], gamma=2**param['g'], probability=True)
    bst.fit(train_feas, train_lab)
    # make predictions
    preds = bst.predict_proba(test_feas)
    auc = roc_auc_score(test_lab[:, 0], preds[:, 1])

    pred_lab = bst.predict(test_feas)

    Acc = acc(test_lab[:, 0], pred_lab)
    Prec = precision(test_lab[:, 0], pred_lab)
    Rec = recall(test_lab[:, 0], pred_lab)
    F1 = f1(test_lab[:, 0], pred_lab)
    Mcc = mcc(test_lab[:, 0], pred_lab)

    return preds[:, 1], [auc, Acc, Prec, Rec, F1, Mcc], bst


def test_model_mv(train_feas, train_lab, seed, test_feas, test_lab, param, model='XGB'):
    seed_torch(seed)

    kmcca = GCCA(latent_dimensions=param['N'], c=param['c'], random_state=2024)
    all_data = [np.row_stack((train_feas[v], test_feas[v])) for v in range(len(train_feas))]
    lat_out = kmcca.fit_transform(all_data)
    lats_out_mvidia = np.concatenate(lat_out, axis=1)

    lats_out_mvidia_test = lats_out_mvidia[len(train_lab):len(lats_out_mvidia[:, 0]), :]
    lats_out_mvidia = lats_out_mvidia[0:len(train_lab), :]

    if model == 'mv-concat':
        bst = XGBClassifier(n_estimators=param['num'], max_depth=param['d'], learning_rate=param['lr'],
                            objective='binary:logistic')
        bst_concat = XGBClassifier(n_estimators=param['num_cat'], max_depth=param['d_cat'], learning_rate=param['lr_cat'],
                            objective='binary:logistic')

        bst.fit(lats_out_mvidia, train_lab)
        preds_mv = bst.predict_proba(lats_out_mvidia_test)

        bst_concat.fit(np.concatenate(train_feas, axis=1), train_lab)
        preds_cat = bst_concat.predict_proba(np.concatenate(test_feas, axis=1))

        preds = (preds_mv + preds_cat)/2#preds_mv * param['alpha'] + preds_cat * (1 - param['alpha'])
        pred_lab = np.array([0] * len(preds))
        pred_lab[np.where((preds[:, 1] >= 0.5))[0]] = 1

        bst = [bst, bst_concat]
    elif model == 'mv+concat':
        bst = XGBClassifier(n_estimators=param['num'], max_depth=param['d'], learning_rate=param['lr'],
                            objective='binary:logistic')
        bst.fit(np.concatenate([lats_out_mvidia, np.concatenate(train_feas, axis=1)], axis=1), train_lab)
        preds = bst.predict_proba(np.concatenate([lats_out_mvidia_test, np.concatenate(test_feas, axis=1)], axis=1))
        pred_lab = bst.predict(np.concatenate([lats_out_mvidia_test, np.concatenate(test_feas, axis=1)], axis=1))
    else:
        if model == 'XGB':
            bst = XGBClassifier(n_estimators=param['num'], max_depth=param['d'], learning_rate=param['lr'],
                                objective='binary:logistic')
        elif model == 'svm':
            bst = SVC(C=2**param['C'], gamma=2**param['g'], probability=True)
        bst.fit(lats_out_mvidia, train_lab)
        preds = bst.predict_proba(lats_out_mvidia_test)
        pred_lab = bst.predict(lats_out_mvidia_test)

    auc = roc_auc_score(test_lab[:, 0], preds[:, 1])
    Acc = acc(test_lab[:, 0], pred_lab)
    Prec = precision(test_lab[:, 0], pred_lab)
    Rec = recall(test_lab[:, 0], pred_lab)
    F1 = f1(test_lab[:, 0], pred_lab)
    Mcc = mcc(test_lab[:, 0], pred_lab)

    return preds[:, 1], [auc, Acc, Prec, Rec, F1, Mcc], lats_out_mvidia_test, bst

def test_model_semi(train_feas, train_lab, seed, test_feas, test_lab, param, model='XGB'):
    seed_torch(seed)
    seed_torch(seed)

    rs = StratifiedKFold(n_splits=5, shuffle=True, random_state=2024)
    # aucs = []
    # Mccs = []

    test_pesudo = np.array([[0] * len(test_lab)]).T
    test_data = [np.row_stack((train_feas[j], test_feas[j])) for j in range(len(train_feas))]
    test_label = np.row_stack((train_lab, test_pesudo))

    kmcca = GCCA(latent_dimensions=param['N'], c=param['c'], random_state=2024)
    lat_out = kmcca.fit_transform(test_data)
    lats_out_tr = lat_out[0]
    for i in range(1, len(lat_out)):
        lats_out_tr = np.column_stack((lats_out_tr, lat_out[i]))

    preds = []
    for i, (train_index, test_index) in enumerate(rs.split(lats_out_tr, test_label)):
        train = lats_out_tr[train_index, :]
        test = lats_out_tr[test_index, :]

        train_y = test_label[train_index]
        test_y = test_label[test_index]

        if model == 'XGB':
            bst = XGBClassifier(n_estimators=param['num'], max_depth=param['d'], learning_rate=param['lr'],
                                objective='binary:logistic')
        elif model == 'svm':
            bst = SVC(C=param['C'], gamma=param['g'], probability=True)
        # fit model
        bst.fit(train, train_y)

        # make predictions
        pred = bst.predict_proba(test[len(train_lab):len(test_label), :])
        preds.append(pred)

    preds = np.mean(preds, axis=0)
    auc = roc_auc_score(test_lab[:, 0], preds)

    pred_lab = np.array([0] * len(preds))
    pred_lab[np.where((preds >= 0.5))[0]] = 1

    Acc = acc(test_lab[:, 0], pred_lab)
    Prec = precision(test_lab[:, 0], pred_lab)
    Rec = recall(test_lab[:, 0], pred_lab)
    F1 = f1(test_lab[:, 0], pred_lab)
    Mcc = mcc(test_lab[:, 0], pred_lab)

    return preds, [auc, Acc, Prec, Rec, F1, Mcc], '', ''

def test_model_mvidia(test_fea_single, train_fea_single, train_feas, train_lab, seed, test_feas, test_lab, bsts, param, model='XGB'):
    seed_torch(seed)

    preds = []
    pred_labs = []

    for i in range(len(bsts)):

        pred = bsts[i].predict_proba(np.row_stack((train_fea_single[i], test_fea_single[i])))
        pred_lab = bsts[i].predict(np.row_stack((train_fea_single[i], test_fea_single[i])))
        preds.append(pred)
        pred_labs.append(pred_lab)

    sum_lab = np.sum(pred_labs, axis=0)
    ind_reliable = np.where(((sum_lab == 0) | (sum_lab == len(bsts))))[0]

    acc0 = acc(np.row_stack((train_lab, test_lab))[ind_reliable, 0], pred_labs[0][ind_reliable])

    train_fea_reliable = [np.row_stack((train_feas[j], test_feas[j]))[ind_reliable, :] for j in range(len(bsts))]
    train_lab_reliable = np.array([pred_labs[0]]).T[ind_reliable]

    if (model == 'mvidia') | (model == 'mv-concat') | (model == 'mv+concat'):

        all_data = [np.row_stack((train_fea_reliable[v], test_feas[v])) for v in range(len(bsts))]

        kmcca = GCCA(latent_dimensions=param['N'], c=param['c'], random_state=2024)

        lat_out = kmcca.fit_transform(all_data)
        lats_out_all = np.concatenate(lat_out, axis=1)

        lats_out_te = lats_out_all[len(train_lab_reliable):len(all_data[0][:, 0]), :]
        lats_out_tr = lats_out_all[0:len(train_lab_reliable), :]

        # all_data = [np.row_stack((train_feas[v], test_feas[v])) for v in range(len(bsts))]
        # kmcca = GCCA(latent_dimensions=param['N'], c=param['c'], random_state=2024)
        #
        # lat_out = kmcca.fit_transform(all_data)
        # lats_out_all = np.concatenate(lat_out, axis=1)
        #
        # lats_out_te = lats_out_all[len(train_lab):len(lats_out_all[:, 0]), :]
        # lats_out_tr = lats_out_all[ind_reliable, :]

    elif model == 'concat':
        lats_out_tr = np.concatenate(train_fea_reliable, axis=1)
        lats_out_te = np.concatenate(test_feas, axis=1)
    elif model == 'ens':
        lats_out_tr = train_fea_reliable
        lats_out_te = test_feas

    if model != 'ens':
        if model == 'mv-concat':
            bst = XGBClassifier(n_estimators=param['num'], max_depth=param['d'], learning_rate=param['lr'],
                                objective='binary:logistic')

            bst.fit(lats_out_tr, train_lab_reliable)
            preds_mv = bst.predict_proba(lats_out_te)

            bst_cat = XGBClassifier(n_estimators=param['num_cat'], max_depth=param['d_cat'], learning_rate=param['lr_cat'],
                                objective='binary:logistic')

            bst_cat.fit(np.concatenate(train_fea_reliable, axis=1), train_lab_reliable)
            preds_cat = bst_cat.predict_proba(np.concatenate(test_feas, axis=1))

            preds = (preds_mv + preds_cat)/2#preds_mv * param['alpha'] + preds_cat * (1 - param['alpha'])
            pred_lab = np.array([0] * len(preds))
            pred_lab[np.where((preds[:, 1] >= 0.5))[0]] = 1

            bst = [bst, bst_cat]

        elif model == 'mv+concat':
            bst = XGBClassifier(n_estimators=param['num'], max_depth=param['d'], learning_rate=param['lr'],
                                objective='binary:logistic')
            bst.fit(np.concatenate([lats_out_tr, np.concatenate(train_fea_reliable, axis=1)], axis=1), train_lab_reliable)
            preds = bst.predict_proba(np.concatenate([lats_out_te, np.concatenate(test_feas, axis=1)], axis=1))
            pred_lab = bst.predict(np.concatenate([lats_out_te, np.concatenate(test_feas, axis=1)], axis=1))

        else:
            bst = XGBClassifier(n_estimators=param['num'], max_depth=param['d'], learning_rate=param['lr'],
                                    objective='binary:logistic')

            bst.fit(lats_out_tr, train_lab_reliable)
            preds = bst.predict_proba(lats_out_te)
            pred_lab = bst.predict(lats_out_te)

        auc = roc_auc_score(test_lab[:, 0], preds[:, 1])
        Acc = acc(test_lab[:, 0], pred_lab)
        Prec = precision(test_lab[:, 0], pred_lab)
        Rec = recall(test_lab[:, 0], pred_lab)
        F1 = f1(test_lab[:, 0], pred_lab)
        Mcc = mcc(test_lab[:, 0], pred_lab)

        preds = preds[:, 1]

    else:

        bst = [XGBClassifier(n_estimators=param['num' + str(v)], max_depth=param['d' + str(v)],
                             learning_rate=param['lr' + str(v)],
                             objective='binary:logistic') for v in range(len(bsts))]

        preds = []
        for v in range(len(bsts)):
            bst[v].fit(lats_out_tr[v], train_lab_reliable)
            pred = bst[v].predict_proba(lats_out_te[v])

            preds.append(pred[:, 1])

        preds = np.mean(preds, axis=0)
        auc = roc_auc_score(test_lab[:, 0], preds)

        pred_lab = np.array([0] * len(preds))
        pred_lab[np.where((preds >= 0.5))[0]] = 1

        Acc = acc(test_lab[:, 0], pred_lab)
        Prec = precision(test_lab[:, 0], pred_lab)
        Rec = recall(test_lab[:, 0], pred_lab)
        F1 = f1(test_lab[:, 0], pred_lab)
        Mcc = mcc(test_lab[:, 0], pred_lab)

    return preds, [auc, Acc, Prec, Rec, F1, Mcc], lats_out_te, bst

def test_model_ens(bsts, params, seed, train_feas, test_feas, test_lab, ty):
    seed_torch(seed)


    preds = []
    for i in range(0,len(train_feas)):

        pred = bsts[i].predict_proba(test_feas[i])
        preds.append(pred[:, 1])

    if 'c' in ty: #fusion ens and cat
        idx = ty.index('c')
        preds.append(bsts[idx].predict_proba(np.concatenate(test_feas, axis=1))[:, 1])

    if 'g' in ty: # fusion ens, cat and gcca

        idx = ty.index('g')

        kmcca = GCCA(latent_dimensions=params[idx]['N'], c=params[idx]['c'], random_state=2024)
        all_data = [np.row_stack((train_feas[v], test_feas[v])) for v in range(len(train_feas))]
        lat_out = kmcca.fit_transform(all_data)
        lats_out_mvidia = np.concatenate(lat_out, axis=1)

        test_lat = lats_out_mvidia[len(train_feas[0][:, 0]):len(lats_out_mvidia[:, 0]), :]

        preds.append(bsts[idx].predict_proba(test_lat)[:, 1])


    preds = np.mean(preds, axis=0)
    auc = roc_auc_score(test_lab[:, 0], preds)

    pred_lab = np.array([0] * len(preds))
    pred_lab[np.where((preds>=0.5))[0]] = 1

    Acc = acc(test_lab[:, 0], pred_lab)
    Prec = precision(test_lab[:, 0], pred_lab)
    Rec = recall(test_lab[:, 0], pred_lab)
    F1 = f1(test_lab[:, 0], pred_lab)
    Mcc = mcc(test_lab[:, 0], pred_lab)

    return preds, [auc, Acc, Prec, Rec, F1, Mcc]

def test_model_ens_all(preds, test_lab):

    preds = np.mean(preds, axis=0)
    auc = roc_auc_score(test_lab[:, 0], preds)

    pred_lab = np.array([0] * len(preds))
    pred_lab[np.where((preds>=0.5))[0]] = 1

    Acc = acc(test_lab[:, 0], pred_lab)
    Prec = precision(test_lab[:, 0], pred_lab)
    Rec = recall(test_lab[:, 0], pred_lab)
    F1 = f1(test_lab[:, 0], pred_lab)
    Mcc = mcc(test_lab[:, 0], pred_lab)

    return preds, [auc, Acc, Prec, Rec, F1, Mcc]

def seed_torch(seed=1029):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)


def objective(trail, train_feas, train_lab, test_feas, test_lab, seed, model_type):
    seed_torch(seed)

    if model_type == 'single':
        num = trail.suggest_int('num', 2, 100, step=5)  # n_estimators
        d = trail.suggest_int('d', 1, 10, step=1)  # max depth
        lr = trail.suggest_float('lr', 0.0001, 1)  # max depth
        param = {'num': num, 'd': d, 'lr':lr}
        auc, mcc, f1, acc = cv_model(train_feas, train_lab, seed, param)

    elif (model_type == 'mv') | (model_type == 'mv+concat'):
        max_N = min([len(train_feas[0][0, :]), len(train_feas[0][:, 0])])
        N = trail.suggest_int('N', 2, max_N, step=1) # n_estimators
        num = trail.suggest_int('num', 2, 100, step=5)  # n_estimators
        d = trail.suggest_int('d', 1, 15, step=1)  # max depth
        c = trail.suggest_float('c', 0.0001, 1)  # max depth
        lr = trail.suggest_float('lr', 0.0001, 1)  # max depth
        # alpha = trail.suggest_float('alpha', 0, 1)
        param = {'N': N, 'num': num, 'd': d, 'lr':lr, 'c':c}
        if model_type == 'mv+cat':
            auc, mcc, f1, acc = cv_model_mv(train_feas, train_lab, test_feas, test_lab, seed, param, model='mv+concat')
        else:
            auc, mcc, f1, acc = cv_model_mv(train_feas, train_lab, test_feas, test_lab, seed, param)

    elif model_type == 'mv-concat':
        max_N = min([len(train_feas[0][0, :]), len(train_feas[0][:, 0])])
        N = trail.suggest_int('N', 2, max_N, step=1) # n_estimators
        num = trail.suggest_int('num', 2, 100, step=5)  # n_estimators
        d = trail.suggest_int('d', 1, 10, step=1)  # max depth
        c = trail.suggest_float('c', 0.0001, 1)  # max depth
        lr = trail.suggest_float('lr', 0.0001, 1)  # max depth

        num_cat = trail.suggest_int('num_cat', 2, 100, step=5)  # n_estimators
        d_cat = trail.suggest_int('d_cat', 1, 10, step=1)  # max depth
        lr_cat = trail.suggest_float('lr_cat', 0.0001, 1)  # max depth
        # alpha = trail.suggest_float('alpha', 0.0, 1)  # max depth
        param = {'N': N, 'num': num, 'd': d, 'lr':lr, 'c':c, 'num_cat':num_cat, 'd_cat':d_cat, 'lr_cat':lr_cat}#, 'alpha':alpha}

        auc, mcc, f1, acc = cv_model_mv(train_feas, train_lab, test_feas, test_lab, seed, param, model='mv-concat')

    elif model_type == 'single_svm':
        C = trail.suggest_int('C', -10, 10, step=1) # n_estimators
        g = trail.suggest_int('g', -10, 10, step=1) # max depth
        #lr = trail.suggest_float('lr', 0.0001, 1) # max depth
        param = {'C': 2**C, 'g': 2**g}
        auc, mcc, f1, acc = cv_model(train_feas, train_lab, seed, param, model='svm')

    elif model_type == 'mv_svm':

        max_N = min([len(train_feas[0][0, :]), len(train_feas[0][:, 0])])
        N = trail.suggest_int('N', 2, max_N, step=1)  # n_estimators
        C = trail.suggest_int('C', -10, 10, step=1)  # n_estimators
        g = trail.suggest_int('g', -10, 10, step=1)  # max depth
        param = {'N': N,'C': 2**C, 'g': 2**g}

        auc, mcc, f1, acc = cv_model_mv(train_feas, train_lab, seed, param, model='svm')


    return 1 - auc#mcc#auc#acc#f1

def objective_semi(trail, train_feas, train_lab, test_feas, test_lab, seed, model_type):
    seed_torch(seed)

    if model_type == 'single':
        num = trail.suggest_int('num', 2, 100, step=5) # n_estimators
        d = trail.suggest_int('d', 1, 10, step=1)  # max depth
        lr = trail.suggest_float('lr', 0.0001, 0.1)  # max depth
        param = {'num': num, 'd': d, 'lr': lr}
        auc, mcc, f1, acc = cv_model_semi(train_feas, train_lab, test_feas, test_lab, seed, param)

    elif model_type == 'semi':

        max_N = min([len(train_feas[0][0, :]), len(train_feas[0][:, 0])])
        N = trail.suggest_int('N', 2, max_N, step=1)  # n_estimators
        num = trail.suggest_int('num', 2, 100, step=5) # n_estimators
        d = trail.suggest_int('d', 1, 10, step=1)  # max depth
        lr = trail.suggest_float('lr', 0.0001, 1)  # max depth
        c = trail.suggest_float('c', 0.0001, 1)  # max depth
        param = {'N': N, 'num': num, 'd': d, 'lr': lr, 'c':c}

        auc, mcc, f1, acc = cv_model_semi(train_feas, train_lab, test_feas, test_lab, seed, param)

    return 1 - auc#acc#f1

def objective_mvidia(trail, test_fea_single, train_fea_single, train_feas, train_lab, test_feas, test_lab, seed, model_type, bst):
    seed_torch(seed)

    if (model_type == 'concat'):
        num = trail.suggest_int('num', 2, 100, step=5) # n_estimators
        d = trail.suggest_int('d', 1, 10, step=1)  # max depth
        lr = trail.suggest_float('lr', 0.0001, 1)  # max depth
        param = {'num': num, 'd': d, 'lr': lr}
        auc, mcc, f1, acc = cv_model_mvidia(test_fea_single, train_fea_single, train_feas, train_lab, test_feas, test_lab, seed, param, bst, model_type)

    elif model_type == 'mv-concat':
        max_N = min([len(train_feas[0][0, :]), len(train_feas[0][:, 0])])
        N = trail.suggest_int('N', 2, max_N, step=1) # n_estimators
        num = trail.suggest_int('num', 2, 100, step=5)  # n_estimators
        d = trail.suggest_int('d', 1, 10, step=1)  # max depth
        c = trail.suggest_float('c', 0.0001, 1)  # max depth
        lr = trail.suggest_float('lr', 0.0001, 1)  # max depth

        num_cat = trail.suggest_int('num_cat', 2, 100, step=5)  # n_estimators
        d_cat = trail.suggest_int('d_cat', 1, 10, step=1)  # max depth
        lr_cat = trail.suggest_float('lr_cat', 0.0001, 1)  # max depth
        # alpha = trail.suggest_float('alpha', 0.0, 1)  # max depth
        param = {'N': N, 'num': num, 'd': d, 'lr':lr, 'c':c, 'num_cat':num_cat, 'd_cat':d_cat, 'lr_cat':lr_cat}#, 'alpha':alpha}

        auc, mcc, f1, acc = cv_model_mvidia(test_fea_single, train_fea_single, train_feas, train_lab, test_feas, test_lab, seed,
                                   param, bst, model_type)

    elif (model_type == 'mvidia') | (model_type == 'mv+concat') | (model_type == 'mv+concat+ens'):

        max_N = min([len(train_feas[0][0, :]), len(train_feas[0][:, 0])])
        N = trail.suggest_int('N', 2, max_N, step=1)  # n_estimators
        c = trail.suggest_float('c', 0.0001, 1)
        num = trail.suggest_int('num', 2, 100, step=5) # n_estimators
        d = trail.suggest_int('d', 1, 10, step=1)  # max depth
        lr = trail.suggest_float('lr', 0.0001, 1)  # max depth
        param = {'N': N, 'num': num, 'd': d, 'lr': lr, 'c':c}

        auc, mcc, f1, acc = cv_model_mvidia(test_fea_single, train_fea_single, train_feas, train_lab, test_feas, test_lab, seed, param, bst, model_type)

    elif model_type == 'ens':
        param = {}
        for v in range(len(bst)):
            num = trail.suggest_int('num'+str(v), 2, 100, step=5)  # n_estimators
            d = trail.suggest_int('d'+str(v), 1, 10, step=1)  # max depth
            lr = trail.suggest_float('lr'+str(v), 0.0001, 1)  # max depth
            param.update({'num'+str(v): num, 'd'+str(v): d, 'lr'+str(v): lr})

        auc, mcc, f1, acc = cv_model_mvidia(test_fea_single, train_fea_single, train_feas, train_lab, test_feas, test_lab, seed, param, bst, model_type)

    return 1 - auc#acc#f1

def optuna_optimize(train_feas, train_lab, seed, model_type, test_feas, test_lab, trial_num):
    seed_torch(seed)
    study = optuna.create_study(study_name='test', direction='minimize', sampler=optuna.samplers.TPESampler(seed=seed),
                                pruner=optuna.pruners.HyperbandPruner())

    if model_type != 'semi':
        func = lambda trial: objective(trial, train_feas, train_lab, test_feas, test_lab, seed, model_type)
    else:
        func = lambda trial: objective_semi(trial, train_feas, train_lab, test_feas, test_lab, seed, model_type)
    study.optimize(func, n_trials=trial_num)
    print(study.best_params)
    print(study.best_trial)
    print(study.best_trial.value)
    print(model_type)
    if (model_type == 'single') | (model_type == 'single_svm'):
        if model_type == 'single_svm':
            model = 'svm'
            #study.best_params.update({'C': 2 ** study.best_params['C'], 'g': 2 ** study.best_params['g']})
        else:
            model = 'XGB'

        pred, auc, bst = test_model(train_feas, train_lab, seed, test_feas, test_lab, study.best_params, model)
        lat = '_'
    elif model_type == 'mv-concat':
        model = model_type
        pred, auc, lat, bst = test_model_mv(train_feas, train_lab, seed, test_feas, test_lab, study.best_params, model)
    elif (model_type == 'mv') | (model_type == 'mv_svm') | (model_type == 'semi') | (model_type == 'mv+concat'):
        if model_type == 'mv_svm':
            model = 'svm'
            #study.best_params.update({'C': 2 ** study.best_params['C'], 'g': 2 ** study.best_params['g']})
        else:
            model = 'XGB'
        pred, auc, lat, bst = test_model_mv(train_feas, train_lab, seed, test_feas, test_lab, study.best_params, model)
    elif model_type == 'semi':
        pred, auc, lat, bst = test_model_semi(train_feas, train_lab, seed, test_feas, test_lab, study.best_params, model)
    return pred, auc, study.best_params, lat, bst

def optuna_optimize_mvidia(test_fea_single, train_fea_single, train_feas, train_lab, seed, model_type, test_feas, test_lab, bst, trial_num):
    seed_torch(seed)
    study = optuna.create_study(study_name='test', direction='minimize', sampler=optuna.samplers.TPESampler(seed=seed),
                                pruner=optuna.pruners.HyperbandPruner())

    func = lambda trial: objective_mvidia(trial, test_fea_single, train_fea_single, train_feas, train_lab, test_feas, test_lab, seed, model_type, bst)
    study.optimize(func, n_trials=trial_num)
    print(study.best_params)
    print(study.best_trial)
    print(study.best_trial.value)
    print(model_type)

    pred, auc, lat, bst = test_model_mvidia(test_fea_single, train_fea_single, train_feas, train_lab, seed, test_feas, test_lab, bst, study.best_params, model_type)
    return pred, auc, study.best_params, lat, bst

def log2Transfer(dt):

    out_mat_inten = np.array(dt.values[:, 2:], dtype='float')
    out_mat_inten[out_mat_inten == 0] = np.nan
    out_mat_inten = np.log2(out_mat_inten)
    out_mat = pd.DataFrame(np.column_stack((dt.values[:, 0:2], out_mat_inten)),
                               columns=list(dt.columns.values))

    return out_mat

def processing_type(data, scale):
    if scale >= 0:
        if scale == 0:
            mm = preprocessing.MinMaxScaler(feature_range=(0, 1))
        elif scale == 1:
            mm = preprocessing.MinMaxScaler(feature_range=(-1, 1))
        elif scale == 2:
            mm = preprocessing.StandardScaler()
        data = mm.fit_transform(data)
    elif scale < 0:
        mm = 0
        data = data
    return data, mm

def align_sample(df, design, g1, g2, scale):

    design = design[(design['condition'] == g1) | (design['condition'] == g2)]

    sample_name_df = df.columns.values[2:]
    sample_name_design = design['sample_name'].values

    mat_df = df.values[:, 2:]
    mat_df[mat_df == 0] = np.nan
    df_info = df.iloc[:, :2]

    idxs = [np.where((sample_name_df == sample_name_design[i]))[0] for i in range(len(sample_name_design))]
    mat_align = mat_df[:, np.array(idxs, dtype=int)[:, 0]]
    mat_align, mm = processing_type(mat_align, scale)  # scale to [0, 1]
    df_mat = pd.DataFrame(mat_align, columns=sample_name_design)
    #mat_min = min(mat_align)

    df_align = pd.concat([df_info, df_mat], axis=1)

    return df_align, design

def get_DEPs(root_fold, sub_fold, all_fold, best_fold, method, logthre, qthre):

    DEA_res_all = pd.read_csv(root_fold + sub_fold + '/' + all_fold + '/DEA_res.csv', sep=',', header=0)
    DEA_best = pd.read_csv(root_fold + sub_fold + '/' + best_fold + '/DEA_res.csv', sep=',', header=0)

    dlfq_deg = DEA_res_all['Protein'].values[
        np.where(((DEA_res_all['dlfq_qval'].values <= qthre) & (abs(DEA_res_all['dlfq_logFC'].values) >= logthre)))]
    maxlfq_deg = DEA_res_all['Protein'].values[
        np.where(((DEA_res_all['maxlfq_qval'].values <= qthre) & (abs(DEA_res_all['maxlfq_logFC'].values) >= logthre)))]
    top3_deg = DEA_res_all['Protein'].values[
        np.where(((DEA_res_all['top3_qval'].values <= qthre) & (abs(DEA_res_all['top3_logFC'].values) >= logthre)))]
    top1_deg = DEA_res_all['Protein'].values[
        np.where(((DEA_res_all['top1_qval'].values <= qthre) & (abs(DEA_res_all['top1_logFC'].values) >= logthre)))]
    hurdle_deg = DEA_best['Protein'].values[
        np.where(((DEA_best['hurdle_qval'].values <= qthre) & (abs(DEA_best['hurdle_logFC'].values) >= logthre)))]

    if method == 'DL_pred':
        DL_deg = DEA_best['Protein'].values[np.where(((DEA_best['MVcontrast_score'].values >= max(
            DEA_best['MVcontrast_threshold'].values)) & (abs(DEA_best['MVcontrast_logFC'].values) >= logthre)))]
    elif method == 'DP_fdr':
        DL_deg = DEA_best['Protein'].values[np.where(((DEA_best['MVcontrast_score.2'].values >= max(
            DEA_best['MVcontrast_threshold.2'].values)) & (abs(DEA_best['MVcontrast_logFC.2'].values) >= logthre)))]

    return dlfq_deg, maxlfq_deg, top3_deg, top1_deg, hurdle_deg, DL_deg

def get_single_view(pro_list, raw_fold_dis, raw_fold_ret, view_type, g1, g2):

    dlfq_logT = 'F'
    post = '.csv'

    design_dis = pd.read_csv(raw_fold_dis + 'design' + post, sep='\t', header=0)
    design_ret = pd.read_csv(raw_fold_ret + 'design' + post, sep='\t', header=0)


    view_dis = pd.read_csv(raw_fold_dis + view_type + post, sep='\t', header=0)
    view_ret = pd.read_csv(raw_fold_ret + view_type + post, sep='\t', header=0)

    if dlfq_logT == 'T':
        view_dis = log2Transfer(view_dis)
        view_ret = log2Transfer(view_ret)

    view_dis, _ = align_sample(view_dis, design_dis, g1, g2, -1)
    view_ret, _ = align_sample(view_ret, design_ret, g1, g2, -1)

    view_dis.index = view_dis['Protein'].values
    view_ret.index = view_ret['Protein'].values
    view_dis = view_dis.reindex(pro_list)
    view_ret = view_ret.reindex(pro_list)

    label_dis = design_dis['condition'].values
    label_dis_bin = (label_dis == g2).astype(int)
    label_dis_bin = np.array([label_dis_bin]).T

    label_ret = design_ret['condition'].values
    label_ret_bin = (label_ret == g2).astype(int)
    label_ret_bin = np.array([label_ret_bin]).T

    return view_dis, view_ret, label_dis_bin, label_ret_bin


def get_views(pro_list, raw_fold_dis, raw_fold_ret, view_type, g1, g2, view_comb):

    if view_type not in ['hurdle', 'DL']:

        view_dis, view_ret, label_dis_bin, label_ret_bin = get_single_view(pro_list, raw_fold_dis, raw_fold_ret, view_type, g1, g2)
        return view_dis, view_ret, label_dis_bin, label_ret_bin

    else:

        views_dis = []
        views_ret = []

        for v in view_comb:
            view_dis, view_ret, label_dis_bin, label_ret_bin = get_single_view(pro_list, raw_fold_dis, raw_fold_ret,
                                                                               v, g1, g2)
            views_dis.append(view_dis)
            views_ret.append(view_ret)

        return views_dis, views_ret, label_dis_bin, label_ret_bin


def TPD_classificaion(raw_fold_dis, raw_fold_ret, root_fold, sub_fold, best_fold, all_fold, trial_num, DEA_method, logthre, qthre, g1, g2, view_comb, save_fold):

    dlfq_deg, maxlfq_deg, top3_deg, top1_deg, hurdle_deg, DL_deg = get_DEPs(root_fold, sub_fold, all_fold, best_fold, DEA_method, logthre, qthre)

    views_dis_dlfq, views_ret_dlfq, lab_dis_dlfq, lab_ret_dlfq = get_views(dlfq_deg, raw_fold_dis,
                                                                                       raw_fold_ret, 'dlfq', g1, g2,
                                                                                       view_comb)
    data_dis_dlfq = np.array(views_dis_dlfq.values[:, 2:].T, dtype='float')
    data_ret_dlfq = np.array(views_ret_dlfq.values[:, 2:].T, dtype='float')

    pd.DataFrame(data_dis_dlfq).to_csv(save_fold + 'TPD_dis_dlfq.csv')
    pd.DataFrame(data_dis_dlfq).to_csv(save_fold + 'TPD_ret_dlfq.csv')
    views_dis_maxlfq, views_ret_maxlfq, lab_dis_maxlfq, lab_ret_maxlfq = get_views(maxlfq_deg, raw_fold_dis,
                                                                                       raw_fold_ret, 'maxlfq', g1, g2,
                                                                                       view_comb)
    data_dis_maxlfq = np.array(views_dis_maxlfq.values[:, 2:].T, dtype='float')
    data_ret_maxlfq = np.array(views_ret_maxlfq.values[:, 2:].T, dtype='float')
    pd.DataFrame(data_dis_maxlfq).to_csv(save_fold + 'TPD_dis_maxlfq.csv')
    pd.DataFrame(data_ret_maxlfq).to_csv(save_fold + 'TPD_ret_maxlfq.csv')
    views_dis_top3, views_ret_top3, lab_dis_top3, lab_ret_top3 = get_views(top3_deg, raw_fold_dis,
                                                                                       raw_fold_ret, 'top3', g1, g2,
                                                                                       view_comb)
    data_dis_top3 = np.array(views_dis_top3.values[:, 2:].T, dtype='float')
    data_ret_top3 = np.array(views_ret_top3.values[:, 2:].T, dtype='float')
    pd.DataFrame(data_dis_top3).to_csv(save_fold + 'TPD_dis_top3.csv')
    pd.DataFrame(data_ret_top3).to_csv(save_fold + 'TPD_ret_top3.csv')
    views_dis_top1, views_ret_top1, lab_dis_top1, lab_ret_top1 = get_views(top1_deg, raw_fold_dis,
                                                                                       raw_fold_ret, 'top1', g1, g2,
                                                                                       view_comb)
    data_dis_top1 = np.array(views_dis_top1.values[:, 2:].T, dtype='float')
    data_ret_top1 = np.array(views_ret_top1.values[:, 2:].T, dtype='float')
    pd.DataFrame(data_dis_top1).to_csv(save_fold + 'TPD_dis_top1.csv')
    pd.DataFrame(data_ret_top1).to_csv(save_fold + 'TPD_ret_top1.csv')
    """
    dlfq based
    """

    data_dis_dlfq = Fill_nan(data_dis_dlfq, min(data_dis_dlfq[~np.isnan(data_dis_dlfq)]))
    data_ret_dlfq = Fill_nan(data_ret_dlfq, min(data_dis_dlfq[~np.isnan(data_dis_dlfq)]))

    # scale the data
    scaler = StandardScaler()
    # scaler = MinMaxScaler()
    scaler.fit(data_dis_dlfq)

    data_dis_dlfq = scaler.transform(data_dis_dlfq)
    data_ret_dlfq = scaler.transform(data_ret_dlfq)

    seed = 2024
    # dlfq
    pred1, auc1, best_params1, lat, bst1 = optuna_optimize(data_dis_dlfq, lab_dis_dlfq, seed, 'single', data_ret_dlfq,
                                                           lab_ret_dlfq, trial_num)

    # """
    #     maxlfq based
    # """
    data_dis_maxlfq = Fill_nan(data_dis_maxlfq, min(data_dis_maxlfq[~np.isnan(data_dis_maxlfq)]))
    # data_dis_maxlfq = Fill_nan(data_dis_maxlfq, 0)
    data_ret_maxlfq = Fill_nan(data_ret_maxlfq, min(data_dis_maxlfq[~np.isnan(data_dis_maxlfq)]))
    # data_ret_maxlfq = Fill_nan(data_ret_maxlfq, 0)

    # scale the data
    scaler = StandardScaler()
    # scaler = MinMaxScaler()
    scaler.fit(data_dis_maxlfq)

    data_dis_maxlfq = scaler.transform(data_dis_maxlfq)
    data_ret_maxlfq = scaler.transform(data_ret_maxlfq)

    seed = 2024
    # maxlfq
    pred2, auc2, best_params2, lat, bst2 = optuna_optimize(data_dis_maxlfq, lab_dis_maxlfq, seed, 'single',
                                                           data_ret_maxlfq,
                                                           lab_ret_maxlfq, trial_num)

    """
            top3 based
        """

    data_dis_top3 = Fill_nan(data_dis_top3, min(data_dis_top3[~np.isnan(data_dis_top3)]))
    # data_dis_top3 = Fill_nan(data_dis_top3, 0)
    data_ret_top3 = Fill_nan(data_ret_top3, min(data_dis_top3[~np.isnan(data_dis_top3)]))
    # data_ret_top3 = Fill_nan(data_ret_top3, 0)

    # scale the data
    scaler = StandardScaler()
    # scaler = MinMaxScaler()
    scaler.fit(data_dis_top3)

    data_dis_top3 = scaler.transform(data_dis_top3)
    data_ret_top3 = scaler.transform(data_ret_top3)

    # top3
    pred3, auc3, best_params3, lat, bst3 = optuna_optimize(data_dis_top3, lab_dis_top3, seed, 'single',
                                                           data_ret_top3,
                                                           lab_ret_top3, trial_num)

    """
                top1 based
            """
    data_dis_top1 = Fill_nan(data_dis_top1, min(data_dis_top1[~np.isnan(data_dis_top1)]))
    # data_dis_top3 = Fill_nan(data_dis_top3, 0)
    data_ret_top1 = Fill_nan(data_ret_top1, min(data_dis_top1[~np.isnan(data_dis_top1)]))
    # data_ret_top3 = Fill_nan(data_ret_top3, 0)

    # scale the data
    scaler = StandardScaler()
    # scaler = MinMaxScaler()
    scaler.fit(data_dis_top1)

    data_dis_top1 = scaler.transform(data_dis_top1)
    data_ret_top1 = scaler.transform(data_ret_top1)

    # top1
    pred4, auc4, best_params4, lat4, bst4 = optuna_optimize(data_dis_top1, lab_dis_top1, seed, 'single',
                                                           data_ret_top1,
                                                           lab_ret_top1, trial_num)

    """
                    hurdle based
                """

    views_diss, views_rets, lab_dis, lab_ret = get_views(hurdle_deg, raw_fold_dis,
                                                                                   raw_fold_ret, 'hurdle', g1, g2,
                                                                                   view_comb)
    data_diss = []
    data_rets = []

    all_zero_col = []
    for v in range(len(view_comb)):
        data_dis = np.array(views_diss[v].values[:, 2:].T, dtype='float')
        data_dis = Fill_nan(data_dis, min(data_dis[~np.isnan(data_dis)]))
        data_ret = np.array(views_rets[v].values[:, 2:].T, dtype='float')
        data_ret = Fill_nan(data_ret, min(data_ret[~np.isnan(data_ret)]))

        zero_col_dis = np.where((data_dis == 0).all(axis=0))[0]
        zero_col_ret = np.where((data_ret == 0).all(axis=0))[0]

        all_zero_col.extend(zero_col_dis)
        all_zero_col.extend(zero_col_ret)

        data_diss.append(data_dis)
        data_rets.append(data_ret)

    # scale the data
    scaler = StandardScaler()
    # scaler = MinMaxScaler()
    scaler.fit(data_diss[0])

    for v in range(len(view_comb)):
        data_diss[v] = scaler.transform(data_diss[v])
        data_rets[v] = scaler.transform(data_rets[v])

    data_dis_hurdle = np.concatenate(data_diss, axis=1)
    data_ret_hurdle = np.concatenate(data_rets, axis=1)
    seed = 2024
    # hurdle
    pred5, auc5, best_params5, lat5, bst5 = optuna_optimize(data_dis_hurdle, lab_dis, seed, 'single',
                                                            data_ret_hurdle,
                                                            lab_ret, trial_num)

    """
                        DL based
                    """
    views_diss, views_rets, lab_dis, lab_ret = get_views(DL_deg, raw_fold_dis,
                                                         raw_fold_ret, 'DL', g1, g2,
                                                         view_comb)
    data_diss = []
    data_rets = []

    all_zero_col = []
    for v in range(len(view_comb)):
        data_dis = np.array(views_diss[v].values[:, 2:].T, dtype='float')
        data_dis = Fill_nan(data_dis, min(data_dis[~np.isnan(data_dis)]))
        data_ret = np.array(views_rets[v].values[:, 2:].T, dtype='float')
        data_ret = Fill_nan(data_ret, min(data_ret[~np.isnan(data_ret)]))

        zero_col_dis = np.where((data_dis == 0).all(axis=0))[0]
        zero_col_ret = np.where((data_ret == 0).all(axis=0))[0]

        all_zero_col.extend(zero_col_dis)
        all_zero_col.extend(zero_col_ret)

        data_diss.append(data_dis)
        data_rets.append(data_ret)

    pd.DataFrame(np.concatenate(data_diss, axis=1)).to_csv(save_fold + 'TPD_dis_MCP.csv')
    pd.DataFrame(np.concatenate(data_rets, axis=1)).to_csv(save_fold + 'TPD_ret_MCP.csv')

    # scale the data
    scaler = StandardScaler()
    # scaler = MinMaxScaler()
    scaler.fit(data_diss[0])

    for v in range(len(view_comb)):
        data_diss[v] = scaler.transform(data_diss[v])
        data_rets[v] = scaler.transform(data_rets[v])

    data_dis_DL = np.concatenate(data_diss, axis=1)
    data_ret_DL = np.concatenate(data_rets, axis=1)

    pd.DataFrame(data_dis_DL).to_csv(save_fold + 'TPD_dis_MCP_scale.csv')
    pd.DataFrame(data_ret_DL).to_csv(save_fold + 'TPD_ret_MCP_scale.csv')
    seed = 2024
    # DL
    pred6, auc6, best_params6, lat6, bst6 = optuna_optimize(data_dis_DL, lab_dis, seed, 'single',
                                                            data_ret_DL,
                                                            lab_ret, trial_num)


    res_all = np.array([auc1, auc2, auc3, auc4, auc5, auc6])
    predicts = np.array([lab_ret[:,0], pred1, pred2, pred3, pred4, pred5, pred6]).T

    res_name = 'DEPs'
    df = pd.DataFrame(np.column_stack((np.array([len(res_all) * [res_name]]).T, res_all)), columns=['FeatureSet', 'auc', 'Acc', 'Prec', 'Rec', 'F1', 'Mcc'],
                 index=['dlfq', 'maxlfq', 'top3', 'top1', 'hurdle', 'MCP'])
    print(df)
    df.to_csv(save_fold + res_name +'_XGB_perform.csv')
    pd.DataFrame(predicts,
                 columns=['True', 'dlfq', 'maxlfq', 'top3', 'top1', 'hurdle', 'MCP']).to_csv(save_fold + 'predicted_results_all.csv')
    return df


if __name__ == "__main__":
    #pro_list = ['P02765', 'P04083', 'O00339', 'P58546', 'O75347', 'P04216', 'P02751', 'P83731', 'P00568', 'P78527', 'P04792', 'P57737', 'P42224', 'P27797', 'Q9HAT2', 'P30086', 'O14964', 'P10909', 'P17931']

    #res_name = 'author19'
    current_fold = os.path.dirname(__file__) + '/'
    parent_fold = os.path.dirname(os.path.dirname(current_fold))
    save_folder = current_fold + '/res/'

    if not os.path.exists(save_folder):
        os.makedirs(save_folder)

    trial_num = 30
    best_fold = 'DIA_dlfq_maxlfq_top3'
    all_fold = 'DIA_dlfq_maxlfq_top3_top1'
    root_fold = parent_fold + '/Case_studies/res/'
    sub_fold = 'TPD_dis_DEA_res'
    DEA_method = 'DP_fdr'
    logthre = np.log2(2)
    qthre = 0.01
    raw_fold_dis = parent_fold + '/data/case_study_views/TPD_views/dis/'
    raw_fold_ret = parent_fold + '/data/case_study_views/TPD_views/ret/'
    g1 = 'B'
    g2 = 'M'
    view_comb = ['dlfq', 'maxlfq', 'top3']

    TPD_classificaion(raw_fold_dis, raw_fold_ret, root_fold, sub_fold, best_fold, all_fold, trial_num, DEA_method, logthre, qthre, g1, g2, view_comb, save_folder)
