import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.model_selection import cross_val_score, ShuffleSplit, StratifiedShuffleSplit, StratifiedKFold
from xgboost import XGBClassifier
from sklearn.metrics import roc_auc_score
from cca_zoo.linear import GCCA
from sklearn import preprocessing
import optuna
import random
import os
from sklearn.decomposition import PCA
from sklearn.metrics import accuracy_score as acc, recall_score as recall, precision_score as precision, f1_score as f1, matthews_corrcoef as mcc
import matplotlib.pyplot as plt
from sklearn.metrics import RocCurveDisplay, roc_curve
from sklearn.metrics import auc as Auc
from sklearn.neighbors import KNeighborsClassifier as KNN
from sklearn.svm import SVC
from sklearn.cluster import KMeans
from sklearn import metrics
from sklearn.metrics import silhouette_score,adjusted_rand_score,normalized_mutual_info_score
from sklearn.metrics.cluster import contingency_matrix
from itertools import combinations

def seed_torch(seed=1029):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)

def log2Transfer(dt):

    out_mat_inten = np.array(dt.values[:, 2:], dtype='float')
    out_mat_inten[out_mat_inten == 0] = np.nan
    out_mat_inten = np.log2(out_mat_inten)
    out_mat = pd.DataFrame(np.column_stack((dt.values[:, 0:2], out_mat_inten)),
                               columns=list(dt.columns.values))

    return out_mat

def processing_type(data, scale):
    if scale >= 0:
        if scale == 0:
            mm = preprocessing.MinMaxScaler(feature_range=(0, 1))
        elif scale == 1:
            mm = preprocessing.MinMaxScaler(feature_range=(-1, 1))
        elif scale == 2:
            mm = preprocessing.StandardScaler()
        data = mm.fit_transform(data)
    elif scale < 0:
        mm = 0
        data = data
    return data, mm

def align_sample(df, design, g1, g2, scale):

    design = design[(design['condition'] == g1) | (design['condition'] == g2)]

    sample_name_df = df.columns.values[2:]
    sample_name_design = design['sample_name'].values

    mat_df = df.values[:, 2:]
    mat_df[mat_df == 0] = np.nan
    df_info = df.iloc[:, :2]

    idxs = [np.where((sample_name_df == sample_name_design[i]))[0] for i in range(len(sample_name_design))]
    mat_align = mat_df[:, np.array(idxs, dtype=int)[:, 0]]
    mat_align, mm = processing_type(mat_align, scale)  # scale to [0, 1]
    df_mat = pd.DataFrame(mat_align, columns=sample_name_design)
    #mat_min = min(mat_align)

    df_align = pd.concat([df_info, df_mat], axis=1)

    return df_align, design

def purity_score(y_true, y_pred):
    contingency_matrix1 = contingency_matrix(y_true, y_pred)
    return np.sum(np.amax(contingency_matrix1, axis=0)) / np.sum(contingency_matrix1)

def load_data(dt_name, raw_fold, sub_fold, best_fold, all_fold, logthre, qthre, dlfq_logT, post, g1, g2, method, scale):
    root_fold = 'D:/Roffline/MVIDIA/case_Res/all08/'
    comb = best_fold.split('_')[1:]

    DEA_res_all = pd.read_csv(root_fold + sub_fold + '/' + all_fold + '/DEA_res.csv', sep=',', header=0)
    DEA_best = pd.read_csv(root_fold + sub_fold + '/' + best_fold + '/DEA_res.csv', sep=',', header=0)

    design = pd.read_csv(raw_fold + 'design' + post, sep='\t', header=0)
    view_dlfq = pd.read_csv(raw_fold + 'dlfq' + post, sep='\t', header=0)
    view_maxlfq = pd.read_csv(raw_fold + 'maxlfq' + post, sep='\t', header=0)
    view_top3 = pd.read_csv(raw_fold + 'top3' + post, sep='\t', header=0)
    view_top1 = pd.read_csv(raw_fold + 'top1' + post, sep='\t', header=0)

    if dlfq_logT == 'T':
        view_dlfq = log2Transfer(view_dlfq)

    view_dlfq, _ = align_sample(view_dlfq, design, g1, g2, scale)
    view_maxlfq, _ = align_sample(view_maxlfq, design, g1, g2, scale)
    view_top3, _ = align_sample(view_top3, design, g1, g2, scale)
    view_top1, design = align_sample(view_top1, design, g1, g2, scale)

    dlfq_deg = DEA_res_all['Protein'].values[
        np.where(((DEA_res_all['dlfq_qval'].values < qthre) & (abs(DEA_res_all['dlfq_logFC'].values) > logthre)))]
    maxlfq_deg = DEA_res_all['Protein'].values[
        np.where(((DEA_res_all['maxlfq_qval'].values < qthre) & (abs(DEA_res_all['maxlfq_logFC'].values) > logthre)))]
    top3_deg = DEA_res_all['Protein'].values[
        np.where(((DEA_res_all['top3_qval'].values < qthre) & (abs(DEA_res_all['top3_logFC'].values) > logthre)))]
    top1_deg = DEA_res_all['Protein'].values[
        np.where(((DEA_res_all['top1_qval'].values < qthre) & (abs(DEA_res_all['top1_logFC'].values) > logthre)))]
    hurdle_deg = DEA_best['Protein'].values[
        np.where(((DEA_best['hurdle_qval'].values < qthre) & (abs(DEA_best['hurdle_logFC'].values) > logthre)))]

    if method == 'DL_pred':
        DL_deg = DEA_best['Protein'].values[np.where(((DEA_best['MVcontrast_score'].values > max(
            DEA_best['MVcontrast_threshold'].values)) & (abs(DEA_best['MVcontrast_logFC'].values) > logthre)))]
    elif method == 'DP_fdr':
        DL_deg = DEA_best['Protein'].values[np.where(((DEA_best['MVcontrast_score.2'].values >= max(
            DEA_best['MVcontrast_threshold.2'].values)) & (abs(DEA_best['MVcontrast_logFC.2'].values) >= logthre)))]

    dt_dict = {'data':dt_name,
               'design':design,
               'dlfq':{'df':view_dlfq, 'view':view_dlfq.values[:, 2:], 'DEP':dlfq_deg},
               'maxlfq':{'df':view_maxlfq, 'view':view_maxlfq.values[:, 2:], 'DEP':maxlfq_deg},
               'top3':{'df':view_top3, 'view': view_top3.values[:, 2:], 'DEP': top3_deg},
               'top1':{'df':view_top1, 'view':view_top1.values[:, 2:], 'DEP':top1_deg},
               'MVDEA':{'DEP':DL_deg},
               'hurdle':{'DEP':hurdle_deg}
               }

    com, idx1, idx2 = np.intersect1d(view_dlfq['Protein'].values, dlfq_deg, return_indices=True)
    dlfq_view_dlfq = np.array(view_dlfq.values[idx1, 2:], dtype=float)
    dt_dict['dlfq'].update({'fea':dlfq_view_dlfq.T})

    com, idx1, idx2 = np.intersect1d(view_maxlfq['Protein'].values, maxlfq_deg, return_indices=True)
    maxlfq_view_maxlfq = np.array(view_maxlfq.values[idx1, 2:], dtype=float)
    dt_dict['maxlfq'].update({'fea': maxlfq_view_maxlfq.T})

    com, idx1, idx2 = np.intersect1d(view_top3['Protein'].values, top3_deg, return_indices=True)
    top3_view_top3 = np.array(view_top3.values[idx1, 2:], dtype=float)
    dt_dict['top3'].update({'fea': top3_view_top3.T})

    com, idx1, idx2 = np.intersect1d(view_top1['Protein'].values, top1_deg, return_indices=True)
    top1_view_top1 = np.array(view_top1.values[idx1, 2:], dtype=float)
    dt_dict['top1'].update({'fea': top1_view_top1.T})

    DL_cat = []
    hurdle_cat = []
    for v in comb:
        combv = np.zeros((len(DL_deg), len(design['condition'].values)))
        combv[combv==0] = np.nan
        com, idx1, idx2 = np.intersect1d(dt_dict[v]['df']['Protein'].values, DL_deg, return_indices=True)
        combv[idx2, :] = dt_dict[v]['df'].values[idx1, 2:]
        DL_cat.append(np.array(combv.T, dtype=float))

        combv = np.zeros((len(hurdle_deg), len(design['condition'].values)))
        combv[combv == 0] = np.nan
        com, idx1, idx2 = np.intersect1d(dt_dict[v]['df']['Protein'].values, hurdle_deg, return_indices=True)
        combv[idx2, :] = dt_dict[v]['df'].values[idx1, 2:]
        hurdle_cat.append(np.array(combv.T, dtype=float))

    dt_dict['MVDEA'].update({'fea': DL_cat})
    dt_dict['hurdle'].update({'fea': hurdle_cat})

    sample_label = design['condition'].values
    sample_label_bin = (sample_label == g2).astype(int)

    dt_dict.update({'label':sample_label, 'label_bin':sample_label_bin})

    return dt_dict

def cluster_perform(data, label):
    k_means = []
    k_means = KMeans(n_clusters=len(np.unique(label)), random_state=2024)

    y = k_means.fit_predict(data)

    ARI = np.round(adjusted_rand_score(label, y), 4)
    ASW = np.round(silhouette_score(np.array([label]).T, np.array([y]).T), 4)
    NMI = np.round(normalized_mutual_info_score(label, y), 4)
    PS = np.round(purity_score(np.array([label]).T, y), 4)

    return [ARI, ASW, NMI, PS], y

def Fill_nan(data, fill_value):

    data[np.isnan(data)] = fill_value
    data = data[:, (data.min(axis=0) != data.max(axis=0))]
    return data

def clustering_all(data, best_fold, save_prefix, fill, flag=''):

    data_dis_dlfq = data['dlfq']['fea']
    data_dis_maxlfq = data['maxlfq']['fea']
    data_dis_top3 = data['top3']['fea']
    data_dis_top1 = data['top1']['fea']
    data_MVDEA_concat = np.concatenate(data['MVDEA']['fea'], axis=1)
    data_hurdle_concat = np.concatenate(data['hurdle']['fea'], axis=1)
    if data_MVDEA_concat.size == 0:
        return

    if fill == 0:
        data_dis_dlfq = Fill_nan(data_dis_dlfq, 0)#min(data_dis_dlfq[~np.isnan(data_dis_dlfq)]))
        data_dis_maxlfq = Fill_nan(data_dis_maxlfq, 0)#min(data_dis_maxlfq[~np.isnan(data_dis_maxlfq)]))
        data_dis_top3 = Fill_nan(data_dis_top3, 0)#min(data_dis_top3[~np.isnan(data_dis_top3)]))
        data_dis_top1 = Fill_nan(data_dis_top1, 0)#min(data_dis_top1[~np.isnan(data_dis_top1)]))

        data_MVDEA_concat = Fill_nan(data_MVDEA_concat, 0)#min(data_MVDEA_concat[~np.isnan(data_MVDEA_concat)]))
        data_hurdle_concat = Fill_nan(data_hurdle_concat, 0)#min(data_hurdle_concat[~np.isnan(data_hurdle_concat)]))
    elif fill =='min':
        data_dis_dlfq = Fill_nan(data_dis_dlfq,  min(data_dis_dlfq[~np.isnan(data_dis_dlfq)]))
        data_dis_maxlfq = Fill_nan(data_dis_maxlfq, min(data_dis_maxlfq[~np.isnan(data_dis_maxlfq)]))
        data_dis_top3 = Fill_nan(data_dis_top3, min(data_dis_top3[~np.isnan(data_dis_top3)]))
        data_dis_top1 = Fill_nan(data_dis_top1, min(data_dis_top1[~np.isnan(data_dis_top1)]))

        data_MVDEA_concat = Fill_nan(data_MVDEA_concat, min(data_MVDEA_concat[~np.isnan(data_MVDEA_concat)]))
        data_hurdle_concat = Fill_nan(data_hurdle_concat, min(data_hurdle_concat[~np.isnan(data_hurdle_concat)]))

    label_clu_tr = data['label_bin']

    seed_torch()

    per_dlfq_tr_noscale, y_dlfq_tr = cluster_perform(data_dis_dlfq, label_clu_tr)
    per_maxlfq_tr_noscale, y_maxlfq_tr = cluster_perform(data_dis_maxlfq, label_clu_tr)
    per_top3_tr_noscale, y_top3_tr = cluster_perform(data_dis_top3, label_clu_tr)
    per_top1_tr_noscale, y_top1_tr = cluster_perform(data_dis_top1, label_clu_tr)
    per_mvdea_tr_noscale, y_mvdea_tr = cluster_perform(data_MVDEA_concat, label_clu_tr)
    per_hurdle_tr_noscale, y_hurdle_tr = cluster_perform(data_hurdle_concat, label_clu_tr)

    pd.DataFrame(np.column_stack((data_dis_dlfq, label_clu_tr))).to_csv(save_prefix + data['data'] + flag + 'dlfq.csv', sep=',')
    pd.DataFrame(np.column_stack((data_dis_maxlfq, label_clu_tr))).to_csv(save_prefix + data['data'] + flag + 'maxlfq.csv', sep=',')
    pd.DataFrame(np.column_stack((data_dis_top3, label_clu_tr))).to_csv(save_prefix + data['data'] + flag + 'top3.csv', sep=',')
    pd.DataFrame(np.column_stack((data_dis_top1, label_clu_tr))).to_csv(save_prefix + data['data'] + flag + 'top1.csv', sep=',')
    pd.DataFrame(np.column_stack((data_MVDEA_concat, label_clu_tr))).to_csv(save_prefix + data['data'] + flag + best_fold + 'mvdea.csv', sep=',')
    pd.DataFrame(np.column_stack((data_hurdle_concat, label_clu_tr))).to_csv(save_prefix + data['data'] + flag + best_fold + 'hurdle.csv', sep=',')

    data_dis_dlfq_full = np.array(data['dlfq']['view'].T, dtype='float')
    dlfq_pro = list(data['dlfq']['df']['Protein'].values)

    data_dis_maxlfq_full = np.array(data['maxlfq']['view'].T, dtype='float')
    maxlfq_pro = list(data['maxlfq']['df']['Protein'].values)

    data_dis_top3_full = np.array(data['top3']['view'].T, dtype='float')
    top3_pro = list(data['top3']['df']['Protein'].values)

    data_dis_top1_full = np.array(data['top1']['view'].T, dtype='float')
    top1_pro = list(data['top1']['df']['Protein'].values)

    pd.DataFrame(np.column_stack((data_dis_dlfq_full, label_clu_tr)), columns=dlfq_pro + ['label']).to_csv(save_prefix + data['data'] + flag + 'dlfq_full.csv',
                                                                        sep=',')
    pd.DataFrame(np.column_stack((data_dis_maxlfq_full, label_clu_tr)), columns=maxlfq_pro + ['label']).to_csv(save_prefix + data['data'] + flag + 'maxlfq_full.csv',
                                                                          sep=',')
    pd.DataFrame(np.column_stack((data_dis_top3_full, label_clu_tr)), columns=top3_pro + ['label']).to_csv(save_prefix + data['data'] + flag + 'top3_full.csv',
                                                                        sep=',')
    pd.DataFrame(np.column_stack((data_dis_top1_full, label_clu_tr)), columns=top1_pro + ['label']).to_csv(save_prefix + data['data'] + flag + 'top1_full.csv',
                                                                        sep=',')

    if save_prefix != '':

        pd.DataFrame(np.array([per_dlfq_tr_noscale, per_maxlfq_tr_noscale, per_top3_tr_noscale, per_top1_tr_noscale,
                                 per_mvdea_tr_noscale, per_hurdle_tr_noscale]),
                       columns=['ARI', 'ASW', 'NMI', 'PS'],
                       index=['dlfq', 'maxlfq', 'top3', 'top1', 'MVDEA', 'hurdle']).to_csv(save_prefix + data['data'] +
                                                                                           '_clustering_performance_fill0_' +
                                                                                           best_fold + flag + '.csv', sep=',')

def get_test_fea(protein, view):

    protein_all = view['df']['Protein'].values
    pro, idx1, idx2 = np.intersect1d(protein, protein_all, return_indices=True)
    protein_view = np.array(view['df'].values[idx2, 2:], dtype=float)

    return pro, protein_view

def train_test_clustering(train_dict, test_dict, comb, save_prefix, fill):

    train_DEP_dlfq = train_dict['dlfq']['DEP']
    train_DEP_maxlfq = train_dict['maxlfq']['DEP']
    train_DEP_top3 = train_dict['top3']['DEP']
    train_DEP_top1 = train_dict['top1']['DEP']

    train_DEP_MVDEA = train_dict['MVDEA']['DEP']
    train_DEP_hurdle = train_dict['hurdle']['DEP']

    pro_dlfq, fea_test_dlfq = get_test_fea(train_DEP_dlfq, test_dict['dlfq'])
    pro_maxlfq, fea_test_maxlfq = get_test_fea(train_DEP_maxlfq, test_dict['maxlfq'])
    pro_top3, fea_test_top3 = get_test_fea(train_DEP_top3, test_dict['top3'])
    pro_top1, fea_test_top1 = get_test_fea(train_DEP_top1, test_dict['top1'])

    DL_cat = []
    hurdle_cat = []
    for v in comb:
        combv = np.zeros((len(train_DEP_MVDEA), len(test_dict['design']['condition'].values)))
        combv[combv == 0] = np.nan
        com, idx1, idx2 = np.intersect1d(test_dict[v]['df']['Protein'].values, train_DEP_MVDEA, return_indices=True)
        combv[idx2, :] = test_dict[v]['df'].values[idx1, 2:]
        DL_cat.append(np.array(combv.T, dtype=float))

        combv = np.zeros((len(train_DEP_hurdle), len(test_dict['design']['condition'].values)))
        combv[combv == 0] = np.nan
        com, idx1, idx2 = np.intersect1d(test_dict[v]['df']['Protein'].values, train_DEP_hurdle, return_indices=True)
        combv[idx2, :] = test_dict[v]['df'].values[idx1, 2:]
        hurdle_cat.append(np.array(combv.T, dtype=float))

    data_MVDEA_concat = np.concatenate(DL_cat, axis=1)
    data_hurdle_concat = np.concatenate(hurdle_cat, axis=1)
    if data_MVDEA_concat.size == 0:
        return

    if fill == 0:
        data_dis_dlfq = Fill_nan(fea_test_dlfq, 0)
        data_dis_maxlfq = Fill_nan(fea_test_maxlfq, 0)
        data_dis_top3 = Fill_nan(fea_test_top3, 0)
        data_dis_top1 = Fill_nan(fea_test_top1, 0)
        data_MVDEA_concat = Fill_nan(data_MVDEA_concat, 0)
        data_hurdle_concat = Fill_nan(data_hurdle_concat, 0)

    elif fill == 'min':
        data_dis_dlfq = Fill_nan(fea_test_dlfq, min(fea_test_dlfq[~np.isnan(fea_test_dlfq)]))
        data_dis_maxlfq = Fill_nan(fea_test_maxlfq, min(fea_test_maxlfq[~np.isnan(fea_test_maxlfq)]))
        data_dis_top3 = Fill_nan(fea_test_top3, min(fea_test_top3[~np.isnan(fea_test_top3)]))
        data_dis_top1 = Fill_nan(fea_test_top1, min(fea_test_top1[~np.isnan(fea_test_top1)]))
        data_MVDEA_concat = Fill_nan(data_MVDEA_concat, min(data_MVDEA_concat[~np.isnan(data_MVDEA_concat)]))
        data_hurdle_concat = Fill_nan(data_hurdle_concat, min(data_hurdle_concat[~np.isnan(data_hurdle_concat)]))

    label_clu_tr = test_dict['label_bin']

    seed_torch()

    per_dlfq_tr_noscale, y_dlfq_tr = cluster_perform(data_dis_dlfq.T, label_clu_tr)
    per_maxlfq_tr_noscale, y_maxlfq_tr = cluster_perform(data_dis_maxlfq.T, label_clu_tr)
    per_top3_tr_noscale, y_top3_tr = cluster_perform(data_dis_top3.T, label_clu_tr)
    per_top1_tr_noscale, y_top1_tr = cluster_perform(data_dis_top1.T, label_clu_tr)
    per_mvdea_tr_noscale, y_mvdea_tr = cluster_perform(data_MVDEA_concat, label_clu_tr)
    per_hurdle_tr_noscale, y_hurdle_tr = cluster_perform(data_hurdle_concat, label_clu_tr)

    pd.DataFrame(np.column_stack((data_dis_dlfq, label_clu_tr))).to_csv(save_prefix + data['data'] + flag + 'dlfq_test.csv',
                                                                        sep=',')
    pd.DataFrame(np.column_stack((data_dis_maxlfq, label_clu_tr))).to_csv(
        save_prefix + data['data'] + flag + 'maxlfq_test.csv', sep=',')
    pd.DataFrame(np.column_stack((data_dis_top3, label_clu_tr))).to_csv(save_prefix + data['data'] + flag + 'top3_test.csv',
                                                                        sep=',')
    pd.DataFrame(np.column_stack((data_dis_top1, label_clu_tr))).to_csv(save_prefix + data['data'] + flag + 'top1_test.csv',
                                                                        sep=',')
    pd.DataFrame(np.column_stack((data_MVDEA_concat, label_clu_tr))).to_csv(
        save_prefix + data['data'] + flag + best_fold + 'mvdea_test.csv', sep=',')
    pd.DataFrame(np.column_stack((data_hurdle_concat, label_clu_tr))).to_csv(
        save_prefix + data['data'] + flag + best_fold + 'hurdle_test.csv', sep=',')

    if save_prefix != '':

        pd.DataFrame(np.array([per_dlfq_tr_noscale, per_maxlfq_tr_noscale, per_top3_tr_noscale, per_top1_tr_noscale,
                                 per_mvdea_tr_noscale, per_hurdle_tr_noscale]),
                       columns=['ARI', 'ASW', 'NMI', 'PS'],
                       index=['dlfq', 'maxlfq', 'top3', 'top1', 'MVDEA', 'hurdle']).to_csv(save_prefix + 'train_DEP_test_clustering_perform.csv', sep=',')

if __name__ == '__main__':

    current_fold = os.path.dirname(__file__) + '/'
    parent_fold = os.path.dirname(os.path.dirname(current_fold))

    for dt_name in ['U2OS_filtered_rb', 'TPD_dis', 'TPD_ret']:
        views_names_all = ['dlfq', 'maxlfq', 'top3', 'top1']
        for view_num in range(2, len(views_names_all) + 1):
            combs = np.array(list(combinations([x for x in range(len(views_names_all))], view_num)))
            for comb_idx in range(len(combs)):
                view_idx = combs[comb_idx, :]
                view_names = list(np.array(views_names_all)[view_idx])
                best_fold = 'DIA'
                for v in view_names:
                    best_fold += '_' + v
                if dt_name == 'TPD_dis':

                    raw_fold = parent_fold + '/data/case_study_views/TPD_views/dis/'
                    sub_fold = 'TPD_dis_filter_all08'
                    all_fold = 'DIA_dlfq_maxlfq_top3_top1'
                    logthre = np.log2(2)
                    qthre = 0.01
                    dlfq_logT = 'F'
                    post = '.csv'
                    g1 = 'B'
                    g2 = 'M'
                    flag = ''
                    scale = -1

                elif dt_name == 'TPD_ret':

                    raw_fold =  parent_fold + '/data/case_study_views/TPD_views/ret/'
                    sub_fold = 'TPD_ret_filter_all08'
                    all_fold = 'DIA_dlfq_maxlfq_top3_top1'
                    logthre = np.log2(2)
                    qthre = 0.01
                    dlfq_logT = 'F'
                    post = '.csv'
                    g1 = 'B'
                    g2 = 'M'
                    flag = ''
                    scale = -1

                elif dt_name == 'U2OS_filtered_rb':

                    raw_fold = parent_fold + '/data/case_study_views/U2OS/single_cell/U2OS_scp/U2OS_rb/'
                    sub_fold = 'U2OS_filter_all08_rb'
                    all_fold = 'DIA_dlfq_maxlfq_top3_top1'
                    logthre = np.log2(1.5)
                    qthre = 0.05
                    dlfq_logT = 'F'
                    post = '.tsv'
                    g1 = 'Control'
                    g2 = 'IFNy'
                    flag = ''
                    scale = -1

                method = 'DP_fdr'
                fill = 0
                save_prefix = current_fold + 'res/clustering/'
                if not os.path.exists(save_prefix):
                    os.path.mkdir(save_prefix)

                dt_dict = load_data(dt_name, raw_fold, sub_fold, best_fold, all_fold, logthre, qthre, dlfq_logT, post, g1, g2, method, scale)
                seed_torch()
                clustering_all(dt_dict, best_fold, save_prefix, fill, flag=flag)


    # # using TPD_dis DEP to test the clustering in TPD_ret
    best_fold = 'DIA_dlfq_maxlfq_top3'
    method = 'DP_fdr'
    comb = ['dlfq', 'maxlfq', 'top3']
    save_prefix = current_fold + 'res/clustering/'
    if not os.path.exists(save_prefix):
        os.path.mkdir(save_prefix)


    dt_name = 'TPD_dis'
    raw_fold = parent_fold + '/data/case_study_views/TPD_views/dis/'
    sub_fold = 'TPD_dis_filter_all08'
    all_fold = 'DIA_dlfq_maxlfq_top3_top1'
    logthre = np.log2(2)
    qthre = 0.01
    dlfq_logT = 'F'
    post = '.csv'
    g1 = 'B'
    g2 = 'M'
    flag = ''
    scale = -1

    dt_dict_train = load_data(dt_name, raw_fold, sub_fold, best_fold, all_fold, logthre, qthre, dlfq_logT, post, g1, g2,
                        method, scale)
    dt_name = 'TPD_ret'

    raw_fold = parent_fold + '/data/case_study_views/TPD_views/ret/'
    sub_fold = 'TPD_ret_filter_all08'
    all_fold = 'DIA_dlfq_maxlfq_top3_top1'
    logthre = np.log2(2)
    qthre = 0.01
    dlfq_logT = 'F'
    post = '.csv'
    g1 = 'B'
    g2 = 'M'
    flag = ''
    scale = -1
    fill = 0

    dt_dict_test = load_data(dt_name, raw_fold, sub_fold, best_fold, all_fold, logthre, qthre, dlfq_logT, post, g1, g2,
                              method, scale)

    train_test_clustering(dt_dict_train, dt_dict_test, comb, save_prefix, fill)

