#######################################################################
#### this is the code for reproduce the figures in manuscript and the Supplementary Notes
# 1. distribution of complementary analysis of different views (& DEA results)
# 2. visualization of DEPs detected by different single views and hurdle ()
# 3. visualization of deepDEA model
######################################################################

# we prepared a python script for calculating the complementarity features between the views
# The three metrics that we shown in Figure 1 are parts of the complementarity features

# load the whole complementarity features
#  if the package "this.path" has not been install please installed
# install.packages("this.path", repos = "https://cloud.r-project.org")
library("this.path", character.only = TRUE)
library("readxl")
library(ggplot2)
library(reshape2)
library(ggpubr)
library(cowplot)


script_path <- this.path()
script_dir <- dirname(script_path)
parent_fold<-dirname(script_dir)
root_fold<-paste0(parent_fold, '/Comlementary_feature_extraction/res/complementary_feas/')

save_fold<-paste0(script_dir, '/res/')
if(!dir.exists(save_fold)){
  dir.create(save_fold, recursive = TRUE)
}

compl_fea_all<-read.table(paste0(root_fold, 'complementary_feas_benchmark.csv'), sep = ',', header = T)
if(length(grep('mr_reduce', colnames(compl_fea_all)))==0){
  mr_reduce<-apply(as.matrix(compl_fea_all[, c(27:32)]), 1, min)-compl_fea_all[, 33]
  compl_fea_all<-cbind(compl_fea_all, mr_reduce)
}


feas_paired<-compl_fea_all[which(compl_fea_all$view_num==2),]
DDA_feas<-feas_paired[which(feas_paired$dea=='limma' & feas_paired$acq=='DDA'),]
DDA_feas$view_name<-gsub('DDA_', '',DDA_feas$view_name,fixed = T)
plot_DDA_feas<-data.frame(views=DDA_feas$view_name, platform=DDA_feas$platform, view_pearson=1-DDA_feas$v_cr_pro, missing_complementary=2*DDA_feas$v_miss, DEA_pearson = 1-DDA_feas$d_cr)
plot_data_DDA<-melt(plot_DDA_feas, id=c('views', 'platform'))
colnames(plot_data_DDA)[3]<-'Complementarity'

pairs = unique(plot_DDA_feas$views)
plts = unique(plot_DDA_feas$platform)
stats<-vector()
for (pair in pairs) {
  for (plt in plts) {
    
  
  pair_fea<-plot_DDA_feas[which(plot_DDA_feas$views == pair & plot_DDA_feas$platform == plt),]
  max_r = max(pair_fea$view_pearson)
  min_r = min(pair_fea$view_pearson)
  mean_r = mean(pair_fea$view_pearson)
  median_r = median(pair_fea$view_pearson)
  sd_r = sd(pair_fea$view_pearson)
  
  max_mr = max(pair_fea$missing_complementary)
  min_mr = min(pair_fea$missing_complementary)
  mean_mr = mean(pair_fea$missing_complementary)
  median_mr = median(pair_fea$missing_complementary)
  sd_mr = sd(pair_fea$missing_complementary)
  
  max_dr = max(pair_fea$DEA_pearson)
  min_dr = min(pair_fea$DEA_pearson)
  mean_dr = mean(pair_fea$DEA_pearson)
  median_dr = median(pair_fea$DEA_pearson)
  sd_dr = sd(pair_fea$DEA_pearson)
  
  stat<-c(pair, plt, max_r, min_r, mean_r, median_r, sd_r, max_mr, min_mr, mean_mr,
          median_mr, sd_mr, max_dr, min_dr, mean_dr, median_dr, sd_dr)
  stats<-rbind(stats, stat)
  }
}

colnames(stats)<-c('pair', 'plt', 'max_r', 'min_r', 'mean_r', 'median_r', 'sd_r', 'max_mr', 'min_mr', 'mean_mr',
                   'median_mr', 'sd_mr', 'max_dr', 'min_dr', 'mean_dr', 'median_dr', 'sd_dr')
write.table(plot_DDA_feas, paste0(save_fold, 'dda_complementary_all.csv'), col.names = T, row.names = F, sep = ',')
write.table(stats, paste0(save_fold, 'dda_complementary_pair_Stats.csv'), col.names = T, row.names = F, sep = ',')


fill_colors <- c(
  "#1b9e77",
  "#d95f02",
  "#7570b3"
)

platform_colors <- c(
  "#e41a1c",
  "#377eb8"
)

DDA_fea <- ggboxplot(
  plot_data_DDA,
  x = "views",
  y = "value",
  color = "platform",
  fill = "Complementarity",
  width = 0.7,
  size = 0.8,
  alpha = 0.7,
  palette = platform_colors,
  add = "jitter",
  add.params = list(alpha = 0.5, size = 0.5),
  title = "Complementarity measurement between DDA views"
) +
  labs(x = "View combination", y = "Complementarity") +
  scale_fill_manual(values = fill_colors) +  # 显式设定 fill 色板
  scale_x_discrete(limits = unique(plot_data_DDA$views)) +
  scale_y_continuous(limits = c(min(plot_data_DDA$value - 0.05), 
                                max(plot_data_DDA$value + 0.05))) +
  theme_classic(base_family = "Times New Roman") +
  theme(
    plot.title = element_text(size = 14, hjust = 0.5, face = "bold"),
    axis.title.y = element_text(size = 13, face = "bold"),
    axis.title.x = element_text(size = 12),
    axis.text.x = element_text(size = 10, face = "bold", angle = 45, hjust = 1),
    axis.text.y = element_text(size = 10, face = "bold"),
    legend.title = element_text(size = 12, face = "bold"),
    legend.text = element_text(size = 10),
    legend.position = "right"
  ) 
DDA_fea

############

DIA_feas<-feas_paired[which(feas_paired$dea=='limma' & feas_paired$acq=='DIA'),]
DIA_feas$view_name<-gsub('DIA_', '',DIA_feas$view_name,fixed = T)
plot_DIA_feas<-data.frame(views=DIA_feas$view_name, platform=DIA_feas$platform, view_pearson=1-DIA_feas$v_cr_pro, missing_complementary=2*DIA_feas$v_miss, DEA_pearson = 1-DIA_feas$d_cr)
plot_data_DIA<-melt(plot_DIA_feas, id=c('views', 'platform'))
colnames(plot_data_DIA)[3]<-'Complementarity'

pairs = unique(plot_DIA_feas$views)
plts = unique(plot_DIA_feas$platform)
stats<-vector()
for (pair in pairs) {
  for (plt in plts) {
  
    pair_fea<-plot_DIA_feas[which(plot_DIA_feas$views == pair & plot_DIA_feas$platform == plt),]

  max_r = max(pair_fea$view_pearson)
  min_r = min(pair_fea$view_pearson)
  mean_r = mean(pair_fea$view_pearson)
  median_r = median(pair_fea$view_pearson)
  sd_r = sd(pair_fea$view_pearson)
  
  max_mr = max(pair_fea$missing_complementary)
  min_mr = min(pair_fea$missing_complementary)
  mean_mr = mean(pair_fea$missing_complementary)
  median_mr = median(pair_fea$missing_complementary)
  sd_mr = sd(pair_fea$missing_complementary)
  
  max_dr = max(pair_fea$DEA_pearson)
  min_dr = min(pair_fea$DEA_pearson)
  mean_dr = mean(pair_fea$DEA_pearson)
  median_dr = median(pair_fea$DEA_pearson)
  sd_dr = sd(pair_fea$DEA_pearson)
  
  stat<-c(pair, plt, max_r, min_r, mean_r, median_r, sd_r, max_mr, min_mr, mean_mr,
          median_mr, sd_mr, max_dr, min_dr, mean_dr, median_dr, sd_dr)
  stats<-rbind(stats, stat)
  }
}
colnames(stats)<-c('pair', 'plt', 'max_r', 'min_r', 'mean_r', 'median_r', 'sd_r', 'max_mr', 'min_mr', 'mean_mr',
                   'median_mr', 'sd_mr', 'max_dr', 'min_dr', 'mean_dr', 'median_dr', 'sd_dr')
write.table(plot_DIA_feas, paste0(save_fold, 'dia_complementary_all.csv'), col.names = T, row.names = F, sep = ',')
write.table(stats, paste0(save_fold, 'dia_complementary_pair_Stats.csv'), col.names = T, row.names = F, sep = ',')


DIA_fea <- ggboxplot(
  plot_data_DIA,
  x = "views",
  y = "value",
  color = "platform",
  fill = "Complementarity",
  width = 0.7,
  size = 0.8,
  alpha = 0.7,
  palette = platform_colors,
  add = "jitter",
  add.params = list(alpha = 0.5, size = 0.5),
  title = "Complementarity measurement between DIA views"
) +
  labs(x = "View combination", y = "Complementarity") +
  scale_fill_manual(values = fill_colors) +  # 显式设定 fill 色板
  scale_x_discrete(limits = unique(plot_data_DIA$views)) +
  scale_y_continuous(limits = c(min(plot_data_DIA$value - 0.05), 
                                max(plot_data_DIA$value + 0.05))) +
  theme_classic(base_family = "Times New Roman") +
  theme(
    plot.title = element_text(size = 14, hjust = 0.5, face = "bold"),
    axis.title.y = element_text(size = 13, face = "bold"),
    axis.title.x = element_text(size = 12),
    axis.text.x = element_text(size = 10, face = "bold", angle = 45, hjust = 1),
    axis.text.y = element_text(size = 10, face = "bold"),
    legend.title = element_text(size = 12, face = "bold"),
    legend.text = element_text(size = 10),
    legend.position = "right"
  ) 
DIA_fea

################# upset or venn for showing complementary in DEP detection
root_fold_case<-paste0(script_dir,'/HYEtims735_DIA/')
DEA_res<-read.table(paste0(root_fold_case, 'HYEtims735_DIA_DP_res_all.csv'),sep = ',', header = T)

DEPs<-list(dlfq=DEA_res$Protein[which(DEA_res$lab_DPdlfq==1)],
           maxlfq=DEA_res$Protein[which(DEA_res$lab_DPmaxlfq==1)],
           top3=DEA_res$Protein[which(DEA_res$lab_DPtop3==1)],
           top1=DEA_res$Protein[which(DEA_res$lab_DPtop1==1)],
           DEPs=DEA_res$Protein[which(DEA_res$True_lab==1)])
library(VennDiagram)
library(ggVennDiagram)
library("readxl")
library(ggplot2)
library(reshape2)
library(ggpubr)
library(cowplot)
set.seed(123)
nature_palette <- c("#E64B35FF", "#4DBBD5FF", "#00A087FF", "#3C5488FF", "#F39B7FFF")

ggVennDiagram(
  DEPs,
  label_alpha = 0,          
  label = "count",          
  set_color = nature_palette
) +
  scale_fill_gradient(low = "#FFFFFF", high = "#E64B35") +
  theme_void(base_size = 14) +                          
  theme(
    legend.position = "none",                                
    plot.title = element_text(size = 16, face = "bold", hjust = 0.5)
  ) 


input_lists<-DEPs
all_items <- unique(unlist(input_lists))


binary_matrix <- matrix(
  0,
  nrow = length(all_items),
  ncol = length(input_lists),
  dimnames = list(all_items, names(input_lists)) 
)


for (i in seq_along(input_lists)) {
  current_list <- input_lists[[i]]
  binary_matrix[current_list, i] <- 1
}
print(binary_matrix)
write.table(binary_matrix, paste0(save_fold, 'venn_plot_DEP_lists.csv'), sep = ',', row.names = T, col.names = T)
