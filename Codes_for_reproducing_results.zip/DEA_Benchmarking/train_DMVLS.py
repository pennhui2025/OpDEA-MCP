import copy
import time
import os
import random
import numpy as np
import torch
from model import ASMVL
from tqdm import tqdm
import torch.nn.functional as F
import torch.nn as nn
from sklearn.model_selection import StratifiedShuffleSplit
import heapq
import math
from sklearn.metrics import accuracy_score as acc, recall_score as recall, precision_score as precision, f1_score as f1, matthews_corrcoef as mcc, roc_auc_score


def seed_torch(seed=1029):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.cuda.manual_seed(seed)


seed_torch()

def train(view_data, pro_lab, param, device):
    fea, labels, num_view, dimension = view_data, pro_lab, len(view_data), [len(view_data[0][0, :])] * len(view_data)
    num_classes = len(np.unique(pro_lab[pro_lab != -1]))
    sample_num = labels.shape[0]
    labels = torch.from_numpy(labels).to(device).long()
    hid_d=[param['h0'], param['h0'], param['h1'], param['h1'], param['h2'], param['h2']]

    real_label_ratio = len(pro_lab[pro_lab != -1])/len(pro_lab)

    each_fea = []
    for v in range(num_view):
        each_fea.append(torch.from_numpy(fea[v]).to(device).float())

    real_unlabel_index = np.where((pro_lab[:, 0] == -1))[0]
    unlabel_index = copy.deepcopy(real_unlabel_index)
    label_index = np.where((pro_lab[:, 0] != -1))[0]
    train_label = labels.cpu().numpy()
    train_label = torch.tensor(train_label)
    train_label = train_label.to(device)

    this_ratio = real_label_ratio
    model = ASMVL(num_classes, num_view, dimension, hid_d, device).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=param['lr'], weight_decay=1e-4)
    epoch_max = 100
    top_ratio = 0.01
    select_each_ratio = 0.025
    for cnttt in range(200):
        if this_ratio > real_label_ratio + (1 - real_label_ratio) / 2:
            cnttt = cnttt - 1
            break
        loss_doc=[]
        with tqdm(total=epoch_max, desc="Training") as pbar:
            for epoch in range(epoch_max):

                loss_total=0
                model.train()
                optimizer.zero_grad()

                time1 = time.time()
                specific_fea_de_lay2, view_class_specific_res, view_class_share_res, label_class_specific_res, label_class_share_res, _, _ = model(
                    each_fea)

                #encoder_decoder_loss
                loss1 = nn.MSELoss()
                each_fea1 = torch.cat(each_fea, dim=1)
                specific_fea_de_lay2 = torch.cat(specific_fea_de_lay2, dim=1)
                ed_loss = loss1(each_fea1, specific_fea_de_lay2)
                del each_fea1, specific_fea_de_lay2

                #classfy_view_loss
                view_loss=0
                for v in range(num_view):
                    tmp_label = torch.zeros((sample_num,num_view), dtype=torch.float, device='cuda:0')
                    tmp_label[:,v]=1.0
                    view_loss=view_loss+F.kl_div(view_class_specific_res[v].softmax(dim=-1).log(), tmp_label.softmax(dim=-1), reduction='sum')
                tmp_label=torch.ones((sample_num,num_view), dtype=torch.float, device='cuda:0')/num_view
                view_loss=view_loss+F.kl_div(view_class_share_res.softmax(dim=-1).log(), tmp_label.softmax(dim=-1), reduction='sum')

                #label_loss
                label_loss=0

                real_label = torch.zeros((label_index.shape[0], num_classes), dtype=torch.float, device='cuda:0')
                for num in range(label_index.shape[0]):
                    real_label[num, train_label[label_index[num]]] = 1

                label_loss = F.kl_div(label_class_specific_res[label_index].softmax(dim=-1).log(), real_label, reduction='sum') + F.kl_div( label_class_share_res[label_index].softmax(dim=-1).log(), real_label, reduction='sum')
                loss_total = ed_loss + param['lam1'] * view_loss + param['lam2'] * label_loss

                loss_total.backward()
                optimizer.step()
                loss_doc.append(loss_total.item())

                pbar.update(1)

        with torch.no_grad():
            model.eval()

            add_pseudo=[]
            class_sample=[]
            for k in range(num_classes):
                class_sample.append([])
            for num in range(label_index.shape[0]):
                class_sample[labels[label_index[num]]].append(label_index[num])
            max_value1=[]
            max_value2 = []
            _, _, _, label_class_specific_res, label_class_share_res, specific_con, share_fea = model(each_fea)
            label_class_specific_res=label_class_specific_res[unlabel_index].softmax(dim=-1)
            label_class_share_res=label_class_share_res[unlabel_index].softmax(dim=-1)

            cnt=0
            all=0
            tenporary=[]
            for num in range(unlabel_index.shape[0]):
                which1 = torch.argmax(label_class_specific_res[num])
                which2 = torch.argmax(label_class_share_res[num])
                if which1==which2:
                    add_pseudo.append(unlabel_index[num])
                    tenporary.append(num)
                    max_value1.append(max(label_class_specific_res[num]))
                    max_value2.append(max(label_class_share_res[num]))
            top_number = min(round(sample_num*top_ratio), len(add_pseudo))
            value1 = heapq.nlargest(top_number, max_value1)
            value2 = heapq.nlargest(top_number, max_value2)

            psudo_add=[]
            pre_l=[]

            top_ratio=min(top_ratio, 0.2)
            for num in range(len(add_pseudo)):
                if max_value1[num] in value1 and max_value2[num] in value2:
                    cnt = cnt + 1
                    psudo_add.append(add_pseudo[num])
                    pre_l.append(torch.argmax(label_class_specific_res[tenporary[num]]))
                    if torch.argmax(label_class_specific_res[tenporary[num]])== labels[add_pseudo[num]]:
                        all = all + 1

            max_res=[]

            for num in range(unlabel_index.shape[0]):
                max_res.append(max(label_class_specific_res[num])*max(label_class_share_res[num]))
            min_number=min(round(sample_num*select_each_ratio),unlabel_index.shape[0])
            min_value = heapq.nsmallest(min_number, max_res)
            select_sample=[]
            if min_number>=0:
                for num in range(unlabel_index.shape[0]):
                    if max_res[num] in  min_value:
                        select_sample.append(unlabel_index[num])
                for num in range(len(select_sample)):
                    unlabel_index = np.delete(unlabel_index, np.where((unlabel_index == select_sample[num])))
                    real_unlabel_index = np.delete(real_unlabel_index,
                                                   np.where((real_unlabel_index == select_sample[num])))
                    label_index = np.append(label_index, values=select_sample[num])

            if len(psudo_add)>0  and this_ratio>=0.175:
                top_ratio = top_ratio + 0.0015
                print(top_ratio)
                for num in range(len(psudo_add)):
                    train_label[psudo_add[num]]=pre_l[num]
                    unlabel_index = np.delete(unlabel_index, np.where((unlabel_index == psudo_add[num])))
                    label_index = np.append(label_index, values=psudo_add[num])
            this_ratio = this_ratio + select_each_ratio
            tmp_epoch = epoch_max-15
            epoch_max = max(150, tmp_epoch)

    specific_fea_de_lay2, view_class_specific_res, view_class_share_res, label_class_specific_res, label_class_share_res, _, _ = model(
        each_fea)

    class_res = torch.max(label_class_specific_res.softmax(dim=-1), label_class_share_res.softmax(dim=-1))
    pred_lab = torch.argmax(class_res, dim=1).detach().cpu().numpy()
    probs = class_res.detach().cpu().numpy()[:, 1]
    Mcc = mcc(pred_lab[pro_lab[:, 0]!=-1], pro_lab[pro_lab!=-1])
    probs[np.isnan(probs)] = 0
    pred_lab[np.isnan(pred_lab)] = 0
    auc = roc_auc_score(pro_lab[pro_lab!=-1], probs[pro_lab[:,0]!=-1])
    print('AUC='+str(auc) + ' || mcc='+str(Mcc))
    return class_res, model, Mcc, auc