import argparse

import numpy as np
import torch
from tqdm import tqdm
import torch.optim as optim
from sklearn.metrics import accuracy_score, f1_score as f1, matthews_corrcoef as mcc, roc_auc_score
from models.TMC_DEA import ETMC, ce_loss
import torchvision.transforms as transforms
from aligned_conc_dataset import AlignedConcDataset
from utils.utils import *
from utils.logger import create_logger
import os
from torch.utils.data import TensorDataset, DataLoader


def model_forward(i_epoch, model, ce_loss, batch, numclass, annealing_epoch):
    pro_labs = batch[-1]

    del batch[-1]
    data = batch

    alphas, pseudo_alpha, alpha_all = model(data)

    loss = 0
    for i in range(len(alphas)):
        loss += ce_loss(pro_labs, alphas[i], numclass, i_epoch, annealing_epoch)

    loss += ce_loss(pro_labs, pseudo_alpha, numclass, i_epoch, annealing_epoch)

    loss += ce_loss(pro_labs, alpha_all, numclass, i_epoch, annealing_epoch)

    return loss, alphas, pseudo_alpha, alpha_all, pro_labs


def model_eval(i_epoch, data, model, criterion, numclass, annealing_epoch, nview):
    model.eval()
    with torch.no_grad():
        losses, combine_preds = [], []
        view_preds = [[] for v in range(nview)]
        tgts = []
        view_alphas = [[] for v in range(nview)]
        alpha_alls = []
        view_probs = [[] for v in range(nview)]
        prob_combine = []
        for b, batch in enumerate(data):
            loss, alpha, pseudo_alpha, alpha_all, tgt = model_forward(i_epoch, model, criterion, batch, numclass, annealing_epoch)
            losses.append(loss.item())

            view_pred = [alpha[v].argmax(dim=1).cpu().detach().numpy() for v in range(len(alpha))]
            for v in range(nview):
                view_preds[v].extend(view_pred[v])
                view_alphas[v].extend(alpha[v])

                view_prob = torch.nn.Softmax(dim=1)(alpha[v]).cpu().detach().numpy()
                view_probs[v].extend(view_prob)

            alpha_alls.extend(alpha_all)
            combine_pred = alpha_all.argmax(dim=1).cpu().detach().numpy()
            combine_preds.extend(combine_pred)
            prob_combine.extend(torch.nn.Softmax(dim=1)(alpha_all).cpu().detach().numpy())
            tgt = tgt.cpu().detach().numpy()
            tgts.extend(tgt)

    metrics = {"loss": np.mean(losses)}
    if len(np.unique(tgts))==1:
        metrics["view_acc"] = 0
        metrics["combine_acc"] = 0
        metrics["view_mcc"] = 0
        metrics["combine_mcc"] = 0
        metrics["view_f1"] = 0
        metrics["combine_f1"] = 0
        metrics["view_auc"] = 0
        metrics["combine_auc"] = 0
    else:
        metrics["view_acc"] = [accuracy_score(tgts, view_preds[v]) for v in range(nview)]
        metrics["combine_acc"] = accuracy_score(tgts, combine_preds)
        metrics["view_mcc"] = [mcc(tgts, view_preds[v]) for v in range(nview)]
        metrics["combine_mcc"] = mcc(tgts, combine_preds)
        metrics["view_f1"] = [f1(tgts, view_preds[v]) for v in range(nview)]
        metrics["combine_f1"] = f1(tgts, combine_preds)
        metrics["view_auc"] = [roc_auc_score(tgts, np.array(view_probs[v])[:,1]) for v in range(nview)]
        metrics["combine_auc"] = roc_auc_score(tgts, np.array(prob_combine)[:, 1])
    metrics['view_preds'] = view_preds
    metrics['all_preds'] = np.array(combine_preds)
    metrics['view_alpha'] = view_alphas
    metrics['all_aplha'] = alpha_alls
    metrics['all_prob'] = np.array(prob_combine)
    return metrics


def train(view_data, pro_lab, param, device):
    set_seed(2025)

    annealing_epoch = 10
    nview = len(view_data)
    in_dim = len(view_data[0][0, :])
    numclass = len(np.unique(pro_lab[np.where((pro_lab != -1))[0]]))
    view_data_tensor = [torch.from_numpy(view_data[t]).to(device).float() for t in range(len(view_data))]
    Train_data = TensorDataset(*view_data_tensor, torch.from_numpy(pro_lab[:, 0]).to(device).long())
    train_loader = DataLoader(Train_data, batch_size=param['bs'], shuffle=True, drop_last=False)

    h_dim, h_dim1, h_dim2, lat_dim = param['h0'], param['h1'], param['h2'], param['ld_ae']

    model = ETMC(in_dim, h_dim, h_dim1, h_dim2, lat_dim, numclass, nview)
    optimizer = optim.Adam(model.parameters(), lr=param['lr'], weight_decay=1e-4)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=100)

    model.cuda()

    for i_epoch in range(100):

        model.train()
        optimizer.zero_grad()
        for b, batch in enumerate(train_loader):
            loss, alphas, pseudo_alpha, alpha_all, pro_labs = model_forward(i_epoch, model, ce_loss, batch, numclass, annealing_epoch)
            loss.backward()
            optimizer.step()
            scheduler.step()
    return model
