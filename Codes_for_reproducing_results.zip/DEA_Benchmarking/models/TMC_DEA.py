import torch
import torch.nn as nn
#from models.image import ImageEncoder
import torch.nn.functional as F

class Encoder(nn.Module):
    """带稀疏约束和特征选择的自编码器"""

    def __init__(self, in_dim, h_dim, lat_dim, dropout=0.2):
        super().__init__()

        self.encoder = nn.Sequential(
            nn.Linear(in_dim, h_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(h_dim, lat_dim)
        )

    def forward(self, x):
        lat = self.encoder(x)
        return lat


# loss function
def KL(alpha, c):
    beta = torch.ones((1, c)).cuda()
    S_alpha = torch.sum(alpha, dim=1, keepdim=True)
    S_beta = torch.sum(beta, dim=1, keepdim=True)
    lnB = torch.lgamma(S_alpha) - torch.sum(torch.lgamma(alpha), dim=1, keepdim=True)
    lnB_uni = torch.sum(torch.lgamma(beta), dim=1, keepdim=True) - torch.lgamma(S_beta)
    dg0 = torch.digamma(S_alpha)
    dg1 = torch.digamma(alpha)
    kl = torch.sum((alpha - beta) * (dg1 - dg0), dim=1, keepdim=True) + lnB + lnB_uni
    return kl

def ce_loss(p, alpha, c, global_step, annealing_step):
    S = torch.sum(alpha, dim=1, keepdim=True)
    E = alpha - 1
    label = F.one_hot(p, num_classes=c)
    A = torch.sum(label * (torch.digamma(S) - torch.digamma(alpha)), dim=1, keepdim=True)

    annealing_coef = min(1, global_step / annealing_step)
    alp = E * (1 - label) + 1
    B = annealing_coef * KL(alp, c)
    return torch.mean((A + B))


class TMC(nn.Module):
    def __init__(self, in_dim, h_dim, h_dim1, lat_dim, numclass, nview, dropout=0.2):
        super(TMC, self).__init__()
        self.enc_list = nn.ModuleList([Encoder(in_dim, h_dim, lat_dim) for i in range(nview)])
        self.clf = nn.Sequential(
            nn.Linear(lat_dim, h_dim1),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(h_dim1, numclass)
        )
        self.clf_views = nn.ModuleList([self.clf for i in range(nview)])
        self.n_classes = numclass

    def DS_Combin_two(self, alpha1, alpha2):
        # Calculate the merger of two DS evidences
        alpha = dict()
        alpha[0], alpha[1] = alpha1, alpha2
        b, S, E, u = dict(), dict(), dict(), dict()
        for v in range(2):
            S[v] = torch.sum(alpha[v], dim=1, keepdim=True)
            E[v] = alpha[v] - 1
            b[v] = E[v] / (S[v].expand(E[v].shape))
            u[v] = self.n_classes / S[v]

        # b^0 @ b^(0+1)
        bb = torch.bmm(b[0].view(-1, self.n_classes, 1), b[1].view(-1, 1, self.n_classes))
        # b^0 * u^1
        uv1_expand = u[1].expand(b[0].shape)
        bu = torch.mul(b[0], uv1_expand)
        # b^1 * u^0
        uv_expand = u[0].expand(b[0].shape)
        ub = torch.mul(b[1], uv_expand)
        # calculate K
        bb_sum = torch.sum(bb, dim=(1, 2), out=None)
        bb_diag = torch.diagonal(bb, dim1=-2, dim2=-1).sum(-1)
        # bb_diag1 = torch.diag(torch.mm(b[v], torch.transpose(b[v+1], 0, 1)))
        K = bb_sum - bb_diag

        # calculate b^a
        b_a = (torch.mul(b[0], b[1]) + bu + ub) / ((1 - K).view(-1, 1).expand(b[0].shape))
        # calculate u^a
        u_a = torch.mul(u[0], u[1]) / ((1 - K).view(-1, 1).expand(u[0].shape))
        # test = torch.sum(b_a, dim = 1, keepdim = True) + u_a #Verify programming errors

        # calculate new S
        S_a = self.n_classes / u_a
        # calculate new e_k
        e_a = torch.mul(b_a, S_a.expand(b_a.shape))
        alpha_a = e_a + 1
        return alpha_a

    def DS_Combin_all(self, views):
        alpha_all = self.DS_Combin_two(views[0], views[1])
        if len(views)>2:
            for j in range(2,len(views)):
                alpha_all = self.DS_Combin_two(alpha_all, views[j])
        return alpha_all

    def forward(self, views):
        feas = []
        for i, enc in enumerate(self.enc_list):
            feas.append(enc(views[i]))
        outs = []
        evidences = []
        alphas = []
        for i, clf in enumerate(self.clf_views):
            out = clf(feas[i])
            outs.append(out)
            evidence = F.softplus(out)
            evidences.append(evidence)
            alphas.append(evidence+1)

        alpha_combine = self.DS_Combin_all(alphas)
        return alphas, alpha_combine


class ETMC(TMC):
    def __init__(self, in_dim, h_dim, h_dim1, h_dim2, lat_dim, numclass, nview, dropout=0.2):
        super(ETMC, self).__init__(in_dim, h_dim, h_dim1, lat_dim, numclass, nview, dropout=0.2)
        last_size = in_dim * nview
        self.clf_e = nn.Sequential(
            nn.Linear(last_size, h_dim2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(h_dim2, numclass)
        )

    def forward(self, views):
        feas = []
        for i, enc in enumerate(self.enc_list):
            feas.append(enc(views[i]))
        outs = []
        evidences = []
        alphas = []
        for i, clf in enumerate(self.clf_views):
            out = clf(feas[i])
            outs.append(out)
            evidence = F.softplus(out)
            evidences.append(evidence)
            alphas.append(evidence + 1)

        pseudo_out = torch.cat(views, -1)
        pseudo_out = self.clf_e(pseudo_out)
        pseudo_evidence = F.softplus(pseudo_out)
        pseudo_alpha = pseudo_evidence+1
        alpha_combine = self.DS_Combin_all(alphas)
        alpha_all = self.DS_Combin_two(alpha_combine, pseudo_alpha)
        return alphas, pseudo_alpha, alpha_all
