#########################################################################
####
# 1. case study 1 TPD DEP comparison, UMAP for visualization of DEP based seperation of normal and disease
#    classification
# 2. Case study 2 PD

#######################################################################

#  if the package "this.path" has not been install please installed
# install.packages("this.path", repos = "https://cloud.r-project.org")
library("this.path", character.only = TRUE)
library(pheatmap)
library(VennDiagram)
library(ggplot2)
library(clusterProfiler)
library(org.Hs.eg.db)
library(SuperExactTest)
library(reshape2)
library(openxlsx)
library(readxl)

script_path <- this.path()
script_dir <- dirname(script_path)
parent_fold<-dirname(script_dir)

root_fold<-paste0(parent_fold, '/data/')
DEA_res_fold<-paste0(parent_fold, '/Case_studies/res/')

save_fold<-paste0(script_dir, '/res/Fig4/')
if(!dir.exists(save_fold)){
  dir.create(save_fold, recursive = TRUE)
}


dt_name = 'TPD_dis'

## Fig4 a, b, c
### best_fold is determined by the regression results by the python script
### 'Supplementary_codes/combination_selection.py'
raw_fold = paste0(root_fold, '/case_study_views/TPD_views/dis/')
sub_fold = 'TPD_dis_DEA_res'
best_fold = 'DIA_dlfq_maxlfq_top3'
all_fold = 'DIA_dlfq_maxlfq_top3_top1'
logthre = log2(2)
qthre = 0.01
dlfq_logT = 'F'
post = '.csv'
g2 = 'M'

res_all<-read.table(paste0(DEA_res_fold, sub_fold, '/', all_fold, '/DEA_res.csv'), header = T, sep = ',')
res_all1<-read.table(paste0(DEA_res_fold, sub_fold, '/', best_fold,'/DEA_res.csv'), header = T, sep = ',')


list_to_matrix <- function(gene_sets) {
  all_genes <- unique(unlist(gene_sets))
  binary_mat <- matrix(0,
                       nrow = length(all_genes),
                       ncol = length(gene_sets),
                       dimnames = list(all_genes, names(gene_sets)))
  
  for(i in seq_along(gene_sets)) {
    binary_mat[rownames(binary_mat) %in% gene_sets[[i]], i] <- 1
  }
  
  return(binary_mat)
}

dlfq_deg <- subset(res_all, dlfq_qval <= qthre & abs(dlfq_logFC) >= logthre)
maxlfq_deg <- subset(res_all, maxlfq_qval <= qthre & abs(maxlfq_logFC) >= logthre)
top3_deg <- subset(res_all, top3_qval <= qthre & abs(top3_logFC) >= logthre)
top1_deg <- subset(res_all, top1_qval <= qthre & abs(top1_logFC) >= logthre)
DL_direct_deg <- subset(res_all1, MVcontrast_score.2 >= max(res_all1$MVcontrast_threshold.2) & abs(MVcontrast_logFC.2) >= logthre)

input=list(dlfq=dlfq_deg$Protein, top3=top3_deg$Protein, maxlfq=maxlfq_deg$Protein, top1 = top1_deg$Protein,
           MCP=DL_direct_deg$Protein)


library(UpSetR)

UpSetR::upset(fromList(input),
              sets = c('dlfq', 'maxlfq',
                       'top3', 'top1',
                       'MCP'
              ),
              order.by="freq", matrix.color="black", point.size=3,
              sets.bar.color=c("#b2df8a", "#33a02c", "#1f78b4", "lightblue", "#f078b4"
              ),mb.ratio=c(0.6, 0.4), text.scale = 1.5,
              number.angles =0,
              keep.order = T,nintersects=20)

input_lists<-input
all_items <- unique(unlist(input_lists))


binary_matrix <- matrix(
  0,
  nrow = length(all_items),
  ncol = length(input_lists),
  dimnames = list(all_items, names(input_lists)) 
)


for (i in seq_along(input_lists)) {
  current_list <- input_lists[[i]]
  binary_matrix[current_list, i] <- 1
}
print(binary_matrix)
write.table(data.frame(protein=all_items, binary_matrix), paste0(save_fold, 'upset_plot_TPD_dis.csv'), col.names = T, row.names = T, sep = ',')

input_top3=list(dlfq=dlfq_deg$Protein, maxlfq=maxlfq_deg$Protein, 
                MCP=DL_direct_deg$Protein)

input_lists<-input_top3
all_items <- unique(unlist(input_lists))


binary_matrix <- matrix(
  0,
  nrow = length(all_items),
  ncol = length(input_lists),
  dimnames = list(all_items, names(input_lists)) 
)


for (i in seq_along(input_lists)) {
  current_list <- input_lists[[i]]
  binary_matrix[current_list, i] <- 1
}

write.table(data.frame(protein=all_items, binary_matrix), paste0(save_fold, 'venn_diagram_TPD_dis.csv'), col.names = T, row.names = T, sep = ',')


library(VennDiagram)
library(ggVennDiagram)
library("readxl")
library(ggplot2)
library(reshape2)
library(ggpubr)
library(cowplot)
set.seed(123)
nature_palette <- c("#b2df8a", "#33a02c", "#f078b4")

ggVennDiagram(
  input_top3,
  label_alpha = 0,
  label = "count",
  set_label_pos = 0.001,
  set_color = nature_palette
) +
  scale_fill_gradient(low = "#FFFFFF", high = "#E64B35") +
  theme_void(base_size = 14) + 
  theme(
    legend.position = "none",
    plot.title = element_text(size = 16, face = "bold", hjust = 0.6)
  )

clustering_fold<-paste0(parent_fold,'/Clustering/')

dlfq<-read.table(paste0(clustering_fold, dt_name, 'dlfq.csv'), sep = ',', header = T)
dlfq_view<-dlfq[,2:(length(dlfq[1,])-1)]
dlfq_lab<-dlfq[,length(dlfq[1,])]
dlfq_lab_chr<-c(rep('benign', length(dlfq_lab)))
dlfq_lab_chr[which(dlfq_lab==1)]='malignant'
dlfq_full<-read.table(paste0(clustering_fold, dt_name, 'dlfq_full.csv'), sep = ',', header = T)
dlfq_view_full<-dlfq_full[,2:(length(dlfq_full[1,])-1)]
dlfq_pro<-colnames(dlfq_view_full)
dlfq_pro<-gsub('\\.', '|', dlfq_pro)

maxlfq<-read.table(paste0(clustering_fold, dt_name, 'maxlfq.csv'), sep = ',', header = T)
maxlfq_view<-maxlfq[,2:(length(maxlfq[1,])-1)]
maxlfq_lab<-maxlfq[,length(maxlfq[1,])]
maxlfq_lab_chr<-c(rep('benign', length(maxlfq_lab)))
maxlfq_lab_chr[which(maxlfq_lab==1)]='malignant'
maxlfq_full<-read.table(paste0(clustering_fold, dt_name, 'maxlfq_full.csv'), sep = ',', header = T)
maxlfq_view_full<-maxlfq_full[,2:(length(maxlfq_full[1,])-1)]
maxlfq_pro<-colnames(maxlfq_view_full)
maxlfq_pro<-gsub('\\.', '|', maxlfq_pro)

top3<-read.table(paste0(clustering_fold, dt_name, 'top3.csv'), sep = ',', header = T)
top3_view<-top3[,2:(length(top3[1,])-1)]
top3_lab<-top3[,length(top3[1,])]
top3_lab_chr<-c(rep('benign', length(top3_lab)))
top3_lab_chr[which(top3_lab==1)]='malignant'
top3_full<-read.table(paste0(clustering_fold, dt_name, 'top3_full.csv'), sep = ',', header = T)
top3_view_full<-top3_full[,2:(length(top3_full[1,])-1)]
top3_pro<-colnames(top3_view_full)
top3_pro<-gsub('\\.', '|', top3_pro)

top1<-read.table(paste0(clustering_fold, dt_name, 'top1.csv'), sep = ',', header = T)
top1_view<-top1[,2:(length(top1[1,])-1)]
top1_lab<-top1[,length(top1[1,])]
top1_lab_chr<-c(rep('benign', length(top1_lab)))
top1_lab_chr[which(top1_lab==1)]='malignant'
top1_full<-read.table(paste0(clustering_fold, dt_name, 'top1_full.csv'), sep = ',', header = T)
top1_view_full<-top1_full[,2:(length(top1_full[1,])-1)]
top1_pro<-colnames(top1_view_full)
top1_pro<-gsub('\\.', '|', top1_pro)

MVDEA<-read.table(paste0(clustering_fold, dt_name, best_fold, 'mvdea.csv'), sep = ',', header = T)
MVDEA_view<-MVDEA[,2:(length(MVDEA[1,])-1)]
MVDEA_lab<-MVDEA[,length(MVDEA[1,])]
MVDEA_lab_chr<-c(rep('benign', length(MVDEA_lab)))
MVDEA_lab_chr[which(MVDEA_lab==1)]='malignant'

hurdle<-read.table(paste0(clustering_fold, dt_name, best_fold, 'hurdle.csv'), sep = ',', header = T)
hurdle_view<-hurdle[,2:(length(hurdle[1,])-1)]
hurdle_lab<-hurdle[,length(hurdle[1,])]
hurdle_lab_chr<-c(rep('benign', length(hurdle_lab)))
hurdle_lab_chr[which(hurdle_lab==1)]='malignant'

library(umap)
library(ggpubr)
library("gridExtra")

clus_perform<-read.table(paste0(clustering_fold, dt_name, '_clustering_performance_fill0_', best_fold, '.csv'), sep = ',', header = T)[,1:4]

umap_dlfq<-umap(as.matrix(dlfq_view), min_dist = 0.05, random_state=2025)

umap_maxlfq<-umap(as.matrix(maxlfq_view), min_dist = 0.05, random_state=2025)


umap_top3<-umap(as.matrix(top3_view), min_dist = 0.05, random_state=2025)


umap_top1<-umap(as.matrix(top1_view), min_dist = 0.05, random_state=2025)

umap_mvdea<-umap(as.matrix(MVDEA_view), min_dist = 0.05, random_state=2025)

umap_hurdle<-umap(as.matrix(hurdle_view), min_dist = 0.05, random_state=2025)


write.table(as.matrix(dlfq_view), paste0(save_fold, 'dlfq_view_clustering.csv'), sep = ',', col.names = T, row.names = T)
write.table(as.matrix(maxlfq_view), paste0(save_fold, 'maxlfq_view_clustering.csv'), sep = ',', col.names = T, row.names = T)
write.table(as.matrix(top3_view), paste0(save_fold, 'top3_view_clustering.csv'), sep = ',', col.names = T, row.names = T)
write.table(as.matrix(top1_view), paste0(save_fold, 'top1_view_clustering.csv'), sep = ',', col.names = T, row.names = T)
write.table(as.matrix(MVDEA_view), paste0(save_fold, 'MCP_view_clustering.csv'), sep = ',', col.names = T, row.names = T)

extract_legend <- function(my_ggp) {
  step1 <- ggplot_gtable(ggplot_build(my_ggp))
  step2 <- which(sapply(step1$grobs, function(x) x$name) == "guide-box")
  step3 <- step1$grobs[[step2]]
  return(step3)
}

plot_umap2 <- function(umap_result_optimized, cluster_label, method_name, clus_perform, show_legend = TRUE){
  
  library(ggplot2)
  library(dplyr)
  
  umap_df <- data.frame(
    UMAP1 = umap_result_optimized$layout[, 1],
    UMAP2 = umap_result_optimized$layout[, 2],
    cluster = as.factor(cluster_label)
  )
  write.table(umap_df, paste0(save_fold, method_name,'_umap_clustering.csv'), sep = ',', col.names = T, row.names = T)
  hull_df <- umap_df %>%
    group_by(cluster) %>%
    filter(n() >= 3) %>%
    do({
      idx <- chull(.$UMAP1, .$UMAP2)
      .[c(idx, idx[1]), ]
    }) %>%
    ungroup()
  
  center_df <- umap_df %>% 
    group_by(cluster) %>% 
    summarise(UMAP1 = mean(UMAP1), UMAP2 = mean(UMAP2))
  
  range_x <- diff(range(umap_df$UMAP1))
  range_y <- diff(range(umap_df$UMAP2))
  ann_x <- max(umap_df$UMAP1) - 0.03 * range_x
  ann_y <- min(umap_df$UMAP2) + 0.03 * range_y
  
  annot_df <- subset(clus_perform, X == method_name)
  
  pup <- ggplot() +
    geom_point(data = umap_df, aes(UMAP1, UMAP2, color = cluster),
               size = 2, alpha = 0.7, stroke = 0.1) +

    labs(x = "UMAP1", y = "UMAP2") +
    
    theme_bw(base_size = 12) +
    theme(

      panel.background = element_rect(fill = "white", colour = NA),
      plot.background = element_rect(fill = "white", colour = NA),
      panel.border = element_rect(colour = "black", fill = NA, linewidth = 0.7),
      
      axis.title = element_text(face = "bold", size = 14, colour = "black"),
      axis.text = element_blank(),
      axis.ticks = element_blank(),
      axis.ticks.length = unit(0, "mm"),
      
      legend.position = ifelse(show_legend, "right", "none"),
      legend.title = element_text(face = "bold", size = 17),
      legend.text = element_text(size = 15),
      legend.key = element_rect(fill = "white", colour = NA),
      
      panel.grid = element_blank(),
      
      plot.margin = margin(t = 5, r = 5, b = 5, l = 5, unit = "mm")
    ) +
    
    scale_color_manual(values = c("#15983D", "#FFA000", "#91D1C2FF","#E64B35FF", "#4878CF")) +
    
    annotate("label",
             x = ann_x, y = ann_y,
             label = sprintf("ARI = %.2f\nASW = %.2f\nNMI = %.2f",
                             annot_df$ARI, annot_df$ASW, annot_df$NMI),
             hjust = 0.9, vjust = 0,
             size = 3,
             fill = alpha("white", 0.5),
             color = "black",
             label.size = 0.3,
             label.r = unit(0.2, "lines")
    )
  
  return(list(p = pup, dt = umap_df))
}

p_dlfq <- plot_umap2(umap_dlfq, as.character(dlfq_lab_chr), "dlfq", clus_perform)
p_maxlfq <- plot_umap2(umap_maxlfq, as.character(maxlfq_lab_chr), "maxlfq", clus_perform)
p_top3   <- plot_umap2(umap_top3,  as.character(top3_lab_chr),  "top3",  clus_perform)
p_top1   <- plot_umap2(umap_top1,  as.character(top1_lab_chr),  "top1",  clus_perform)
p_mvdea  <- plot_umap2(umap_mvdea, as.character(MVDEA_lab_chr), "MVDEA", clus_perform)
p_hurdle <- plot_umap2(umap_hurdle,as.character(hurdle_lab_chr),"hurdle",clus_perform)

shared_legend <- extract_legend(p_dlfq$p)

pall<-grid.arrange(
  p_dlfq$p+ggtitle('dlfq')+theme(legend.position = 'none',plot.title = element_text(hjust = 0.5), axis.title.x = element_blank()),
  p_maxlfq$p+ggtitle('maxlfq')+theme(legend.position = 'none', axis.title.y = element_blank(), axis.title.x = element_blank(),plot.title = element_text(hjust = 0.5)),
  p_top3$p+ggtitle('top3')+theme(legend.position = 'none', axis.title.y = element_blank(), axis.title.x = element_blank(),plot.title = element_text(hjust = 0.5)),
  p_top1$p+ggtitle('top1')+theme(legend.position = 'none', plot.title = element_text(hjust = 0.5)),
  p_mvdea$p+ggtitle('MCP')+theme(legend.position = 'none', axis.title.y = element_blank(), plot.title = element_text(hjust = 0.5)),
  shared_legend,
  ncol=3,widths=c(1, 1, 1))

per_melt<-melt(clus_perform)

colnames(per_melt)<-c('Method', 'Metrics', 'Value')
per_melt<-per_melt[which(per_melt$Method!='hurdle'),]
per_melt<-per_melt[which(per_melt$Metrics!='ASW'),]
per_melt$Method<-factor(per_melt$Method, levels = c("dlfq", "maxlfq", "top3", "top1",  "MVDEA"))#"hurdle",
per_melt$Value<-round(as.numeric(per_melt$Value), 3)


hp_per <- ggdotchart(
  per_melt, 
  x = "Metrics", 
  y = "Value", 
  group = "Method", 
  color = "Method",
  palette = c("#b2df8a", "#33a02c", "#1f78b4", "lightblue", "#f078b4"),
  add = "segments",
  add.params = list(color = "black", size = 1),
  dot.size = 3,
  position = position_dodge(width = 0.8)
) +
  geom_text(
    aes(label = round(Value, 2), group = Method), 
    position = position_dodge(width = 0.8),   
    vjust = -0.8,
    size = 4,
    inherit.aes = TRUE
  ) +
  theme(
    axis.text.x = element_text(size = 14, angle = 0, hjust = 0.5),
    axis.title.x = element_blank(),
    legend.position = 'right'
  )
hp_per

############### diagnosis

diag_perform<-read.table(paste0(parent_fold,'/Patient_diagnosis/res/','DEPs_XGB_perform.csv'), sep = ',', header = T)
diag_perform<-diag_perform[which(diag_perform$X!='hurdle'),]
colnames(diag_perform)[3:8]<-c('AUC', 'Accuracy','Precision', 'Recall', 'F1', 'MCC')
library(ggplot2)

methods <- diag_perform$X
metrics <- setdiff(names(diag_perform), c("X", "FeatureSet"))
perf_matrix <- as.matrix(diag_perform[, metrics])
rownames(perf_matrix) <- methods

heat_data <- expand.grid(Method = methods, Metric = metrics)
heat_data$Value <- as.vector(perf_matrix)

p <- ggplot(heat_data, aes(x = Method, y = Metric, fill = Value)) +
  geom_tile(color = "white", linewidth = 0.5) +
  geom_text(aes(label = sprintf("%.2f", Value)), 
            size = 3.5, color = "black", family = "Arial") +
  scale_fill_gradient2(
    low = "#3C5488",      
    high = "#E64B35",     
    midpoint = mean(heat_data$Value),  
    limits = c(0.5, 0.95), 
    name = "Performance"  
  ) +
  theme_minimal() +
  theme(
    plot.background = element_rect(fill = "white", color = NA),
    plot.margin = margin(10, 10, 10, 10),
    plot.title = element_text(size = 12, face = "bold", hjust = 0.5, family = "Arial"),
    axis.title = element_text(size = 11, face = "bold", family = "Arial"),
    axis.text = element_text(size = 10, family = "Arial"),
    axis.text.x = element_text(angle = 0, hjust = 0.5),
    legend.title = element_text(size = 9, face = "bold", family = "Arial"),
    legend.text = element_text(size = 8, family = "Arial"),
    legend.key.height = unit(1.5, "cm"),
    panel.grid = element_blank(),
    axis.line = element_blank(),
    axis.ticks = element_blank()
  ) +
  labs(
    title = "Applying DEPs for Patient Diagnosis",
    x = "Method for detecting DEPs",
    y = "Evaluation Metric",
    fill = "Performance Value"
  )

print(p)



##################################################################
###########################################################################
# case study on CRC
library(pheatmap)
library(VennDiagram)
library(ggplot2)
library(clusterProfiler)
library(org.Hs.eg.db)
library(SuperExactTest)
library(reshape2)

script_path <- this.path()
script_dir <- dirname(script_path)
root_fold<-paste0(script_dir, '/data/')

save_fold<-paste0(script_dir, '/res/Fig4/')
if(!dir.exists(save_fold)){
  dir.create(save_fold, recursive = TRUE)
}

## Fig4 a, b, c
### best_fold is determined by the regression results by the python script
### 'Supplementary_codes/combination_selection.py'
raw_fold = paste0(parent_fold, '/data/case_study_views/CRC_views/')
DEA_res_fold<-paste0(parent_fold, '/Case_studies/res/')
dt_name = 'CRC'

sub_fold = 'CRC_DEA_res'
best_fold = 'DIA_dlfq_maxlfq_top3'
all_fold = 'DIA_dlfq_maxlfq_top3_top1'
logthre = log2(1.5)
qthre = 0.05
dlfq_logT = 'T'
post = '.tsv'
g2 = 'N'

res_all<-read.table(paste0(DEA_res_fold, sub_fold, '/', all_fold, '/DEA_res.csv'), header = T, sep = ',')
res_all1<-read.table(paste0(DEA_res_fold, sub_fold, '/', best_fold,'/DEA_res.csv'), header = T, sep = ',')

list_to_matrix <- function(gene_sets) {
  all_genes <- unique(unlist(gene_sets))
  
  binary_mat <- matrix(0,
                       nrow = length(all_genes),
                       ncol = length(gene_sets),
                       dimnames = list(all_genes, names(gene_sets)))
  for(i in seq_along(gene_sets)) {
    binary_mat[rownames(binary_mat) %in% gene_sets[[i]], i] <- 1
  }
  
  return(binary_mat)
}

dlfq_deg <- subset(res_all, dlfq_qval <= qthre & abs(dlfq_logFC) >= logthre)
maxlfq_deg <- subset(res_all, maxlfq_qval <= qthre & abs(maxlfq_logFC) >= logthre)
top3_deg <- subset(res_all, top3_qval <= qthre & abs(top3_logFC) >= logthre)
top1_deg <- subset(res_all, top1_qval <= qthre & abs(top1_logFC) >= logthre)
DL_direct_deg <- subset(res_all1, MVcontrast_score.2 >= max(res_all1$MVcontrast_threshold.2) & abs(MVcontrast_logFC.2) >= logthre)

input=list(dlfq=dlfq_deg$Protein, top3=top3_deg$Protein, maxlfq=maxlfq_deg$Protein, top1 = top1_deg$Protein,
           MCP=DL_direct_deg$Protein)


library(UpSetR)

UpSetR::upset(fromList(input),
              sets = c('dlfq', 'maxlfq',
                       'top3', 'top1',
                       'MCP'
              ),
              order.by="freq", matrix.color="black", point.size=3,
              sets.bar.color=c("#b2df8a", "#33a02c", "#1f78b4", "lightblue", "#f078b4"
              ),mb.ratio=c(0.6, 0.4), text.scale = 1.5,
              number.angles =0,
              keep.order = T,nintersects=20)

input_lists<-input
all_items <- unique(unlist(input_lists))


binary_matrix <- matrix(
  0,
  nrow = length(all_items),
  ncol = length(input_lists),
  dimnames = list(all_items, names(input_lists)) 
)


for (i in seq_along(input_lists)) {
  current_list <- input_lists[[i]]
  binary_matrix[current_list, i] <- 1
}

write.table(data.frame(protein=all_items, binary_matrix), paste0(save_fold, 'CRC_DEPs.csv'), col.names = T, row.names = T, sep = ',')


input_top3=list(dlfq=dlfq_deg$Protein, maxlfq=maxlfq_deg$Protein, 
                MCP=DL_direct_deg$Protein)

input_lists<-input_top3
all_items <- unique(unlist(input_lists))


binary_matrix <- matrix(
  0,
  nrow = length(all_items),
  ncol = length(input_lists),
  dimnames = list(all_items, names(input_lists)) 
)


for (i in seq_along(input_lists)) {
  current_list <- input_lists[[i]]
  binary_matrix[current_list, i] <- 1
}

write.table(data.frame(protein=all_items, binary_matrix), paste0(save_fold, 'CRC_top3_DEPs.csv'), col.names = T, row.names = T, sep = ',')


library(VennDiagram)
library(ggVennDiagram)
library("readxl")
library(ggplot2)
library(reshape2)
library(ggpubr)
library(cowplot)
set.seed(123)
nature_palette <- c("#b2df8a", "#33a02c", "#f078b4")

ggVennDiagram(
  input_top3,
  label_alpha = 0,
  label = "count", 
  set_label_pos = 0.001,
  set_color = nature_palette
) +
  scale_fill_gradient(low = "#FFFFFF", high = "#E64B35") +
  theme_void(base_size = 14) + 
  theme(
    legend.position = "none", 
    plot.title = element_text(size = 16, face = "bold", hjust = 0.6)
  )

library(survival)
library(survminer)  
library(clusterProfiler)
library(org.Hs.eg.db)
library(ggplot2)
library(dplyr)
library(tidyr)
library(ggtext)

root_fold_cptac <- paste0(parent_fold, '/data/case_study_views/CRC_views/')

proteomics <- read.table(paste0(root_fold_cptac, 'proteomics_dataframe.tsv'), sep = '\t', header = T)
clinic <- read.table(paste0(root_fold_cptac, 'clinical_dataframe.tsv'), sep = '\t', header = T)

proteomics_clean<-proteomics[3:length(proteomics),]
colnames(proteomics_clean)[1]<-'Sample_ID'

for (i in 2:ncol(proteomics_clean)) {
  proteomics_clean[, i] <- as.numeric(proteomics_clean[, i])
}

clinical_surv <- clinic[, c("Patient_ID", 
                            "Overall.survival..days", 
                            "Survival.status..1..dead..0..alive.")]
colnames(clinical_surv) <- c("Sample_ID", "OS_time", "OS_status")

clinical_surv <- clinical_surv[!is.na(clinical_surv$Sample_ID) & 
                                 !is.na(clinical_surv$OS_time) & 
                                 !is.na(clinical_surv$OS_status) & 
                                 clinical_surv$OS_time > 0, ]
clinical_surv$OS_status <- as.numeric(clinical_surv$OS_status)

combined_data <- merge(proteomics_clean, clinical_surv, by = "Sample_ID")

max_os_time <- max(combined_data$OS_time, na.rm = TRUE)
combined_data$OS_status <- ifelse(combined_data$OS_time == max_os_time, 0, combined_data$OS_status)

write.table(combined_data, paste0(save_fold, 'cptac_CRC_survival_data.csv'), sep = ',', col.names = T, row.names = T)
cat("sample number：", nrow(combined_data), "\n")
cat("protein/gene number：", ncol(combined_data) - 3, "\n")

uni_pro_MCP<-setdiff(DL_direct_deg$Protein, c(dlfq_deg$Protein, maxlfq_deg$Protein, top3_deg$Protein, top1_deg$Protein))
uni_pro_MCP_record<-DL_direct_deg[match(uni_pro_MCP, DL_direct_deg$Protein), ]

target_uniprot <- uni_pro_MCP

gene_df <- bitr(target_uniprot,
                fromType = "UNIPROT",
                toType = "SYMBOL",
                OrgDb = org.Hs.eg.db)
write.table(gene_df, paste0(save_fold, 'MCP_unique_protein_CRC.csv'), sep = ',', col.names = T)
valid_symbols <- intersect(gene_df$SYMBOL, colnames(combined_data))
valid_uniprot_info <- gene_df[gene_df$SYMBOL %in% valid_symbols, ]  


surv_results <- list()
for (i in seq_along(valid_uniprot_info$SYMBOL)) {
  col_name <- valid_uniprot_info$SYMBOL[i]  
  uniprot_id <- valid_uniprot_info$UNIPROT[i]  
  
  expr_vec <- combined_data[, col_name]
  data_temp <- combined_data[!is.na(expr_vec), c("OS_time", "OS_status", col_name)]
  
  if (nrow(data_temp) < 10) {
    warning(paste(uniprot_id, "(SYMBOL:", col_name, ") no enough sample，skip"))
    next
  }
  
  median_val <- median(data_temp[, col_name], na.rm = TRUE)
  data_temp$group <- factor(ifelse(data_temp[, col_name] > median_val, "High", "Low"), 
                            levels = c("Low", "High"))
  
  fit <- survfit(Surv(OS_time, OS_status) ~ group, data = data_temp)
  
  lr_test <- survdiff(Surv(OS_time, OS_status) ~ group, data = data_temp)
  p_val <- ifelse(is.na(lr_test$chisq), 1, 1 - pchisq(lr_test$chisq, df = 1))
  
  surv_results[[uniprot_id]] <- list(
    fit = fit,  
    p_val = p_val,
    n_low = sum(data_temp$group == "Low"),
    n_high = sum(data_temp$group == "High"),
    symbol = col_name,
    data_temp = data_temp,
    max_time = max(data_temp$OS_time, na.rm = TRUE)
  )
  
  cat(uniprot_id, "(SYMBOL:", col_name, ")→ p value：", signif(p_val, 3), 
      "（low expression n=", surv_results[[uniprot_id]]$n_low, 
      "，high expression n=", surv_results[[uniprot_id]]$n_high, "）\n", sep = "")
}


# ============================================
plot_list <- list()

for (uniprot_id in names(surv_results)) {
  res <- surv_results[[uniprot_id]]
  plot_max_time <- ifelse(res$max_time == 0, 1, res$max_time)
  
  ggsurv_temp <- ggsurvplot(
    res$fit,
    data = res$data_temp,
    xlab = "Time (Days)",
    ylab = "Survival Probability",
    palette = c("#2E9FDF", "#E7B800"),
    linetype = "solid",
    size = 1.2,
    conf.int = FALSE,
    pval = TRUE,
    pval.size = 5,
    pval.coord = c(plot_max_time * 0.6, 0.9),
    legend = "none",
    xlim = c(0, plot_max_time * 1.05),
    ylim = c(0.6, 1.05),
    break.time.by = ifelse(plot_max_time > 1000, 200, 100),
    ggtheme = theme_bw()
  )
  
  plot_title <- paste("CPTAC-COAD:", uniprot_id, " (", res$symbol, ")", sep = "")
  
  p <- ggsurv_temp$plot +
    aes(color = group) +
    scale_color_manual(
      values = c("#2E9FDF", "#E7B800"),
      labels = c(paste("Low (n=", res$n_low, ")"), paste("High (n=", res$n_high, ")")),
      name = ""
    ) +
    ggtitle(plot_title) +
    theme(
      plot.title = element_text(
        size = 14, 
        face = "bold", 
        hjust = 0.5,
        vjust = 1,
        margin = margin(b = 10)
      ),
      axis.title = element_text(size = 12),
      axis.text = element_text(size = 10),
      panel.grid = element_line(color = "gray90", linetype = "dashed"),
      legend.position = c(0.05, 0.05),
      legend.justification = c(0, 0),
      legend.background = element_rect(fill = "white", alpha = 0.9),
      legend.key = element_rect(fill = NA)
    )
  
  # suppressWarnings(print(p))
  plot_list[[uniprot_id]] <- p
  
  cat("already analyzed", uniprot_id, "\n")
}

plot_list$Q9Y279
write.table(surv_results$Q9Y279$data_temp, paste0(save_fold, 'VSIG4_survival_curve.csv'), sep = ',', col.names = T, row.names = T)

# ============================================
p_table <- data.frame(
  UniProt_ID = names(surv_results),
  Symbol = sapply(surv_results, function(x) x$symbol),
  Log_rank_p = sapply(surv_results, function(x) signif(x$p_val, 3)),
  N_Low = sapply(surv_results, function(x) x$n_low),
  N_High = sapply(surv_results, function(x) x$n_high),
  FDR_p = signif(p.adjust(sapply(surv_results, function(x) x$p_val), "fdr"), 3)
)
write.csv(p_table, paste0(save_fold, 'CRC_CPTAC_survival_results.csv'), row.names = FALSE)
cat("\n=== summary ===\n")
print(p_table)


library(survival)
library(survminer)
library(tidyverse)
library(ezcox)
library(forestplot)

set.seed(123)
n <- 200
sample_data <- cbind(combined_data$OS_time, combined_data$OS_status,combined_data[,match(valid_symbols, colnames(combined_data))])
colnames(sample_data)[1:2]<-c('time', 'status')

vars_to_analyze <- names(sample_data)[3:ncol(sample_data)]


univ_models <- ezcox(
  data = sample_data,
  covariates = vars_to_analyze,
  return_models = TRUE
)

set.seed(1234)
res_2_test <-univ_models$res

ref_df <- data.frame(
  UNIPROT = c("P0DJI8", "P0DJI9", "P30086", "P32754", "P62328", "Q8NBJ4", "Q9UEW3", "Q9Y279"),
  SYMBOL = c("SAA1", "SAA2", "PEBP1", "HPD", "TMSB4X", "GOLM1", "MARCO", "VSIG4"),
  association = c("PMID:36345658", "PMID:24744574", "PMID:17179102", "PMID:36813208", "PMID:17072345", "PMID:40414849", "PMID:36958650", "PMID:40405491")
)

colnames(res_2_test)[1]<-'SYMBOL'
res_2_test$significant <- c(rep(NA,length(res_2_test$SYMBOL)))
res_2_test$significant[which(res_2_test$p.value<0.05)] = 'p<0.05'

all_gene_df <- bitr(target_uniprot,
                    fromType = "UNIPROT",
                    toType = "SYMBOL",
                    OrgDb = org.Hs.eg.db)
head(ref_df)
head(all_gene_df)

library(dplyr)

merge_ref_all <- full_join(
  ref_df, 
  all_gene_df, 
  by = "SYMBOL",
  suffix = c("_ref", "_all")
) %>%
  mutate(UNIPROT = coalesce(UNIPROT_ref, UNIPROT_all)) %>%
  dplyr::select(-UNIPROT_ref, -UNIPROT_all)

merged_all <- full_join(
  merge_ref_all, 
  res_2_test, 
  by = "SYMBOL",
  suffix = c("", "_test")
)

final_df <- merged_all %>%
  mutate(
    across(where(is.numeric), ~replace(., is.na(.), NA)),
    across(where(is.logical), ~replace(., is.na(.), FALSE)),
    across(where(is.character), ~replace(., is.na(.), NA))
  )

ggplot(final_df, aes(HR, reorder(SYMBOL, HR), col = significant, shape = significant)) +  
  geom_point(size = 2.5) +  
  geom_errorbarh(aes(xmax = upper_95, xmin = lower_95), height = 0.4) + 
  geom_vline(aes(xintercept = 1), linetype = "dashed", color = "gray50") + 
  geom_text(
    data = subset(final_df, !is.na(association)),  
    aes(
      x = ifelse(!is.na(upper_95), upper_95, 1),  
      y = reorder(SYMBOL, HR),
      label = association
    ),
    color = "orange",  
    hjust = ifelse(subset(final_df, !is.na(association))$upper_95 %>% is.na(), 
                   -0.1, -0.1),
    size = 3.5,
    inherit.aes = FALSE
  ) +
  xlab('HR(95%CI)') + 
  ylab('') +  
  theme_bw(base_size = 12) + 
  scale_color_manual(values = c("gray", "red")) +
  xlim(min(final_df$lower_95, na.rm = TRUE), 
       max(c(final_df$upper_95, 1.2*ifelse(is.na(final_df$upper_95),1,final_df$upper_95)), na.rm = TRUE)) +
  theme(
    legend.position = "bottomright",
    legend.background = element_rect(fill = NA),
    legend.margin = margin(t = 0, r = 0, b = 0, l = 0, unit = "pt"),
    legend.key.size = unit(8, "pt"),
    legend.spacing.x = unit(4, "pt"),
    legend.box.spacing = unit(0, "pt")
  )

final_df <- final_df %>%
  mutate(
    significant = case_when(
      significant == "p<0.05" ~ "p<0.05",
      is.na(significant) ~ "ns",
      TRUE ~ "ns"
    ) %>% 
      factor(levels = c("ns", "p<0.05"))
  )

ggplot(final_df, aes(HR, reorder(SYMBOL, HR), col = significant, shape = significant)) +  
  geom_point(size = 2.5) +  
  geom_errorbarh(aes(xmax = upper_95, xmin = lower_95), height = 0.4) + 
  geom_vline(xintercept = 1, linetype = "dashed", color = "gray50") + 
  geom_text(
    data = subset(final_df, !is.na(association)),  
    aes(x = ifelse(!is.na(upper_95), upper_95, 1), y = reorder(SYMBOL, HR), label = association),
    color = "orange", hjust = -0.1, size = 3.5, inherit.aes = FALSE
  ) +
  xlab('HR(95%CI)') + ylab('') +  
  theme_bw(base_size = 12) + 
  scale_color_manual(
    values = c("ns" = "gray50", "p<0.05" = "red"),
    name = "Significance" 
  ) +
  scale_shape_manual(
    values = c("ns" = 19, "p<0.05" = 17),
    name = "Significance"
  ) +
  theme(
    legend.position = c(0.95, 0.05),
    legend.justification = c(1, 0),
    legend.background = element_rect(fill = NA),
    legend.key.size = unit(10, "pt")
  ) +
  xlim(0, max(final_df$upper_95, na.rm = TRUE) * 1.2) 
write.table(final_df, paste0(save_fold,'CRC_cox_regression.csv'), col.names = T, sep = ',', row.names = T)
