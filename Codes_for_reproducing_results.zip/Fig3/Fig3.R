#######################################################################
# 1. model explainability, performance prediction for views selection

### view weights analysis
#######################################################################

#  if the package "this.path" has not been install please installed
# install.packages("this.path", repos = "https://cloud.r-project.org")
library("this.path", character.only = TRUE)
library(dplyr)
library(ggplot2)
library(tidyr)
library(rstatix)
library(openxlsx)
library(readxl)

script_path <- this.path()
script_dir <- dirname(script_path)
parent_fold<-dirname(script_dir)

root_fold<-paste0(script_dir, '/res/res_MCP/')

save_fold<-paste0(script_dir, '/res/Fig3/')
if(!dir.exists(save_fold)){
  dir.create(save_fold, recursive = TRUE)
}

########################
# Fig3a,b,c,d in res/Fig3/
# a:FragPipe_weights.svg
# b:Maxquant_weights.svg
# c:DIANN_weights.svg
# d:Spectronaut_weights.svg

root_fold_weight<-root_fold
views_names_all_DDA = c('dlfq', 'maxlfq', 'top0', 'top3', 'count')
views_names_all_DIA = c('dlfq', 'maxlfq', 'top3', 'top1')
views_DDA = c('view1', 'view2', 'view3', 'view4', 'view5')
views_DIA = c('view1', 'view2', 'view3', 'view4')

acq = 'DDA'
  views_names_all = views_names_all_DDA
  weights_all<-vector()
  for(v in 2:length(views_names_all)){
    cbns = combn(length(views_names_all),v) 
    for (s in 1:length(cbns[1,])) {
      vn = views_names_all[cbns[,s]]
      vnstr = acq
      vnnum = c()
      
      for (j in 1:length(vn)) {
        vnstr = paste0(vnstr, '_', vn[j])
        if(length(vnnum)==0){
          vnnum=as.character(cbns[,s][j])
        }else{
          vnnum = paste0(vnnum, '_', as.character(cbns[,s][j]))
        }
      }
      
      res = read_xlsx(paste0(root_fold_weight, acq, '_metrics_all_', as.character(v), 'views_', vnstr, '.xlsx'), sheet = 'view_weights') #DDA_metrics_all_2views_DDA_dlfq_count
      weights_all<-rbind(weights_all, res)
    }
    
  }
  write.table(weights_all, paste0(root_fold_weight, "DDA_view_weights_all.csv"), sep = ',', col.names = T, row.names = F)
  df_dda <- read.csv(paste0(root_fold_weight,"DDA_view_weights_all.csv"), stringsAsFactors = FALSE)

  fea_str_dda = views_names_all

  acq = 'DIA'
  views_names_all = views_names_all_DIA
  weights_all<-vector()
  for(v in 2:length(views_names_all)){
    cbns = combn(length(views_names_all),v) 
    for (s in 1:length(cbns[1,])) {
      vn = views_names_all[cbns[,s]]
      vnstr = acq
      vnnum = c()
      
      for (j in 1:length(vn)) {
        vnstr = paste0(vnstr, '_', vn[j])
        if(length(vnnum)==0){
          vnnum=as.character(cbns[,s][j])
        }else{
          vnnum = paste0(vnnum, '_', as.character(cbns[,s][j]))
        }
      }
      
      res = read_xlsx(paste0(root_fold_weight, acq, '_metrics_all_', as.character(v), 'views_', vnstr, '.xlsx'), sheet = 'view_weights') #DDA_metrics_all_2views_DDA_dlfq_count
      weights_all<-rbind(weights_all, res)
    }
    
  }
  write.table(weights_all, paste0(root_fold_weight, "DIA_view_weights_all.csv"), sep = ',', col.names = T, row.names = F)

  df_dia <- read.csv(paste0(root_fold_weight,"DIA_view_weights_all.csv"), stringsAsFactors = FALSE)

  fea_str_dia = views_names_all

df_dda[df_dda == -1] <- NA
df_dia[df_dia == -1] <- NA
colnames(df_dda)<-c('DEA',	'platform',	'dataset',	'dlfq',	'maxlfq',	'top0',	'top3', 'count')
colnames(df_dia)<-c('DEA',	'platform',	'dataset',	'dlfq',	'maxlfq',	'top3',	'top1')


pss<-list()
flag = 1

for(acq in c('DDA', 'DIA')){
  if(acq == 'DDA'){
    plts<-c('FragPipe', 'Maxquant')
    dfs = df_dda
    
  }else if(acq == 'DIA'){
    plts<-c('DIANN', 'Spectronaut')
    dfs = df_dia
  }
  for (plt in plts) {
    df = dfs[which(dfs$platform == plt),]

if (acq=='DDA'){
  df_long <- df %>%
    pivot_longer(
      cols = c(dlfq, maxlfq, top0, top3, count),
      names_to = "Feature",
      values_to = "Weight"
    ) %>%
    filter(!is.na(Weight)) %>%
    mutate(Feature = factor(Feature, levels = fea_str_dda))
}else if (acq=='DIA'){
  df_long <- df %>%
    pivot_longer(
      cols = c(dlfq, maxlfq, top3, top1),
      names_to = "Feature",
      values_to = "Weight"
    ) %>%
    filter(!is.na(Weight)) %>%
    mutate(Feature = factor(Feature, levels = fea_str_dia))#c("dlfq", "maxlfq", "top0", "top3", "count")))
}


platform_summary <- df_long %>%
  group_by(platform, Feature) %>%
  summarise(
    Mean = mean(Weight),
    SD = sd(Weight),
    N = n(),
    SE = SD / sqrt(N),
    .groups = "drop"
  )


stat_test_results <- df_long %>%
  group_by(platform) %>%
  t_test(Weight ~ Feature, p.adjust.method = "bonferroni") %>%
  add_significance("p.adj") %>%
  filter(p.adj < 0.05)


feature_positions <- data.frame(
  Feature = levels(df_long$Feature),
  x = 1:length(levels(df_long$Feature))
)

stat_links <- stat_test_results %>%
  group_by(platform) %>%
  mutate(group_num = row_number()) %>% 
  ungroup() %>%
  left_join(feature_positions, by = c("group1" = "Feature")) %>%
  rename(x_start = x) %>%
  left_join(feature_positions, by = c("group2" = "Feature")) %>%
  rename(x_end = x) %>% 
  left_join(
    platform_summary %>% 
      group_by(platform) %>% 
      summarise(y_base = max(Mean + SE)),
    by = "platform"
  ) %>%
  mutate(
    y_level = y_base + 0.2 * group_num,
    p_label = case_when(
      p.adj < 0.001 ~ "***",
      p.adj < 0.01 ~ "**",
      p.adj < 0.05 ~ "*",
      TRUE ~ ""
    )
  )


y_upper <- ifelse(nrow(stat_links) > 0, max(stat_links$y_level) + 0.3, 
                  max(platform_summary$Mean + platform_summary$SE) * 1.1)

write.table(platform_summary, paste0(save_fold, 'view_important_', acq, '_', plt, '.csv'), sep = ',', row.names = F, col.names = T)
ps<-ggplot(platform_summary, aes(x = Feature, y = Mean, fill = Feature)) +
  geom_col(width = 0.7, alpha = 0.9) +
  geom_errorbar(
    aes(ymin = Mean - SE, ymax = Mean + SE),
    width = 0.2,
    color = "black",
    linewidth = 0.6
  ) +
  {
    if(nrow(stat_links) > 0) {
      list(
        geom_segment(
          data = stat_links,
          aes(x = x_start, xend = x_end, y = y_level, yend = y_level),
          color = "black", linewidth = 0.6, inherit.aes = FALSE
        ),
        geom_segment(
          data = stat_links,
          aes(x = x_start, xend = x_start, y = y_level - 0.02, yend = y_level),
          color = "black", linewidth = 0.6, inherit.aes = FALSE
        ),
        geom_segment(
          data = stat_links,
          aes(x = x_end, xend = x_end, y = y_level - 0.02, yend = y_level),
          color = "black", linewidth = 0.6, inherit.aes = FALSE
        ),
        geom_text(
          data = stat_links,
          aes(x = (x_start + x_end)/2, y = y_level + 0.05, label = p_label),
          color = "black", size = 4, fontface = "bold", inherit.aes = FALSE
        )
      )
    }
  } +
  facet_wrap(~platform, ncol = 2) +
  scale_y_continuous(limits = c(NA, 1.1), expand = expansion(mult = c(0, 0.05))) +
  scale_fill_manual(values = c("#4DBBD5FF", "#00A087FF", "#E64B35FF", "#3C5488FF", "#F39B7FFF")) +  # Nature 期刊常用配色
  labs(
    #title = "none",
    x = "views",
    y = "Mean Weight (±SEM)",
    caption = "*p<0.05\n**p<0.01\n ***p<0.001"
  ) +
  theme_classic(base_family = "Helvetica", base_size = 14) +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1),
    axis.title = element_text(face = "bold"),
    plot.title = element_text(hjust = 0.5, face = "bold", size = 16),
    strip.background = element_blank(),
    strip.text = element_text(face = "bold", size = 14),
    legend.position = "none",
    axis.line = element_line(color = "black"),
    panel.grid = element_blank(),
    plot.caption = element_text(hjust = 0.5)
  )
pss[[flag]] = ps
flag = flag + 1
  }
}
pss[[1]]
pss[[2]]
pss[[3]]
pss[[4]]
plts<-c('FragPipe', 'Maxquant', 'DIANN', 'Spectronaut')
for (i in c(1:4)) {
  ggsave(paste0(save_fold, plts[i], '_weights.svg'), 
         plot = pss[[i]],
         device = svg,
         width = 6,
         height = 3,
         units = "in",
         limitsize = FALSE,
         dpi = 300)
}

#######################################################################
###########################################
## 
# Fig 3e,f,g,h in res/Fig3/cross_view_analysis/
# e: fragpipe_zscore_avg_cross_attention_heatmap_4x4.svg
# f: maxquant_zscore_avg_cross_attention_heatmap_4x4.svg
# g: diann_zscore_avg_cross_attention_heatmap_4x4.svg
# h: spectronaut_zscore_avg_cross_attention_heatmap_4x4.svg

library(tidyverse)
library(ggplot2)
library(igraph)
library(reshape2)
library(ggraph)
library(RColorBrewer)
library(pheatmap)
library(circlize)
library("this.path", character.only = TRUE)

script_path <- this.path()
script_dir <- dirname(script_path)
parent_fold<-dirname(script_dir)

root_fold<-paste0(parent_fold, '/DEA_Benchmarking/res/')

save_fold<-paste0(script_dir, '/res/Fig2/')
if(!dir.exists(save_fold)){
  dir.create(save_fold, recursive = TRUE)
}

base_path2 <- paste0(root_fold, '2views_MCP')  
files2 <- as.data.frame(list.files(base_path2, pattern = "*_view_cross_matrix.csv", full.names = TRUE, recursive = TRUE))
base_path3 <- paste0(root_fold, '3views_MCP')
base_path4 <- paste0(root_fold, '4views_MCP')
base_path5 <- paste0(root_fold, '5views_MCP')
files3 <- as.data.frame(list.files(base_path3, pattern = "*_view_cross_matrix.csv", full.names = TRUE, recursive = TRUE))
files4 <- as.data.frame(list.files(base_path4, pattern = "*_view_cross_matrix.csv", full.names = TRUE, recursive = TRUE))
files5 <- as.data.frame(list.files(base_path5, pattern = "*_view_cross_matrix.csv", full.names = TRUE, recursive = TRUE))

colnames(files2)<-'files'
colnames(files3)<-'files'
colnames(files4)<-'files'
colnames(files5)<-'files'
files = rbind(files2, files3, files4, files5)

files_fragpipe<-files[grep('FragPipe', files$files),]
files_maxquant<-files[grep('Maxquant', files$files),]
files_diann<-files[grep('DIANN', files$files),]
files_spectronaut<-files[grep('Spectronaut', files$files),]

softmax <- function(x) {
  exp_x <- exp(x - max(x))
  exp_x / sum(exp_x)
}

normalize_matrix <- function(mat, method = "raw") {
  if (method == "raw") {
    return(mat)
  } else if (method == "abs") {
    max_val <- max(abs(mat))
    if (max_val == 0) return(mat)
    return(mat / max_val)
  } else if (method == "zscore") {
    m <- mean(mat)
    s <- sd(as.vector(mat))
    if (s == 0) return(mat * 0)
    return((mat - m) / s)
  } else if (method == "pos_softmax") {
    mat[mat < 0] <- 0
    row_sums <- rowSums(mat)
    row_sums[row_sums == 0] <- 1  # 防止除0
    return(sweep(mat, 1, row_sums, "/"))
  }else if(method == 'softmax'){
    return(t(apply(mat, 1, softmax)))
  } else {
    stop("unknown methods")
  }
}

read_all_matrices <- function(files, method = "raw") {
  all_df <- list()
  for (csv in files) {
    mat <- read.csv(csv, row.names = 1, check.names = FALSE)
    mat[is.na(mat)] <- 0
    mat <- as.matrix(mat)
    row.names(mat)<-colnames(mat)
    
    fname <- basename(csv)
    dataset <- strsplit(dirname(csv), "/")[[1]]
    dataset <- tail(dataset, 1)
    view_list <- colnames(mat)
    
    norm_mat <- normalize_matrix(mat, method)
    df_long <- melt(norm_mat, varnames = c("From", "To"), value.name = "Attention")
    df_long <- df_long %>% filter(From != To)
    df_long$dataset <- dataset
    df_long$comb <- paste(view_list, collapse = '_')
    all_df[[length(all_df)+1]] <- df_long
  }
  bind_rows(all_df)
}

read_all_perform_matrices <- function(files, method='DP_direct') {
  all_df <- list()
  for (csv in files) {
    mat <- read.csv(csv, row.names = 1, check.names = FALSE)
    mcc = mat$Mcc[which(row.names(mat)==method)]
    mat[is.na(mat)] <- 0
    mat <- as.matrix(mat)
    
    fname <- basename(csv)
    dataset <- strsplit(dirname(csv), "/")[[1]]
    dataset <- tail(dataset, 1)
    view_list <- colnames(mat)
    
    df_long <- data.frame()
    df_long$dataset <- dataset
    df_long$comb <- paste(view_list, collapse = '_')
    df_long$mcc<-mcc
    all_df[[length(all_df)+1]] <- df_long
  }
  bind_rows(all_df)
}

# ======== zscore was used finally
for (normalization_method in c("raw", "abs", "zscore", "pos_softmax", 'softmax')){

  for (sub in c('fragpipe', 'maxquant', 'diann', 'spectronaut')){
    if(sub == 'fragpipe'){
      attn_all <- read_all_matrices(files_fragpipe, normalization_method)
      title = 'FragPIpe'
    }else if(sub == 'maxquant'){
      attn_all <- read_all_matrices(files_maxquant, normalization_method)
      title = 'Maxquant'
    }else if(sub == 'diann'){
      attn_all <- read_all_matrices(files_diann, normalization_method)
      title = 'DIANN'
    }else if(sub == 'spectronaut'){
      attn_all <- read_all_matrices(files_spectronaut, normalization_method)
      title = 'Spectronaut'
    }
    
    save_fold_cva<-paste0(save_fold, 'cross_view_analysis/')
    
    write.csv(attn_all, paste0(save_fold_cva, sub, '_', normalization_method, "_attentions.csv"), row.names = FALSE)

    # ==== ALL attention ====
    summary_df <- attn_all %>%
      group_by(From, To) %>%
      summarise(mean_attn = mean(Attention), .groups = "drop")
    
    mat_mean <- summary_df %>%
      pivot_wider(names_from = To, values_from = mean_attn) %>%
      column_to_rownames("From") %>%
      as.matrix()
    
    pheatmap(mat_mean,
             color = colorRampPalette(brewer.pal(9, "YlGnBu"))(100),
             cluster_rows = FALSE,
             cluster_cols = FALSE,
             display_numbers = TRUE,
             number_format = "%.2f",
             main = paste("交叉注意力热图 (标准化方法:", normalization_method, ")"),
             fontsize_number = 10,
             legend = TRUE)
    
    heatmap(mat_mean, col = colorRampPalette(brewer.pal(9, "YlGnBu"))(100),
            main = paste("交叉注意力热图 (方法:", normalization_method, ")"))
    
    # ==== top 25% attention ====
    net_df <- summary_df %>%
      filter(mean_attn > quantile(mean_attn, 0.75))
    
    g <- graph_from_data_frame(net_df, directed = TRUE)
    E(g)$weight <- net_df$mean_attn
    
    p <- ggraph(g, layout = 'circle') + 
      geom_edge_fan(aes(width = weight, alpha = weight), color = "steelblue") +
      geom_node_point(size = 6, color = "darkorange") +
      geom_node_text(aes(label = name), size = 5, vjust = 1.5) +
      theme_void() +
      ggtitle(paste("Top25% cross-view -", normalization_method))
    ggsave(filename = paste0(save_fold_cva, sub,'_', normalization_method, "_interact_network_top25.svg"),
           plot = p,
           width = 8, height = 8,
           dpi = 300,
           device = "svg")
    # ==== Outflow & Inflow ====
    top_contrib <- summary_df %>%
      group_by(From) %>%
      summarise(outflow = sum(mean_attn)) %>%
      arrange(desc(outflow))
    
    top_receive <- summary_df %>%
      group_by(To) %>%
      summarise(inflow = sum(mean_attn)) %>%
      arrange(desc(inflow))
    
    p1 <- ggplot(top_contrib, aes(x = reorder(From, outflow), y = outflow)) +
      geom_col(fill = "skyblue") + coord_flip() +
      labs(title = " Outflow", x = "view", y = "amount")
    
    p2 <- ggplot(top_receive, aes(x = reorder(To, inflow), y = inflow)) +
      geom_col(fill = "salmon") + coord_flip() +
      labs(title = "Inflow", x = "view", y = "amount")
    
    print(p1)
    print(p2)
    
    library(ggplot2)
    
    avg_matrix <- attn_all %>%
      group_by(From, To) %>%
      summarise(mean_attn = mean(Attention, na.rm = TRUE)) %>%
      ungroup()
    
    p <- ggplot(avg_matrix, aes(x = To, y = From, fill = mean_attn)) +
      geom_tile(color = "grey90") +  # 增加瓦片边框以提升辨识度
      scale_fill_gradient2(
        low = "#2166ac", mid = "white", high = "#b2182b", midpoint = 0,
        name = "Mean attention"
      ) +
      coord_fixed() +
      labs(
        title = title,
        x = "To view",
        y = "From view"
      ) +
      theme_minimal(base_family = "Helvetica") +
      theme(
        plot.title = element_text(size = 16, face = "bold", hjust = 0.5),
        axis.title = element_text(size = 14, face = "bold"),
        axis.text = element_text(size = 12, color = "black"),
        legend.title = element_text(size = 12, face = "bold"),
        legend.text = element_text(size = 11),
        panel.grid = element_blank()  # 去掉网格线以提升视觉集中度
      )
    
    ggsave(
      filename = paste0(save_fold_cva, sub, '_', normalization_method, "_avg_cross_attention_heatmap.svg"),
      plot = p,
      width = 8, height = 8,
      dpi = 300,
      device = "svg"
    )
    
    chord_df <- avg_matrix %>%
      filter(From != To) %>%
      select(From, To, mean_attn) %>%
      rename(value = mean_attn)
    
    view_names <- c('dlfq','maxlfq','top0', 'top3', 'top1','count')
    view_colors <- setNames(RColorBrewer::brewer.pal(n = length(view_names), name = "Set2"), view_names)
    
    svg(filename = paste0(save_fold_cva, sub, '_', normalization_method, "_avg_cross_attention_chord.svg"),
        width = 8, height = 8)
    
    circos.clear()
    chordDiagram(
      chord_df,
      grid.col = view_colors,
      transparency = 0.25,
      annotationTrack = c("grid"),
      preAllocateTracks = list(track.height = 0.1)
    )
    
    circos.trackPlotRegion(
      track.index = 1,
      panel.fun = function(x, y) {
        circos.text(
          CELL_META$xcenter, CELL_META$ylim[1] + mm_y(5),
          CELL_META$sector.index,
          facing = "bending",
          niceFacing = TRUE,
          adj = c(0, 0.5),
          cex = 3,
          col = "black"
        )
      }, bg.border = NA
    )
    
    dev.off()
  }
}

####################################################################
################## 
### regression analysis (python)
# Fig 3i in /data/combination_selection/raincloud_spearman.svg
# Fig 3j in /data/combination_selection/res_all_exp_MCC_new_all08_MCC__shap_summary_plot_nature_style3.svg
## spearman correlation
library(ggplot2)
library(ggdist)
library(ggpubr)
library(dplyr)
library(cowplot)

root_fold<-paste0(parent_fold,'/View_combination_selection/')
sprs<-read.table(paste0(root_fold, 'test_MCC__nest_cv_all_res_shap3.csv'), header = T,sep = ',')
plts<-unlist(lapply(sprs$dataset, function(x) strsplit(x, '_', fixed = T)[[1]][1]))
sprs$Platform<-plts
sprs$Platform<-factor(sprs$Platform, levels = c("FragPipe", "Maxquant", "DIANN", "Spectronaut"))

p <- ggplot(sprs, aes(x = Platform, y = Spearman, fill = Platform)) +
  # half violin
  stat_halfeye(
    adjust = .5, width = .6, .width = 0,
    justification = -0.2, point_color = NA, alpha = 0.6
  ) +
  # jitter points
  geom_jitter(
    aes(color = Platform), width = 0.12, size = 1.4, alpha = 0.6, show.legend = FALSE
  ) +
  # boxplot
  geom_boxplot(
    width = .15, outlier.shape = NA, alpha = 0.4, color = "black"
  ) +
  # median
  stat_summary(fun = median, geom = "crossbar", width = 0.3, color = "black", fatten = 2) +
  scale_fill_brewer(palette = "Set2") +
  scale_color_brewer(palette = "Set2") +
  coord_cartesian(ylim = c(min(sprs$Spearman)-0.1, 1)) +
  theme_classic(base_size = 14) +
  theme(
    axis.title.x = element_blank(),
    axis.title.y = element_text(size = 14),
    axis.text.x = element_text(size = 12),
    legend.position = "none"
  ) +
  ylab("Spearman correlation")

print(p)

# ===== SVG or PDF =====
ggsave(paste0(save_fold, "raincloud_spearman.svg"), plot = p, width = 8, height = 5)
ggsave(paste0(save_fold,"raincloud_spearman.pdf"), plot = p, width = 8, height = 5)
