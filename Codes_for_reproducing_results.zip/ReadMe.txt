**The simple instruction of how to use the codes reproduce the results.


*1. Complementary_feature_extraction: the python codes for extracting the view combination features. Run:

    python complementary_feature.py
   
   Please make sure the variable "R_script" in the script "complementary_feature.py" should be replaced
   by the Rscript executable tool path (usually under the bin fold of your R installation path)
   
   
*2. DEA_Benchmarking: the python codes for implementing performance benchmarking of the baseline tools and 
   MCP, for reproducing the ablation studies, the investigating the effection of reference view selection.
   
   2.1 Comparing MCP, single view methods and hurdle, run:
    
	  python MCP_benchmark.py
	  
   2.2  performance evaluation of DMVLS, run:
   
      python MCP_benchmark.py
	  
   2.3  performance evaluation of ETMC, run:
   
      python ETMC_benchmark.py
   
   2.4  ablation studies, run:
   
      python MCP_benchmark_ablation_ASB.py
	  python MCP_benchmark_ablation_Contrastive.py
	  python MCP_benchmark_ablation_no_Fusion.py
	  
   2.5 affection of reference view selection, run:
   
      python MCP_reference_partner.py
	  
   2.6  testing the alternative strategy for labeling proteins before MCP training, run:
   
      python MCP_label_all_view_intersect.py
	  
*3 View_combination_selection: the python codes for implementing view combination selection for 
   preparing the inputs to MCP. Run:
   
      python combination_selection.py
	  
*4 Case_studies: python codes for coducting case studies, run:

      python MVcontrast_DEA_TPD_dis.py
	  python MVcontrast_DEA_TPD_ret.py
	  python MVcontrast_DEA_CRC.py
	  python MVcontrast_DEA_U2OS_bulk.py
	  python MVcontrast_DEA_U2OS_rb.py
	  
*5 Clustering: python codes for reproducing patient and cell clustering, run:

      python sample_clustering.py
	  
*6 Patient_diagnosis: python codes for reproducing the patient diagnosis, run:

      python TPD_classification.py
	  
*7 Fig1~Fig5: R codes for reproducing the Figures shown in our manuscript.

*8 data: the view data

*9 R_code: the R_code we used in proteomics data analysis

*10 MCP: the python codes of our MCP, to conduct DEA with MCP, please run:

      python MCP.py -f [view fold folder]                    \
	                -q [adj.pvalue threshold]                \
					-l [the logFC threshold]                 \
					-p [the quantification platform]         \
					-o [whether conduct log2 Transformation] \
					-g1 [the first group in comparison]      \
					-g2 [the second group in comparison]     \
					-R [Rscript path]                        \
					-s [save fold path]                      \
					-A [acqusition type]                     \
					-S [whether select view combination ]    \
					
     where -f [view fold folder], requires the input of the folder that you store your view files and design file.
	                -q [adj.pvalue threshold], requires the input of the adj.p-value threshold in DEA.
					-l [the logFC threshold], requires the input of the logFC threshold in DEA.
					-p [the quantification platform], specify the platform for MS raw data quantification can be FragPipe or Maxquant for DDA data, DIANN or Spectronaut for DIA data.
					-o [whether conduct log2 Transformation], should be a vector indication the corresponding view should be or not be log2 transformed, e.g., [T,T,T,T,T] for DDA data, which means all five views should be log2 transformed.
					-g1 [the first group in comparison], the name of the first group in DEA, e.g., normal
					-g2 [the second group in comparison], the name of the second group in DEA, e.g., cancer
					-R [Rscript path], the path to the Rscript executable tool in your device. For windows, it should be under the "bin/" folder of your R installation adress. For linux, it should be under "/usr/bin/" by default.
					-s [save fold path], the path that you plan to store the DEA analysis results.
					-A [acqusition type], specify the acqusition type of the MS data, e.g., DDA or DIA.
					-S [whether select view combination ], specify whether conduct view selection, "T" means applying view selection, "F" means do not apply view selection and use the best view combination per or benchmarking results.
					

   
   
   
      
   