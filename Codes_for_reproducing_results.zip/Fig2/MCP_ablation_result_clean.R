library("readxl")
library(ggplot2)
library(reshape2)
library(ggpubr)
library(cowplot)
library(svglite)
library("this.path", character.only = TRUE)

script_path <- this.path()
script_dir <- dirname(script_path)
parent_fold<-dirname(script_dir)
tools = c('MCP_ASB', 'MCP_Contrast', 'MCP_nofuse')
tool = 'MCP_ASB'
dea_res_fold = paste0(parent_fold, '/DEA_Benchmarking/res/')

save_fold = paste0(script_dir, '/res/res_MCP_ablation/')
if(!dir.exists(save_fold)){
  dir.create(save_fold, recursive = TRUE)
}


views_names_all_DDA = c('dlfq', 'maxlfq', 'top0', 'top3', 'count')
views_names_all_DIA = c('dlfq', 'maxlfq', 'top3', 'top1')
views_DDA = c('view1', 'view2', 'view3', 'view4', 'view5')
views_DIA = c('view1', 'view2', 'view3', 'view4')
pss = list()
view_weights<-c()
for (v in c(2:3)) {
  views_names_list = list()
  views_names_list[[1]]=c('dlfq', 'top0', 'top3') # Maxquant
  views_names_list[[2]]=c('dlfq', 'count') # FragPipe
  for (s in 1:length(views_names_list)) {
    vn = views_names_list[s]

    vnstr = 'DDA'
    for (j in vn) {
      vnstr = paste0(vnstr, '_', j)
    }
    print(vnstr)
    res_folder=paste0(dea_res_fold, as.character(v),'views_', tool, '/',vnstr,'/')

    platform = c('FragPipe', 'Maxquant')
    deas = c('limma', 'ROTS')
    metric = c('Mcc', 'pauc005', 'Prec', 'Rec')
    dts_dda<-read.table(paste0(parent_fold, '/DEA_Benchmarking/data/dataset_info/DDA_Frag.txt'), sep = '\t', header = T)
    dt_idx_dda<-c(6, 0, 3, 1, 7, 9, 4, 2, 5, 10, 11)+1
    
    dts<-dts_dda
    dt_idx<-dt_idx_dda
    mccs<-c()
    paucs<-c()
    precs<-c()
    recs<-c()
    f1s<-c()
    names<-c()
    
    for(idx in dt_idx){
      flag=0
      for (plt in platform) {
        for (dea in deas) {
          if (file.exists(paste0(res_folder,'temp', as.character(flag), '_', dea, '_', plt, '_view',as.character(v),'/', dts$dataset[idx], '/', dts$dataset[idx], '__metrics_all_s.csv'))){
            res<-read.table(paste0(res_folder,'temp', as.character(flag), '_', dea, '_', plt, '_view',as.character(v),'/', dts$dataset[idx], '/', dts$dataset[idx], '__metrics_all_s.csv'), sep = ',', header = T)
            view_weight = read.table(paste0(res_folder,'temp', as.character(flag), '_', dea, '_', plt, '_view',as.character(v),'/', dts$dataset[idx], '/', dts$dataset[idx], '_view_weights.csv'), sep = ',', header = T)
            vw<-c(rep(-1, length(views_DDA)))
            com_name = intersect(colnames(view_weight),views_names_all_DDA)
            v_idx<-match(com_name, views_names_all_DDA)
            v_idx_w<-match(com_name, colnames(view_weight)) 
            vw[v_idx] =  as.numeric(view_weight)[v_idx_w]
            view_weights<-rbind(view_weights, c(dea, plt,dts$dataset[idx],vw))
            if(length(mccs)==0){
              mccs<-cbind(res[,1], res[,which(colnames(res)=='Mcc')])
              paucs<-cbind(res[,1], res[,which(colnames(res)=='pauc005')])
              precs<-cbind(res[,1], res[,which(colnames(res)=='Prec')])
              recs<-cbind(res[,1], res[,which(colnames(res)=='Rec')])
              f1s<-cbind(res[,1], res[,which(colnames(res)=='F1')])
              names<-c('method', paste0(dts$dataset[idx], '_', plt, '_', dea))
            }else{
              mccs<-cbind(mccs, res[,which(colnames(res)=='Mcc')])
              paucs<-cbind(paucs, res[,which(colnames(res)=='pauc005')])
              precs<-cbind(precs, res[,which(colnames(res)=='Prec')])
              recs<-cbind(recs, res[,which(colnames(res)=='Rec')])
              f1s<-cbind(f1s, res[,which(colnames(res)=='F1')])
              names<-c(names, paste0(dts$dataset[idx], '_', plt, '_', dea))
            }
            flag<-flag+1
          }
        }
      }
      
    }
    colnames(mccs)<-names
    colnames(paucs)<-names
    colnames(precs)<-names
    colnames(recs)<-names
    colnames(f1s)<-names
    
    if(length(mccs)==0){
      next
    }
    
    library(openxlsx)
    wb1 <- createWorkbook()
    sheet='MCC'
    addWorksheet(wb1,sheet)
    writeData(wb1, sheet, mccs, startRow = 1, startCol = 1, colNames = TRUE, rowNames = FALSE)
    
    sheet='F1'
    addWorksheet(wb1,sheet)
    writeData(wb1, sheet, f1s, startRow = 1, startCol = 1, colNames = TRUE, rowNames = FALSE)
    
    sheet='pAUC'
    addWorksheet(wb1,sheet)
    writeData(wb1, sheet, paucs, startRow = 1, startCol = 1, colNames = TRUE, rowNames = FALSE)
    
    sheet='Prec'
    addWorksheet(wb1,sheet)
    writeData(wb1, sheet, precs, startRow = 1, startCol = 1, colNames = TRUE, rowNames = FALSE)
    
    sheet='Rec'
    addWorksheet(wb1,sheet)
    writeData(wb1, sheet, recs, startRow = 1, startCol = 1, colNames = TRUE, rowNames = FALSE)
    
    sheet='view_weights'
    addWorksheet(wb1,sheet)
    writeData(wb1, sheet, as.data.frame(view_weights), startRow = 1, startCol = 1, colNames = TRUE, rowNames = FALSE)
    
    saveWorkbook(wb1, file = paste0(save_fold,'DDA_metrics_all_',as.character(v),'views_',vnstr,'.xlsx'), overwrite = TRUE)
    
    
    
    ps = list()
    
    for (acq in c('DDA')) {
      if (acq =='DDA'){
        platforms = c('FragPipe', 'Maxquant')
      }else if(acq == 'DIA'){
        platforms = c('DIANN','Spectronaut')
      }
      for (platform in platforms) {
        
        mat_cb<-c()
        library(openxlsx)
        wb2 <- createWorkbook()

        for (metric in c('MCC', 'pAUC', 'Prec', 'Rec', 'F1')) {
          
          data_fold = res_folder
          
          m_all = read_excel(paste0(save_fold, acq, '_metrics_all_',as.character(v),'views_',vnstr,'.xlsx'), sheet = metric)
          methods = c(views_DDA[1:v], c('hurdle', 'DL_KNN', 'DL_pred', 'DP_vote', 'DP_fdr', 'DP_05'))

          row.names(m_all)<-methods
          
          a<-melt(t(m_all))
          colnames(a)<-c('dataset', 'Method', 'Performance')
          a$Metric<-metric
          mat_cb<-rbind(mat_cb, a)
          
        }
        sheet='all'
        addWorksheet(wb2,sheet)
        writeData(wb2, sheet, mat_cb, startRow = 1, startCol = 1, colNames = TRUE, rowNames = FALSE)
        saveWorkbook(wb2, file = paste0(save_fold, acq, '_', platform,'_',as.character(v),'views_',vnstr, '.xlsx'), overwrite = TRUE)
        view_col<-c("#b2df8a","#33a02c","#1f78b4", '#12d000', "#417000")
        if(platform == 'Spectronaut' | platform == 'DIANN'){
          lel = c(views_DIA[1:v], c(
            'hurdle', 'DL_KNN', 'DL_pred', 'DP_vote', 'DP_fdr', 'DP_05'))
          
        }else if(platform == 'Maxquant' | platform == 'FragPipe'){
          lel = c(views_DDA[1:v], c(
            'hurdle', 'DL_KNN', 'DL_pred', 'DP_vote', 'DP_fdr', 'DP_05'))
        }
        col<-c(view_col[1:v],c("#F7DC6F",
                               "purple", '#C0392B','#C71585', '#00CED1', 'pink', '#7FFFD4','red','black'))
        mat_cb$Method <- factor(mat_cb$Method, levels=lel)
        mat_cb$Performance<-as.numeric(mat_cb$Performance)
        mat_cb<-mat_cb[which(!is.na(mat_cb$Method)),]
        
        p1<-ggboxplot(mat_cb, "Metric", "Performance",width = 0.7, size=1,
                      color = "Method", fill = 'Method', alpha=0.5, palette =col,
                      add = "jitter", add.params = list(alpha=0.1,size=0.7),
                      title = platform)+
          labs(x = '', y = 'Metric value')+
          scale_x_discrete(limits=unique(mat_cb$Metric)) +
          scale_y_continuous(limits = c(min(mat_cb$Performance-0.05),
                                        max(mat_cb$Performance+0.05)))+theme_classic() +
          theme(axis.title.y= element_text(size=12, face = 'bold'))+
          theme(axis.title.x = element_text(size = 10),
                axis.text.x = element_text(size = 10, face = 'bold'),
                axis.text.y = element_text(size = 10, face = 'bold'))+
          theme(legend.position = "right")+
          stat_summary(fun=mean, geom="point", shape=20, aes(group=Method),
                       position=position_dodge(.8), size=2, color="red", fill="red")+
          theme(plot.title = element_text(size = 12,hjust = 0.5, face = "bold"))+

          theme(text=element_text(family="Times New Roman", size=12))
        ggsave(paste0(save_fold, acq, '_', platform,'_',as.character(v),'views_',vnstr, '.svg'), plot = p1, width = 12, height = 10)
        p1
        ps<-append(ps, list(p=p1))
      }
    }
    pss<-append(pss, list(ps=ps))
  }
}

for (v in c(2:3)) {
  views_names_list = list()
  views_names_list[[1]]=c('dlfq', 'maxlfq', 'top3') # Spectronaut
  views_names_list[[2]]=c('dlfq', 'maxlfq', 'top1') # DIA-NN
  for (s in 1:length(views_names_list)) {
    vn = views_names_list[s]

    vnstr = 'DIA'
    for (j in vn) {
      vnstr = paste0(vnstr, '_', j)
    }
    res_folder=paste0(dea_res_fold, as.character(v),'views_', tool, '/',vnstr,'/')

    platform = c('DIANN', 'Spectronaut')
    deas = c('limma', 'ROTS')
    metric = c('Mcc', 'pauc005', 'Prec', 'Rec')
    dts_dia<-read.table(paste0(parent_fold, '/DEA_Benchmarking/data/dataset_info/DIA_DIANN.txt'), sep = '\t', header = T)
    dt_idx_dia<-c(2, 3, 4, 5, 6, 1, 0)+1
    dts<-dts_dia
    dt_idx<-dt_idx_dia
    mccs<-c()
    paucs<-c()
    precs<-c()
    recs<-c()
    names<-c()
    f1s<-c()
    
    for(idx in dt_idx){
      flag=0
      for (plt in platform) {
        for (dea in deas) {
          if (file.exists(paste0(res_folder,'temp', as.character(flag), '_', dea, '_', plt, '_view',as.character(v),'/', dts$dataset[idx], '/', dts$dataset[idx], '__metrics_all_s.csv'))){
            res<-read.table(paste0(res_folder,'temp', as.character(flag), '_',dea, '_', plt, '_view',as.character(v),'/', dts$dataset[idx], '/', dts$dataset[idx], '__metrics_all_s.csv'), sep = ',', header = T)
          }else{
            next
          }
          if(length(mccs)==0){
            mccs<-cbind(res[,1], res[,which(colnames(res)=='Mcc')])
            paucs<-cbind(res[,1], res[,which(colnames(res)=='pauc005')])
            precs<-cbind(res[,1], res[,which(colnames(res)=='Prec')])
            recs<-cbind(res[,1], res[,which(colnames(res)=='Rec')])
            f1s<-cbind(res[,1], res[,which(colnames(res)=='F1')])
            names<-c('method', paste0(dts$dataset[idx], '_', plt, '_', dea))
          }else{
            mccs<-cbind(mccs, res[,which(colnames(res)=='Mcc')])
            paucs<-cbind(paucs, res[,which(colnames(res)=='pauc005')])
            precs<-cbind(precs, res[,which(colnames(res)=='Prec')])
            recs<-cbind(recs, res[,which(colnames(res)=='Rec')])
            f1s<-cbind(f1s, res[,which(colnames(res)=='F1')])
            names<-c(names, paste0(dts$dataset[idx], '_', plt, '_', dea))
          }
          flag<-flag+1
        }
      }
      
    }
    colnames(mccs)<-names
    colnames(paucs)<-names
    colnames(precs)<-names
    colnames(recs)<-names
    colnames(f1s)<-names
    
    if(length(mccs)==0){
      next
    }
    
    library(openxlsx)
    wb1 <- createWorkbook()
    sheet='MCC'
    addWorksheet(wb1,sheet)
    writeData(wb1, sheet, mccs, startRow = 1, startCol = 1, colNames = TRUE, rowNames = FALSE)
    
    sheet='F1'
    addWorksheet(wb1,sheet)
    writeData(wb1, sheet, f1s, startRow = 1, startCol = 1, colNames = TRUE, rowNames = FALSE)
    
    sheet='pAUC'
    addWorksheet(wb1,sheet)
    writeData(wb1, sheet, paucs, startRow = 1, startCol = 1, colNames = TRUE, rowNames = FALSE)
    
    sheet='Prec'
    addWorksheet(wb1,sheet)
    writeData(wb1, sheet, precs, startRow = 1, startCol = 1, colNames = TRUE, rowNames = FALSE)
    
    sheet='Rec'
    addWorksheet(wb1,sheet)
    writeData(wb1, sheet, recs, startRow = 1, startCol = 1, colNames = TRUE, rowNames = FALSE)
    saveWorkbook(wb1, file = paste0(save_fold,'DIA_metrics_all_',as.character(v),'views_',vnstr,'.xlsx'), overwrite = TRUE)
    
    ps = list()
    
    for (acq in c('DIA')) {
      if (acq =='DDA'){
        platforms = c('FragPipe', 'Maxquant')
      }else if(acq == 'DIA'){
        platforms = c('DIANN','Spectronaut')
      }
      for (platform in platforms) {
        
        mat_cb<-c()
        library(openxlsx)
        wb2 <- createWorkbook()

        for (metric in c('MCC', 'pAUC', 'Prec', 'Rec', 'F1')) {
          
          data_fold = res_folder
          
          m_all = read_excel(paste0(save_fold, acq, '_metrics_all_',as.character(v),'views_',vnstr,'.xlsx'), sheet = metric)
          methods = c(views_DDA[1:v], c('hurdle', 'DL_KNN', 'DL_pred', 'DP_vote', 'DP_fdr', 'DP_05'))
          row.names(m_all)<-methods
          
          a<-melt(t(m_all))
          colnames(a)<-c('dataset', 'Method', 'Performance')
          a$Metric<-metric
          mat_cb<-rbind(mat_cb, a)
          
        }
        sheet='all'
        addWorksheet(wb2,sheet)
        writeData(wb2, sheet, mat_cb, startRow = 1, startCol = 1, colNames = TRUE, rowNames = FALSE)
        saveWorkbook(wb2, file = paste0(save_fold,acq, '_', platform,'_',as.character(v),'views_',vnstr,'.xlsx'), overwrite = TRUE)
        view_col<-c("#b2df8a","#33a02c","#1f78b4", '#12d000', "#417000")
        if(platform == 'Spectronaut' | platform == 'DIANN'){
          lel = c(views_DIA[1:v], c(
            'hurdle', 'DL_KNN', 'DL_pred', 'DP_vote', 'DP_fdr', 'DP_05'))
        }else if(platform == 'Maxquant' | platform == 'FragPipe'){
          lel = c(views_DDA[1:v], c(
            'hurdle', 'DL_KNN', 'DL_pred', 'DP_vote', 'DP_fdr', 'DP_05'))
        }
        col<-c(view_col[1:v],c("#F7DC6F",
                               "purple", '#C0392B','#C71585', '#00CED1', 'pink', '#7FFFD4','red','black'))
        mat_cb$Method <- factor(mat_cb$Method, levels=lel)
        mat_cb$Performance<-as.numeric(mat_cb$Performance)
        mat_cb<-mat_cb[which(!is.na(mat_cb$Method)),]
        
        p1<-ggboxplot(mat_cb, "Metric", "Performance",width = 0.7, size=1,
                      color = "Method", fill = 'Method', alpha=0.5, palette =col,
                      add = "jitter", add.params = list(alpha=0.1,size=0.7),
                      title = platform)+
          labs(x = '', y = 'Metric value')+
          scale_x_discrete(limits=unique(mat_cb$Metric)) +
          scale_y_continuous(limits = c(min(mat_cb$Performance-0.05),
                                        max(mat_cb$Performance+0.05)))+theme_classic() +
          theme(axis.title.y= element_text(size=12, face = 'bold'))+
          theme(axis.title.x = element_text(size = 10),
                axis.text.x = element_text(size = 10, face = 'bold'),
                axis.text.y = element_text(size = 10, face = 'bold'))+
          theme(legend.position = "right")+
          stat_summary(fun=mean, geom="point", shape=20, aes(group=Method),
                       position=position_dodge(.8), size=2, color="red", fill="red")+
          theme(plot.title = element_text(size = 12,hjust = 0.5, face = "bold"))+

          theme(text=element_text(family="Times New Roman", size=12))
        ggsave(paste0(save_fold, acq, '_', platform,'_',as.character(v),'views_',vnstr, '.svg'), plot = p1, width = 12, height = 10)
        p1
        ps<-append(ps, list(p=p1))
      }
    }
    pss<-append(pss, list(ps=ps))
  }
  
}
