#######################################################################
####
# 1. benchmarking results
# 2. ablation study results
# 3. single dataset discussion (DIA 0375)：AUCs、intersections、UMAP for representation (no hurdle)
######################################################################

#  if the package "this.path" has not been installed please install
# install.packages("this.path", repos = "https://cloud.r-project.org")

library("this.path", character.only = TRUE)
library(readxl)
library(ggplot2)
library(reshape2)
library(ggpubr)
library(cowplot)
library(openxlsx)
library(scales)
library(dplyr)

script_path <- this.path()
script_dir <- dirname(script_path)
parent_fold<-dirname(script_dir)

root_fold<-paste0(script_dir, '/res/res_MCP/')

save_fold<-paste0(script_dir, '/res/Fig2/')
if(!dir.exists(save_fold)){
  dir.create(save_fold, recursive = TRUE)
}

# the following folder store the statistics
if(!dir.exists(paste0(save_fold, 'stats/'))){
  dir.create(paste0(save_fold, 'stats/'), recursive = TRUE)
}


##############################################################################
###############
# Fig 2a,b,c in folder: Figures/res/Fig2/stats/
# a:stats_DIA_DIANN_MCC_median.svg
# b:stats_DIA_DIANN_Rec_median.svg
# c:stats_DIA_DIANN_Prec_median.svg

subs<-c('ETMC', 'MCP', 'DMVLS')
views_names_all_DDA = c('dlfq', 'maxlfq', 'top0', 'top3', 'count')
views_names_all_DIA = c('dlfq', 'maxlfq', 'top3', 'top1')
views_DDA = c('view1', 'view2', 'view3', 'view4', 'view5')
views_DIA = c('view1', 'view2', 'view3', 'view4')

get_matrix<-function(out_dt, mths, cbns, avgty){
  out_mat<-matrix(nrow = length(cbns), ncol = length(mths))
  for (i in 1:length(mths)) {
    for(j in 1:length(cbns)){
      if(length(which(out_dt$cbn==cbns[j] & out_dt$method==mths[i]))>0){
      if(avgty=='mean'){
        
        out_mat[j, i] = out_dt$Mean[which(out_dt$cbn==cbns[j] & out_dt$method==mths[i])]
      }else if(avgty=='median'){
        
        out_mat[j, i] = out_dt$Median[which(out_dt$cbn==cbns[j] & out_dt$method==mths[i])]
      }
      }
    }
  }
  out_mat<-as.data.frame(out_mat)
  colnames(out_mat)<-mths
  row.names(out_mat)<-cbns
  return(out_mat)
}


for (avgty in c('mean', 'median')) {
  acqs = c('DIA', 'DIA', 'DDA', 'DDA')
  plts = c('Spectronaut','DIANN',  'FragPipe', 'Maxquant')

  for (m in 1:length(acqs)) {
    acq=acqs[m]#'DDA'#'DIA'
    plt = plts[m]#'FragPipe'
    all_cbn = c()
    statss<-vector()
    for(sub in subs){
      
      if(acq=='DDA'){
        tv=length(views_DDA)
      }else if(acq=='DIA'){
        tv=length(views_DIA)
      }
      
      for (v in c(2:tv)) {
        res_all=vector()
        
        if(acq=='DDA'){
          view_names = views_names_all_DDA
        }else if(acq=='DIA'){
          view_names = views_names_all_DIA
        }
        
        cbns = combn(length(view_names),v) 
        
        for (s in 1:length(cbns[1,])) {
          vn = view_names[cbns[,s]]
          vnstr = acq
          vnnum = c()
          
          for (j in 1:length(vn)) {
            vnstr = paste0(vnstr, '_', vn[j])
            if(length(vnnum)==0){
              vnnum=as.character(cbns[,s][j])
            }else{
              vnnum = paste0(vnnum, '_', as.character(cbns[,s][j]))
            }
          }
          
          all_cbn=c(all_cbn, vnnum)
          
          res = read_xlsx(paste0(root_fold, 'res_', sub, '/', acq, '_', plt, '_',
                                 as.character(v),'views_', vnstr,'.xlsx'), sheet = 'all')
          
          if(sub == 'ETMC'){
            res<-res[res$Method %in% c('ETMC_prob','ETMC_fdr', 'ETMC_lab'), ]
          }else if(sub == 'DMVLS'){
            res<-res[res$Method %in% c('DVMLC_f1','DVMLC_prob'), ]
          }else if(sub == 'MCP'){
            res<-res[res$Method %in% c('view1','view2','view3','view4','view5','dlfq', 'maxlfq', 'top0', 'top3', 'top1', 'count',
                                          'hurdle','DP_fdr'), ]
          }
          mths = unique(res$Method)
          mtrs = unique(res$Metric)
          
          svs = unique(res$Method[grep('view',res$Method)])
          if(length(svs)>0){
          for (x in 1:length(svs)) {
            vidx = as.numeric(gsub('view','',svs[x]))
            res$Method[which(res$Method==svs[x])] = vn[vidx]
          }
          }
          mths = unique(c(res$Method, view_names))
          for(mth in mths){
            for(mtr in mtrs){
              if(mth == 'hurdle'){
                a=0
              }
              if(length(grep(mth, res$Method))==0){
                avg=NaN
                med=NaN
                std=NaN
                num=0
                
              }else{
                avg = mean(as.numeric(res$Performance[which(res$Method==mth & res$Metric==mtr)]))
                med = median(as.numeric(res$Performance[which(res$Method==mth & res$Metric==mtr)]))
                std = sd(as.numeric(res$Performance[which(res$Method==mth & res$Metric==mtr)]))
                num = length(res$Performance[which(res$Method==mth & res$Metric==mtr)])
              }
              
              out = c(sub, acq, plt, v, vnstr, vnnum, mth, mtr, avg, med, std, num)
              statss<-rbind(statss, out)
            }
          }
        }
      }
    }
    statss<-as.data.frame(statss)
    colnames(statss)<-c('Test', 'Acq', 'platform', 'viewnum', 'viewstr', 'cbn', 'method', 'metric', 'Mean', 'Median', 'sd', 'testnum')
    
    if(plt=='DIANN'){
      a=0
    }
    
    wb1 <- createWorkbook()
    
    for(mtr in unique(statss$metric)){
      if(mtr=='F1'){
        a=0
      }
      sheet=mtr
      addWorksheet(wb1,sheet)
      out_dt = statss[which(statss$metric==mtr),]
      out_dt = out_dt[which(out_dt$method!='MVIDIA' & out_dt$method!='Concat' & out_dt$method!='MLE'),]
      remove_idx<-c()
      remove_idx<-c(remove_idx, which(out_dt$Test=='ETMC' & out_dt$method %in% view_names))
      remove_idx<-c(remove_idx, which(out_dt$Test=='DMVLS' & out_dt$method %in% view_names))
      out_dt<-out_dt[-remove_idx,]
      
      out_dt$Mean<-round(as.numeric(out_dt$Mean), 2)
      out_dt$Median<-round(as.numeric(out_dt$Median), 2)
      
      out_dt<-out_dt[out_dt$method %in% c('dlfq', 'maxlfq', 'top0', 'top3', 'top1', 'count',
                                          'hurdle','DP_fdr','ETMC_prob','DVMLC_f1'), ]
      
      
      out_dt$method<-gsub('DP_fdr','MCP', out_dt$method)
      out_dt$method<-gsub('ETMC_prob','ETMC', out_dt$method)
      out_dt$method<-gsub('DVMLC_f1', 'DMVLS', out_dt$method)
      
      out_dt$method<-factor(out_dt$method, 
                            levels = c(view_names, c('hurdle','ETMC','DMVLS','MCP')))
      
      out_dt$cbn<-factor(out_dt$cbn, 
                         levels = unique(all_cbn))
      
      if(mtr=='Prec'){
        tl = 'Precision'
      }else if(mtr=='Rec'){
        tl = 'Recall'
      }else{
        tl = mtr
      }
      if(avgty=='mean'){
        valid_vals <- out_dt$Mean[!is.na(out_dt$Mean) & !is.nan(out_dt$Mean)]
        val_range <- range(valid_vals, na.rm = TRUE)
        val_median <- median(valid_vals, na.rm = TRUE)
        hp<-ggplot(out_dt, aes(x = method, y = cbn, fill = Mean, label = round(Mean, 2))) +
          geom_tile(color = "grey90", size = 0.3) +  
          geom_text(size = 3.5, color = "black") + 
          scale_fill_gradientn(
            colours = c("#2166AC", "white", "#B2182B"),
            values = rescale(c(val_range[1], val_median, val_range[2])),
            na.value = "gray90",
            name = "Mean" 
          ) +
          scale_x_discrete(expand = c(0, 0)) +
          scale_y_discrete(expand = c(0, 0)) +
          coord_fixed() + 
          labs(x = "Method", y = "View Combination",title = tl) +
          theme_minimal(base_size = 12, base_family = "Helvetica") + 
          theme(
            axis.text.x = element_text(size = 10, angle = 30, hjust = 1, vjust = 1),
            axis.text.y = element_text(size = 10),
            plot.title = element_text(hjust = 0.5),
            axis.title = element_text(size = 12, face = "bold"),
            legend.title = element_text(size = 11),
            legend.text = element_text(size = 10),
            panel.grid = element_blank(),
            plot.margin = unit(c(0.4, 0.5, 0.3, 0.5), "cm")
          )
        
      }else if(avgty=='median'){
        valid_vals <- out_dt$Mean[!is.na(out_dt$Median) & !is.nan(out_dt$Median)]
        val_range <- range(valid_vals, na.rm = TRUE)
        val_median <- median(valid_vals, na.rm = TRUE)
        hp<-ggplot(out_dt, aes(x = method, y = cbn, fill = Median, label = round(Median, 2))) +
          geom_tile(color = "grey90", size = 0.3) + 
          geom_text(size = 3.5, color = "black") +
          scale_fill_gradientn(
            colours = c("#2166AC", "white", "#B2182B"),
            values = rescale(c(val_range[1], val_median, val_range[2])),
            na.value = "gray90",
            name = "Median" 
          ) +
          scale_x_discrete(expand = c(0, 0)) +
          scale_y_discrete(expand = c(0, 0)) +
          coord_fixed() +
          labs(x = "Method", y = "View Combination",title = tl) +
          theme_minimal(base_size = 12, base_family = "Helvetica") +
          theme(
            axis.text.x = element_text(size = 10, angle = 30, hjust = 1, vjust = 1),
            plot.title = element_text(hjust = 0.5),
            axis.text.y = element_text(size = 10),
            axis.title = element_text(size = 12, face = "bold"),
            legend.title = element_text(size = 11),
            legend.text = element_text(size = 10),
            panel.grid = element_blank(),
            plot.margin = unit(c(0.4, 0.5, 0.3, 0.5), "cm")
          )
      }
      sort_meths<-c(view_names, c('hurdle','ETMC','DMVLS','MCP'))
      sort_cbns<-unique(all_cbn)
      out_mat = get_matrix(out_dt, sort_meths, sort_cbns, avgty)
      
      write.table(as.data.frame(out_mat), paste0(save_fold, 'stats/', 'stats_', acq, '_', plt, '_', mtr, '_', avgty, '.csv'), sep = ',', col.names = T, row.names = T)

      if(acq=='DDA'){
        h = 10
        w = 16
      }else{
        h = 5
        w = 8
      }
      ggsave(paste0(save_fold, 'stats/', 'stats_', acq, '_', plt, '_', mtr, '_', avgty, '.svg'), 
             plot = hp,
             device = svg,
             width = w,
             height = h,
             units = "in",
             limitsize = FALSE,
             dpi = 300)

      writeData(wb1, sheet, out_dt, startRow = 1, startCol = 1, colNames = TRUE, rowNames = FALSE)
    }
    
    write.table(statss, paste0(save_fold, 'stats/', 'stats_', acq, '_', plt, '.csv'), sep = ',', col.names = T, row.names = F)
    saveWorkbook(wb1, file = paste0(save_fold, 'stats/','stats_', acq, '_', plt, '.xlsx'), overwrite = TRUE)
  }
}


#############################################################
#####################
## label view selection
# Fig 2d in folder: Figures/res/Fig2/DIA_DIANN_mcc_medians.heatmap.svg

root_fold<-paste0(script_dir,'/res/res_reference/')
subs<-c('MCP_reference')
views_names_all_DDA = c('dlfq', 'maxlfq', 'top0', 'top3', 'count')
views_names_all_DIA = c('dlfq', 'maxlfq', 'top3', 'top1')
views_DDA = c('view1', 'view2', 'view3', 'view4', 'view5')
views_DIA = c('view1', 'view2', 'view3', 'view4')

acqs = c('DIA', 'DIA', 'DDA', 'DDA')
plts = c('Spectronaut','DIANN',  'FragPipe', 'Maxquant')
library(gtools)

plot_heatmap<-function(mat, mat_name, save_fold, tl, metric, eva){
  write.table(mat, paste0(save_fold, mat_name, '.heatmap.csv'), sep = ',', col.names = T, row.names = T)
  library(ggplot2)
  library(reshape2)
  df <- melt(mat)
  colnames(df)<-c('Reference', 'Partner', 'value')
  
  hp<-ggplot(df, aes(x = Reference, y = Partner, fill = value, label = round(value, 2))) +
    geom_tile(color = "grey90", size = 0.3) + 
    geom_text(size = 3.5, color = "black") +
    scale_fill_gradientn(
      colours = c("#2166AC", "white", "#B2182B"), 
      values = rescale(c(val_range[1], val_median, val_range[2])),
      na.value = "gray90",
      name = eva
    ) +
    scale_x_discrete(expand = c(0, 0)) +
    scale_y_discrete(expand = c(0, 0)) +
    coord_fixed() +
    labs(x = "Reference view", y = "Partner View",title = paste0(metric,'(',tl,')')) +
    theme_minimal(base_size = 12, base_family = "Helvetica") +
    theme(
      axis.text.x = element_text(size = 10, angle = 30, hjust = 1, vjust = 1),
      axis.text.y = element_text(size = 10),
      plot.title = element_text(hjust = 0.5),
      axis.title = element_text(size = 12, face = "bold"),
      legend.title = element_text(size = 11),
      legend.text = element_text(size = 10),
      panel.grid = element_blank(),
      plot.margin = unit(c(0.4, 0.5, 0.3, 0.5), "cm")
    )
  
  ggsave(paste0(save_fold, mat_name, '.heatmap.svg'), 
         plot = hp,
         device = svg,
         width = 6,
         height = 3,
         units = "in",
         limitsize = FALSE,
         dpi = 300)
}

for (i in 1:length(acqs)) {
  acq = acqs[i]
  plt = plts[i]
  
  if(acq=='DDA'){
    view_names = views_names_all_DDA
  }else if(acq=='DIA'){
    view_names = views_names_all_DIA
  }
  
  cbns = permutations(n = length(view_names), r = 2, v = view_names)
  
  vnstrs = apply(cbns, 1, paste0, collapse = "_")
  mcc_means<-matrix(nrow = length(view_names), ncol = length(view_names))
  mcc_medians<-matrix(nrow = length(view_names), ncol = length(view_names))
  f1_means<-matrix(nrow = length(view_names), ncol = length(view_names))
  f1_medians<-matrix(nrow = length(view_names), ncol = length(view_names))
  pre_means<-matrix(nrow = length(view_names), ncol = length(view_names))
  pre_medians<-matrix(nrow = length(view_names), ncol = length(view_names))
  rec_means<-matrix(nrow = length(view_names), ncol = length(view_names))
  rec_medians<-matrix(nrow = length(view_names), ncol = length(view_names))
  pauc_means<-matrix(nrow = length(view_names), ncol = length(view_names))
  pauc_medians<-matrix(nrow = length(view_names), ncol = length(view_names))
  
  out_all<-c()
  for (s in 1:length(vnstrs)) {
    vn = cbns[s,]
    x = which(view_names == vn[1])
    y = which(view_names == vn[2])
    res = read_xlsx(paste0(root_fold, acq, '_', plt, '_',
                           as.character(2),'views_', acq, '_', vnstrs[s],'.xlsx'), sheet = 'all')
    res = res[which(res$Method=='DP_fdr'),]
    mcc_mean = mean(as.numeric(res$Performance[which(res$Metric=='MCC')]))
    mcc_median = median(as.numeric(res$Performance[which(res$Metric=='MCC')]))
    f1_mean = mean(as.numeric(res$Performance[which(res$Metric=='F1')]))
    f1_median = median(as.numeric(res$Performance[which(res$Metric=='F1')]))
    prec_mean = mean(as.numeric(res$Performance[which(res$Metric=='Prec')]))
    prec_median = median(as.numeric(res$Performance[which(res$Metric=='Prec')]))
    rec_mean = mean(as.numeric(res$Performance[which(res$Metric=='Rec')]))
    rec_median = median(as.numeric(res$Performance[which(res$Metric=='Rec')]))
    pauc_mean = mean(as.numeric(res$Performance[which(res$Metric=='pAUC')]))
    pauc_median = median(as.numeric(res$Performance[which(res$Metric=='pAUC')]))
    
    mcc_means[x, y] = mcc_mean
    mcc_medians[x, y] = mcc_median
    f1_means[x, y] = f1_mean
    f1_medians[x, y] = f1_median
    pre_means[x, y] = prec_mean
    pre_medians[x, y] = prec_median
    rec_means[x, y] = rec_mean
    rec_medians[x, y] = rec_median
    pauc_means[x, y] = pauc_mean
    pauc_medians[x, y] = pauc_median
    out<-c(vnstrs[s], vn, mcc_mean, mcc_median, f1_mean, f1_median, prec_mean,
           prec_median, rec_mean, rec_median, pauc_mean, pauc_median)
    out_all<-rbind(out_all, out)
  }
  colnames(mcc_means)<-view_names
  row.names(mcc_means)<-view_names
  colnames(mcc_medians)<-view_names
  row.names(mcc_medians)<-view_names
  colnames(f1_means)<-view_names
  row.names(f1_means)<-view_names
  colnames(f1_medians)<-view_names
  row.names(f1_medians)<-view_names
  colnames(pre_means)<-view_names
  row.names(pre_means)<-view_names
  colnames(pre_medians)<-view_names
  row.names(pre_medians)<-view_names
  colnames(rec_means)<-view_names
  row.names(rec_means)<-view_names
  colnames(rec_medians)<-view_names
  row.names(rec_medians)<-view_names
  colnames(pauc_means)<-view_names
  row.names(pauc_means)<-view_names
  colnames(pauc_medians)<-view_names
  row.names(pauc_medians)<-view_names
  colnames(out_all)<-c('vnstr','v1', 'v2', 'mcc_mean', 'mcc_median', 'f1_mean', 
                       'f1_median', 'prec_mean', 'prec_median', 'rec_mean', 'rec_median', 'pauc_mean', 'pauc_median')
  
  write.table(out_all, paste0(save_fold, acq, '_', plt, 'pair_rank_comparisons.csv'), sep = ',', col.names = T, row.names = F)
  
  plot_heatmap(mcc_means, paste0(acq, '_', plt, '_mcc_means'), save_fold, plt, 'MCC', 'Mean')
  plot_heatmap(mcc_medians, paste0(acq, '_', plt, '_mcc_medians'), save_fold, plt, 'MCC', 'Median')
  plot_heatmap(f1_means, paste0(acq, '_', plt, '_f1_means'), save_fold, plt, 'F1', 'Mean')
  plot_heatmap(f1_medians, paste0(acq, '_', plt, '_f1_medians'), save_fold, plt, 'F1', 'Median')
  plot_heatmap(pre_means, paste0(acq, '_', plt, '_prec_means'), save_fold, plt, 'Precision', 'Mean')
  plot_heatmap(pre_medians, paste0(acq, '_', plt, '_prec_medians'), save_fold, plt, 'Precision', 'Median')
  plot_heatmap(rec_means, paste0(acq, '_', plt, '_rec_means'), save_fold, plt, 'Recall', 'Mean')
  plot_heatmap(rec_medians, paste0(acq, '_', plt, '_rec_medians'), save_fold, plt, 'Recall', 'Median')
  plot_heatmap(pauc_means, paste0(acq, '_', plt, '_pauc_means'), save_fold, plt, 'pAUC', 'Mean')
  plot_heatmap(pauc_means, paste0(acq, '_', plt, '_pauc_medians'), save_fold, plt, 'pAUC', 'Median')
}


#########################################################################
################
### ablation study
# Fig 2e,f in folder: /res/Fig2/
#e:ab_dda_fragpipe.svg f:ab_dia_diann.svg
root_fold<-paste0(script_dir,'/res/')
combi = 'dlfq_count'
res_MCP<-read_xlsx(paste0(root_fold, 'res_MCP/DDA_FragPipe_2views_DDA_', combi,'.xlsx'), sheet = 'all')
res_ASB<-read_xlsx(paste0(root_fold, 'res_MCP_ASB/DDA_FragPipe_2views_DDA_', combi,'.xlsx'), sheet = 'all')
res_Contrast<-read_xlsx(paste0(root_fold, 'res_MCP_Contrast/DDA_FragPipe_2views_DDA_', combi,'.xlsx'), sheet = 'all')
res_nofuse<-read_xlsx(paste0(root_fold, 'res_MCP_nofuse/DDA_FragPipe_2views_DDA_', combi,'.xlsx'), sheet = 'all')

res_MCP_sub<-res_MCP[which(res_MCP$Method=='DP_fdr'),]
res_MCP_sub$Type<-'MCP'
res_ASB_sub<-res_ASB[which(res_ASB$Method=='DP_fdr'),]
res_ASB_sub$Type<-'Balancing'
res_Contrast_sub<-res_Contrast[which(res_Contrast$Method=='DP_fdr'),]
res_Contrast_sub$Type<-'Contrastive'
res_nofuse_sub<-res_nofuse[which(res_nofuse$Method=='DP_fdr'),]
res_nofuse_sub$Type<-'C-Attention'

ab_colors<-c(
  "#E64B35", "#4DBBD5", "#00A087", "#3C5488"
  
)
ablation_DDA<-rbind(rbind(rbind(res_MCP_sub,res_ASB_sub),res_Contrast_sub),res_nofuse_sub)

ablation_DDA$Performance<-as.numeric(ablation_DDA$Performance)
ablation_DDA$Metric = gsub('Prec', 'Precision', ablation_DDA$Metric)
ablation_DDA$Metric = gsub('Rec', 'Recall', ablation_DDA$Metric)
ablation_DDA$Metric<-factor(ablation_DDA$Metric, 
                      levels = c('MCC', 'F1', 'Precision', 'Recall', 'pAUC'))

mcc_ref_value <- ablation_DDA %>%
  filter(Type == "MCP", Metric == "MCC") %>%
  summarise(median_value = median(Performance, na.rm = TRUE)) %>%
  pull(median_value)

ab_dda<-ggboxplot(
  ablation_DDA,
  x = "Metric",
  y = "Performance",
  color = "Type",
  fill = "Type",
  width = 0.7,
  size = 0.8,
  alpha = 0.7,
  palette = ab_colors,
  add = "jitter",
  add.params = list(alpha = 0.5, size = 0.5),
  title = "Ablation Study(FragPipe)"
) +
  labs(x = "", y = "Metric Values") +
  scale_fill_manual(values = ab_colors) +
  scale_x_discrete(limits = unique(ablation_DDA$Metric)) +
  scale_y_continuous(limits = c(0.5,max(ablation_DDA$Performance + 0.05))) +
  theme_classic(base_family = "Helvetica") +
  theme(
    plot.title = element_text(size = 14, hjust = 0.5, face = "bold"),
    axis.title.y = element_text(size = 13, face = "bold"),
    axis.title.x = element_text(size = 12),
    axis.text.x = element_text(size = 10, face = "bold", angle = 45, hjust = 1),
    axis.text.y = element_text(size = 10, face = "bold"),
    legend.title = element_text(size = 12, face = "bold"),
    legend.text = element_text(size = 10),
    legend.position = "right"
  )
ab_dda
ggsave(paste0(save_fold, 'ab_dda_fragpipe', '.svg'), 
       plot = ab_dda,
       device = svg,
       width = w,
       height = h,
       units = "in",
       limitsize = FALSE,
       dpi = 300)

stats<-vector()
for (ty in unique(ablation_DDA$Type)) {
  for (met in unique(ablation_DDA$Metric)) {
    avg = mean(ablation_DDA$Performance[which(ablation_DDA$Metric==met & ablation_DDA$Type==ty)])
    med = median(ablation_DDA$Performance[which(ablation_DDA$Metric==met & ablation_DDA$Type==ty)])
    std = sd(ablation_DDA$Performance[which(ablation_DDA$Metric==met & ablation_DDA$Type==ty)])
    stats<-rbind(stats, c(ty, met, avg, med, std))
  }
}
colnames(stats)<-c('Type', 'Metric', 'Mean', 'Median', 'sd')
write.table(stats, paste0(save_fold, 'stats_FragPipe_ablation_',combi,'.csv'), sep = ',', col.names = T, row.names = F)

#maxquant
combi = 'dlfq_top0_top3'
res_MCP<-read_xlsx(paste0(root_fold, 'res_MCP/DDA_Maxquant_3views_DDA_', combi,'.xlsx'), sheet = 'all')
res_ASB<-read_xlsx(paste0(root_fold, 'res_MCP_ASB/DDA_Maxquant_3views_DDA_', combi,'.xlsx'), sheet = 'all')
res_Contrast<-read_xlsx(paste0(root_fold, 'res_MCP_Contrast/DDA_Maxquant_3views_DDA_', combi,'.xlsx'), sheet = 'all')
res_nofuse<-read_xlsx(paste0(root_fold, 'res_MCP_nofuse/DDA_Maxquant_3views_DDA_', combi,'.xlsx'), sheet = 'all')

res_MCP_sub<-res_MCP[which(res_MCP$Method=='DP_fdr'),]
res_MCP_sub$Type<-'MCP'
res_ASB_sub<-res_ASB[which(res_ASB$Method=='DP_fdr'),]
res_ASB_sub$Type<-'Balancing'
res_Contrast_sub<-res_Contrast[which(res_Contrast$Method=='DP_fdr'),]
res_Contrast_sub$Type<-'Contrastive'
res_nofuse_sub<-res_nofuse[which(res_nofuse$Method=='DP_fdr'),]
res_nofuse_sub$Type<-'C-Attention'

ab_colors<-c(
  "#E64B35", "#4DBBD5", "#00A087", "#3C5488"
  
)
ablation_DDA<-rbind(rbind(rbind(res_MCP_sub,res_ASB_sub),res_Contrast_sub),res_nofuse_sub)

ablation_DDA$Performance<-as.numeric(ablation_DDA$Performance)
ablation_DDA$Metric = gsub('Prec', 'Precision', ablation_DDA$Metric)
ablation_DDA$Metric = gsub('Rec', 'Recall', ablation_DDA$Metric)
ablation_DDA$Metric<-factor(ablation_DDA$Metric, 
                            levels = c('MCC', 'F1', 'Precision', 'Recall', 'pAUC'))

mcc_ref_value <- ablation_DDA %>%
  filter(Type == "MCP", Metric == "MCC") %>%
  summarise(median_value = median(Performance, na.rm = TRUE)) %>%
  pull(median_value)

ab_dda<-ggboxplot(
  ablation_DDA,
  x = "Metric",
  y = "Performance",
  color = "Type",
  fill = "Type",
  width = 0.7,
  size = 0.8,
  alpha = 0.7,
  palette = ab_colors,
  add = "jitter",
  add.params = list(alpha = 0.5, size = 0.5),
  title = "Ablation Study(Maxquant)"
) +
  labs(x = "", y = "Metric Values") +
  scale_fill_manual(values = ab_colors) +
  scale_x_discrete(limits = unique(ablation_DDA$Metric)) +
  scale_y_continuous(limits = c(0.5, max(ablation_DDA$Performance + 0.05))) +
  theme_classic(base_family = "Helvetica") +
  theme(
    plot.title = element_text(size = 14, hjust = 0.5, face = "bold"),
    axis.title.y = element_text(size = 13, face = "bold"),
    axis.title.x = element_text(size = 12),
    axis.text.x = element_text(size = 10, face = "bold", angle = 45, hjust = 1),
    axis.text.y = element_text(size = 10, face = "bold"),
    legend.title = element_text(size = 12, face = "bold"),
    legend.text = element_text(size = 10),
    legend.position = "none"
  )
ab_dda
ggsave(paste0(save_fold, 'ab_dda_maxquant', '.svg'), 
       plot = ab_dda,
       device = svg,
       width = w,
       height = h,
       units = "in",
       limitsize = FALSE,
       dpi = 300)

stats<-vector()
for (ty in unique(ablation_DDA$Type)) {
  for (met in unique(ablation_DDA$Metric)) {
    avg = mean(ablation_DDA$Performance[which(ablation_DDA$Metric==met & ablation_DDA$Type==ty)])
    med = median(ablation_DDA$Performance[which(ablation_DDA$Metric==met & ablation_DDA$Type==ty)])
    std = sd(ablation_DDA$Performance[which(ablation_DDA$Metric==met & ablation_DDA$Type==ty)])
    stats<-rbind(stats, c(ty, met, avg, med, std))
  }
}
colnames(stats)<-c('Type', 'Metric', 'Mean', 'Median', 'sd')
write.table(stats, paste0(save_fold, 'stats_Maxquant_ablation_',combi,'.csv'), sep = ',', col.names = T, row.names = F)


#### DIA-NN
combi = 'dlfq_maxlfq_top1'
res_MCP<-read_xlsx(paste0(root_fold, 'res_MCP/DIA_DIANN_3views_DIA_', combi,'.xlsx'), sheet = 'all')
res_ASB<-read_xlsx(paste0(root_fold, 'res_MCP_ASB/DIA_DIANN_3views_DIA_', combi,'.xlsx'), sheet = 'all')
res_Contrast<-read_xlsx(paste0(root_fold, 'res_MCP_Contrast/DIA_DIANN_3views_DIA_', combi,'.xlsx'), sheet = 'all')
res_nofuse<-read_xlsx(paste0(root_fold, 'res_MCP_nofuse/DIA_DIANN_3views_DIA_', combi,'.xlsx'), sheet = 'all')

res_MCP_sub<-res_MCP[which(res_MCP$Method=='DP_fdr'),]
res_MCP_sub$Type<-'MCP'
res_ASB_sub<-res_ASB[which(res_ASB$Method=='DP_fdr'),]
res_ASB_sub$Type<-'Balancing'
res_Contrast_sub<-res_Contrast[which(res_Contrast$Method=='DP_fdr'),]
res_Contrast_sub$Type<-'Contrastive'
res_nofuse_sub<-res_nofuse[which(res_nofuse$Method=='DP_fdr'),]
res_nofuse_sub$Type<-'C-Attention'

ab_colors<-c(
  "#E64B35", "#4DBBD5", "#00A087", "#3C5488"
)
ablation_DIA<-rbind(rbind(rbind(res_MCP_sub,res_ASB_sub),res_Contrast_sub),res_nofuse_sub)

ablation_DIA$Performance<-as.numeric(ablation_DIA$Performance)
ablation_DIA$Metric = gsub('Prec', 'Precision', ablation_DIA$Metric)
ablation_DIA$Metric = gsub('Rec', 'Recall', ablation_DIA$Metric)
ablation_DIA$Metric<-factor(ablation_DIA$Metric, 
                            levels = c('MCC', 'F1', 'Precision', 'Recall', 'pAUC'))

mcc_ref_value <- ablation_DIA %>%
  filter(Type == "MCP", Metric == "MCC") %>%
  summarise(median_value = median(Performance, na.rm = TRUE)) %>%
  pull(median_value)

ab_dia<-ggboxplot(
  ablation_DIA,
  x = "Metric",
  y = "Performance",
  color = "Type",
  fill = "Type",
  width = 0.7,
  size = 0.8,
  alpha = 0.7,
  palette = ab_colors,
  add = "jitter",
  add.params = list(alpha = 0.5, size = 0.5),
  title = "Ablation Study(DIA-NN)"
) +
  labs(x = "", y = "Metric Values") +
  scale_fill_manual(values = ab_colors) +
  scale_x_discrete(limits = unique(ablation_DIA$Metric)) +
  scale_y_continuous(limits = c(0.5,max(ablation_DIA$Performance + 0.05))) +
  theme_classic(base_family = "Helvetica") +
  theme(
    plot.title = element_text(size = 14, hjust = 0.5, face = "bold"),
    axis.title.y = element_text(size = 13, face = "bold"),
    axis.title.x = element_text(size = 12),
    axis.text.x = element_text(size = 10, face = "bold", angle = 45, hjust = 1),
    axis.text.y = element_text(size = 10, face = "bold"),
    legend.title = element_text(size = 12, face = "bold"),
    legend.text = element_text(size = 10),
    legend.position = "top"
  )
ab_dia
ggsave(paste0(save_fold, 'ab_dia_diann', '.svg'), 
       plot = ab_dia,
       device = svg,
       width = w,
       height = h,
       units = "in",
       limitsize = FALSE,
       dpi = 300)

stats_dia<-vector()
for (ty in unique(ablation_DIA$Type)) {
  for (met in unique(ablation_DIA$Metric)) {
    avg = mean(ablation_DIA$Performance[which(ablation_DIA$Metric==met & ablation_DIA$Type==ty)])
    med = median(ablation_DIA$Performance[which(ablation_DIA$Metric==met & ablation_DIA$Type==ty)])
    std = sd(ablation_DIA$Performance[which(ablation_DIA$Metric==met & ablation_DIA$Type==ty)])
    stats_dia<-rbind(stats_dia, c(ty, met, avg, med, std))
  }
}
colnames(stats_dia)<-c('Type', 'Metric', 'Mean', 'Median', 'sd')
write.table(stats_dia, paste0(save_fold, 'stats_DIANN_ablation_',combi,'.csv'), sep = ',', col.names = T, row.names = F)

####Spectronaut

combi = 'dlfq_maxlfq_top3'
res_MCP<-read_xlsx(paste0(root_fold, 'res_MCP/DIA_Spectronaut_3views_DIA_', combi,'.xlsx'), sheet = 'all')
res_ASB<-read_xlsx(paste0(root_fold, 'res_MCP_ASB/DIA_Spectronaut_3views_DIA_', combi,'.xlsx'), sheet = 'all')
res_Contrast<-read_xlsx(paste0(root_fold, 'res_MCP_Contrast/DIA_Spectronaut_3views_DIA_', combi,'.xlsx'), sheet = 'all')
res_nofuse<-read_xlsx(paste0(root_fold, 'res_MCP_nofuse/DIA_Spectronaut_3views_DIA_', combi,'.xlsx'), sheet = 'all')

res_MCP_sub<-res_MCP[which(res_MCP$Method=='DP_fdr'),]
res_MCP_sub$Type<-'MCP'
res_ASB_sub<-res_ASB[which(res_ASB$Method=='DP_fdr'),]
res_ASB_sub$Type<-'Balancing'
res_Contrast_sub<-res_Contrast[which(res_Contrast$Method=='DP_fdr'),]
res_Contrast_sub$Type<-'Contrastive'
res_nofuse_sub<-res_nofuse[which(res_nofuse$Method=='DP_fdr'),]
res_nofuse_sub$Type<-'C-Attention'

ab_colors<-c(
  "#E64B35", "#4DBBD5", "#00A087", "#3C5488"
)
ablation_DIA<-rbind(rbind(rbind(res_MCP_sub,res_ASB_sub),res_Contrast_sub),res_nofuse_sub)

ablation_DIA$Performance<-as.numeric(ablation_DIA$Performance)
ablation_DIA$Metric = gsub('Prec', 'Precision', ablation_DIA$Metric)
ablation_DIA$Metric = gsub('Rec', 'Recall', ablation_DIA$Metric)
ablation_DIA$Metric<-factor(ablation_DIA$Metric, 
                            levels = c('MCC', 'F1', 'Precision', 'Recall', 'pAUC'))

mcc_ref_value <- ablation_DIA %>%
  filter(Type == "MCP", Metric == "MCC") %>%
  summarise(median_value = median(Performance, na.rm = TRUE)) %>%
  pull(median_value)

ab_dia<-ggboxplot(
  ablation_DIA,
  x = "Metric",
  y = "Performance",
  color = "Type",
  fill = "Type",
  width = 0.7,
  size = 0.8,
  alpha = 0.7,
  palette = ab_colors,
  add = "jitter",
  add.params = list(alpha = 0.5, size = 0.5),
  title = "Ablation Study(Spectronaut)"
) +
  labs(x = "", y = "Metric Values") +
  scale_fill_manual(values = ab_colors) +
  scale_x_discrete(limits = unique(ablation_DIA$Metric)) +
  scale_y_continuous(limits = c(0.5, 
                                max(ablation_DIA$Performance + 0.05))) +
  theme_classic(base_family = "Helvetica") +
  theme(
    plot.title = element_text(size = 14, hjust = 0.5, face = "bold"),
    axis.title.y = element_text(size = 13, face = "bold"),
    axis.title.x = element_text(size = 12),
    axis.text.x = element_text(size = 10, face = "bold", angle = 45, hjust = 1),
    axis.text.y = element_text(size = 10, face = "bold"),
    legend.title = element_text(size = 12, face = "bold"),
    legend.text = element_text(size = 10),
    legend.position = "right"
  )
ab_dia
ggsave(paste0(save_fold, 'ab_dia_spt', '.svg'), 
       plot = ab_dia,
       device = svg,
       width = w,
       height = h,
       units = "in",
       limitsize = FALSE,
       dpi = 300)

stats_dia<-vector()
for (ty in unique(ablation_DIA$Type)) {
  for (met in unique(ablation_DIA$Metric)) {
    avg = mean(ablation_DIA$Performance[which(ablation_DIA$Metric==met & ablation_DIA$Type==ty)])
    med = median(ablation_DIA$Performance[which(ablation_DIA$Metric==met & ablation_DIA$Type==ty)])
    std = sd(ablation_DIA$Performance[which(ablation_DIA$Metric==met & ablation_DIA$Type==ty)])
    stats_dia<-rbind(stats_dia, c(ty, met, avg, med, std))
  }
}
colnames(stats_dia)<-c('Type', 'Metric', 'Mean', 'Median', 'sd')
write.table(stats_dia, paste0(save_fold, 'stats_Spectronaut_ablation_',combi,'.csv'), sep = ',', col.names = T, row.names = F)



###################
#### case on three species data
wb_all <- createWorkbook()
root_fold<-paste0(parent_fold, '/DEA_Benchmarking/res/')

res_views<-read.table(paste0(root_fold,'4views_MCP/DIA_dlfq_maxlfq_top3_top1/','temp0_limma_DIANN_view4/HYEtims735_DIA/',
                             'HYEtims735_DIA_DP_res_all.csv'), sep = ',', header = T)
res_MCP<-read.table(paste0(root_fold,'3views_MCP/DIA_dlfq_maxlfq_top1/','temp0_limma_DIANN_view3/HYEtims735_DIA/',
                           'HYEtims735_DIA_DP_res_all.csv'), sep = ',', header = T)
res_ETMC<-read.table(paste0(root_fold,'3views_ETMC/DIA_dlfq_maxlfq_top1/','temp0_limma_DIANN_view3/HYEtims735_DIA/',
                            'HYEtims735_DIA__all_preds.csv'), sep = ',', header = T)
res_DMVLC<-read.table(paste0(root_fold,'3views_DMVLC/DIA_dlfq_maxlfq_top1/','temp0_limma_DIANN_view3/HYEtims735_DIA/',
                            'HYEtims735_DIA_all_preds.csv'), sep = ',', header = T)

library(pROC)
roc_dlfq <- roc(res_views$True_lab, res_views$score_DPdlfq)
roc_maxlfq <- roc(res_views$True_lab, res_views$score_DPmaxlfq)
roc_top3 <- roc(res_views$True_lab, res_views$score_DPtop3)
roc_top1 <- roc(res_views$True_lab, res_views$score_DPtop1)
roc_hurdle<-roc(res_MCP$True_lab, res_MCP$score_DP_hurdle)
roc_MCP<-roc(res_MCP$True_lab, res_MCP$Probability.3)
roc_ETMC<-roc(res_MCP$True_lab, res_ETMC$Probability)
roc_DMVLC<-roc(res_MCP$True_lab, res_DMVLC$Probability)


spe_sens<-rbind(cbind(roc_dlfq$specificities, roc_dlfq$sensitivities,
                      c(rep(paste0('dlfq(',as.character(round(as.numeric(auc(roc_dlfq,
                                                                             partial.auc=c(1, 0.95),
                                                                             partial.auc.correct=TRUE)),3)),')'),
                            length(roc_dlfq$specificities)))),
                cbind(roc_maxlfq$specificities, roc_maxlfq$sensitivities,
                      c(rep(paste0('maxlfq(',as.character(round(auc(roc_maxlfq,
                                                                    partial.auc=c(1, 0.95),
                                                                    partial.auc.correct=TRUE),3)),')'),
                            length(roc_maxlfq$specificities)))),
                cbind(roc_top3$specificities, roc_top3$sensitivities,
                      c(rep(paste0('top3(',as.character(round(auc(roc_top3,
                                                                  partial.auc=c(1, 0.95),
                                                                  partial.auc.correct=TRUE),3)),')'),
                            length(roc_top3$specificities)))),
                cbind(roc_top1$specificities, roc_top1$sensitivities,
                      c(rep(paste0('top1(',as.character(round(auc(roc_top1,
                                                                    partial.auc=c(1, 0.95),
                                                                    partial.auc.correct=TRUE),3)),')'),
                            length(roc_top1$specificities)))),
                cbind(roc_hurdle$specificities, roc_hurdle$sensitivities,
                      c(rep(paste0('hurdle(',as.character(round(auc(roc_hurdle,
                                                                     partial.auc=c(1, 0.95),
                                                                     partial.auc.correct=TRUE),3)),')'),
                            length(roc_hurdle$specificities)))),

                cbind(roc_MCP$specificities, roc_MCP$sensitivities,
                      c(rep(paste0('MCP(',as.character(round(auc(roc_MCP,
                                                                     partial.auc=c(1, 0.95),
                                                                     partial.auc.correct=TRUE),3)),')'),
                            length(roc_MCP$specificities)))),

                cbind(roc_ETMC$specificities, roc_ETMC$sensitivities,
                      c(rep(paste0('ETMC(',as.character(round(auc(roc_ETMC,
                                                                     partial.auc=c(1, 0.95),
                                                                     partial.auc.correct=TRUE),3)),')'),
                            length(roc_ETMC$specificities)))),

                cbind(roc_DMVLC$specificities, roc_DMVLC$sensitivities,
                      c(rep(paste0('DMVLC(',as.character(round(auc(roc_DMVLC,
                                                                  partial.auc=c(1, 0.95),
                                                                  partial.auc.correct=TRUE),3)),')'),
                            length(roc_DMVLC$specificities))))
                
)

colnames(spe_sens)<-c('Specificity', 'Sensitivity', 'Method(pAUC(FPR=0.05))')
spe_sens<-as.data.frame(spe_sens)
spe_sens$Specificity<-1-as.numeric(spe_sens$Specificity)
spe_sens$Sensitivity<-as.numeric(spe_sens$Sensitivity)

spe_sens$`Method(pAUC(FPR=0.05))` <- factor(spe_sens$`Method(pAUC(FPR=0.05))`, 
                                            levels=unique(spe_sens$`Method(pAUC(FPR=0.05))`))

sheet = 'Fig.2f_spe_sens'
addWorksheet(wb_all, sheet)
writeData(wb_all, sheet, spe_sens, startRow = 2, startCol = 2)

breaks = seq(0,0.1,0.01)

library(ggplot2)
library(dplyr)
library(stringr)

method_levels_sorted <- spe_sens %>%
  distinct(`Method(pAUC(FPR=0.05))`) %>%
  mutate(
    pAUC = as.numeric(str_extract(`Method(pAUC(FPR=0.05))`, "(?<=\\().+?(?=\\))"))
  ) %>%
  arrange(desc(pAUC)) %>%
  pull(`Method(pAUC(FPR=0.05))`)

spe_sens$`Method(pAUC(FPR=0.05))` <- factor(
  spe_sens$`Method(pAUC(FPR=0.05))`,
  levels = method_levels_sorted
)

ggplot(spe_sens, aes(x = Specificity, y = Sensitivity, colour = `Method(pAUC(FPR=0.05))`)) +
  geom_step(linewidth = 0.8, alpha = 0.9) +
  scale_color_manual(values = c(
    '#FF1493','#40E0D0',"#CD6155","#7D3C98",
    "#b2df8a","#33a02c","#1f78b4","#00A087"
    
  )[1:length(method_levels_sorted)]) +
  scale_x_continuous(
    name = "False Positive Rate (1 - Specificity)", 
    limits = c(0, 0.1), 
    breaks = seq(0, 0.1, 0.02)
  ) +
  scale_y_continuous(
    name = "True Positive Rate (Sensitivity)", 
    limits = c(0, 1), 
    breaks = seq(0, 1, 0.2)
  ) +
  theme_minimal(base_size = 12) +
  theme(
    panel.grid = element_blank(),
    axis.line = element_line(color = "black"),
    legend.title = element_text(size = 10, face = "bold"),
    legend.text = element_text(size = 9),
    legend.key = element_blank(),
    legend.position = c(0.75, 0.23)
  ) +
  guides(color = guide_legend(ncol = 2)) +
  labs(
    x = "False Positive Rate (1 - Specificity)",
    y = "True Positive Rate (Sensitivity)",
    color = "Method (pAUC @ FPR ≤ 0.05)"
  ) +
  geom_vline(xintercept = 0.05, linetype = "dashed", color = "gray40")

DEPs<-list(T_DEP=res_views$Protein[which(res_views$True_lab==1)],
           dlfq=res_views$Protein[which(res_views$lab_DPdlfq==1)],
           maxlfq=res_views$Protein[which(res_views$lab_DPmaxlfq==1)],
           top3=res_views$Protein[which(res_views$lab_DPtop3==1)],
           top1=res_views$Protein[which(res_views$lab_DPtop1==1)],

           MCP=res_MCP$Protein[which(abs(res_MCP$ori_logFC)>=log2(1.5) & res_MCP$Probability>=res_MCP$threshold.3[1])]

)
library(UpSetR)

UpSetR::upset(fromList(DEPs),
              sets = c('T_DEP','dlfq', 'maxlfq', 
                       'top3', 
                       'top1',
                       'MCP'
              ),
              order.by="freq", matrix.color="black", point.size=3,
              sets.bar.color=c('gold','#40E0D0',"#CD6155","#b2df8a","#1f78b4",'#FF1493'
              ),mb.ratio=c(0.6, 0.4), text.scale = 1.5,
              number.angles =0,
              keep.order = T,nintersects=20)

input_lists<-DEPs
all_items <- unique(unlist(input_lists))


binary_matrix <- matrix(
  0,
  nrow = length(all_items),
  ncol = length(input_lists),
  dimnames = list(all_items, names(input_lists)) 
)


for (i in seq_along(input_lists)) {
  current_list <- input_lists[[i]]
  binary_matrix[current_list, i] <- 1
}
print(binary_matrix)

sheet = 'Fig.2f_upset'
addWorksheet(wb_all, sheet)
writeData(wb_all, sheet, data.frame(protein=all_items, binary_matrix), startRow = 2, startCol = 2)


cal_metrics<-function(T_lab, mth_lab, roc_s){
  
  TP=length(which(T_lab==1 & mth_lab==1))
  TN=length(which(T_lab==0 & mth_lab==0))
  FP=length(which(T_lab==0 & mth_lab==1))
  FN=length(which(T_lab==1 & mth_lab==0))
  
  Recall = TP/(TP+FN)
  Precision = TP/(TP+FP)
  Specificity = TN/(TN+FP)
  F1=2*Recall*Precision/(Recall+Precision)
  MCC = (TP*TN-FP*FN)/(((TP+FP)^0.5)*((TP+FN)^0.5)*((TN+FP)^0.5)*((TN+FN))^0.5)
  Gmean = (Recall*Specificity)^0.5
  nMCC = (1+MCC)/2
  
  pauc001=as.numeric(auc(roc_s, partial.auc=c(1, 0.99), partial.auc.correct=TRUE))
  pauc005=as.numeric(auc(roc_s, partial.auc=c(1, 0.95), partial.auc.correct=TRUE))
  pauc01=as.numeric(auc(roc_s, partial.auc=c(1, 0.90), partial.auc.correct=TRUE))
  metrics=data.frame(metric=c('pAUC(0.01)','pAUC(0.05)','pAUC(0.1)','TP', 'TN', 'FP', 'FN', 'Recall', 'Precision', 'Specificity', 'F1', 'MCC', 'G-mean','nMCC'),
                     value=c(pauc001,pauc005,pauc01,TP, TN, FP, FN, Recall, Precision, Specificity, F1, MCC, Gmean,nMCC))
  return(metrics)
}

lab_MCP<-c(rep(0, length(res_MCP$Protein)))
lab_MCP[which(abs(res_MCP$ori_logFC.3)>=log2(1.5) & res_MCP$Probability.3>=res_MCP$threshold.3[1])]=1
lab_ETMC<-c(rep(0, length(res_ETMC$Protein)))
lab_ETMC[which(abs(res_ETMC$ori_logFC)>=log2(1.5) & res_ETMC$Probability>=res_ETMC$threshold[1])]=1
lab_DMVLC<-c(rep(0, length(res_DMVLC$Protein)))
lab_DMVLC[which(abs(res_DMVLC$ori_logFC)>=log2(1.5) & res_DMVLC$Probability>=res_DMVLC$threshold[1])]=1

met_dlfq=cal_metrics(res_views$True_lab, res_views$lab_DPdlfq, roc_dlfq)
met_maxlfq=cal_metrics(res_views$True_lab, res_views$lab_DPmaxlfq, roc_maxlfq)
met_top3=cal_metrics(res_views$True_lab, res_views$lab_DPtop3, roc_top3)
met_top1=cal_metrics(res_views$True_lab, res_views$lab_DPtop1, roc_top1)
met_hurdle=cal_metrics(res_views$True_lab, res_views$lab_DP_hurdle, roc_hurdle)

met_MCP=cal_metrics(res_views$True_lab, lab_MCP, roc_MCP)

met_ETMC=cal_metrics(res_views$True_lab, lab_ETMC, roc_ETMC)

met_DMVLC=cal_metrics(res_views$True_lab, lab_DMVLC, roc_DMVLC)

rdar_dt<-rbind(met_dlfq$value, met_maxlfq$value, met_top3$value,
               met_top1$value,
               met_MCP$value
)
colnames(rdar_dt)<-met_dlfq$metric
row.names(rdar_dt)<-c('dlfq', 'maxlfq', 
                      'top3', 
                      'top1',
                      'MCP'
)

rdar_dt<-as.data.frame(as.matrix(rdar_dt))
pt_rdar_dt<-data.frame(group=row.names(rdar_dt))

sheet = 'Fig.2f_rdar_dt'
addWorksheet(wb_all, sheet)
writeData(wb_all, sheet, data.frame(pt_rdar_dt,rdar_dt), startRow = 2, startCol = 2)

count_TPs<-data.frame(method=row.names(rdar_dt))
count_TPs<-cbind(count_TPs, rdar_dt[,c(4:7)])
melt_dt<-melt(count_TPs)
melt_dt$label<-as.character(melt_dt$value)
melt_dt$label[which(melt_dt$variable=='TN' | melt_dt$variable=='FN')]=''

nums<-vector()


for (i in 1:length(unique(melt_dt$method))){
  num_i<-melt_dt[which(melt_dt$method==melt_dt$method[i]),]
  uni_var<-levels(factor(melt_dt$variable))
  re_order<-match(num_i$variable, uni_var)
  num_i<-num_i[re_order,]
  l_y<-c(rep(0,length(uni_var)))
  for (j in length(uni_var):1) {
    if(j==length(uni_var)){
      l_y[j]=num_i$value[j]/2
    }else{
      l_y_j=num_i$value[j]/2 + sum(num_i$value[c((j+1):length(uni_var))])
      l_y[j]=l_y_j
    }
  }
  num_i$l_y<-l_y
  nums<-rbind(nums,num_i)
}


ggbarplot(nums, "method", "value", group = "variable", color = "variable",fill="variable",
          platette = c('#5494cc','#e18283','#0d898a','#f9cc52')
) +geom_vline(xintercept = 10.5, linetype=2, show.legend=FALSE)+ scale_x_discrete(limits=c('dlfq', 'maxlfq', 
                                                                                           'top3', 
                                                                                           'top1',
                                                                                           'MCP'
                                                                                           
)) + geom_text(aes(y=l_y, label=label)) +
  theme(axis.title.y = element_blank())+ theme(axis.line.y = element_blank())+ coord_flip()

sheet = 'Fig.2f_baplot'
addWorksheet(wb_all, sheet)
writeData(wb_all, sheet, count_TPs, startRow = 2, startCol = 2)

saveWorkbook(wb_all, paste0(save_fold, "fig_2f.xlsx"), overwrite = TRUE)
